using Newtonsoft.Json.Linq;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static LoanAccountDisbursementSvanidhi.Entities.GeneralRequest;
using static LoanAccountDisbursementSvanidhi.Entities.SIDBIResponse;

namespace LoanAccountDisbursementSvanidhi.DataLayer
{
    
    public static class DataLayer
    {
        public static Logger _Logger = LogManager.GetLogger("DisburshmentAndOtherServicesLogger");

        static string connectionString = ConfigurationManager.ConnectionStrings["PMSvanidhiContext"].ConnectionString;
        public static List<EligibleDataForSchedular> GetEligibleCustomerJourney()
        {
            List<EligibleDataForSchedular> journeyDetails = new List<EligibleDataForSchedular>();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    //string query = @"SELECT top(50) (Select top(1) KeyValue from SVND_CONFIGURATION_DATA (nolock) where KeyName='ROI' ) ROI_Disbursement, C.E_MAIL as BranchEmail,A.[JourneyID],UPPER(A.[PMSNumber]) as PMSNumber,[AadhaarNo],A.[CustomerID],[CustomerName],A.[MobileNo],[JourneyMilestone],
                    //                     [JourneyMilestoneDesc],A.[LoanTranche],[LoanAmount],[LoanTenure],CAST(JourneySanctionedDate AS DATE) JourneySanctionedDate,LoanAmount,[LoanAccountNumber]
                    //                     ,CAST(LoanAccountOpenDate AS DATE) LoanAccountOpenDate,isLoanAccountOpened,isSIDBIDisbursementMark,isSRMCreated,isLoanDisbursed,isQRPushCode,A.isSMSSent,isMailSent
                    //                     ,B.solid,B.AccountNo,C.BRANCH,C.IFSC,D.Verification_DigitalPayment_UPIID AS UPIID,Verification_DigitalPayment_QRCode AS QRCode, D.Verification_AadhaarBankAccount_AccountNo as Verification_AadhaarBankAccount_AccountNo
                    //                     ,E.CommAddress_Address1,E.CommAddress_Address2,E.CommAddress_City,E.CommAddress_State,E.CommAddress_PINCode,E.Email_ID,E.Date_of_Birth,
                    //                     F.Signed_NeSL_Doc_Byte AS Signed_NeSL_Doc_Byte, F.Signed_NeSL_Bank_Doc_Byte as Signed_NeSL_Bank_Doc_Byte
                    //                     FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                    //                     INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.AadhaarNumber=A.AadhaarNo
                    //                     INNER JOIN SVND_BRANCH_MASTER C ON C.BRANCH_CODE=B.solid
                    //                     INNER JOIN SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA D ON D.App_PortalRefNo=A.PMSNumber
                    //                     INNER JOIN SVND_CBS_CUSTOMER_DETAILS E ON E.CustomerID=A.CustomerID
                    //                     INNER JOIN SVND_NESL_DOCUMENT F ON F.PMSNumber=A.PMSNumber AND F.JourneyID=A.JourneyID
                    //                     WHERE isCustomerJourneyCompleted=1 and isLoanAccountOpened=1 and isSchedularJourneyCompleted=0
                    //                     and F.Signed_NeSL_Bank_Doc_Byte is not null  and LoanAccountNumber is not null
                    //                     order by LoanAccountOpenDate asc";

                    SqlCommand command = new SqlCommand("proc_GetEligibleLoans", connection);

                   // SqlCommand command = new SqlCommand(query, connection);

                    //command.CommandTimeout = 180;
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            EligibleDataForSchedular journeyDetail = new EligibleDataForSchedular
                            {
                                JourneyID = Convert.ToString(reader["JourneyID"]),
                                PMSNumber = Convert.ToString(reader["PMSNumber"]),
                                AadhaarNo = Convert.ToString(reader["AadhaarNo"]),
                                CustomerID = Convert.ToString(reader["CustomerID"]),
                                CustomerName = Convert.ToString(reader["CustomerName"]),
                                MobileNo = Convert.ToString(reader["MobileNo"]),
                                JourneyMilestone = Convert.ToString(reader["JourneyMilestone"]),
                                JourneyMilestoneDesc = Convert.ToString(reader["JourneyMilestoneDesc"]),
                                LoanTranche = Convert.ToString(reader["LoanTranche"]),
                                LoanAmount = Convert.ToString(reader["LoanAmount"]),
                                LoanTenure = Convert.ToString(reader["LoanTenure"]),
                                JourneySanctionedDate = Convert.ToDateTime(reader["JourneySanctionedDate"]),
                                LoanAccountNumber = Convert.ToString(reader["LoanAccountNumber"]),
                                LoanAccountOpenDate = Convert.ToString(reader["LoanAccountOpenDate"]),
                                isLoanAccountOpened = Convert.ToBoolean(reader["isLoanAccountOpened"]),
                                IsSIDBIDisbursementMark = Convert.ToBoolean(reader["isSIDBIDisbursementMark"]),
                                IsSRMCreated = Convert.ToBoolean(reader["IsSRMCreated"]),
                                IsLoanDisbursed = Convert.ToBoolean(reader["isLoanDisbursed"]),
                                IsQRPushCode = Convert.ToBoolean(reader["isQRPushCode"]),
                                IsSMSSent = Convert.ToBoolean(reader["isSMSSent"]),
                                IsMailSent = Convert.ToBoolean(reader["isMailSent"]),
                                Solid = Convert.ToString(reader["solid"]),
                                AccountNo = Convert.ToString(reader["AccountNo"]),
                                Verification_AadhaarBankAccount_AccountNo = Convert.ToString(reader["Verification_AadhaarBankAccount_AccountNo"]),
                                BRANCH = Convert.ToString(reader["BRANCH"]),
                                IFSC = Convert.ToString(reader["IFSC"]),
                                UPIID = Convert.ToString(reader["UPIID"]),
                                QRCode = Convert.ToString(reader["QRCode"]),
                                CommAddress_Address1 = Convert.ToString(reader["CommAddress_Address1"]),
                                CommAddress_Address2 = Convert.ToString(reader["CommAddress_Address2"]),
                                CommAddress_City = Convert.ToString(reader["CommAddress_City"]),
                                CommAddress_State = Convert.ToString(reader["CommAddress_State"]),
                                CommAddress_PINCode = Convert.ToString(reader["CommAddress_PINCode"]),
                                Email_ID = Convert.ToString(reader["Email_ID"]),
                                Date_of_Birth = Convert.ToString(reader["Date_of_Birth"]),
                                SignedDoc = (byte[])reader["Signed_NeSL_Doc_Byte"],
                                BranchEmail=reader["BranchEmail"].ToString(),
                                BankSignedDoc= (byte[])reader["Signed_NeSL_Bank_Doc_Byte"],
                                ROI_Disbursement = reader["ROI_Disbursement"].ToString()
                            };
                            journeyDetails.Add(journeyDetail);
                        }
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return journeyDetails;
        }
        //reader["CustomerName"] != DBNull.Value ? Convert.ToString(reader["CustomerName"]) : string.Empty,
        public static bool UpdateSRMResponse(string PMSNumber, string JourneyID, string Status, string ColNum)
        {
            bool isUpdated = false;

            // SQL query to update the data
            string query = @"UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isSRMCreated = @Status, SRMCreationTime=@StatusUpdateDate,SRMCreationRemarks=@Remarks
                             WHERE [JourneyID] = @JourneyID AND PMSNumber=@PMSNumber";

            // Open a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //try
                //{
                    connection.Open();

                    // Create the SQL command and pass in the query and connection
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to prevent SQL injection
                        command.Parameters.AddWithValue("@PMSNumber", PMSNumber);
                        command.Parameters.AddWithValue("@JourneyID", JourneyID);
                        command.Parameters.AddWithValue("@Status", (Status == "Y" || Status == "Success") ? true : false);
                        command.Parameters.AddWithValue("@StatusUpdateDate", DateTime.Now);
                        command.Parameters.AddWithValue("@Remarks", ColNum);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            connection.Close();
                            isUpdated = true;
                        }
                    }
                //}
                //catch (Exception ex)
                //{                
                //    Console.WriteLine("Error: " + ex.ToString());
                //}
            }

            return isUpdated;
        }

        public static bool UpdateDisbursementResponse(string PMSNumber, string JourneyID, string Status, string Remarks)
        {
            bool isUpdated = false;

            // SQL query to update the data
            string query = @"UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isLoanDisbursed = @isLoanDisbursed, LoanDisbursedTime=@StatusUpdateDate,LoanDisbursedRemarks=@Remarks
                            WHERE [JourneyID] = @JourneyID AND PMSNumber=@PMSNumber";

            // Open a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //try
                //{
                    connection.Open();

                    // Create the SQL command and pass in the query and connection
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to prevent SQL injection
                        command.Parameters.AddWithValue("@PMSNumber", PMSNumber);
                        command.Parameters.AddWithValue("@JourneyID", JourneyID);
                        command.Parameters.AddWithValue("@isLoanDisbursed", (Status == "Y" || Status == "Success") ? "1" : "0");
                        command.Parameters.AddWithValue("@Status", (Status == "Y" || Status == "Success") ? true : false);
                        command.Parameters.AddWithValue("@StatusUpdateDate", DateTime.Now);
                        command.Parameters.AddWithValue("@Remarks", Remarks);
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            isUpdated = true;
                        }
                        connection.Close();
                    }
                //}
                //catch (Exception ex)
                //{  
                //    Console.WriteLine("Error: " + ex.Message);
                //}
            }

            return isUpdated;
        }


        public static bool UpdateGeneralResponse(string PMSNumber, string JourneyID, string StatusFlag, string Message, string OperationType)
        {
            bool isUpdated = false;
            string query = "";
            // SQL query to update the data

            try
            {
                if (!String.IsNullOrEmpty(OperationType))
                {
                    if (OperationType == "SIDBIStatus")
                    {
                        query = @"UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET CurrentStatus='Disbursed',isSIDBIDisbursementMark = @Status, SIDBIDisbursementMarkTime=@StatusUpdateDate,SIDBIDisbursementMarkMessage=@Message
                                WHERE [JourneyID] = @JourneyID AND PMSNumber=@PMSNumber";                      
                    }
                    else if (OperationType == "QRPushCode")
                    {
                        query = @"UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isQRPushCode = @Status, QRPushCodeTime=@StatusUpdateDate,QRPushCodeRemarks=@Message
                                WHERE [JourneyID] = @JourneyID AND PMSNumber=@PMSNumber";
                    }
                    else if (OperationType == "SMSSent")
                    {
                        query = @"UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isSMSSent = @Status, SMSSentTime=@StatusUpdateDate,SMSSentRemarks=@Message
                                WHERE [JourneyID] = @JourneyID AND PMSNumber=@PMSNumber";
                    }
                    else if (OperationType == "EmailSent")
                    {
                        query = @"UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isMailSent = @Status, MailSentTime=@StatusUpdateDate,MailSentRemarks=@Message
                                WHERE [JourneyID] = @JourneyID AND PMSNumber=@PMSNumber";
                    }
                    else if (OperationType == "SchedularJourney")
                    {
                        query = @"UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isSchedularJourneyCompleted =1, SchedulerJourneyCompletedTime=@StatusUpdateDate
                                WHERE [JourneyID] = @JourneyID AND PMSNumber=@PMSNumber";
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        // Create the SQL command and pass in the query and connection
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Add parameters to prevent SQL injection
                            command.Parameters.AddWithValue("@PMSNumber", PMSNumber);
                            command.Parameters.AddWithValue("@JourneyID", JourneyID);
                            command.Parameters.AddWithValue("@Status", (StatusFlag == "Y" || StatusFlag == "Success") ? true : false);
                            command.Parameters.AddWithValue("@StatusUpdateDate", DateTime.Now);
                            command.Parameters.AddWithValue("@Message", Message);

                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {

                                isUpdated = true;
                            }
                            connection.Close();
                        }
                    }
                }
                // Open a connection to the database
            }
            catch (Exception ex)
            {
                throw ex;
            }



            return isUpdated;
        }


        public static string isVFirstTokenValid()
        {
            string Token = "";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proc_VFirstToken_IsValid", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Output parameter
                    var outputParam = new SqlParameter("@p_Output", SqlDbType.VarChar, 1000)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(outputParam);

                    connection.Open();
                    command.ExecuteNonQuery();

                    // Retrieve the output parameter value
                    if (!String.IsNullOrEmpty(Convert.ToString(outputParam.Value)))
                    {
                        Token = Convert.ToString(outputParam.Value).Split(':')[1];
                    }

                }
            }

            return Token;
        }

        public static long insertVFirstToken(string token, string expiry)
        {
            Int32 RowUpdatedCount = 0;

            using (SqlConnection conn2 = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO SVND_VALUEFIRST_TOKENS([token],[expiry],[generation_date]) VALUES (@token,@expiry,@generation_date)";
                using (SqlCommand cmd2 = new SqlCommand(query, conn2))
                {
                    cmd2.Parameters.AddWithValue("@token", token);
                    cmd2.Parameters.AddWithValue("@expiry", expiry);
                    cmd2.Parameters.AddWithValue("@generation_date", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
                    conn2.Open();
                    int rowsAffected = cmd2.ExecuteNonQuery();
                    conn2.Close();
                    if (rowsAffected > 0)
                    {
                        RowUpdatedCount = rowsAffected;
                    }
                    else
                    {
                        RowUpdatedCount = 0;
                    }
                }
            }

            return RowUpdatedCount;
        }


        public static string APIRequestResponseLogs(string PMSNumber, string JourneyID, string PlainReq, string EncReq, string EncResp, string PlainResp, string Operation, string APIName, string RequestID)
        {
            string requestID = ""; // To store the generated ID         
            try
            {
                string query = "";
                using (SqlConnection conn2 = new SqlConnection(connectionString))
                {
                    if (Operation == "Insert")
                    {
                        query = @"INSERT INTO SVND_ALL_API_REQUEST_RESPONSE_TRACKING ([PMSNumber],[JourneyID],[PlainRequest],[EncRequest],[APIName],[RequestTime]) 
		                            VALUES (@PMSNumber,@JourneyID,@PlainRequest,@EncRequest,@APIName,@Time);
                                SELECT CAST(SCOPE_IDENTITY() AS INT);"; // Get the newly generated ID
                    }
                    else if (Operation == "Update" && !String.IsNullOrEmpty(RequestID))
                    {
                        query = @"UPDATE SVND_ALL_API_REQUEST_RESPONSE_TRACKING SET PlainResponse=@PlainResponse,EncResponse=@EncResponse,ResponseTime=@Time
		                        WHERE [PMSNumber]=@PMSNumber AND RequestId=@RequestId AND JourneyID=@JourneyID;
                                SELECT CAST(SCOPE_IDENTITY() AS INT);"; // Get the newly generated ID
                    }
                    using (SqlCommand cmd2 = new SqlCommand(query, conn2))
                    {
                        cmd2.Parameters.AddWithValue("@PMSNumber", PMSNumber);
                        cmd2.Parameters.AddWithValue("@JourneyID", JourneyID);
                        if (Operation == "Insert")
                        {
                            cmd2.Parameters.AddWithValue("@PlainRequest", PlainReq);
                            cmd2.Parameters.AddWithValue("@EncRequest", !String.IsNullOrEmpty(EncReq) ? EncReq : PlainReq);
                        }
                        else if (Operation == "Update")
                        {
                            cmd2.Parameters.AddWithValue("@PlainResponse", PlainResp);
                            cmd2.Parameters.AddWithValue("@EncResponse", !String.IsNullOrEmpty(EncResp) ? EncResp : PlainResp);
                            cmd2.Parameters.AddWithValue("@RequestId", RequestID);
                        }
                        cmd2.Parameters.AddWithValue("@APIName", APIName);
                        cmd2.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));

                        conn2.Open();

                        if (Operation == "Insert")
                        {
                            // Execute the query and retrieve the generated ID
                            requestID = Convert.ToString(cmd2.ExecuteScalar());
                        }
                        if (Operation == "Update")
                        {

                            cmd2.ExecuteScalar();
                            requestID = RequestID;
                        }
                        conn2.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return requestID;
        }
        /// <summary>
        /// Called by the scheduler when creating the SMS download link.
        /// Inserts a new record with token, file path, 30-day expiry, and max 3 clicks.
        /// </summary>
        public static bool InsertDocumentDownloadLink(string pmsNumber, string journeyId, string token, string filePath, DateTime expiryDate, int maxClicks)
        {
            bool isInserted = false;
            try
            {
                string query = @"INSERT INTO [dbo].[SVND_SMS_DOCUMENT_LINKS]
                                    (PMSNumber, JourneyID, Token, FilePath, CreatedDate, ExpiryDate, ClickCount, MaxClicks, IsActive)
                                 VALUES
                                    (@PMSNumber, @JourneyID, @Token, @FilePath, GETDATE(), @ExpiryDate, 0, @MaxClicks, 1)";

                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@PMSNumber", pmsNumber);
                    cmd.Parameters.AddWithValue("@JourneyID", journeyId);
                    cmd.Parameters.AddWithValue("@Token",     token);
                    cmd.Parameters.AddWithValue("@FilePath",  filePath);
                    cmd.Parameters.AddWithValue("@ExpiryDate", expiryDate);
                    cmd.Parameters.AddWithValue("@MaxClicks",  maxClicks);
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    isInserted = rows > 0;
                }
            }
            catch (Exception ex)
            {
                _Logger.Info("InsertDocumentDownloadLink Exception: " + ex.ToString());
            }
            return isInserted;
        }

        /// <summary>
        /// Called by DownloadDoc.ashx on EVERY click of the SMS link.
        /// Returns the file path if the token is valid (not expired, under click limit).
        /// Returns empty string if expired or limit reached — caller must show error.
        /// Also atomically increments ClickCount so concurrent clicks are handled safely.
        /// </summary>
        public static string ValidateAndIncrementDownloadLink(string token)
        {
            string filePath = string.Empty;
            try
            {
                // Single atomic query: check validity AND increment in one round-trip
                string query = @"
                    UPDATE [dbo].[SVND_SMS_DOCUMENT_LINKS]
                    SET    ClickCount = ClickCount + 1
                    OUTPUT INSERTED.FilePath,
                           INSERTED.ExpiryDate,
                           INSERTED.ClickCount,
                           INSERTED.MaxClicks,
                           INSERTED.IsActive
                    WHERE  Token      = @Token
                      AND  IsActive   = 1
                      AND  ExpiryDate >= GETDATE()
                      AND  ClickCount  < MaxClicks";

                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Token", token);
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Row updated — link is valid
                            filePath = reader["FilePath"].ToString();
                        }
                        // If no row returned: token not found, expired, or click limit reached
                    }
                }
            }
            catch (Exception ex)
            {
                _Logger.Info("ValidateAndIncrementDownloadLink Exception: " + ex.ToString());
            }
            return filePath;
        }
    }
}
