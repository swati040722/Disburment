﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAccountDisbursementSvanidhi.Entities
{
    public static class GeneralRequest
    {
        public class EligibleDataForSchedular
        {
            public string JourneyID { get; set; }
            public string PMSNumber { get; set; }
            public string AadhaarNo { get; set; }
            public string CustomerID { get; set; }
            public string CustomerName { get; set; }
            public string MobileNo { get; set; }
            public string JourneyMilestone { get; set; }
            public string JourneyMilestoneDesc { get; set; }
            public string LoanTranche { get; set; }
            public string LoanAmount { get; set; }
            public string LoanTenure { get; set; }
            public DateTime? JourneySanctionedDate { get; set; }
            public string LoanAccountNumber { get; set; }
            public string LoanAccountOpenDate { get; set; }

            public bool isLoanAccountOpened { get; set; }
            public bool IsSIDBIDisbursementMark { get; set; }
            public bool IsSRMCreated { get; set; }
            public bool IsLoanDisbursed { get; set; }
            public bool IsQRPushCode { get; set; }
            public bool IsSMSSent { get; set; }
            public bool IsMailSent { get; set; }
            public string Solid { get; set; }
            public string AccountNo { get; set; }
            public string Verification_AadhaarBankAccount_AccountNo { get; set; }
            public string BRANCH { get; set; }
            public string BranchEmail { get; set; }
            public string IFSC { get; set; }

            public string UPIID { get; set; }
            public string QRCode { get; set; }

            public string CommAddress_Address1 { get; set; }

            public string CommAddress_Address2 { get; set; }
            public string CommAddress_City { get; set; }

            public string CommAddress_State { get; set; }
            public string CommAddress_PINCode { get; set; }
            public string Email_ID { get; set; }

            public string Date_of_Birth { get; set; }

            public byte[] SignedDoc { get; set; }
            public byte[] BankSignedDoc { get; set; }

            public string ROI_Disbursement { get; set; }

        }




        public class Header
        {
            public string apiVersion { get; set; }
            public string clientID { get; set; }
            public long timeStamp { get; set; }
        }

        public class Request
        {
            public Application[] applications { get; set; }
            public string rejectionReasonTypeCode { get; set; }
            public string otherReason { get; set; }
        }
        public class Application
        {
            public string application_No { get; set; }
            public string portal_RefNo { get; set; }
            public string loan_Account_No { get; set; }
            public string bankName { get; set; }
            public string branchName { get; set; }
            public string ifsc { get; set; }
            public string accountNo { get; set; }
            public string paymentAggregatorCode { get; set; }
            public string upiid { get; set; }
            public string dP1QRCode { get; set; }
            public string sanctionDate { get; set; }
            public string sanctionAmount { get; set; }
            public string disbursementDate { get; set; }
            public string disbursementAmt { get; set; }
            public string loan_Tenure { get; set; }
            public string interestRate { get; set; }
            public string IsDisbursedRequest { get; set; }
            public string SanctioningBranchIFSC { get; set; }

        }
    }
}
