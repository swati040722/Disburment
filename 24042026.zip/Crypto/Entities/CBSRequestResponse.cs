﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAccountDisbursementSvanidhi.Entities
{
    public static class CBSRequestResponse
    {

        public class Token
        {
            public string access_token { get; set; }
            public string token_type { get; set; }
            public int expires_in { get; set; }
        }

        public class EncRequest
        {
            public string EncReqData { get; set; }
        }
        public class EncResponse
        {
            public string EncRespData { get; set; }
        }
        public class PlainRequest
        {
            public string OperationName { get; set; }

            public string RequestData { get; set; }
        }
        public class SRMCreationRequest
        {
            public string AcctNo { get; set; }
            public string CollCode { get; set; }
            public string CollVal { get; set; }
            public string Margin { get; set; }
            public string SecurityName { get; set; }
        }

        public class SRMCreationResponse
        {
            public string Status { get; set; }
            public string ResponseData { get; set; }  // This is a stringified JSON

            public ResponseDataObj ResponseDataObj { get; set; }  // This is a stringified JSON

        }

        public class LoanDisbursementRequest
        {
            public string CrAcct { get; set; }
            public string LoanAcct { get; set; }
            public string LoanAmt { get; set; }
            public string LoanPeriod { get; set; }
            public string SolId { get; set; }
        }
        public class LoanDisbursementResponse
        {
            public string Status { get; set; }
            public string ResponseData { get; set; }  // This is a stringified JSON
            public ResponseDataObj ResponseDataObj { get; set; }
        }

        public class QRPushCodeRequest
        {
            public string AccountNumber { get; set; }
            public string MerchantName { get; set; }
            public string Mobile { get; set; }
            public string DOB { get; set; }
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public string Address3 { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string PIN { get; set; }
            public string SolId { get; set; }
            public string EmailId { get; set; }
        }
        public class QRPushCodeResponse
        {
            public string Status { get; set; }
            public string ResponseData { get; set; }  // This is a stringified JSON
            public ResponseDataObj ResponseDataObj { get; set; }
        }

        public class ResponseDataObj
        {
            public string ColNum { get; set; }

            public string Remarks { get; set; }

            public string Status { get; set; }

            public string Message { get; set; }
        }
    }
}
