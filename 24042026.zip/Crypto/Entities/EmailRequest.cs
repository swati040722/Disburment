﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LoanAccountDisbursementSvanidhi.Entities
{

    public static class EmailRequest
    {
        public class Content
        {
            public string type { get; set; }
            public string value { get; set; }
        }

        public class From
        {
            public string name { get; set; }
            public string emailid { get; set; }
        }

        public class PersonalizationData
        {
            [JsonProperty(":app_id")]
            public string app_id { get; set; }
        }

        public class Recipient
        {
            public PersonalizationData personalization_data { get; set; }
            public List<To> to { get; set; }
           
            public List<Cc> cc { get; set; }
        }

        public class Root
        {
            public string mailtype { get; set; }
            public List<Recipient> recipients { get; set; }
            public string subject { get; set; }
            public From from { get; set; }
            public List<Content> content { get; set; }
            public List<Attachment> attachments { get; set; }  // Add the attachments property
        }

        public class To
        {
            public string name { get; set; }
            public string emailid { get; set; }
        }
        // Added Cc class (matches the To class structure)
        public class Cc
        {
            public string name { get; set; }
            public string emailid { get; set; }
        }
        public class Attachment
        {
            public string disposition { get; set; }
            public string filename { get; set; }
            public string content_id { get; set; }
            public string type { get; set; }
            public string content { get; set; }
        }
    }   
}