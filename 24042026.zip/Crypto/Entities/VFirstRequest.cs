﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAccountDisbursementSvanidhi.Entities
{
    public static class VFirstRequest
    {
        public class SMSData
        {
            public string PMSNumber { get; set; }
            public string MobileNo { get; set; }
        }
        public class SMSRequest
        {
            public string ver { get; set; }
            public string key { get; set; }
            public string encrpt { get; set; }
            public List<Message> messages { get; set; }
        }

        public class Message
        {
            public List<string> dest { get; set; }
            public string text { get; set; }
            public string send { get; set; }
        }



        public class VLRequest
        {
            [JsonProperty(PropertyName = "@VER")]
            public string VER
            {
                get
                {
                    return "1.2";
                }
            }
            public USER USER { get; set; }
            public DLR DLR { get; set; }
            public List<SM> SMS { get; set; }
        }

        public class VFirstTokenGenerationResponse
        {
            public string token { get; set; }
            public string expiryDate { get; set; }
        }
        public class VFirstTokenEnableResponse
        {
            public string Response { get; set; }
        }
        public class USER
        {
        }

        public class DLR
        {
            [JsonProperty(PropertyName = "@URL")]
            public string URL
            {
                get
                {
                    return "";
                }
            }
        }

        public class SM
        {
            [JsonProperty(PropertyName = "@UDH")]
            public string UDH
            {
                get
                {
                    return "0";
                }
            }
            [JsonProperty(PropertyName = "@CODING")]
            public string CODING
            {
                get
                {
                    return "1";
                }
            }
            [JsonProperty(PropertyName = "@TEXT")]
            public string TEXT { get; set; }
            [JsonProperty(PropertyName = "@PROPERTY")]
            public string PROPERTY { get { return "0"; } }
            [JsonProperty(PropertyName = "@ID")]
            public string ID
            {
                get
                {
                    return "1";
                }
            }
            public List<ADDRESS> ADDRESS { get; set; }
        }

        public class ADDRESS
        {
            [JsonProperty(PropertyName = "@FROM")]
            public string FROM
            {
                get
                {
                    return "PNBSMS";
                }
            }
            [JsonProperty(PropertyName = "@TO")]
            public string TO { get; set; }
            [JsonProperty(PropertyName = "@SEQ")]
            public string SEQ
            {
                get
                {
                    return "1";
                }
            }
            [JsonProperty(PropertyName = "@TAG")]
            public string TAG
            {
                get
                {
                    return "";
                }
            }
        }
    }
}
