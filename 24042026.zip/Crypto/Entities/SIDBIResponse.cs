﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAccountDisbursementSvanidhi.Entities
{
    public class SIDBIResponse
    {
        public class ApiResponse
        {
            public Header header { get; set; }
            public Response response { get; set; }
            public Status status { get; set; }
        }
    
        public class ApplicationDetails
        {
            public string portal_RefNo { get; set; }
            public string application_No { get; set; }
        }

        public class ApplicationStatus
        {
            public object statusMsg { get; set; }
            public string statusCode { get; set; }
        }

        public class ErrorDetails
        {
            public string BranchName { get; set; }
            public int ErrorCode { get; set; }
            public string PaymentAggregatorCode { get; set; }
            public string DP1QRCode { get; set; }
        }
         
      




        public class Root
        {
            public Header header { get; set; }
            public Response response { get; set; }
            public Status status { get; set; }
        }

        public class Header
        {
            public string apiversion { get; set; }
            public string clientID { get; set; }
            public string timeStamp { get; set; }
            public object hCheckValue { get; set; }
        }

        public class Response
        {
            public int recordCount { get; set; }
            public Application[] applications { get; set; }
        }

        public class Application
        {
            public Application_Status application_Status { get; set; }
            public Application_Details application_Details { get; set; }
            public Error_Details error_Details { get; set; }
        }

        public class Application_Status
        {
            public object statusMsg { get; set; }
            public string statusCode { get; set; }
        }

        public class Application_Details
        {
            public string portal_RefNo { get; set; }
            public string application_No { get; set; }
        }

        public class Error_Details
        {
            public string ErrorMessage { get; set; }
            public int ErrorCode { get; set; }
        }

        public class Status
        {
            public bool isSuccess { get; set; }
            public object message { get; set; }
            public object statusCode { get; set; }
        }



    }
}
