-- =============================================
-- Table: SVND_SMS_DOCUMENT_LINKS
-- Purpose: Tracks secure one-time download links sent via SMS
--          Each row = one customer's loan document link
--          Link expires after 30 days OR 3 clicks, whichever comes first
-- =============================================

CREATE TABLE [dbo].[SVND_SMS_DOCUMENT_LINKS]
(
    [Id]          INT            IDENTITY(1,1) PRIMARY KEY,
    [PMSNumber]   NVARCHAR(50)   NOT NULL,           -- Customer PMS number
    [JourneyID]   NVARCHAR(50)   NOT NULL,           -- Journey reference
    [Token]       NVARCHAR(100)  NOT NULL UNIQUE,    -- GUID token embedded in SMS link
    [FilePath]    NVARCHAR(500)  NOT NULL,           -- Full path: D:\SMSDocStore\<token>.pdf
    [CreatedDate] DATETIME       NOT NULL DEFAULT GETDATE(),
    [ExpiryDate]  DATETIME       NOT NULL,           -- CreatedDate + 30 days
    [ClickCount]  INT            NOT NULL DEFAULT 0, -- How many times customer clicked
    [MaxClicks]   INT            NOT NULL DEFAULT 3, -- Maximum allowed clicks
    [IsActive]    BIT            NOT NULL DEFAULT 1  -- 0 = manually deactivated
);

GO

-- Index for fast token lookup on every download click
CREATE UNIQUE INDEX IX_SVND_SMS_DOC_LINKS_Token
    ON [dbo].[SVND_SMS_DOCUMENT_LINKS] ([Token]);

GO
