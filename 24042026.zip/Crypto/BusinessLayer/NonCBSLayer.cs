using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text;
using NLog;
using System.Configuration;
using static LoanAccountDisbursementSvanidhi.Entities.VFirstRequest;
using LoanAccountDisbursementSvanidhi.Entities;
using static LoanAccountDisbursementSvanidhi.Entities.EmailRequest;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net.Mail;
using System.Net.Mime;

namespace LoanAccountDisbursementSvanidhi.BusinessLayer
{
    public static class NonCBSLayer
    {
        public static Logger _logger = LogManager.GetLogger("DisburshmentAndOtherServicesLogger");

        static string VFirstUSERID = ConfigurationManager.AppSettings["VFirstUSERID"];
        static string VFirstPassword = ConfigurationManager.AppSettings["VFirstPassword"];
        static string VFIRST_TOKEN_GENERATE_URL = ConfigurationManager.AppSettings["VFIRST_TOKEN_GENERATE_URL"];
        static string VFirstSMSAPI = ConfigurationManager.AppSettings["VFirstSMSAPI"];


        static string EMAIL_API_USERID = ConfigurationManager.AppSettings["EMAIL_API_USERID"];
        static string EMAIL_API_PASSWORD = ConfigurationManager.AppSettings["EMAIL_API_PASSWORD"];
        static string EMAIL_API_URL = ConfigurationManager.AppSettings["EMAIL_API_URL"];
        static string EMAIL_API_SENDER = ConfigurationManager.AppSettings["EMAIL_API_SENDER"];


        static string filePath = ConfigurationManager.AppSettings["filePath"];

        public static SIDBIResponse.Root CallSidbiDisbursementStatusAPI(string request)
        {
            Console.WriteLine("Inside CallSidbiDisbursementStatusAPI");
            _logger.Info("Inside CallSidbiDisbursementStatusAPI");
            SIDBIResponse.Root sidbiResponse = null;
            //try
            //{
            string API_URL = ConfigurationManager.AppSettings["SIDBI_API_URL"];
            _logger.Info("SIDBI Disbursement API URL: " + API_URL);
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;


            string url = string.Format(API_URL, request);
            HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);

            // Set the request content with the correct content type
            message.Content = new StringContent(request, Encoding.UTF8, "application/json");
            using (HttpClient client = new HttpClient())
            {
                var responsedata = client.SendAsync(message).Result;
                if (responsedata.IsSuccessStatusCode)
                {
                    var data = responsedata.Content.ReadAsStringAsync().Result;
                    _logger.Info($"data {data}");
                    if (!string.IsNullOrEmpty(data))
                    {
                        sidbiResponse = JsonConvert.DeserializeObject<SIDBIResponse.Root>(data);
                        _logger.Info($"sidbiResponse {sidbiResponse}");
                    }
                }
                else
                {
                    _logger.Info("Else Error: Plain Response Data " + responsedata.ReasonPhrase);
                    Console.WriteLine("Else Error: Plain Response Data " + responsedata.ReasonPhrase);
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            return sidbiResponse;
        }
        public static string SendOTPVfirst(string PMSNumber, string JourneyID, string mobile, string txtmessage)
        {
            _logger.Info("SendOTPVfirst called for Mobile No " + mobile);
            _logger.Info("SendOTPVfirst called for message " + txtmessage);
            string message = "";
            //try
            //{

            string Token = DataLayer.DataLayer.isVFirstTokenValid();

            if (!String.IsNullOrEmpty(Token))
            {
                _logger.Info("if Valid Token: " + Token);

                message = sendSMS(PMSNumber, JourneyID, mobile, txtmessage, Token);

                _logger.Info("is SMS Sent Status: " + message);
            }
            else
            {
                _logger.Info("value first token is invalid, call token generate API");
                string tokenExpiry = String.Empty;
                string token = GenerateVfirstToken(ref tokenExpiry);
                _logger.Info("generated token:" + token);
                _logger.Info("tokenExpiry:" + tokenExpiry);
                if (!String.IsNullOrEmpty(token))
                {
                    long resultTokenInsert = DataLayer.DataLayer.insertVFirstToken(token, tokenExpiry);
                    if (resultTokenInsert > 0)
                    {
                        _logger.Info("token insertion result:" + resultTokenInsert);

                        message = sendSMS(PMSNumber, JourneyID, mobile, txtmessage, token);

                        _logger.Info("is SMS Sent Status: " + message);
                    }
                    else
                    {
                        _logger.Info("Error While Token Insert in Database");
                    }
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    _logger.Error("While SendOTPVfirst: " + ex.ToString());
            //}
            return message;
        }

        //Sent document via sms
        public static string SendDocumentVfirst(string PMSNumber, string JourneyID, string mobile, string txtmessage)
        {
            _logger.Info("SendOTPVfirst called for Mobile No " + mobile);
            _logger.Info("SendOTPVfirst called for message " + txtmessage);
            string message = "";
            //try
            //{

            string Token = DataLayer.DataLayer.isVFirstTokenValid();

            if (!String.IsNullOrEmpty(Token))
            {
                _logger.Info("if Valid Token: " + Token);

                message = sendSMS(PMSNumber, JourneyID, mobile, txtmessage, Token);

                _logger.Info("is SMS Sent Status: " + message);
            }
            else
            {
                _logger.Info("value first token is invalid, call token generate API");
                string tokenExpiry = String.Empty;
                string token = GenerateVfirstToken(ref tokenExpiry);
                _logger.Info("generated token:" + token);
                _logger.Info("tokenExpiry:" + tokenExpiry);
                if (!String.IsNullOrEmpty(token))
                {
                    long resultTokenInsert = DataLayer.DataLayer.insertVFirstToken(token, tokenExpiry);
                    if (resultTokenInsert > 0)
                    {
                        _logger.Info("token insertion result:" + resultTokenInsert);

                        message = sendSMS(PMSNumber, JourneyID, mobile, txtmessage, token);

                        _logger.Info("is SMS Sent Status: " + message);
                    }
                    else
                    {
                        _logger.Info("Error While Token Insert in Database");
                    }
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    _logger.Error("While SendOTPVfirst: " + ex.ToString());
            //}
            return message;
        }








        private static HttpClient GetClient()
        {
            //First create a proxy object
            var proxy = new WebProxy
            {
                Address = new Uri(@"http://10.161.75.29:3128"),
                BypassProxyOnLocal = false,
                UseDefaultCredentials = false,
                // *** These creds are given to the proxy server, not the web server ***
                Credentials = new NetworkCredential(
                     userName: "5216750",
                     password: "Welcome@54321")
            };
            //// Now create a client handler which uses that proxy
            var httpClientHandler = new HttpClientHandler
            {
                Proxy = proxy,
            };
            return new HttpClient(httpClientHandler);
        }

        public static string GenerateVfirstToken(ref string tokenExpiry)
        {
            _logger.Info("GenerateVfirstToken called");
            string token = String.Empty;
            System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)(768 | 3072);
            //try
            //{
            string username = VFirstUSERID;
            _logger.Info("username:" + username);
            string password = VFirstPassword;
            _logger.Info("password:" + password);
            string url = VFIRST_TOKEN_GENERATE_URL;
            _logger.Info("url:" + url);
            HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(username + ":" + password);
            var authHeader = "Basic " + Convert.ToBase64String(plainTextBytes);
            message.Headers.Add("Authorization", authHeader);

            VFirstTokenGenerationResponse response = new VFirstTokenGenerationResponse();
            //  using (HttpClient client = new HttpClient())
            using (var client = new HttpClient(new HttpClientHandler { UseProxy = false }))
            {
                _logger.Info("client:" + client);

                var responsedata = client.SendAsync(message).Result;
                _logger.Info("Success Resp");
                _logger.Info(responsedata.StatusCode);
                if (responsedata.IsSuccessStatusCode)
                {
                    var data = responsedata.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(data))
                    {
                        response = JsonConvert.DeserializeObject<VFirstTokenGenerationResponse>(data);
                        token = response.token;
                        _logger.Info("token:" + token);
                        tokenExpiry = response.expiryDate;
                        _logger.Info("expiryDate:" + tokenExpiry);

                    }
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    _logger.Error("While GenerateVfirstToken VFirst Token APi Call: " + ex.ToString());
            //}
            return token;
        }

        public static string sendSMS(string PMSNumber, string JourneyID, string mobile, string txtmessage, string Token)
        {
            _logger.Info("value first token is valid");

            System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)(768 | 3072);
            //try
            //{
            _logger.Info("Mobile: " + mobile);
            _logger.Info("Message: " + txtmessage);
            string content = "";
            long mobileno = 0;
            if (string.IsNullOrEmpty(mobile) || !long.TryParse(mobile, out mobileno) || mobile.Length != 10)
            {
                return "Mobile Number should be a valid 10 digit number";
            }
            if (string.IsNullOrEmpty(txtmessage))
            {
                return "Message is required field";
            }
            //string key = ConfigurationManager.AppSettings["VfToken"];
            //string key = DataLayer.getVFirstToken();
            _logger.Info("value first token: " + Token);
            string url = VFirstSMSAPI;
            VLRequest request = new VLRequest()
            {
                SMS = new List<SM>()
                    {
                                new SM(){
                            TEXT = txtmessage,
                            ADDRESS=new List<ADDRESS>(){
                            new ADDRESS(){
                                TO=mobile
                                }
                            }
                        }
                    },
                DLR = new DLR(),
                USER = new USER()
            };
            _logger.Info("URL: " + url);
            _logger.Info("JSON Rqequest: " + JsonConvert.SerializeObject(request));
            Console.WriteLine("JSON Rqequest: " + JsonConvert.SerializeObject(request));

            var RequestID = DataLayer.DataLayer.APIRequestResponseLogs(PMSNumber, JourneyID, JsonConvert.SerializeObject(request), null, null, null, "Insert", "SMSSent", null);
            Console.WriteLine("API Insert Logs Inserted with RequestID: " + RequestID);
            try
            {
                using (var client = new HttpClient(new HttpClientHandler { UseProxy = true }))
                {
                    Console.WriteLine("S111111 " + RequestID);
                    HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);
                    message.Headers.Add("Authorization", "Bearer " + Token);
                    message.Content = new StringContent(JsonConvert.SerializeObject(request), System.Text.Encoding.UTF8, "application/json");
                    Console.WriteLine("S222222 " + RequestID);
                    var response = client.SendAsync(message).Result;
                    Console.WriteLine("S333333 " + response);
                    if (response.IsSuccessStatusCode)
                    {
                        content = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        content = response.Content.ReadAsStringAsync().Result;
                    }
                    var isUpdated = DataLayer.DataLayer.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JsonConvert.SerializeObject(content), "Update", "SMSSent", RequestID);
                    Console.WriteLine("API Logs Updated with RequestID: " + isUpdated);
                }
                _logger.Info("SMS Sent Actual Content: " + content);
                return "Success";
            }
            catch (Exception ex)
            {
                Console.WriteLine("While Send SMS VFirst API Call:" + ex.ToString());
                _logger.Error("While Send SMS VFirst API Call: " + ex.ToString());
                return "Error Sending OTP. Please try Again";

            }
            //}
            //catch (Exception ex)
            //{
            //    _logger.Error("While Send SMS VFirst API Call: " + ex.ToString());
            //    return "Error Sending OTP. Please try Again";
            //}
        }

        public static string SendEmailForSanctionLetter(string PMSNumber, string JourneyID, byte[] SignedByteDoc, string EmailID, string message, string ccEmailId)
        {
            string isEmailSent = "Failure";
            try
            {
                //<{ "mailtype":"TRANS","attachments":[{ "disposition":"attachment","filename":"SanctionLetter_PAPL_978579","content_id":"1","type":"application/pdf","content":"BASE64"}],"recipients":[{ "personalization_data":{ ":app_id":"PAPL/348600/987181"},"to":[{ "name":"MANI RAM","emailid":"MS966928@GMAIL.COM"}]}],"subject":"Loan Sanction Letter","from":{ "name":"PnbInstaLoan","emailid":"pnbinstaloans@punjabnationalbank.in"},"content":[{ "template_id":"fb47cd99a211192377dada62079a161d"}]},[Content - Type:"application/json", Authorization:"Basic X3VzZXI5NTUzMDlhMWI5ZjFlODU4OTozZjBjNjRjZGQzZWM4NWNkZGUxYjg5M2Y5NzdhYjE4Yg=="] >
                //EmailID = "suraj.singh3@pnb.bank.in";
                //ccEmailId = "swati.sharma5@pnb.bank.in";


                if (!String.IsNullOrEmpty(EmailID))
                {

                    // 1. Verify if the file is a valid PDF
                    if (!IsValidPdf(SignedByteDoc))
                    {
                        Console.WriteLine("Invalid PDF file.");
                        return "Failure";
                    }

                    byte[] pdfBytes = SignedByteDoc;
                    pdfBytes = CompressPdfV(SignedByteDoc);
                    _logger.Info($"PDF Size: {pdfBytes.Length} bytes ({pdfBytes.Length / (1024.0 * 1024.0):F2} MB)");

                    //byte[] pdfBytes = File.ReadAllBytes(filePath); // Read the input PDF as byte[]


                    // 2. Convert the byte array to Base64
                    string base64Content = Convert.ToBase64String(pdfBytes);




                    SaveBase64ToFile(SignedByteDoc, filePath);

                    // 3. Prepare email details
                    Root root = new Root();

                    // Set mail type
                    root.mailtype = "TRANS";

                    // Set recipient
                    PersonalizationData personalization = new PersonalizationData() { app_id = PMSNumber };
                    To to = new To() { name = "", emailid = EmailID };
                    Cc cc = new Cc() { name = "", emailid = ccEmailId };

                    List<To> toList = new List<To>();
                    toList.Add(to);
                    List<Cc> CcList = new List<Cc>();
                    CcList.Add(cc);

                    string[] sampleCCEmailList = ConfigurationManager.AppSettings["SAMPLECCEmails"].ToString().Split('|');
                    string isEnabled = sampleCCEmailList[0];
                    for (int i = 1; i < sampleCCEmailList.Length; i++)
                    {
                        if (isEnabled == "1" && !string.IsNullOrEmpty(sampleCCEmailList[i]))
                        {
                            cc = new Cc() { name = "", emailid = sampleCCEmailList[i] };
                            CcList.Add(cc);
                        }
                    }






                    Recipient recipient = new Recipient() { personalization_data = personalization, to = toList, cc = CcList };
                    List<Recipient> recipientsList = new List<Recipient>();
                    recipientsList.Add(recipient);
                    root.recipients = recipientsList;

                    // Set subject
                    root.subject = "e PM Svanidhi";

                    // Set sender
                    From from = new From() { name = "e PM Svanidhi", emailid = string.Format(EMAIL_API_SENDER) };
                    root.from = from;

                    // Set email content (with HTML formatting)
                    Content content = new Content();
                    content.type = "text/html";
                    content.value = message;
                    List<Content> contentList = new List<Content>();
                    contentList.Add(content);
                    root.content = contentList;

                    // Add attachment (PDF file)
                    EmailRequest.Attachment attachment = new EmailRequest.Attachment()
                    {
                        disposition = "attachment",
                        filename = "SanctionLetter.pdf",
                        content_id = PMSNumber,
                        type = "application/pdf",
                        content = base64Content
                    };

                    List<EmailRequest.Attachment> attachmentList = new List<EmailRequest.Attachment>();
                    attachmentList.Add(attachment);
                    root.attachments = attachmentList;

                    // Send the email

                    isEmailSent = SendEmail(root, PMSNumber, JourneyID);

                    // Return result
                    Console.WriteLine(isEmailSent == "Success" ? "Email sent successfully!" : "Failed to send email.");

                }
            }
            catch (Exception ex)
            {
                _logger.Info(ex.ToString());

            }
            return isEmailSent;
        }

        public static string SendEmailForSanctionLetterN(string PMSNumber, string JourneyID, byte[] SignedByteDoc, string toEmailId, string emailBodyHtml, string ccEmailId)
        {
            string result = "Failure";

            try
            {
                _logger.Info("********************** SANCTION LETTER EMAIL START **********************");
                _logger.Info("PMSNumber: {0}, JourneyID: {1}", PMSNumber, JourneyID);

                if (string.IsNullOrWhiteSpace(toEmailId))
                {
                    _logger.Info("Recipient email is empty");
                    return "Failure";
                }

                // ✅ Validate PDF
                if (!IsValidPdf(SignedByteDoc))
                {
                    _logger.Info("Invalid PDF content");
                    return "Failure";
                }

                // ✅ Create MailMessage
                MailMessage mail = new MailMessage
                {
                    From = new MailAddress(string.Format(EMAIL_API_SENDER), "e-PM SVANidhi"),
                    Subject = "Loan Sanction Letter",
                    Body = emailBodyHtml,
                    IsBodyHtml = true
                };

                // TO
                mail.To.Add(toEmailId);

                // CC (dynamic + config driven)
                if (!string.IsNullOrWhiteSpace(ccEmailId))
                    mail.CC.Add(ccEmailId);

                string[] ccConfig =
                    ConfigurationManager.AppSettings["SAMPLECCEmails"]?.Split('|');

                if (ccConfig != null && ccConfig.Length > 1 && ccConfig[0] == "1")
                {
                    for (int i = 1; i < ccConfig.Length; i++)
                    {
                        if (!string.IsNullOrWhiteSpace(ccConfig[i]))
                            mail.CC.Add(ccConfig[i]);
                    }
                }

                // ✅ Attach PDF
                using (MemoryStream pdfStream = new MemoryStream(SignedByteDoc))
                {
                    System.Net.Mail.Attachment pdfAttachment = new System.Net.Mail.Attachment(pdfStream, "SanctionLetter.pdf", MediaTypeNames.Application.Pdf);

                    mail.Attachments.Add(pdfAttachment);

                    // ✅ SMTP send
                    using (SmtpClient smtp = new SmtpClient(ConfigurationManager.AppSettings["EmailIP"], Convert.ToInt32(ConfigurationManager.AppSettings["EmailPort"])))
                    {
                        //smtp.EnableSsl = true;
                        //smtp.Credentials = new NetworkCredential(
                        //    ConfigurationManager.AppSettings["eMAILUsername"],
                        //    ConfigurationManager.AppSettings["eMAILPassword"]);

                        smtp.Send(mail);
                    }
                }

                _logger.Info("Sanction letter email sent successfully to {0}", toEmailId);
                result = "Success";
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error while sending sanction letter email");
            }
            finally
            {
                _logger.Info("********************** SANCTION LETTER EMAIL END **********************");
            }

            return result;
        }


        public static string SendSMSForLoanDocument(string PMSNumber, string JourneyID, byte[] SignedByteDoc, string toEmailId, string emailBodyHtml, string ccEmailId)
        {
            string result = "Failure";

            try
            {
                _logger.Info("********************** SANCTION LETTER EMAIL START **********************");
                _logger.Info("PMSNumber: {0}, JourneyID: {1}", PMSNumber, JourneyID);

                if (string.IsNullOrWhiteSpace(toEmailId))
                {
                    _logger.Info("Recipient email is empty");
                    return "Failure";
                }

                // ✅ Validate PDF
                if (!IsValidPdf(SignedByteDoc))
                {
                    _logger.Info("Invalid PDF content");
                    return "Failure";
                }

                // ✅ Create MailMessage
                MailMessage mail = new MailMessage
                {
                    From = new MailAddress(string.Format(EMAIL_API_SENDER), "e-PM SVANidhi"),
                    Subject = "Loan Sanction Letter",
                    Body = emailBodyHtml,
                    IsBodyHtml = true
                };

                // TO
                mail.To.Add(toEmailId);

                // CC (dynamic + config driven)
                if (!string.IsNullOrWhiteSpace(ccEmailId))
                    mail.CC.Add(ccEmailId);

                string[] ccConfig =
                    ConfigurationManager.AppSettings["SAMPLECCEmails"]?.Split('|');

                if (ccConfig != null && ccConfig.Length > 1 && ccConfig[0] == "1")
                {
                    for (int i = 1; i < ccConfig.Length; i++)
                    {
                        if (!string.IsNullOrWhiteSpace(ccConfig[i]))
                            mail.CC.Add(ccConfig[i]);
                    }
                }

                // ✅ Attach PDF
                using (MemoryStream pdfStream = new MemoryStream(SignedByteDoc))
                {
                    System.Net.Mail.Attachment pdfAttachment = new System.Net.Mail.Attachment(pdfStream, "SanctionLetter.pdf", MediaTypeNames.Application.Pdf);

                    mail.Attachments.Add(pdfAttachment);

                    // ✅ SMTP send
                    using (SmtpClient smtp = new SmtpClient(ConfigurationManager.AppSettings["EmailIP"], Convert.ToInt32(ConfigurationManager.AppSettings["EmailPort"])))
                    {
                        //smtp.EnableSsl = true;
                        //smtp.Credentials = new NetworkCredential(
                        //    ConfigurationManager.AppSettings["eMAILUsername"],
                        //    ConfigurationManager.AppSettings["eMAILPassword"]);

                        smtp.Send(mail);
                    }
                }

                _logger.Info("Sanction letter email sent successfully to {0}", toEmailId);
                result = "Success";
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error while sending sanction letter email");
            }
            finally
            {
                _logger.Info("********************** SANCTION LETTER EMAIL END **********************");
            }

            return result;
        }

        public static byte[] CompressPdf(byte[] pdfBytes)
        {
            using (MemoryStream inputStream = new MemoryStream(pdfBytes))
            using (MemoryStream outputStream = new MemoryStream())
            {
                // Open the original PDF document from the byte array
                PdfReader reader = new PdfReader(inputStream);

                // Create a PdfStamper to write the compressed output PDF to memory
                PdfStamper stamper = new PdfStamper(reader, outputStream);

                // Set compression level for streams in the output PDF
                stamper.SetFullCompression();

                // Optional: Loop through the pages and apply further custom compression, if necessary
                // Note: iTextSharp doesn't provide direct image compression, but you can apply custom logic here

                // Close the stamper and the reader
                stamper.Close();
                reader.Close();

                // Return the compressed PDF as a byte array
                return outputStream.ToArray();
            }
        }

        public static byte[] CompressPdfV(byte[] pdfBytes)
        {
            using (var inputStream = new MemoryStream(pdfBytes))
            using (var outputStream = new MemoryStream())
            {
                PdfReader reader = new PdfReader(inputStream);

                PdfStamper stamper = new PdfStamper(
                    reader,
                    outputStream,
                    PdfWriter.VERSION_1_5);

                // Enable full compression
                stamper.SetFullCompression();

                // Compress content streams
                int total = reader.NumberOfPages;
                for (int i = 1; i <= total; i++)
                {
                    reader.SetPageContent(i, reader.GetPageContent(i));
                }

                stamper.Close();
                reader.Close();

                return outputStream.ToArray();
            }
        }


        public static void SaveBase64ToFile(byte[] pdfBytes, string filePath)
        {
            try
            {
                // Decode the Base64 string into a byte array
                //byte[] fileBytes = Convert.FromBase64String(base64String);

                // Write the byte array to the file system
                File.WriteAllBytes(filePath, pdfBytes);

                Console.WriteLine($"File saved successfully to {filePath}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Invalid Base64 string: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while saving the file: " + ex.Message);
            }
        }


        public static bool IsValidPdf(byte[] fileBytes)
        {
            // PDF signature check (%PDF-)
            byte[] pdfSignature = { 37, 80, 68, 70, 45, 49, 46 }; // Corresponding to "%PDF-"

            // Check if the first 7 bytes of the file match the PDF signature
            return fileBytes.Take(7).SequenceEqual(pdfSignature);
        }
        //public static string SendEmail(Root messagetext, string PMSNumber, string JourneyID)
        //{
        //    string response = "Failure";
        //    //try
        //    //{
        //    string url = string.Format(EMAIL_API_URL);  // Make sure URL is correct
        //    _logger.Info("SEND MAIL API URL:" + url);
        //    _logger.Info("SEND MAIL JSON Request: " + JsonConvert.SerializeObject(messagetext));

        //    var RequestID = DataLayer.DataLayer.APIRequestResponseLogs(PMSNumber, JourneyID, JsonConvert.SerializeObject(messagetext), null, null, null, "Insert", "EmailSent", null);
        //    Console.WriteLine("API Insert Logs Inserted with RequestID: " + RequestID);

        //    // Ensure proper SSL/TLS security protocols
        //    ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

        //    // Prepare the email request
        //    HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);
        //    var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(EMAIL_API_USERID + ":" + EMAIL_API_PASSWORD);
        //    var authHeader = Convert.ToBase64String(plainTextBytes);
        //    message.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", authHeader);
        //    message.Content = new StringContent(JsonConvert.SerializeObject(messagetext), Encoding.UTF8, "application/json");

        //    using (HttpClient client = new HttpClient(new HttpClientHandler() { UseProxy = false }))
        //    {
        //        var responsedata = client.SendAsync(message).Result;
        //        if (responsedata.IsSuccessStatusCode)
        //        {
        //            var data = responsedata.Content.ReadAsStringAsync().Result;
        //            if (!string.IsNullOrEmpty(data))
        //            {
        //                _logger.Info("SEND MAIL CBS API Response Success Status Code:" + responsedata.IsSuccessStatusCode);
        //                _logger.Info("SEND MAIL CBS API Response Success Result:" + data);
        //                response = "Success";
        //                var isUpdated = DataLayer.DataLayer.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JsonConvert.SerializeObject(data), "Update", "EmailSent", RequestID);
        //                Console.WriteLine("API Logs Updated with RequestID: " + isUpdated);
        //            }
        //        }
        //        else
        //        {
        //            var data = responsedata.Content.ReadAsStringAsync().Result;
        //            _logger.Info("SEND MAIL CBS API Response Failed Result:" + data);
        //        }
        //    }
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    _logger.Error("Exception occurred while sending email: " + ex.Message);
        //    //    // Log the stack trace for better debugging
        //    //    _logger.Error("Stack Trace: " + ex.StackTrace);
        //    //}
        //    return response;
        //}

        public static string SendEmail(Root messagetext, string PMSNumber, string JourneyID)
        {
            string response = "Failure";

            string url = string.Format(EMAIL_API_URL);
            _logger.Info("SEND MAIL API URL: " + url);

            // 🔹 Serialize once (important)
            string requestJson = JsonConvert.SerializeObject(messagetext);

            // 🔹 Calculate lengths
            int requestCharLength = requestJson.Length;
            int requestByteLength = Encoding.UTF8.GetByteCount(requestJson);

            // 🔹 Log request & lengths _logger.Info($"PDF Size: {pdfBytes.Length} bytes ({pdfBytes.Length / (1024.0 * 1024.0):F2} MB)");
            _logger.Info("SEND MAIL JSON Request: " + requestJson);
            _logger.Info($"SEND MAIL REQUEST LENGTH (Chars): {requestCharLength / (1024.0 * 1024.0):F2} MB");
            _logger.Info($"SEND MAIL REQUEST LENGTH (Bytes UTF-8): {requestByteLength / (1024.0 * 1024.0):F2} MB");

            var RequestID = DataLayer.DataLayer.APIRequestResponseLogs(
                PMSNumber,
                JourneyID,
                requestJson,
                null,
                null,
                null,
                "Insert",
                "EmailSent",
                null
            );

            Console.WriteLine("API Insert Logs Inserted with RequestID: " + RequestID);

            ServicePointManager.ServerCertificateValidationCallback =
                new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);

            ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Tls |
                SecurityProtocolType.Tls11 |
                SecurityProtocolType.Tls12 |
                SecurityProtocolType.Ssl3;

            HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);

            var plainTextBytes = Encoding.UTF8.GetBytes(EMAIL_API_USERID + ":" + EMAIL_API_PASSWORD);
            var authHeader = Convert.ToBase64String(plainTextBytes);

            message.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", authHeader);

            // 🔹 Use already serialized JSON
            message.Content = new StringContent(requestJson, Encoding.UTF8, "application/json");

            using (HttpClient client = new HttpClient(new HttpClientHandler() { UseProxy = false }))
            {
                var responsedata = client.SendAsync(message).Result;

                if (responsedata.IsSuccessStatusCode)
                {
                    var data = responsedata.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(data))
                    {
                        _logger.Info("SEND MAIL CBS API Response Status Code: " + responsedata.StatusCode);
                        _logger.Info("SEND MAIL CBS API Response Result: " + data);

                        response = "Success";

                        var isUpdated = DataLayer.DataLayer.APIRequestResponseLogs(
                            PMSNumber,
                            JourneyID,
                            null,
                            null,
                            null,
                            JsonConvert.SerializeObject(data),
                            "Update",
                            "EmailSent",
                            RequestID
                        );

                        Console.WriteLine("API Logs Updated with RequestID: " + isUpdated);
                    }
                }
                else
                {
                    var data = responsedata.Content.ReadAsStringAsync().Result;
                    _logger.Info("SEND MAIL CBS API Response Failed Result: " + data);
                }
            }

            return response;
        }

        private static bool RemoteServerCertificateValidationCallback(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
    }
}
