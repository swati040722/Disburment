﻿using System;
using System.Net.Http;
using System.Net;
using System.Text;
using static LoanAccountDisbursementSvanidhi.Entities.CBSRequestResponse;
using System.Configuration;
using Newtonsoft.Json;
using LoanAccountDisbursementSvanidhi.Crypto;
using NLog;
using Org.BouncyCastle.Asn1.Ocsp;

namespace LoanAccountDisbursementSvanidhi.BusinessLayer
{
    public static class CBSSvcManager
    {
        static string API_URL = ConfigurationManager.AppSettings["CBS_API_URL"];
        public static Logger _Logger = LogManager.GetLogger("DisburshmentAndOtherServicesLogger");
        static string ProxyUserID = ConfigurationManager.AppSettings["ProxyUserID"];
        static string ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
        static string ProxyAddress = ConfigurationManager.AppSettings["ProxyAddress"];
        static string ClientID = ConfigurationManager.AppSettings["Client-ID"];
        public static Token CBSToken()
        {
            Console.WriteLine("Inside CBSToken Method");
            _Logger.Info("Inside CBSToken Method");
            Token response = null;
            try
            {
                string UserID = ConfigurationManager.AppSettings["UserID"];
                string Password = ConfigurationManager.AppSettings["Password"];
                string CBS_TOKEN_API_URL = ConfigurationManager.AppSettings["CBS_TOKEN_API_URL"];

                _Logger.Info("UserID: " + UserID);
                _Logger.Info("Password: " + Password);
                _Logger.Info("CBS_TOKEN_API_URL: " + CBS_TOKEN_API_URL);

                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

                string Plainbody = "grant_type=password&username=" + UserID + "&password=" + Password;
                _Logger.Info("CBSToken API Plain Request : " + Plainbody);
                
                string url = string.Format(CBS_TOKEN_API_URL);
                HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);
                // Set the request content with the correct content type
                message.Content = new StringContent(Plainbody, Encoding.UTF8, "application/json");
                using (var client = new HttpClient(new HttpClientHandler { UseProxy = false }))
              //  using (HttpClient client = new HttpClient())
                {
                    _Logger.Info("Client Information: " + client.ToString());
                    var responsedata = client.SendAsync(message).Result;
                    if (responsedata.IsSuccessStatusCode)
                    {
                        var data = responsedata.Content.ReadAsStringAsync().Result;
                        if (!string.IsNullOrEmpty(data))
                        {
                            response = JsonConvert.DeserializeObject<Token>(data);
                            _Logger.Info("CBSToken API Plain Response Data " + JsonConvert.SerializeObject(response));
                            Console.WriteLine("CBSToken API successfully called");
                        }
                    }
                    else
                    {
                        _Logger.Info("CBSToken API StatusCode " + responsedata.StatusCode);
                        Console.WriteLine("Else :CBSToken API Failed");
                    }
                }
            }
            catch (Exception ex)
            {
                _Logger.Info("CBS Token APIException: " + ex.ToString());
                Console.WriteLine("CBS Token APIException: " + ex.ToString());
            }
            return response;
        }
        public static SRMCreationResponse SRMCreation(string PMSNumber, string JourneyID, string RequestID, string EncRequest, string AccessToken)
        {
            SRMCreationResponse response = null;
            //try
            //{
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            string url = string.Format(API_URL, EncRequest);
            _Logger.Info("url: " + url);
            _Logger.Info("ClientID: " + ClientID);
            _Logger.Info("AccessToken: " + AccessToken);
            _Logger.Info("EncRequest: " + EncRequest);
            HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);
            message.Headers.Add("Client-Id", ClientID);  // Replace with your custom Client-Id
            message.Headers.Add("Authorization", "Bearer " + AccessToken);  // Bearer token header
            message.Content = new StringContent(EncRequest, Encoding.UTF8, "application/json");

            using (var client = new HttpClient(new HttpClientHandler { UseProxy = false }))
            {
                var responsedata = client.SendAsync(message).Result;
                if (responsedata.IsSuccessStatusCode)
                {
                    var data = responsedata.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(data))
                    {
                        var Plainresponse = SVND_Crypto.Decrypt((JsonConvert.DeserializeObject<EncResponse>(data).EncRespData));

                        response = JsonConvert.DeserializeObject<SRMCreationResponse>(Plainresponse);

                        var isUpdated = DataLayer.DataLayer.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, JsonConvert.SerializeObject(data), JsonConvert.SerializeObject(response), "Update", "SRMCreation", RequestID);
                        Console.WriteLine("SRM Creation API Logs Updated with RequestID: " + isUpdated);
                    }
                }
                else
                {
                    _Logger.Info("Else: SRM Creation API StatusCode " + responsedata.StatusCode);
                    Console.WriteLine("Else :SRM Creation API Failed");
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            return response;
        }

        public static LoanDisbursementResponse LoanDisbursement(string PMSNumber, string JourneyID, string RequestID, string EncRequest, string AccessToken)
        {
            LoanDisbursementResponse response = null;
            //try
            //{
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            string url = string.Format(API_URL);
            _Logger.Info("url: " + url);
            _Logger.Info("ClientID: " + ClientID);
            _Logger.Info("AccessToken: " + AccessToken);
            _Logger.Info("EncRequest: " + EncRequest);
            HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);
            message.Headers.Add("Client-Id", ClientID);  // Replace with your custom Client-Id
            message.Headers.Add("Authorization", "Bearer " + AccessToken);  // Bearer token header
            message.Content = new StringContent(EncRequest, Encoding.UTF8, "application/json");

            using (var client = new HttpClient(new HttpClientHandler { UseProxy = false }))
            {

                var responsedata = client.SendAsync(message).Result;
                if (responsedata.IsSuccessStatusCode)
                {
                    var data = responsedata.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(data))
                    {
                        var Plainresponse = SVND_Crypto.Decrypt((JsonConvert.DeserializeObject<EncResponse>(data).EncRespData));

                        response = JsonConvert.DeserializeObject<LoanDisbursementResponse>(Plainresponse);

                        var isUpdated = DataLayer.DataLayer.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, (JsonConvert.DeserializeObject<EncResponse>(data).EncRespData), JsonConvert.SerializeObject(response), "Update", "LoanDisbursement", RequestID);
                        Console.WriteLine("Loan Disbursement API Logs Updated with RequestID: " + isUpdated);
                    }
                }
                else
                {
                    Console.WriteLine("Loan Disbursement Else- StatusCode " + responsedata.IsSuccessStatusCode);
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            return response;
        }

        public static QRPushCodeResponse QRDataPush(string PMSNumber, string JourneyID, string RequestID, string EncRequest, string AccessToken)
        {
            QRPushCodeResponse response = null;
            //try
            //{
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            string url = string.Format(API_URL);
            _Logger.Info("url: " + url);
            _Logger.Info("ClientID: " + ClientID);
            _Logger.Info("AccessToken: " + AccessToken);
            _Logger.Info("EncRequest: " + EncRequest);
            HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, url);
            message.Headers.Add("Client-Id", ClientID);  // Replace with your custom Client-Id
            message.Headers.Add("Authorization", "Bearer " + AccessToken);  // Bearer token header
            message.Content = new StringContent(EncRequest, Encoding.UTF8, "application/json");

             using (var client = new HttpClient(new HttpClientHandler { UseProxy = false }))
            {

                var responsedata = client.SendAsync(message).Result;
                if (responsedata.IsSuccessStatusCode)
                {
                    var data = responsedata.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(data))
                    {
                        var Plainresponse = SVND_Crypto.Decrypt((JsonConvert.DeserializeObject<EncResponse>(data).EncRespData));

                        response = JsonConvert.DeserializeObject<QRPushCodeResponse>(Plainresponse);

                        var isUpdated = DataLayer.DataLayer.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, (JsonConvert.DeserializeObject<EncResponse>(data).EncRespData), JsonConvert.SerializeObject(response), "Update", "QRDataPush", RequestID);
                        Console.WriteLine("QR Push Code API Logs Updated with RequestID: " + isUpdated);
                    }
                }
                else
                {
                    Console.WriteLine("QR Data Push Else- StatusCode " + responsedata.IsSuccessStatusCode);
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            return response;
        }

        private static HttpClient GetClient()
        {
            //First create a proxy object
            var proxy = new WebProxy
            {
                Address = new Uri(ProxyAddress),
                BypassProxyOnLocal = false,
                UseDefaultCredentials = false,
                // *** These creds are given to the proxy server, not the web server ***
                Credentials = new NetworkCredential(
                     userName: ProxyUserID,
                     password: ProxyPassword)
            };
            //// Now create a client handler which uses that proxy
            var httpClientHandler = new HttpClientHandler
            {
                Proxy = proxy,
            };
            return new HttpClient(httpClientHandler);
        }
        private static bool RemoteServerCertificateValidationCallback(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }


    }
}
