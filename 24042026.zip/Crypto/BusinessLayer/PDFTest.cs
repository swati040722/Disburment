﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UglyToad.PdfPig;
using UglyToad.PdfPig.Content;

namespace LoanAccountDisbursementSvanidhi.BusinessLayer
{
    public class PDFTest
    {
        // ===================== ENTRY POINT =====================
        public void CallIt()
        {
            try
            {
                ProcessPdfFilesAndWriteCsv();
                //ProcessFromDatabaseAndWriteCsv();
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Fatal error:");
                Console.WriteLine(ex);
            }
        }

        public static void ProcessPdfFilesAndWriteCsv()
        {
            string pdfFolder = @"G:\Shared\exported_pdfs";
            string basePath = AppDomain.CurrentDomain.BaseDirectory;
            string csvPath = Path.Combine(basePath, "PDF_FileSystem_Only_Comparison.csv");

            using (StreamWriter writer = new StreamWriter(csvPath, false, Encoding.UTF8))
            {
                // ---------- CSV HEADER ----------
                writer.WriteLine(
                    "PDF_PMS,PDF_Account,AccountName,BorrowerName,Branch,Circle,SanctionDate,ParseStatus");
                int i = 0;
                foreach (string file in Directory.GetFiles(pdfFolder, "*.pdf"))
                {
                    i++;
                    if (i > 2)
                        return;
                    string pdfPms = "NOT FOUND";
                    string pdfAccount = "NOT FOUND";
                    string accountName = "NOT FOUND";
                    string borrowerName = "NOT FOUND";
                    string branch = "NOT FOUND";
                    string circle = "NOT FOUND";
                    string sanctionDate = "NOT FOUND";
                    string parseStatus = "PDF_READ_ERROR";

                    try
                    {
                        // --------- EXTRACT FROM FILENAME ---------
                        string fileName = Path.GetFileNameWithoutExtension(file);
                        string[] parts = fileName.Split('_');

                        if (parts.Length >= 2)
                        {
                            pdfPms = parts[0].Trim().ToUpperInvariant();
                            pdfAccount = parts[1].Trim();
                        }

                        // --------- READ PDF CONTENT ---------
                        byte[] pdfBytes = File.ReadAllBytes(file);
                        if (pdfBytes.Length == 0)
                            throw new Exception("Empty PDF");

                        string pdfText = ExtractPdfText(pdfBytes);

                        // --------- FLEXIBLE EXTRACTION ---------
                        sanctionDate = ExtractValue(pdfText, @"\d{2}-\d{2}-\d{4}");
                        circle = ExtractValue(pdfText, @"CO-[A-Z\s\-]+");

                        // --------- NAME + BRANCH ---------
                        if (circle != "NOT FOUND")
                        {
                            int end = pdfText.IndexOf(circle, StringComparison.OrdinalIgnoreCase);
                            if (end > 0)
                            {
                                string headerBlock = pdfText.Substring(0, end)
                                    .Replace("\n", " ")
                                    .Replace("\r", " ");

                                headerBlock = Regex.Replace(headerBlock, @"[\d%\.]+", "").Trim();

                                Match nm = Regex.Match(headerBlock, @"([A-Z]+\s[A-Z]+)\s+(.*)");
                                if (nm.Success)
                                {
                                    accountName = borrowerName = nm.Groups[1].Value.Trim();
                                    branch = nm.Groups[2].Value.Trim();
                                }
                            }
                        }

                        parseStatus = "PARSED_OK";
                    }
                    catch
                    {
                        parseStatus = "PDF_READ_ERROR";
                    }

                    // ---------- WRITE CSV ----------
                    writer.WriteLine(string.Join(",",
                        Csv(pdfPms),
                        Csv(pdfAccount),
                        Csv(accountName),
                        Csv(borrowerName),
                        Csv(branch),
                        Csv(circle),
                        Csv(sanctionDate),
                        Csv(parseStatus)
                    ));
                }
            }

            Console.WriteLine("✅ CSV generation completed");
            Console.WriteLine("📄 File: " + csvPath);
        }

        // ===================== MAIN PROCESS =====================
        public static void ProcessFromDatabaseAndWriteCsv()
        {
            string connectionString =
                ConfigurationManager.ConnectionStrings["PMSvanidhiContext"].ConnectionString;

            string basePath = AppDomain.CurrentDomain.BaseDirectory;
            string csvPath = Path.Combine(basePath, "PDF_DB_ComparisonN.csv");

            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlDataAdapter da = new SqlDataAdapter(@"
        SELECT 
            ND.PMSNumber,
            ND.Unsign_Doc_Byte,
            CB.AccountNo AS DB_AccountNo
        FROM SVND_NESL_DOCUMENT ND
        INNER JOIN SVND_LOAN_JOURNEY_MASTER LM
            ON ND.PMSNumber = LM.PMSNumber
        JOIN SVND_CBS_CITY_KYC_STATUS CB 
            ON ND.PMSNumber = CB.PMSNumber
        WHERE 
            ND.isPendingForNeSLeSign = 'N'
            AND ND.isPendingForBankOfficialSign = 'N'
            AND LM.LoanAccountOpenDate <= CAST(GETDATE() AS DATE)
    ", con))
            {
                da.Fill(dt);
            }

            using (StreamWriter writer = new StreamWriter(csvPath, false, Encoding.UTF8))
            {
                // ---------- CSV HEADER ----------
                writer.WriteLine(
                    "DB_PMS,DB_Account,PDF_PMS,PDF_Account,AccountName,BorrowerName," +
                    "Branch,Circle,SanctionDate,MatchStatus");

                foreach (DataRow row in dt.Rows)
                {
                    string dbPms = row["PMSNumber"]?.ToString()?.Trim().ToUpperInvariant();
                    string dbAccount = row["DB_AccountNo"]?.ToString();

                    string pdfPms = "NOT FOUND";
                    string pdfAccount = "NOT FOUND";
                    string accountName = "NOT FOUND";
                    string borrowerName = "NOT FOUND";
                    string branch = "NOT FOUND";
                    string circle = "NOT FOUND";
                    string sanctionDate = "NOT FOUND";
                    string matchStatus = "PDF_READ_ERROR";

                    try
                    {
                        byte[] pdfBytes = row["Unsign_Doc_Byte"] as byte[];

                        if (pdfBytes == null || pdfBytes.Length == 0)
                            throw new Exception("Empty PDF bytes");

                        string pdfText = ExtractPdfText(pdfBytes);

                        // --------- FLEXIBLE EXTRACTION ---------
                        pdfPms = ExtractValue(pdfText, @"(?i)pms\d{11,12}")
                                    .ToUpperInvariant();

                        pdfAccount = ExtractValue(pdfText, @"(?<!\d)(\d{13,16})(?!\d)");
                        sanctionDate = ExtractValue(pdfText, @"\d{2}-\d{2}-\d{4}");
                        circle = ExtractValue(pdfText, @"CO-[A-Z\s\-]+");

                        // --------- NAME + BRANCH ---------
                        if (pdfPms != "NOT FOUND" && circle != "NOT FOUND")
                        {
                            int start = pdfText.IndexOf(pdfPms, StringComparison.OrdinalIgnoreCase)
                                        + pdfPms.Length;
                            int end = pdfText.IndexOf(circle, StringComparison.OrdinalIgnoreCase);

                            if (end > start)
                            {
                                string middle = pdfText.Substring(start, end - start)
                                    .Replace("\n", " ")
                                    .Replace("\r", " ");

                                middle = Regex.Replace(middle, @"[\d%\.]+", "").Trim();

                                Match nm = Regex.Match(middle, @"^([A-Z]+\s[A-Z]+)\1");
                                if (nm.Success)
                                {
                                    accountName = borrowerName = nm.Groups[1].Value.Trim();
                                    branch = middle.Replace(nm.Value, "").Trim();
                                }
                            }
                        }

                        // --------- MATCH LOGIC (CRITICAL FIX) ---------
                        bool pmsMatch =
                            !string.IsNullOrEmpty(dbPms) &&
                            !string.IsNullOrEmpty(pdfPms) &&
                            pdfPms.StartsWith(dbPms);

                        bool accMatch = dbAccount == pdfAccount;

                        if (pmsMatch && accMatch)
                            matchStatus = "NO_MISMATCH";
                        else if (!pmsMatch && !accMatch)
                            matchStatus = "BOTH_MISMATCH";
                        else if (!pmsMatch)
                            matchStatus = "PMS_MISMATCH";
                        else
                            matchStatus = "ACCOUNT_MISMATCH";
                    }
                    catch
                    {
                        matchStatus = "PDF_READ_ERROR";
                    }

                    // ---------- WRITE CSV ----------
                    writer.WriteLine(string.Join(",",
                        Csv(dbPms),
                        Csv(dbAccount),
                        Csv(pdfPms),
                        Csv(pdfAccount),
                        Csv(accountName),
                        Csv(borrowerName),
                        Csv(branch),
                        Csv(circle),
                        Csv(sanctionDate),
                        Csv(matchStatus)
                    ));
                }
            }

            Console.WriteLine("✅ CSV generation completed");
            Console.WriteLine("📄 File: " + csvPath);
        }


        // ===================== HELPERS =====================
        private static string ExtractValue(string text, string pattern)
        {
            Match m = Regex.Match(text, pattern);
            return m.Success ? m.Value.Trim() : "NOT FOUND";
        }

        private static string Csv(string value)
        {
            if (value == null) return "";
            value = value.Replace("\"", "\"\"");
            return $"\"{value}\"";
        }

        private static string ExtractPdfText(byte[] pdfBytes)
        {
            StringBuilder sb = new StringBuilder();
            using (MemoryStream ms = new MemoryStream(pdfBytes))
            using (PdfDocument doc = PdfDocument.Open(ms))
            {
                foreach (Page p in doc.GetPages())
                    sb.AppendLine(p.Text);
            }
            return sb.ToString();
        }
    }
}
