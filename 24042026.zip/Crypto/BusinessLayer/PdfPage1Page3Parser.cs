﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;

namespace LoanAccountDisbursementSvanidhi.BusinessLayer
{
    public static class PdfPage1Page3Parser
    {
        public static void CallIt()
        {
            try
            {
                ProcessPdfsAndWriteCsv();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Fatal error:");
                Console.WriteLine(ex);
            }
        }

        public static void ProcessPdfsAndWriteCsv()
        {
            string pdfFolder = @"G:\Shared\Unsign\UnSign";
            string csvPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "PDF_Page1_Page3_Comparison_NESL.csv"
            );

            using (StreamWriter writer = new StreamWriter(csvPath, false, Encoding.UTF8))
            {
                writer.WriteLine(
                    "FILENAME_PMS,FILENAME_Account,PDF_PMS,PDF_Account," +
                    "AccountName,BorrowerName,Branch,Circle,SanctionDate,MatchStatus"
                );

                foreach (string file in Directory.GetFiles(pdfFolder, "*.pdf"))
                {
                    string filePms = "NOT FOUND";
                    string fileAccount = "NOT FOUND";

                    string pdfPms = "NOT FOUND";
                    string pdfAccount = "NOT FOUND";
                    string accountName = "NOT FOUND";
                    string borrowerName = "NOT FOUND";
                    string branch = "NOT FOUND";
                    string circle = "NOT FOUND";
                    string sanctionDate = "NOT FOUND";

                    string matchStatus = "PDF_READ_ERROR";

                    try
                    {
                        // -------- Filename --------
                        string[] parts = Path.GetFileNameWithoutExtension(file).Split('_');
                        if (parts.Length >= 2)
                        {
                            filePms = parts[0].Trim().ToUpperInvariant();
                            fileAccount = parts[1].Trim();
                        }

                        // -------- Read Page 1 & Page 3 --------
                        string page1, page3;
                        ExtractPage1AndPage3(File.ReadAllBytes(file), out page1, out page3);

                        // -------- Page 1 parse (identity data) --------
                        ParseIdentityPage(
                            page1,
                            out pdfPms,
                            out accountName,
                            out borrowerName,
                            out branch,
                            out circle,
                            out sanctionDate
                        );

                        // -------- Page 3 operative account --------
                        pdfAccount = ExtractOperativeAccountFromPage3(page3);

                        filePms = filePms.ToUpperInvariant();
                        pdfPms = pdfPms.ToUpperInvariant();

                        // -------- Match logic --------
                        if (filePms == pdfPms && fileAccount == pdfAccount)
                            matchStatus = "NO_MISMATCH";
                        else if (filePms != pdfPms && fileAccount != pdfAccount)
                            matchStatus = "BOTH_MISMATCH";
                        else if (filePms != pdfPms)
                            matchStatus = "PMS_MISMATCH";
                        else
                            matchStatus = "ACCOUNT_MISMATCH";
                    }
                    catch
                    {
                        matchStatus = "PDF_READ_ERROR";
                    }

                    writer.WriteLine(string.Join(",",
                        Csv(filePms),
                        Csv(fileAccount),
                        Csv(pdfPms),
                        Csv(pdfAccount),
                        Csv(accountName),
                        Csv(borrowerName),
                        Csv(branch),
                        Csv(circle),
                        Csv(sanctionDate),
                        Csv(matchStatus)
                    ));
                }
            }

            Console.WriteLine("CSV generated: " + csvPath);
        }

        // ================= PDF READ =================

        private static void ExtractPage1AndPage3(
            byte[] pdfBytes,
            out string page1,
            out string page3)
        {
            page1 = page3 = string.Empty;

            using (MemoryStream ms = new MemoryStream(pdfBytes))
            using (PdfReader reader = new PdfReader(ms))
            using (PdfDocument pdf = new PdfDocument(reader))
            {
                if (pdf.GetNumberOfPages() >= 1)
                    page1 = PdfTextExtractor.GetTextFromPage(pdf.GetPage(1));

                if (pdf.GetNumberOfPages() >= 3)
                    page3 = PdfTextExtractor.GetTextFromPage(pdf.GetPage(3));
            }
        }

        // ================= PAGE 1 (IDENTITY DATA) =================

        private static void ParseIdentityPage(
            string text,
            out string pdfPms,
            out string accountName,
            out string borrowerName,
            out string branch,
            out string circle,
            out string sanctionDate)
        {
            pdfPms = accountName = borrowerName = branch = circle = sanctionDate = "NOT FOUND";

            if (string.IsNullOrWhiteSpace(text))
                return;

            string[] lines = Regex.Split(text, @"\r?\n");
            List<string> clean = new List<string>();

            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.Length == 0) continue;
                if (line.Contains(":")) continue;
                if (line.IndexOf("INR", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                if (line.IndexOf("RS", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                if (line.StartsWith("Sanction", StringComparison.OrdinalIgnoreCase)) continue;
                if (line.StartsWith("Nature", StringComparison.OrdinalIgnoreCase)) continue;
                if (line.StartsWith("Amount", StringComparison.OrdinalIgnoreCase)) continue;

                clean.Add(line);
            }

            for (int i = 0; i < clean.Count; i++)
            {
                string line = clean[i];

                // PMS
                if (pdfPms == "NOT FOUND" && Regex.IsMatch(line, @"(?i)^PMS\d{11,14}$"))
                {
                    pdfPms = line;
                    continue;
                }

                // -------- CIRCLE (CO- split handling) --------
                if (circle == "NOT FOUND")
                {
                    if (Regex.IsMatch(line, @"^CO-[A-Z\-]+$"))
                    {
                        circle = line;
                        continue;
                    }

                    if (line == "CO-" && i + 1 < clean.Count)
                    {
                        string next = clean[i + 1];
                        if (Regex.IsMatch(next, @"^[A-Z]{3,}$"))
                        {
                            circle = "CO-" + next;
                            continue;
                        }
                    }
                }

                // ACCOUNT NAME
                if (accountName == "NOT FOUND" && Regex.IsMatch(line, @"^[A-Z\s]{3,}$"))
                {
                    accountName = line;
                    continue;
                }

                // BORROWER NAME
                if (borrowerName == "NOT FOUND" && Regex.IsMatch(line, @"^[A-Z\s]{3,}$"))
                {
                    borrowerName = line;
                    continue;
                }

                // BRANCH
                if (branch == "NOT FOUND"
                    && Regex.IsMatch(line, @"^[A-Z\s\(\)\-]+$")
                    && !Regex.IsMatch(line, @"\d"))
                {
                    branch = line;
                    continue;
                }

                // SANCTION DATE
                if (sanctionDate == "NOT FOUND"
                    && Regex.IsMatch(line, @"\d{2}-\d{2}-\d{4}"))
                {
                    sanctionDate = line;
                    continue;
                }
            }
        }

        // ================= PAGE 3 (ACCOUNT) =================

        private static string ExtractOperativeAccountFromPage3(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return "NOT FOUND";

            Match m = Regex.Match(
                text,
                @"account\s*no\.?\s*[\r\n\s]*([0-9]{13,16})",
                RegexOptions.IgnoreCase
            );

            return m.Success ? m.Groups[1].Value : "NOT FOUND";
        }

        // ================= UTIL =================

        private static string Csv(string v)
        {
            if (v == null) return "\"\"";
            return "\"" + v.Replace("\"", "\"\"") + "\"";
        }
    }
}
