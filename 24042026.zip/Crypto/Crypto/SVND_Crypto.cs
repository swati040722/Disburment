﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LoanAccountDisbursementSvanidhi.Crypto
{
    public static class SVND_Crypto
    {
        public static string Decrypt(string encryptedText)
        {
            encryptedText = encryptedText.Replace(' ', '+');
            string text = encryptedText.Replace(@"\/", "/");
            byte[] cipherText = Convert.FromBase64String(text);

            byte[] key = Encoding.UTF8.GetBytes(ConfigurationManager.AppSettings["SwanidhiKey"]);
            byte[] iv = Encoding.UTF8.GetBytes("1234567890123456");
            string plaintext = null;

            using (AesCryptoServiceProvider aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;
                aes.IV = iv;
                aes.Padding = PaddingMode.PKCS7;
                aes.Mode = CipherMode.CBC;
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (var msDecrypt = new MemoryStream(cipherText))
                using (CryptoStream cs = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                using (StreamReader sr = new StreamReader(cs))
                {
                    var result = sr.ReadToEnd();
                    var bytearray = Encoding.UTF8.GetBytes(result);
                    var decodedplaintext = Encoding.UTF8.GetString(bytearray);
                    plaintext = decodedplaintext.Substring(decodedplaintext.IndexOf('{'), (decodedplaintext.Length - decodedplaintext.IndexOf('{')));
                }
            }
            return plaintext;
        }

      

        public static string Encrypt(string plainText)
        {
            byte[] cipherText = Encoding.UTF8.GetBytes(plainText);
            byte[] key = Encoding.UTF8.GetBytes(ConfigurationManager.AppSettings["SwanidhiKey"]);
            byte[] iv = Encoding.UTF8.GetBytes("1234567890123456");
            byte[] encrypted;
            using (AesManaged aes = new AesManaged())
            {
                aes.KeySize = 256;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                // Create encryptor    
                ICryptoTransform encryptor = aes.CreateEncryptor(key, iv);
                // Create MemoryStream    
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }

                        encrypted = ms.ToArray();
                    }
                }
            }
            string encryptedText = Convert.ToBase64String(encrypted);
            return encryptedText;
        }
    }
}
