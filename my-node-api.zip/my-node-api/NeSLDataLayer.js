// NeSLDataLayer.js



const express = require("express");
const axios = require('axios');
//const sql = require("mssql");
const app = express();
app.use(express.json())
var cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');

const { PDFDocument, rgb } = require('pdf-lib');
const forge = require('node-forge');

const crypto = require('crypto');
const moment = require('moment');

const { readFileSync, writeFileSync } = require('fs');

const { sql, getPool } = require('./db');

const fs = require('fs');
const path = require('path');
const os = require('os');


app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

const { HttpsProxyAgent } = require('https-proxy-agent');//for System Proxy
const https = require('https');

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('NeSLDataLayer');
const objGeneralOperation = require('./GeneralDataLayer');
const objCommonFunction = require('./CommonFunctions');
const logError = require('./ErrorLog');
const objCBSLayer = require('./CBSDataLayer');


// Set up cookie parser middleware
app.use(cookieParser());
//SQL Server configuration
// var config = {
//   user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000
//   },
//   "options": {
//     "encrypt": false
//   }
// }

var config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};




// Define your proxy URL (you can get this from environment variables or hardcode it)
const proxyUrl = process.env.HTTPS_PROXY || 'http://10.192.205.150:3128';     //http://10.192.34.167:3128         //'http://10.192.20.171:8001' //111000
// Create a new agent instance
const ProxyAgent = new HttpsProxyAgent(proxyUrl);


// const agent = new https.Agent({
//    rejectUnauthorized: false, // Set to false to bypass certificate verification 
//    HttpsProxyAgent:proxyUrl 
// });
const httpAgent = new https.Agent({
  rejectUnauthorized: false, // Set to false to bypass certificate verification 

});


async function getPDFDocumentContext(PMSNumber, JourneyID) {
  const pool = await getPool();
  const request = pool.request();

  const result = await request
    .input('PMSNumber', sql.NVarChar, PMSNumber)
    .input('JourneyID', sql.NVarChar, JourneyID)
    .execute('dbo.proc_GetPDFDocumentContext');

  if (!result.recordsets || result.recordsets.length < 3) {
    throw new Error('Incomplete PDF document context');
  }

  return {
    journey: result.recordsets[0][0],
    branch: result.recordsets[1][0],
    amortization: result.recordsets[2],
	cityKYC: result.recordsets[0][0],                //111000
  };
}


function BindTrancheWisePDFDocument(pdfContext) {
	const {
    //PMSNumber,
    //JourneyID,
    branch,
    journey,
    cityKYC,
    amortization
  } = pdfContext;
  logger.info('***************************** Inside BindTrancheWisePDFDocument *****************************');
  logger.info(  `[PDF REQUEST] PMS=${journey.PMSNumber}, Journey=${journey.JourneyID}, Tranche=${journey.LoanTranche}`);
  //logger.info('journey ',JSON.stringify(journey));
	if (!journey.PMSNumber || !journey.JourneyID || !journey?.LoanTranche) {
	  throw new Error(
		`Invalid PDF context | PMS=${journey.PMSNumber}, Journey=${journey.JourneyID}`
	  );
	}
  return new Promise(async (resolve, reject) => {
    try {
      // const nodalOfficerName = await GetKeyConfigurationValue('NodalOfficerName'); // Await the promise
      logger.info(await GetKeyConfigurationValue('NodalOfficerName')) // Await the promise)
      let ExistingDocByte;
      if (journey.LoanTranche == 1) {


        logger.info('Tranche ', journey.LoanTranche);

        const filePath = path.resolve(__dirname, 'Documents/TrancheOneN.pdf');
        if (fs.existsSync(filePath)) {
          ExistingDocByte = fs.readFileSync(filePath);
        } else {
          logger.error('Tranch 1 document not found:', filePath);
        }

        //ExistingDocByte = fs.readFileSync('Documents/TrancheOne.pdf');

        //const existingPdfBytes = await fs.promises.readFile('path/to/your/pdf.pdf');
      }
      else if (journey.LoanTranche == 2) {
        logger.info('Tranche ', journey.LoanTranche);
        const filePath = path.resolve(__dirname, 'Documents/TrancheTwo.pdf');
        if (fs.existsSync(filePath)) {
          ExistingDocByte = fs.readFileSync(filePath);
        } else {
          logger.error('Tranch 2 document not found:', filePath);
        }
        //ExistingDocByte = fs.readFileSync('Documents/TrancheTwo.pdf');
      }
      else if (journey.LoanTranche == 3) {
        logger.info('Tranche ', journey.LoanTranche);
        const filePath = path.resolve(__dirname, 'Documents/TrancheThree.pdf');
        if (fs.existsSync(filePath)) {
          ExistingDocByte = fs.readFileSync(filePath);
        } else {
          logger.error('Tranch 2 document not found:', filePath);
        }
        //ExistingDocByte = fs.readFileSync('Documents/TrancheThree.pdf');
      }

      const pdfDoc = await PDFDocument.load(ExistingDocByte);




      const defaultFontSize = 12;
     
	  
	   const positions = {
     

      'SLApplicationreferencenumber': { page: 0, x: 240, y: 712 },
        'SLNameoftheAccount': { page: 0, x: 192, y: 693 },
        'SLNameoftheBorrower': { page: 0, x: 198, y: 675 },
        'SLBOName': { page: 0, x: 150, y: 655 },
        'SLCOName': { page: 0, x: 118, y: 635 },
        'SLSanctionDate': { page: 0, x: 170, y: 619 },
        'SLRs': { page: 0, x: 210, y: 574 },
        'SLINR': { page: 0, x: 300, y: 576 },
        'SLRLLR': { page: 0, x: 230, y: 519 },   //Changed
        // 'SLBSP':{ page: 0, x: 305, y: 519 },
        'SLSpread': { page: 0, x: 313, y: 519 },
        // 'SLServicecharge': { page: 0, x: 450, y: 519 },
        'SLROI': { page: 0, x: 385, y: 519 },
        'SLRepaymentPeriod': { page: 0, x: 190, y: 418 },
        'SLSignatureofAuthorized': { page: 1, x: 80, y: 620 },
        'SLSignatureoftheBorrower': { page: 1, x: 360, y: 620 },
      




        //Undertaking
        'UDate': { page: 2, x: 468, y: 738 },
        'UPlace': { page: 2, x: 468, y: 726 },
        'UBOName': { page: 2, x: 72, y: 672 },
        'URs': { page: 2, x: 252, y: 570 }, //Changed
        'UINR': { page: 2, x: 350, y: 570 },
        'UROI': { page: 2, x: 298, y: 546 },//update 
        'ULoanTenure': { page: 2, x: 510, y: 545 },//Changed
        'UBOName1': { page: 2, x: 105, y: 496 },
        'UAccountNo': { page: 2, x: 296, y: 443 },
        'UBorrowerName': { page: 2, x: 76, y: 350 },



        //Letter to bank
        'LBDate': { page: 3, x: 452, y: 726 },
        'LBPlace': { page: 3, x: 455, y: 712 },
        'LBRs': { page: 3, x: 90, y: 584 },
        'LBBOName': { page: 3, x: 72, y: 658 },
        'LBCustomerName': { page: 3, x: 72, y: 232 },


        //Demand Promisonery Note        
        'DPDate': { page: 4, x: 458, y: 670 },
        'DPPlace': { page: 4, x: 460, y: 684 },
        'DPRs': { page: 4, x: 82, y: 672 },  //changed
        'DPRsInWords': { page: 4, x: 146, y: 672 },
        'DPBranchName': { page: 4, x: 270, y: 618 },
        'DPRs1': { page: 4, x: 80, y: 582 },   //changed
        'DPRs1InWords': { page: 4, x: 140, y: 582 },
        'DPHSpreadServiceCharge': { page: 4, x: 90, y: 568 },
        'DPHROI': { page: 4, x: 340, y: 568 },
        'DPBranchName1': { page: 4, x: 178, y: 504 },
        'DPRs2': { page: 4, x: 436, y: 491 },           //changed
        'DPRs2InWords': { page: 4, x: 82, y: 480 },
        'DPESpreadServiceCharge1': { page: 4, x: 500, y: 478 },
        'DPEROI1': { page: 4, x: 458, y: 465 },
        'DPCustomerSign': { page: 4, x: 350, y: 420 }, //update
        'DPCustomerName': { page: 4, x: 410, y: 312 }, //Changed
        'DPCustomerAddress': { page: 4, x: 428, y: 298 },   //Changed



        //  KFS
        'KFS_A_AccountNo': { page: 5, x: 230, y: 662 },
        'KFS_A_LoanAmount': { page: 5, x: 384, y: 636 },
        'KFS_A_LoanAmountInWords': { page: 5, x: 384, y: 610 }, // AmountInDigits
        'KFS_A_LoanTenure': { page: 5, x: 385, y: 540 }, //Changed
        'KFS_A_EPICount1': { page: 5, x: 195, y: 495}, //Changed
        'KFS_A_EPIAmount1': { page: 5, x: 275, y: 495 },//update
        'KFS_A_RLLR': { page: 5, x: 390, y: 468 },   //  { page: 5, x: 390, y: 452 }  //Chnaged
        // 'KFS_A_BSP':{ page: 5, x: 465, y: 452 },
        'KFS_A_Spread': { page: 5, x: 472, y: 468 },
        // 'KFS_A_Servicecharge': { page: 5, x: 442, y: 380 },
        'KFS_A_ROI1': { page: 5, x: 350, y: 455 },
        'KFS_A_BenchmarkRate': { page: 5, x: 120, y: 350 },  
        'KFS_A_BenchmarkRate': { page: 5, x: 120, y: 350 },  //Changed
        'KFS_A_SpreadServiceCharge': { page: 5, x: 185, y: 350 },  //Changed
        'KFS_A_ROI2': { page: 5, x: 238, y: 350 },  //Changed
        'KFS_A_B': { page: 5, x: 290, y: 350 },   //Changed
        'KFS_A_EPIAmount2': { page: 5, x: 380, y: 350 }, //Changed
        'KFS_A_EPICount2': { page: 5, x: 515, y: 350 },
        'KFS_A_StampCharge': { page: 5, x: 452, y: 68 },
        // 'KFS_A_CICCharge': { page: 6, x: 452, y: 745 },
        'KFS_A_ROI3': { page: 6, x: 260, y: 740 },
        'KFS_A_BODigiSignName': { page: 6, x: 355, y: 405 },
        'KFS_A_BODigiSignDesignation': { page: 6, x: 388, y: 385 },
        'KFS_A_BODigiSignContactNo': { page: 6, x: 382, y: 368 },  //{ page: 6, x: 386, y: 328 },
        'KFS_A_BODigiSignEmailId': { page: 6, x: 367, y: 355 },

        'KFS_B_LoanAmount': { page: 7, x: 428, y: 678 },
        'KFS_B_LoanTenure': { page: 7, x: 424, y: 647 },
        'KFS_B_EPIAmount': { page: 7, x: 426, y: 530 },     //Changed
        'KFS_B_EPICount': { page: 7, x: 420, y: 610},     //Changed
        'KFS_B_ROI': { page: 7, x: 455, y: 384 },//update
        'KFS_B_Spread': { page: 7, x: 528, y: 384 },//update   //Changed
		    'KFS_B_ROI1': { page: 7, x: 428, y: 370 },//update        //Changed
        'KFS_B_TotalInterestAmount': { page: 7, x: 430, y:340},  //Changed
        'KFS_B_FeePayable': { page: 7, x: 422, y: 300 },
        'KFS_B_ThirdPartyPayable': { page: 7, x: 422, y: 260 },
        'KFS_B_NetDisbursedAmount': { page: 7, x: 426, y: 230 },
        'KFS_B_TotalAmountPaidBorrower': { page: 7, x: 426, y: 215 },
        'KFS_B_AnnualPercentageRate': { page: 7, x: 440, y: 180 },
        'KFS_B_DisbursementSchedule': { page: 7, x: 415, y: 150 },

        'DigitalSignatureBankOfficial': { page: 8, x: 90, y: 100 }
    };


      // Define the values object directly in your code
      const values = {
        //  Sanction Letter
        SLApplicationreferencenumber: journey.PMSNumber, //ApplicationRefNo
        SLNameoftheAccount: journey.CustomerName, //CustomerName
        SLNameoftheBorrower: journey.CustomerName, //CustomerName
        SLBOName: branch.BRANCH, // Branch
        SLCOName: branch.CIRCLE, // Circle
        SLSanctionDate: journey.JourneySanctionedDate, // SanctionDate
        SLRs: journey.LoanAmount.toString(),  //AmountInDigits          
        SLINR: NumberToEnglishWords(journey.LoanAmount),  //AmountInWords
        SLRLLR: await GetKeyConfigurationValue('ROI_RLLR') + "%",
     
        SLSpread: await GetKeyConfigurationValue('ROI_SPREAD') + "%",
     
        SLROI: await GetKeyConfigurationValue('ROI') + "%",
        SLRepaymentPeriod: journey.LoanTenure + " Months",
     

        //undertaking
        UDate: journey.JourneySanctionedDate,
        UPlace: branch.CITY,
        UBOName: branch.BRANCH, //Branch   
        URs: journey.LoanAmount.toString() + "/-",  //AmountInDigits
        UINR: NumberToEnglishWords(journey.LoanAmount), //AmountInWords
        UROI: await GetKeyConfigurationValue('ROI') + "%",
        ULoanTenure: journey.LoanTenure, //Branch  
        UBOName1: branch.BRANCH, //Branch   
        UAccountNo: cityKYC.AccountNo.toString(), // AccountNo
        UBorrowerName: journey.CustomerName,  //CustomerName


        //Letter To Bank
        LBDate: journey.JourneySanctionedDate,
        LBPlace: branch.CITY,
        LBRs: journey.LoanAmount.toString() + "/-", // AmountInDigits
        LBBOName: branch.BRANCH,
        LBCustomerName: journey.CustomerName, //CustomerName
        //Letter To Bank

        //Demand Promisary Note       
        DPDate: journey.JourneySanctionedDate,
        DPPlace: branch.CITY,
        DPRs: journey.LoanAmount.toString() + "/-",
        DPRsInWords: NumberToEnglishWords(journey.LoanAmount),
        DPBranchName: branch.BRANCH,
        DPRs1: journey.LoanAmount.toString() + "/-",
        DPRs1InWords: NumberToEnglishWords(journey.LoanAmount),
        // DPHSpreadServiceCharge: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD')) + parseFloat(await GetKeyConfigurationValue('ROI_ServiceCharge'))),
         DPHSpreadServiceCharge: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD'))),
        DPHROI: await GetKeyConfigurationValue('ROI'),
        DPBranchName1: branch.BRANCH,
        DPRs2: journey.LoanAmount.toString() + "/-",  // TotalPricipal
        DPRs2InWords: NumberToEnglishWords(journey.LoanAmount),
        //DPESpreadServiceCharge1: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD')) + parseFloat(await GetKeyConfigurationValue('ROI_ServiceCharge'))),
        DPESpreadServiceCharge1: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD'))),
        DPEROI1: await GetKeyConfigurationValue('ROI'),
        //DPCustomerSign:'Digital Sign', //CustomerName
        DPCustomerName: journey.CustomerName, //CustomerName
        DPCustomerAddress: journey.CommAddress, //CustomerName
        //Demand Promisary Note    

        // // KFS
        KFS_A_AccountNo: journey.PMSNumber, // AccountNo        
        KFS_A_LoanAmount: journey.LoanAmount.toString() + "/-", // AmountInDigits
        KFS_A_LoanAmountInWords: NumberToEnglishWords(journey.LoanAmount),
        KFS_A_LoanTenure: journey.LoanTenure.toString() + ' Months',//LoanTerm
        KFS_A_EPICount1: journey.LoanTenure.toString(), //TotalInstallment
        KFS_A_EPIAmount1: journey.EMI1.toString(),
        KFS_A_RLLR: await GetKeyConfigurationValue('ROI_RLLR') + "%",
        // KFS_A_BSP:await GetKeyConfigurationValue('ROI_BSP')+"%",
        KFS_A_Spread: await GetKeyConfigurationValue('ROI_SPREAD') + "%",
        // KFS_A_Servicecharge: await GetKeyConfigurationValue('ROI_ServiceCharge') + "%",
        KFS_A_ROI1: await GetKeyConfigurationValue('ROI') + "%",
        KFS_A_BenchmarkRate: (parseFloat(await GetKeyConfigurationValue('ROI_RLLR'))) + "%",
        KFS_A_SpreadServiceCharge: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD'))) + "%",
        KFS_A_ROI2: await GetKeyConfigurationValue('ROI') + "%",
        KFS_A_B: '36',
        KFS_A_EPIAmount2: journey.EMI2.toString(), // EMI
        KFS_A_EPICount2: journey.LoanTenure.toString(), // TotalInstallment
        KFS_A_ROI3: await GetKeyConfigurationValue('ROI') + "%",
        KFS_A_BODigiSignName: await GetKeyConfigurationValue('NodalOfficerName'),
        KFS_A_BODigiSignDesignation: await GetKeyConfigurationValue('NodalOfficerDesignation'),
        KFS_A_BODigiSignContactNo: await GetKeyConfigurationValue('NodalOfficerContactNo'),
        KFS_A_BODigiSignEmailId: await GetKeyConfigurationValue('NodalOfficerEmailID'),
        // KFS_A_StampCharge: '10',
        // KFS_A_CICCharge: '100+GST(i.e 18%)',
        KFS_B_LoanAmount: journey.LoanAmount.toString() + "/-",
        KFS_B_LoanTenure: journey.LoanTenure.toString() + ' Months',
        KFS_B_EPIAmount: journey.EMI1.toString(), // EMI
        KFS_B_EPICount: journey.LoanTenure.toString(), // TotalInstallment
        KFS_B_ROI: await GetKeyConfigurationValue('ROI_RLLR') + "%",
		KFS_B_Spread:await GetKeyConfigurationValue('ROI_SPREAD') + "%",
        KFS_B_ROI1: await GetKeyConfigurationValue('ROI') + "%",
        KFS_B_TotalInterestAmount: journey.TotalInterestAmount.toString(), // TotalInterest
        KFS_B_FeePayable: journey.LoanTranche == 3 ? '128' : '10',
        KFS_B_ThirdPartyPayable: journey.LoanTranche == 3 ? '128' : '10',
        KFS_B_NetDisbursedAmount: journey.LoanTranche == 3 ? (journey.LoanAmount - 128).toString() : (journey.LoanAmount - 10).toString() + "/-",
        KFS_B_TotalAmountPaidBorrower: journey.TotalPayableAmount.toString(),
        KFS_B_AnnualPercentageRate: await GetKeyConfigurationValue('ROI') + "%",
        KFS_B_DisbursementSchedule: '100% upfront',

        // KFS

        // DigitalSignatureBankOfficial: 'Bank Digital Sign Here 1'
      };

    
      logger.info('Code Works, no issue find till here 1');

      //logger.info('Amort Array '+JSON.stringify(amortization));

      // Parse the JSON string
      const installments = JSON.parse(JSON.stringify(amortization));

      // Iterate and log each object without brackets
      installments.forEach(installment => {
        logger.info(JSON.stringify(installment));
      });



/******************** AMORTIZATION SCHEDULE (REVISED) ********************/

// 1️⃣ Validate amortization data
if (!Array.isArray(amortization)) {
  logger.error('Amortization schedule is not an array');
  return;
}

// 2️⃣ Log each installment (unchanged, for audit)
amortization.forEach((installment, idx) => {
  logger.info(`Amort Row ${idx + 1}: ` + JSON.stringify(installment));
});

// 3️⃣ Page where amortization table exists
const amortPageIndex = 8;
const amortPage = pdfDoc.getPages()[amortPageIndex];

// 4️⃣ Column X positions (TRANCHE-WISE)
let cols = {};
let startY = 0;
let rowGap = 15; // vertical distance between rows

if (journey.LoanTranche === 1) {
  cols = {
    outstandingPrincipal: 170,
    principal: 270,
    interest: 340,
    installmentAmount: 470
  };
  startY = 610; // calibrated anchor
}

else if (journey.LoanTranche === 2) {
  cols = {
    outstandingPrincipal: 170,
    principal: 270,
    interest: 340,
    installmentAmount: 460
  };
  startY = 610; // calibrated anchor
}

else if (journey.LoanTranche === 3) {
  cols = {
    outstandingPrincipal: 184,
    principal: 280,
    interest: 355,
    installmentAmount: 470
  };
  startY = 610; // calibrated anchor
}

logger.info(
  `Amortization Layout → Tranche: ${journey.LoanTranche}, startY: ${startY}`
);

// 5️⃣ Helper formatter
const formatValue = (val) =>
  val !== null && val !== undefined && val !== ''
    ? Number(val).toFixed(2)
    : '';

// 6️⃣ Draw amortization rows
amortization.forEach((installment, index) => {
  const y = startY - index * rowGap;

  // Safety: avoid footer overlap
  if (y < 100) {
    logger.warn(`Amortization row ${index + 1} skipped (page overflow)`);
    return;
  }

  amortPage.drawText(formatValue(installment.outstandingPrincipal), {
    x: cols.outstandingPrincipal,
    y,
    size: 10
  });

  amortPage.drawText(formatValue(installment.principal), {
    x: cols.principal,
    y,
    size: 10
  });

  amortPage.drawText(formatValue(installment.interest), {
    x: cols.interest,
    y,
    size: 10
  });

  amortPage.drawText(formatValue(installment.installmentAmount), {
    x: cols.installmentAmount,
    y,
    size: 10
  });
});

logger.info('Amortization schedule rendered successfully');

      for (const key in values) {
        if (values.hasOwnProperty(key) && positions[key]) {
          const { page, x, y } = positions[key];
          const pdfPage = pdfDoc.getPages()[page]; // Get the page by index

          // Ensure values[key] is a string before passing to drawText
          const textToDraw = String(values[key]); // Convert to string

          pdfPage.drawText(textToDraw, {
            x,
            y,
            size: 11, // Set the font size as needed            
            color: rgb(0, 0, 0) // Set the text color as needed
          });
        }
      }

      logger.info('Bind Amort');



      const pdfBytes = await pdfDoc.save();
      logger.info('PDF size in bytes:', pdfBytes.length);
      //res.setHeader('Content-Type', 'application/pdf');
      //fs.writeFileSync('test4.pdf', pdfBytes);
      //fs.writeFileSync('../Logs/NeSlSignedDoc/UnsignedDoc'+journey.LoanTranche+'.pdf', pdfBytes);

      // Get the absolute path
      const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSlSignedDoc');
      //const filePath = path.join(outputDir, 'UnsignedDoc' + journey.LoanTranche + '.pdf');
	  //fs.writeFileSync(filePath, pdfBytes);// Write the PDF
	  const tranche = journey.LoanTranche;

const unsignedFileName =  `Unsigned_${journey.PMSNumber}_${journey.JourneyID}_${tranche}_${Date.now()}.pdf`;
	
	  const unsignedPath = path.join(outputDir, unsignedFileName);
		fs.writeFileSync(unsignedPath, pdfBytes);
		logger.info(`[PDF GENERATED] ${unsignedFileName}`);
      

      // res.send(pdfBytes);

      //Insert into Database
      const NeSLSignCoordinates = "410|60"
      const Unsign_Doc_Byte = Buffer.from(pdfBytes)

      const NeSLTranID = 'Nesl_' + journey.JourneyID;
logger.info('NeSLTranID '+NeSLTranID);
      SavePDFBytes(journey.PMSNumber, journey.JourneyID, journey.LoanTranche, Unsign_Doc_Byte, NeSLSignCoordinates, "Insert", NeSLTranID).then(async (objRespSavePDFBytes) => {
        if (objRespSavePDFBytes.ErrorCode == "00") {
          objNeSLDocResp = {
            "ErrorCode": objRespSavePDFBytes.ErrorCode,
            "ErrorMsg": objRespSavePDFBytes.ErrorMsg
          }
          resolve(objNeSLDocResp);
        }
        else {
          objNeSLDocResp = {
            "ErrorCode": objRespSavePDFBytes.ErrorCode,
            "ErrorMsg": objRespSavePDFBytes.ErrorMsg
          }
          resolve(objNeSLDocResp);
        }

      });
    } catch (err1) {
      logger.error('Exception in BindTrancheWisePDFDocument Method: ', err1);
      reject(err1);
    }
  });
}

// function BindTrancheWisePDFDocument(PMSNumber, JourneyID, objBranchInformation, objCustomerJourneyData, objCityKYCInfoData, objAmortizationSchedule) {
  // logger.info('***************************** Inside BindTrancheWisePDFDocument *****************************');
  // logger.info(  `[PDF REQUEST] PMS=${PMSNumber}, Journey=${JourneyID}, Tranche=${objCustomerJourneyData.LoanTranche}`);
  // //logger.info('objCustomerJourneyData ',JSON.stringify(objCustomerJourneyData));
	// if (!PMSNumber || !JourneyID || !objCustomerJourneyData?.LoanTranche) {
	  // throw new Error(
		// `Invalid PDF context | PMS=${PMSNumber}, Journey=${JourneyID}`
	  // );
	// }
  // return new Promise(async (resolve, reject) => {
    // try {
      // // const nodalOfficerName = await GetKeyConfigurationValue('NodalOfficerName'); // Await the promise
      // logger.info(await GetKeyConfigurationValue('NodalOfficerName')) // Await the promise)
      // let ExistingDocByte;
      // if (objCustomerJourneyData.LoanTranche == 1) {


        // logger.info('Tranche ', objCustomerJourneyData.LoanTranche);

        // const filePath = path.resolve(__dirname, 'Documents/TrancheOneN.pdf');
        // if (fs.existsSync(filePath)) {
          // ExistingDocByte = fs.readFileSync(filePath);
        // } else {
          // logger.error('Tranch 1 document not found:', filePath);
        // }

        // //ExistingDocByte = fs.readFileSync('Documents/TrancheOne.pdf');

        // //const existingPdfBytes = await fs.promises.readFile('path/to/your/pdf.pdf');
      // }
      // else if (objCustomerJourneyData.LoanTranche == 2) {
        // logger.info('Tranche ', objCustomerJourneyData.LoanTranche);
        // const filePath = path.resolve(__dirname, 'Documents/TrancheTwo.pdf');
        // if (fs.existsSync(filePath)) {
          // ExistingDocByte = fs.readFileSync(filePath);
        // } else {
          // logger.error('Tranch 2 document not found:', filePath);
        // }
        // //ExistingDocByte = fs.readFileSync('Documents/TrancheTwo.pdf');
      // }
      // else if (objCustomerJourneyData.LoanTranche == 3) {
        // logger.info('Tranche ', objCustomerJourneyData.LoanTranche);
        // const filePath = path.resolve(__dirname, 'Documents/TrancheThree.pdf');
        // if (fs.existsSync(filePath)) {
          // ExistingDocByte = fs.readFileSync(filePath);
        // } else {
          // logger.error('Tranch 2 document not found:', filePath);
        // }
        // //ExistingDocByte = fs.readFileSync('Documents/TrancheThree.pdf');
      // }

      // const pdfDoc = await PDFDocument.load(ExistingDocByte);




      // const defaultFontSize = 12;
     
	  
	   // const positions = {
     

      // 'SLApplicationreferencenumber': { page: 0, x: 240, y: 712 },
        // 'SLNameoftheAccount': { page: 0, x: 192, y: 693 },
        // 'SLNameoftheBorrower': { page: 0, x: 198, y: 675 },
        // 'SLBOName': { page: 0, x: 150, y: 655 },
        // 'SLCOName': { page: 0, x: 118, y: 635 },
        // 'SLSanctionDate': { page: 0, x: 170, y: 619 },
        // 'SLRs': { page: 0, x: 210, y: 574 },
        // 'SLINR': { page: 0, x: 300, y: 576 },
        // 'SLRLLR': { page: 0, x: 230, y: 519 },   //Changed
        // // 'SLBSP':{ page: 0, x: 305, y: 519 },
        // 'SLSpread': { page: 0, x: 313, y: 519 },
        // // 'SLServicecharge': { page: 0, x: 450, y: 519 },
        // 'SLROI': { page: 0, x: 385, y: 519 },
        // 'SLRepaymentPeriod': { page: 0, x: 190, y: 418 },
        // 'SLSignatureofAuthorized': { page: 1, x: 80, y: 620 },
        // 'SLSignatureoftheBorrower': { page: 1, x: 360, y: 620 },
      




        // //Undertaking
        // 'UDate': { page: 2, x: 468, y: 738 },
        // 'UPlace': { page: 2, x: 468, y: 726 },
        // 'UBOName': { page: 2, x: 72, y: 672 },
        // 'URs': { page: 2, x: 252, y: 570 }, //Changed
        // 'UINR': { page: 2, x: 350, y: 570 },
        // 'UROI': { page: 2, x: 298, y: 546 },//update 
        // 'ULoanTenure': { page: 2, x: 510, y: 545 },//Changed
        // 'UBOName1': { page: 2, x: 105, y: 496 },
        // 'UAccountNo': { page: 2, x: 296, y: 443 },
        // 'UBorrowerName': { page: 2, x: 76, y: 350 },



        // //Letter to bank
        // 'LBDate': { page: 3, x: 452, y: 726 },
        // 'LBPlace': { page: 3, x: 455, y: 712 },
        // 'LBRs': { page: 3, x: 90, y: 584 },
        // 'LBBOName': { page: 3, x: 72, y: 658 },
        // 'LBCustomerName': { page: 3, x: 72, y: 232 },


        // //Demand Promisonery Note        
        // 'DPDate': { page: 4, x: 458, y: 670 },
        // 'DPPlace': { page: 4, x: 460, y: 684 },
        // 'DPRs': { page: 4, x: 82, y: 672 },  //changed
        // 'DPRsInWords': { page: 4, x: 146, y: 672 },
        // 'DPBranchName': { page: 4, x: 270, y: 618 },
        // 'DPRs1': { page: 4, x: 80, y: 582 },   //changed
        // 'DPRs1InWords': { page: 4, x: 140, y: 582 },
        // 'DPHSpreadServiceCharge': { page: 4, x: 90, y: 568 },
        // 'DPHROI': { page: 4, x: 340, y: 568 },
        // 'DPBranchName1': { page: 4, x: 178, y: 504 },
        // 'DPRs2': { page: 4, x: 436, y: 491 },           //changed
        // 'DPRs2InWords': { page: 4, x: 82, y: 480 },
        // 'DPESpreadServiceCharge1': { page: 4, x: 500, y: 478 },
        // 'DPEROI1': { page: 4, x: 458, y: 465 },
        // 'DPCustomerSign': { page: 4, x: 350, y: 420 }, //update
        // 'DPCustomerName': { page: 4, x: 410, y: 312 }, //Changed
        // 'DPCustomerAddress': { page: 4, x: 428, y: 298 },   //Changed



        // //  KFS
        // 'KFS_A_AccountNo': { page: 5, x: 230, y: 662 },
        // 'KFS_A_LoanAmount': { page: 5, x: 384, y: 636 },
        // 'KFS_A_LoanAmountInWords': { page: 5, x: 384, y: 610 }, // AmountInDigits
        // 'KFS_A_LoanTenure': { page: 5, x: 385, y: 540 }, //Changed
        // 'KFS_A_EPICount1': { page: 5, x: 195, y: 495}, //Changed
        // 'KFS_A_EPIAmount1': { page: 5, x: 275, y: 495 },//update
        // 'KFS_A_RLLR': { page: 5, x: 390, y: 468 },   //  { page: 5, x: 390, y: 452 }  //Chnaged
        // // 'KFS_A_BSP':{ page: 5, x: 465, y: 452 },
        // 'KFS_A_Spread': { page: 5, x: 472, y: 468 },
        // // 'KFS_A_Servicecharge': { page: 5, x: 442, y: 380 },
        // 'KFS_A_ROI1': { page: 5, x: 350, y: 455 },
        // 'KFS_A_BenchmarkRate': { page: 5, x: 120, y: 350 },  
        // 'KFS_A_BenchmarkRate': { page: 5, x: 120, y: 350 },  //Changed
        // 'KFS_A_SpreadServiceCharge': { page: 5, x: 185, y: 350 },  //Changed
        // 'KFS_A_ROI2': { page: 5, x: 238, y: 350 },  //Changed
        // 'KFS_A_B': { page: 5, x: 290, y: 350 },   //Changed
        // 'KFS_A_EPIAmount2': { page: 5, x: 380, y: 350 }, //Changed
        // 'KFS_A_EPICount2': { page: 5, x: 515, y: 350 },
        // 'KFS_A_StampCharge': { page: 5, x: 452, y: 68 },
        // // 'KFS_A_CICCharge': { page: 6, x: 452, y: 745 },
        // 'KFS_A_ROI3': { page: 6, x: 260, y: 740 },
        // 'KFS_A_BODigiSignName': { page: 6, x: 355, y: 405 },
        // 'KFS_A_BODigiSignDesignation': { page: 6, x: 388, y: 385 },
        // 'KFS_A_BODigiSignContactNo': { page: 6, x: 382, y: 368 },  //{ page: 6, x: 386, y: 328 },
        // 'KFS_A_BODigiSignEmailId': { page: 6, x: 367, y: 355 },

        // 'KFS_B_LoanAmount': { page: 7, x: 428, y: 678 },
        // 'KFS_B_LoanTenure': { page: 7, x: 424, y: 647 },
        // 'KFS_B_EPIAmount': { page: 7, x: 426, y: 530 },     //Changed
        // 'KFS_B_EPICount': { page: 7, x: 420, y: 610},     //Changed
        // 'KFS_B_ROI': { page: 7, x: 455, y: 384 },//update
        // 'KFS_B_Spread': { page: 7, x: 528, y: 384 },//update   //Changed
		    // 'KFS_B_ROI1': { page: 7, x: 428, y: 370 },//update        //Changed
        // 'KFS_B_TotalInterestAmount': { page: 7, x: 430, y:340},  //Changed
        // 'KFS_B_FeePayable': { page: 7, x: 422, y: 300 },
        // 'KFS_B_ThirdPartyPayable': { page: 7, x: 422, y: 260 },
        // 'KFS_B_NetDisbursedAmount': { page: 7, x: 426, y: 230 },
        // 'KFS_B_TotalAmountPaidBorrower': { page: 7, x: 426, y: 215 },
        // 'KFS_B_AnnualPercentageRate': { page: 7, x: 440, y: 180 },
        // 'KFS_B_DisbursementSchedule': { page: 7, x: 415, y: 150 },

        // 'DigitalSignatureBankOfficial': { page: 8, x: 90, y: 100 }
    // };


      // // Define the values object directly in your code
      // const values = {
        // //  Sanction Letter
        // SLApplicationreferencenumber: objCustomerJourneyData.PMSNumber, //ApplicationRefNo
        // SLNameoftheAccount: objCustomerJourneyData.CustomerName, //CustomerName
        // SLNameoftheBorrower: objCustomerJourneyData.CustomerName, //CustomerName
        // SLBOName: objBranchInformation.BRANCH, // Branch
        // SLCOName: objBranchInformation.CIRCLE, // Circle
        // SLSanctionDate: objCustomerJourneyData.JourneySanctionedDate, // SanctionDate
        // SLRs: objCustomerJourneyData.LoanAmount.toString(),  //AmountInDigits          
        // SLINR: NumberToEnglishWords(objCustomerJourneyData.LoanAmount),  //AmountInWords
        // SLRLLR: await GetKeyConfigurationValue('ROI_RLLR') + "%",
        // // SLBSP:await GetKeyConfigurationValue('ROI_BSP')+"%",
        // SLSpread: await GetKeyConfigurationValue('ROI_SPREAD') + "%",
        // // SLServicecharge: await GetKeyConfigurationValue('ROI_ServiceCharge') + "%",
        // SLROI: await GetKeyConfigurationValue('ROI') + "%",
        // SLRepaymentPeriod: objCustomerJourneyData.LoanTenure + " Months",
        // // SLSignatureofAuthorized: 'Bank Digital Sign Here',
        // //SLSignatureoftheBorrower:objCustomerJourneyData.CustomerName,// CustomerName

        // //undertaking
        // UDate: objCustomerJourneyData.JourneySanctionedDate,
        // UPlace: objBranchInformation.CITY,
        // UBOName: objBranchInformation.BRANCH, //Branch   
        // URs: objCustomerJourneyData.LoanAmount.toString() + "/-",  //AmountInDigits
        // UINR: NumberToEnglishWords(objCustomerJourneyData.LoanAmount), //AmountInWords
        // UROI: await GetKeyConfigurationValue('ROI') + "%",
        // ULoanTenure: objCustomerJourneyData.LoanTenure, //Branch  
        // UBOName1: objBranchInformation.BRANCH, //Branch   
        // UAccountNo: objCityKYCInfoData.AccountNo.toString(), // AccountNo
        // UBorrowerName: objCustomerJourneyData.CustomerName,  //CustomerName


        // //Letter To Bank
        // LBDate: objCustomerJourneyData.JourneySanctionedDate,
        // LBPlace: objBranchInformation.CITY,
        // LBRs: objCustomerJourneyData.LoanAmount.toString() + "/-", // AmountInDigits
        // LBBOName: objBranchInformation.BRANCH,
        // LBCustomerName: objCustomerJourneyData.CustomerName, //CustomerName
        // //Letter To Bank

        // //Demand Promisary Note       
        // DPDate: objCustomerJourneyData.JourneySanctionedDate,
        // DPPlace: objBranchInformation.CITY,
        // DPRs: objCustomerJourneyData.LoanAmount.toString() + "/-",
        // DPRsInWords: NumberToEnglishWords(objCustomerJourneyData.LoanAmount),
        // DPBranchName: objBranchInformation.BRANCH,
        // DPRs1: objCustomerJourneyData.LoanAmount.toString() + "/-",
        // DPRs1InWords: NumberToEnglishWords(objCustomerJourneyData.LoanAmount),
        // // DPHSpreadServiceCharge: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD')) + parseFloat(await GetKeyConfigurationValue('ROI_ServiceCharge'))),
         // DPHSpreadServiceCharge: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD'))),
        // DPHROI: await GetKeyConfigurationValue('ROI'),
        // DPBranchName1: objBranchInformation.BRANCH,
        // DPRs2: objCustomerJourneyData.LoanAmount.toString() + "/-",  // TotalPricipal
        // DPRs2InWords: NumberToEnglishWords(objCustomerJourneyData.LoanAmount),
        // //DPESpreadServiceCharge1: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD')) + parseFloat(await GetKeyConfigurationValue('ROI_ServiceCharge'))),
        // DPESpreadServiceCharge1: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD'))),
        // DPEROI1: await GetKeyConfigurationValue('ROI'),
        // //DPCustomerSign:'Digital Sign', //CustomerName
        // DPCustomerName: objCustomerJourneyData.CustomerName, //CustomerName
        // DPCustomerAddress: objCustomerJourneyData.CommAddress, //CustomerName
        // //Demand Promisary Note    

        // // // KFS
        // KFS_A_AccountNo: objCustomerJourneyData.PMSNumber, // AccountNo        
        // KFS_A_LoanAmount: objCustomerJourneyData.LoanAmount.toString() + "/-", // AmountInDigits
        // KFS_A_LoanAmountInWords: NumberToEnglishWords(objCustomerJourneyData.LoanAmount),
        // KFS_A_LoanTenure: objCustomerJourneyData.LoanTenure.toString() + ' Months',//LoanTerm
        // KFS_A_EPICount1: objCustomerJourneyData.LoanTenure.toString(), //TotalInstallment
        // KFS_A_EPIAmount1: objCustomerJourneyData.EMI1.toString(),
        // KFS_A_RLLR: await GetKeyConfigurationValue('ROI_RLLR') + "%",
        // // KFS_A_BSP:await GetKeyConfigurationValue('ROI_BSP')+"%",
        // KFS_A_Spread: await GetKeyConfigurationValue('ROI_SPREAD') + "%",
        // // KFS_A_Servicecharge: await GetKeyConfigurationValue('ROI_ServiceCharge') + "%",
        // KFS_A_ROI1: await GetKeyConfigurationValue('ROI') + "%",
        // KFS_A_BenchmarkRate: (parseFloat(await GetKeyConfigurationValue('ROI_RLLR'))) + "%",
        // KFS_A_SpreadServiceCharge: (parseFloat(await GetKeyConfigurationValue('ROI_SPREAD'))) + "%",
        // KFS_A_ROI2: await GetKeyConfigurationValue('ROI') + "%",
        // KFS_A_B: '36',
        // KFS_A_EPIAmount2: objCustomerJourneyData.EMI2.toString(), // EMI
        // KFS_A_EPICount2: objCustomerJourneyData.LoanTenure.toString(), // TotalInstallment
        // KFS_A_ROI3: await GetKeyConfigurationValue('ROI') + "%",
        // KFS_A_BODigiSignName: await GetKeyConfigurationValue('NodalOfficerName'),
        // KFS_A_BODigiSignDesignation: await GetKeyConfigurationValue('NodalOfficerDesignation'),
        // KFS_A_BODigiSignContactNo: await GetKeyConfigurationValue('NodalOfficerContactNo'),
        // KFS_A_BODigiSignEmailId: await GetKeyConfigurationValue('NodalOfficerEmailID'),
        // // KFS_A_StampCharge: '10',
        // // KFS_A_CICCharge: '100+GST(i.e 18%)',
        // KFS_B_LoanAmount: objCustomerJourneyData.LoanAmount.toString() + "/-",
        // KFS_B_LoanTenure: objCustomerJourneyData.LoanTenure.toString() + ' Months',
        // KFS_B_EPIAmount: objCustomerJourneyData.EMI1.toString(), // EMI
        // KFS_B_EPICount: objCustomerJourneyData.LoanTenure.toString(), // TotalInstallment
        // KFS_B_ROI: await GetKeyConfigurationValue('ROI_RLLR') + "%",
		// KFS_B_Spread:await GetKeyConfigurationValue('ROI_SPREAD') + "%",
        // KFS_B_ROI1: await GetKeyConfigurationValue('ROI') + "%",
        // KFS_B_TotalInterestAmount: objCustomerJourneyData.TotalInterestAmount.toString(), // TotalInterest
        // KFS_B_FeePayable: objCustomerJourneyData.LoanTranche == 3 ? '128' : '10',
        // KFS_B_ThirdPartyPayable: objCustomerJourneyData.LoanTranche == 3 ? '128' : '10',
        // KFS_B_NetDisbursedAmount: objCustomerJourneyData.LoanTranche == 3 ? (objCustomerJourneyData.LoanAmount - 128).toString() : (objCustomerJourneyData.LoanAmount - 10).toString() + "/-",
        // KFS_B_TotalAmountPaidBorrower: objCustomerJourneyData.TotalPayableAmount.toString(),
        // KFS_B_AnnualPercentageRate: await GetKeyConfigurationValue('ROI') + "%",
        // KFS_B_DisbursementSchedule: '100% upfront',

        // // KFS

        // // DigitalSignatureBankOfficial: 'Bank Digital Sign Here 1'
      // };
      // logger.info('Code Works, no issue find till here');
      
      // logger.info('Code Works, no issue find till here 1');

      // //logger.info('Amort Array '+JSON.stringify(objAmortizationSchedule));

      // // Parse the JSON string
      // const installments = JSON.parse(JSON.stringify(objAmortizationSchedule));

      // // Iterate and log each object without brackets
      // installments.forEach(installment => {
        // logger.info(JSON.stringify(installment));
      // });



// /******************** AMORTIZATION SCHEDULE (REVISED) ********************/

// // 1️⃣ Validate amortization data
// if (!Array.isArray(objAmortizationSchedule)) {
  // logger.error('Amortization schedule is not an array');
  // return;
// }

// // 2️⃣ Log each installment (unchanged, for audit)
// objAmortizationSchedule.forEach((installment, idx) => {
  // logger.info(`Amort Row ${idx + 1}: ` + JSON.stringify(installment));
// });

// // 3️⃣ Page where amortization table exists
// const amortPageIndex = 8;
// const amortPage = pdfDoc.getPages()[amortPageIndex];

// // 4️⃣ Column X positions (TRANCHE-WISE)
// let cols = {};
// let startY = 0;
// let rowGap = 15; // vertical distance between rows

// if (objCustomerJourneyData.LoanTranche === 1) {
  // cols = {
    // outstandingPrincipal: 170,
    // principal: 270,
    // interest: 340,
    // installmentAmount: 470
  // };
  // startY = 610; // calibrated anchor
// }

// else if (objCustomerJourneyData.LoanTranche === 2) {
  // cols = {
    // outstandingPrincipal: 170,
    // principal: 270,
    // interest: 340,
    // installmentAmount: 460
  // };
  // startY = 610; // calibrated anchor
// }

// else if (objCustomerJourneyData.LoanTranche === 3) {
  // cols = {
    // outstandingPrincipal: 184,
    // principal: 280,
    // interest: 355,
    // installmentAmount: 470
  // };
  // startY = 610; // calibrated anchor
// }

// logger.info(
  // `Amortization Layout → Tranche: ${objCustomerJourneyData.LoanTranche}, startY: ${startY}`
// );

// // 5️⃣ Helper formatter
// const formatValue = (val) =>
  // val !== null && val !== undefined && val !== ''
    // ? Number(val).toFixed(2)
    // : '';

// // 6️⃣ Draw amortization rows
// objAmortizationSchedule.forEach((installment, index) => {
  // const y = startY - index * rowGap;

  // // Safety: avoid footer overlap
  // if (y < 100) {
    // logger.warn(`Amortization row ${index + 1} skipped (page overflow)`);
    // return;
  // }

  // amortPage.drawText(formatValue(installment.outstandingPrincipal), {
    // x: cols.outstandingPrincipal,
    // y,
    // size: 10
  // });

  // amortPage.drawText(formatValue(installment.principal), {
    // x: cols.principal,
    // y,
    // size: 10
  // });

  // amortPage.drawText(formatValue(installment.interest), {
    // x: cols.interest,
    // y,
    // size: 10
  // });

  // amortPage.drawText(formatValue(installment.installmentAmount), {
    // x: cols.installmentAmount,
    // y,
    // size: 10
  // });
// });

// logger.info('Amortization schedule rendered successfully');

      // for (const key in values) {
        // if (values.hasOwnProperty(key) && positions[key]) {
          // const { page, x, y } = positions[key];
          // const pdfPage = pdfDoc.getPages()[page]; // Get the page by index

          // // Ensure values[key] is a string before passing to drawText
          // const textToDraw = String(values[key]); // Convert to string

          // pdfPage.drawText(textToDraw, {
            // x,
            // y,
            // size: 11, // Set the font size as needed            
            // color: rgb(0, 0, 0) // Set the text color as needed
          // });
        // }
      // }

      // logger.info('Bind Amort');



      // const pdfBytes = await pdfDoc.save();
      // logger.info('PDF size in bytes:', pdfBytes.length);
    

      // // Get the absolute path
      // const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSlSignedDoc');
     
	  // const tranche = objCustomerJourneyData.LoanTranche;

// const unsignedFileName =  `Unsigned_${PMSNumber}_${JourneyID}_${tranche}_${Date.now()}.pdf`;
	
	  // const unsignedPath = path.join(outputDir, unsignedFileName);
		// fs.writeFileSync(unsignedPath, pdfBytes);
		// logger.info(`[PDF GENERATED] ${unsignedFileName}`);
      

      // // res.send(pdfBytes);

      // //Insert into Database
      // const NeSLSignCoordinates = "410|60"
      // const Unsign_Doc_Byte = Buffer.from(pdfBytes)

      // const NeSLTranID = 'Nesl_' + JourneyID;
// logger.info('NeSLTranID '+NeSLTranID);
      // SavePDFBytes(PMSNumber, JourneyID, objCustomerJourneyData.LoanTranche, Unsign_Doc_Byte, NeSLSignCoordinates, "Insert", NeSLTranID).then(async (objRespSavePDFBytes) => {
        // if (objRespSavePDFBytes.ErrorCode == "00") {
          // objNeSLDocResp = {
            // "ErrorCode": objRespSavePDFBytes.ErrorCode,
            // "ErrorMsg": objRespSavePDFBytes.ErrorMsg
          // }
          // resolve(objNeSLDocResp);
        // }
        // else {
          // objNeSLDocResp = {
            // "ErrorCode": objRespSavePDFBytes.ErrorCode,
            // "ErrorMsg": objRespSavePDFBytes.ErrorMsg
          // }
          // resolve(objNeSLDocResp);
        // }

      // });
    // } catch (err1) {
      // logger.error('Exception in BindTrancheWisePDFDocument Method: ', err1);
      // reject(err1);
    // }
  // });
// }


async function GetKeyConfigurationValue(KeyName) {
  logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  const query = `
    SELECT [KeyValue]
    FROM [dbo].[SVND_CONFIGURATION_DATA]
    WHERE KeyName = @KeyName
  `;

  try {
    const pool = await getPool();
    const request = pool.request();

    const result = await request
      .input('KeyName', sql.VarChar, KeyName)
      .query(query);

    if (result.recordset && result.recordset.length > 0) {
      const value = result.recordset[0].KeyValue;
      //logger.info('KeyValue fetched: ' + value);
      return value;
    } else {
      logger.info('No results found for the provided KeyName.');
      return null;
    }

  } catch (err) {
    logger.error('GetKeyConfigurationValue Error:', err);
    return null;
  }
}



async function SavePDFBytes(
  PMSNumber,
  JourneyID,
  LoanTranche,
  Unsign_Doc_Byte,
  NeSLSignCoordinates,
  Operation,
  NeSLTranID
) {
  logger.info('############################# Inside SavePDFBytes Method ##########################');
  logger.info('PMS Number: ' + PMSNumber);
logger.info(`[PDF DB SAVE] PMS=${PMSNumber}, Journey=${JourneyID}, Bytes=${Unsign_Doc_Byte.length}`);

	if (!NeSLTranID.startsWith(`Nesl_${JourneyID}`)) {
	  throw new Error('NeSL Transaction mismatch detected');
	}
  try {
    const pool = await getPool();
    const request = pool.request();

    request
      .input('PMSNumber', sql.NVarChar, PMSNumber)
      .input('JourneyID', sql.VarChar, JourneyID)
      .input('NeSL_Tran_ID', sql.VarChar, NeSLTranID)
      .input('LoanTranche', sql.Int, LoanTranche)
      .input('Unsign_Doc_Byte', sql.VarBinary(sql.MAX), Unsign_Doc_Byte)
      .input('NeSLSignCoordinates', sql.VarChar, NeSLSignCoordinates)
      .input('Operation', sql.VarChar, Operation)
      .output('p_OutStatusCode', sql.NVarChar);

    const result = await request.execute('proc_NeSLPDF_InsertUpdate');

    logger.info('DB Result: '+ JSON.stringify(result));

    if (
      result.output?.p_OutStatusCode === '200' &&
      result.rowsAffected &&
      result.rowsAffected[0] > 0
    ) {
      return {
        ErrorCode: '00',
        ErrorMsg: 'NeSL Document saved successfully'
      };
    }

    return {
      ErrorCode: '01',
      ErrorMsg: 'Failed to save NeSL document'
    };

  } catch (err) {
    logger.error('SavePDFBytes Exception:', err);

    return {
      ErrorCode: 'EX_01',
      ErrorMsg: 'Database error while saving NeSL document'
    };
  }
}


function NumberToEnglishWords(num) {
  if (num === 0) {
    return 'Zero rupees';
  }

  let integerPart = Math.floor(num);
  let decimalPart = num - integerPart;

  let integerWords = '';
  let decimalWords = '';

  if (integerPart > 0) {
    integerWords = helper(integerPart) + ' rupees';
  }

  if (decimalPart > 0) {
    decimalPart = Math.round(decimalPart * 100); // round to 2 decimal places
    decimalWords = ' and ' + helper(decimalPart) + ' paise';
  }

  let result = integerWords + decimalWords;
  return result.charAt(0).toUpperCase() + result.slice(1);
}

function helper(num) {
  const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
  const teens = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
  const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
  const thousands = ['', 'thousand', 'million', 'billion'];

  if (num === 0) {
    return '';
  } else if (num < 10) {
    return ones[num];
  } else if (num < 20) {
    return teens[num - 10];
  } else if (num < 100) {
    return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + ones[num % 10] : '');
  } else if (num < 1000) {
    return ones[Math.floor(num / 100)] + ' hundred' + (num % 100 !== 0 ? ' ' + helper(num % 100) : '');
  } else if (num < 1000000) {
    return helper(Math.floor(num / 1000)) + ' thousand' + (num % 1000 !== 0 ? ' ' + helper(num % 1000) : '');
  } else if (num < 1000000000) {
    return helper(Math.floor(num / 1000000)) + ' million' + (num % 1000000 !== 0 ? ' ' + helper(num % 1000000) : '');
  } else {
    return helper(Math.floor(num / 1000000000)) + ' billion' + (num % 1000000000 !== 0 ? ' ' + helper(num % 1000000000) : '');
  }
}





async function CallStatusData(PMSNumber, JourneyID, NeSLTxnID) {

  logger.info("================================================================================");
  logger.info("🚀 START :: NeSL CallStatusData API");
  logger.info("--------------------------------------------------------------------------------");
  logger.info(`🔑 PMSNumber     : ${PMSNumber}`);
  logger.info(`🧭 JourneyID     : ${JourneyID}`);
  logger.info(`🔗 NeSLTxnID     : ${NeSLTxnID}`);
  logger.info(`🕒 Request Time  : ${new Date().toISOString()}`);
  logger.info("================================================================================");

  try {
    const NeslAuthorization = await GetKeyConfigurationValue('NeslAuthorization');
    const NeSLStatusAPI_URL = await GetKeyConfigurationValue('NeSLStatusAPI_URL');

    const headers = {
      "Content-Type": "application/json",
      Authorization: "Basic " + NeslAuthorization,
    };

    const PlainRequest = {
      digisign: "NeSL Status Doc Data API",
      loanno: PMSNumber,
      transId: NeSLTxnID,
    };

    logger.info("📤 NeSL REQUEST DETAILS");
    logger.info(`🌐 API URL       : ${NeSLStatusAPI_URL}`);
    logger.info(`📦 Plain Request : ${JSON.stringify(PlainRequest, null, 2)}`);

    const APILogsResp = await logError.APIRequestResponseLogs(
      PMSNumber,
      JourneyID,
      "NeSLStatusDataAPI",
      JSON.stringify(PlainRequest),
      JSON.stringify(PlainRequest),
      null,
      null,
      null,
      "Insert"
    );

    if (APILogsResp.ErrorCode !== "00") {
      logger.warn("⚠️ API log insert failed. NeSL API call skipped.");
      return "API log insert failed, skipping API call.";
    }

    const NeSLStatusData = await axios.post(
      NeSLStatusAPI_URL,
      JSON.stringify(PlainRequest),
      { headers, httpsAgent: ProxyAgent,timeout: 120000 }
    );

    const responseData = NeSLStatusData.data;
    const NeSLStatusDataObj = new StatusDataResponse(responseData);

    let result;

    if (NeSLStatusDataObj?.cipherText && NeSLStatusDataObj?.sessionId) {
      const sessionKey = objCommonFunction.PrivatedecryptSessionKey(
        NeSLStatusDataObj.sessionId
      );

      result = objCommonFunction.PKCS5PaddingDecrypt(
        NeSLStatusDataObj.cipherText,
        sessionKey
      );

      await logError.APIRequestResponseLogs(
        PMSNumber,
        JourneyID,
        'CallStatusData',
        null,
        null,
        JSON.stringify(result),
        JSON.stringify(responseData),
        APILogsResp.RequestId,
        "Update"
      );

      return result;
    }

    // Fallback path (ER011, ER005, etc.)
    result = JSON.stringify(responseData);

    await logError.APIRequestResponseLogs(
      PMSNumber,
      JourneyID,
      'CallStatusData',
      null,
      null,
      //JSON.stringify(result),
	  result,
      JSON.stringify(responseData),
      APILogsResp.RequestId,
      "Update"
    );

    return result;

  } catch (err) {
    logger.error("🔥 EXCEPTION IN CallStatusData METHOD");
    logger.error(err.stack || err);
    throw err;   // let caller handle
  }
}



// Define the StatusDataResponse class
class StatusDataResponse {
  constructor(data) {
    this.cipherText = data.cipherText;
    this.sessionId = data.sessionId;
    this.digisign = data.digisign;
    this.transid = data.transid;
    this.statusCode = data.statusCode;
    this.statusMessage = data.statusMessage;
  }
}

function updateNeSLResponse(NeslTranID, PMSNumber, JourneyID, objNeSLReturnObj, UpdateMode) {
  logger.info('###################### Inside updateNeSLResponse Method######################');
  logger.info('Serilizied Object', JSON.stringify(objNeSLReturnObj));
  logger.info(`NeslTranID,${NeslTranID}`);
  logger.info(`PMSNumber,${PMSNumber}`)
  logger.info(`JourneyID,${JourneyID}`)

  return new Promise((resolve, reject) => {

    if (UpdateMode == "NonCallBackAPIUpdate") {
      logger.info(`NonCallBackAPIUpdate`);
      logger.info('statusResponse: ', JSON.stringify(objNeSLReturnObj));
      logger.info('Transaction ID:', objNeSLReturnObj.transId);              // Nel_10014500
      logger.info('Status Code:', objNeSLReturnObj.statusCode);              // 1
      logger.info('Status Message:', objNeSLReturnObj.statusMsg);            // Success
      logger.info('Estamp Certificate:', objNeSLReturnObj.estampCertificate); // ["IN-K41142Q"]

      // // Accessing the nested "docStatus" array and its first element
      const docStatus = objNeSLReturnObj.docStatus[0];  // The first item in the docStatus array

      logger.info(`Signer Name ${docStatus.signtryName}`);         // Vish Ram Meena
      logger.info(`PAN ${docStatus.pan}`);                         // 1170
      logger.info(`Relationship ${docStatus.rltnshp}`);            // DEBTOR
      logger.info(`Esign Status ${docStatus.esignStatus}`);        // Success
      logger.info(`Estamp Status ${docStatus.estampStatus}`);      // Success
      logger.info(`yobPercent ${docStatus.yobPercent}`);
      logger.info(`genderPercent ${docStatus.genderPercent}`);
      logger.info(`aadharPercent ${docStatus.aadharPercent}`);
      logger.info(`Sequence Number ${docStatus.seqNo}`);
      if (objNeSLReturnObj != null && objNeSLReturnObj.statusMsg.trim().toUpperCase() == "SUCCESS") {
        logger.info('Success condition', objNeSLReturnObj.statusMsg.trim().toUpperCase());

        // Decode the Base64 string into a Buffer (equivalent to byte array in C#)
        const DoccumetByteArray = Buffer.from(docStatus.docData, 'base64')
        // Get the absolute path
        const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSlSignedDoc');
        // Ensure the directory exists, if not, create it
         if (!fs.existsSync(outputDir)) {
           fs.mkdirSync(outputDir, { recursive: true });
		 }
        //const filePath = path.join(outputDir, 'NeSlSignedDoc.pdf');
        //fs.writeFileSync(filePath, DoccumetByteArray);// Write the PDF

		const signedFileName = `NeSlSigned_${PMSNumber}_${JourneyID}_${Date.now()}.pdf`;

		const signedPath = path.join(outputDir, signedFileName);
		fs.writeFileSync(signedPath, DoccumetByteArray);

		logger.info(`[PDF SIGNED] ${signedFileName}`);


        //fs.writeFileSync('../Logs/NeSlSignedDoc/NeSlSignedDoc.pdf', DoccumetByteArray);// Download pdf file in folder

        //Update NeSL Document Data in Document Table
        UpdateNeSLDocumentData(PMSNumber, JourneyID, NeslTranID, DoccumetByteArray, objNeSLReturnObj.statusCode, objNeSLReturnObj.statusMsg, docStatus.esignStatus, docStatus.esignDate, docStatus.estampStatus, docStatus.estampDate
          , docStatus.signtryName, docStatus.signedName, docStatus.signatoryYob, docStatus.signedYob, docStatus.yobPercent, docStatus.signatoryGender, docStatus.signedGender, docStatus.genderPercent,
          docStatus.signatoryAadhar, docStatus.signedAadhar, docStatus.aadharPercent, docStatus.matchPercentage
          , objNeSLReturnObj.estampCertificate, 'NeSLSignDocument', UpdateMode).then(async (respUpdateNeslResponseDatabase) => {
            if (respUpdateNeslResponseDatabase.ErrorCode = "00") {
              if (docStatus.esignStatus.toUpperCase() == "SUCCESS") {
                //Update NeSL status in Customer Journey Table
                UpdateNeSLStatusForCustomerJourney(PMSNumber, JourneyID, true, 'NeSL eSign Successfully done').then(async (respUpdateNeSLStatusForCustomerJourney) => {
                  logger.info('Output UpdateNeSLStatusForCustomerJourney ', respUpdateNeSLStatusForCustomerJourney);
                  if (respUpdateNeSLStatusForCustomerJourney) {
                    respJSON = {
                      "ErrorCode": "00",
                      "ErrorMsg": "DDE successfuly done and updated in database"
                    }
                    logger.info('Success DDE updated in Database ' + JSON.stringify(respJSON))
                    resolve(respJSON);
                  }
                  else {
                    respJSON = {
                      "ErrorCode": "01",
                      "ErrorMsg": "Error to update NeSL response in Database"
                    }
                    logger.info('Success DDE updated in Database ' + JSON.stringify(respJSON))
                    resolve(respJSON);
                  }
                });
              }
              else {
                logger.info('Failure for ')
                UpdateNeSLStatusForCustomerJourney(PMSNumber, JourneyID, false, 'NeSL Name/YOB/Aadhaar/Gender Mismatch').then(async (respUpdateNeSLStatusForCustomerJourney) => {
                  logger.info('Output UpdateNeSLStatusForCustomerJourney 1' + respUpdateNeSLStatusForCustomerJourney);
                  respJSON = {
                    "ErrorCode": "04",
                    "ErrorMsg": "NeSL Name/YOB/Aadhaar/Gender Mismatch"
                  }
                  resolve(respJSON);
                  // Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, JourneyID, "Rejected", "NeSL Name/YOB/Aadhaar/Gender Mismatch").then(async (respUpdateJourneyStatus) => {
                  //   logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney NonCallBackAPIUpdate:  " + JSON.stringify(respUpdateJourneyStatus));
                  //   if (respUpdateJourneyStatus.ErrorCode == "00") {
                  //     respJSON = {
                  //       "ErrorCode": "04",
                  //       "ErrorMsg": "NeSL Name/YOB/Aadhaar/Gender Mismatch"
                  //     }
                  //     resolve(respJSON);
                  //   }
                  // });
                });

              }
            }
            else {
              respJSON = {
                "ErrorCode": "01",
                "ErrorMsg": "Error to update NeSL response in DOCUMENT table"
              }
              logger.info('Success DDE updated in Database ' + JSON.stringify(respJSON))
              resolve(respJSON);
            }
          });
      }
      else {
        UpdateNeSLStatusForCustomerJourney(PMSNumber, JourneyID, false, 'Failed at NeSL').then(async (respUpdateNeSLStatusForCustomerJourney) => {
          respJSON = {
            "ErrorCode": "01",
            "ErrorMsg": "Failed at NeSL while document signing"
          }
          resolve(respJSON);
        });
      }
    }
    else if (UpdateMode == "CallBackAPIUpdate") {
      //logger.info(`#$%@#$ CallBackAPIUpdate #$%@#$`);
      //logger.info(`CallBackAPIUpdate for NeSDoc ${objNeSLReturnObj.signedDocData}`);
      // Decode the Base64 string into a Buffer (equivalent to byte array in C#)
      const DoccumetByteArray = Buffer.from(objNeSLReturnObj.signedDocData, 'base64')
      //fs.writeFileSync('../Logs/NeSlSignedDoc.pdf', DoccumetByteArray);// Download pdf file in folder

      // logger.info(`signatoryName: ${objNeSLReturnObj.signatoryName}`); // Nel_10014500
      // logger.info(`matchPercentage: ${objNeSLReturnObj.matchPercentage}`); // 1
      // logger.info(`eSignAffixed: ${objNeSLReturnObj.eSignAffixed}`); // Success
      // logger.info(`eStampAffixed: ${objNeSLReturnObj.eStampAffixed}`); // Empty string or value
      //Update NeSL Document Data in Document Table
      // logError.APIRequestResponseLogs(PMSNumber, JourneyID, "NeSLCallBackAPIResponse", JSON.stringify(objNeSLReturnObj), null, null, null, null, "Insert").then(async (APILogsResp) => {
      //   logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
      //   if (APILogsResp.ErrorCode == "00") {
      UpdateNeSLDocumentData(PMSNumber, JourneyID, NeslTranID, DoccumetByteArray, '1', 'Success', objNeSLReturnObj.eSignAffixed, null, "", null
        , objNeSLReturnObj.signatoryName, objNeSLReturnObj.signedName, objNeSLReturnObj.signatoryYob, objNeSLReturnObj.signedYob, objNeSLReturnObj.yobPercent, objNeSLReturnObj.signatoryGender, objNeSLReturnObj.signedGender, objNeSLReturnObj.genderPercent,
        objNeSLReturnObj.signatoryAadhar, objNeSLReturnObj.signedAadhar, objNeSLReturnObj.aadharPercent, objNeSLReturnObj.matchPercentage
        , null, 'NeSLSignDocument', UpdateMode).then(async (respUpdateNeslResponseDatabase) => {
          if (respUpdateNeslResponseDatabase.ErrorCode = "00") {
            if (objNeSLReturnObj.eSignAffixed.toUpperCase() == "Y") {
              //Update NeSL status in Customer Journey Table
              UpdateNeSLStatusForCustomerJourney(PMSNumber, JourneyID, true, 'NeSL eSign Successfully done').then(async (respUpdateNeSLStatusForCustomerJourney) => {
                // logger.info('Output UpdateNeSLStatusForCustomerJourney ', respUpdateNeSLStatusForCustomerJourney);
                if (respUpdateNeSLStatusForCustomerJourney) {
                  respJSON = {
                    "ErrorCode": "00",
                    "ErrorMsg": "DDE successfuly done and updated in database"
                  }
                  logger.info('Success DDE updated in Database ' + JSON.stringify(respJSON))
                  resolve(respJSON);
                }
                else {
                  respJSON = {
                    "ErrorCode": "01",
                    "ErrorMsg": "Error to update NeSL response in Database"
                  }
                  logger.info('Success DDE updated in Database ' + JSON.stringify(respJSON))
                  resolve(respJSON);
                }
              });
            }
            else {
              //logger.info('Failure response update');
              UpdateNeSLStatusForCustomerJourney(PMSNumber, JourneyID, false, 'NeSL Name/YOB/Aadhaar/Gender Mismatch').then(async (respUpdateNeSLStatusForCustomerJourney) => {
                respJSON = {
                  "ErrorCode": "04",
                  "ErrorMsg": "NeSL Name/YOB/Aadhaar/Gender Mismatch"
                }
                resolve(respJSON);
                //logger.info('Output UpdateNeSLStatusForCustomerJourney ' + respUpdateNeSLStatusForCustomerJourney);
                // Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, JourneyID, null, "Rejected", "Error05", "NeSL Name/YOB/Aadhaar/Gender Mismatch", "NESL").then(async (respUpdateJourneyStatus) => {
                //   logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney CallBackAPIUpdate:  " + JSON.stringify(respUpdateJourneyStatus));
                //   if (respUpdateJourneyStatus.ErrorCode == "00") {
                //     respJSON = {
                //       "ErrorCode": "04",
                //       "ErrorMsg": "NeSL Name/YOB/Aadhaar/Gender Mismatch"
                //     }
                //     resolve(respJSON);
                //   }
                // });
              });
            }
          }
          else {
            respJSON = {
              "ErrorCode": "01",
              "ErrorMsg": "Error to update NeSL response in DOCUMENT table"
            }
            resolve(respJSON);
          }
        });
      //   }
      // });
    }
  });
}



function Sanctioned_Rejected_Suspended_CustomerJourney(
  PMSNumber,
  JourneyID,
  LoanTranche,
  JourneyStatus,
  JourneyRejectionCode,
  JourneyRejectionReason,
  SidbiResponseCode
) {
  logger.info('############################# Called  Sanctioned_Rejected_Suspended_CustomerJourney Start ##########################');
  logger.info('PMSNumber ' + PMSNumber);
  logger.info('JourneyID ' + JourneyID);
  logger.info('JourneyStatus ' + JourneyStatus);
  logger.info('LoanTranche ' + LoanTranche);
  logger.info('JourneyRejectionCode ' + JourneyRejectionCode);
  logger.info('JourneyRejectionReason ' + JourneyRejectionReason);
  logger.info('SidbiResponseCode ' + SidbiResponseCode);

  return new Promise((resolve, reject) => {
    try {
      getPool()
        .then(pool => {
          const request = pool.request();

          request
            .input('PMSNumber', sql.NVarChar, PMSNumber)
            .input('JourneyID', sql.VarChar, JourneyID)
            .input('LoanTranche', sql.Int, LoanTranche)
            .input('JourneyStatus', sql.VarChar, JourneyStatus)
            .input('JourneyRejectionCode', sql.VarChar, JourneyRejectionCode)
            .input('JourneyRejectionReason', sql.VarChar, JourneyRejectionReason)
            .input('SidbiResponseCode', sql.VarChar, SidbiResponseCode)
            .output('p_OutStatusCode', sql.NVarChar)
            .execute(
              'proc_Journey_SanctionedRejectedSuspendedResumeSuspension',
              function (err, queryResult) {
                logger.info("queryResult: " + JSON.stringify(queryResult));
                logger.info("Rows Affacted: " + queryResult.rowsAffected[0]);

                if (
                  queryResult.output.p_OutStatusCode == '200' &&
                  queryResult.rowsAffected[0] > 0
                ) {
                  response = {
                    "ErrorCode": "00",
                    "ErrorMsg": "Journey Status updated successfully.",
                  };
                  resolve(response);
                } else {
                  response = {
                    "ErrorCode": "01",
                    "ErrorMsg": err
                  };
                  resolve(response);
                }
              }
            );
        })
        .catch(poolErr => {
          logger.error('DB Pool Error:', poolErr);
          reject(poolErr);
        });

    } catch (err1) {
      logger.error(`Exception in Sanctioned_Rejected_Suspended_CustomerJourney Method  ${err1}`);
      reject(err1);
    }
  });
}





function UpdateNeSLStatusForCustomerJourney(PMSNumber, JourneyID, StatusFlag, StatusMsg) {
  // logger.info('Inside UpdateNeSLStatusForCustomerJourney Method ')
  // logger.info('StatusFlag ' + StatusFlag)
  // logger.info('StatusMsg ' + StatusMsg)
  return new Promise((resolve, reject) => {
    try {
      const query = `UPDATE SVND_LOAN_JOURNEY_MASTER 
                     SET NeSLDDEStatus=@StatusFlag, 
                         NeSLDDEMessage=@StatusMsg 
                     WHERE PMSNumber=@PMSNumber 
                       AND JourneyID=@JourneyID 
                       AND isJourneyActive=1`;

      getPool()
        .then(async pool => {
          const result = await pool.request()
            .input('PMSNumber', sql.VarChar, PMSNumber)
            .input('JourneyID', sql.VarChar, JourneyID)
            .input('StatusFlag', sql.VarChar, StatusFlag == true ? 'Success' : 'Failure')
            .input('StatusMsg', sql.VarChar, StatusMsg)
            .query(query);

          if (result.rowsAffected[0] > 0) {
            resolve(true);
          } else {
            resolve(false);
          }
        })
        .catch(poolErr => {
          logger.error('DB Pool Error:', poolErr);
          reject(poolErr);
        });
    }
    catch (err1) {
      logger.error('Exception in UpdateNeSLStatusForCustomerJourney Method: ' + err1);
      reject(err1);
    }
  });
}


function UpdateNeSLDocumentData(
  PMSNumber,
  JourneyID,
  NeslTranID,
  DoccumetByteArray,
  statuscode,
  statusmsg,
  esignStatus,
  esignDate,
  estampStatus,
  estampDate,
  signtryName,
  signedName,
  signatoryYob,
  signedYob,
  yobPercent,
  signatoryGender,
  signedGender,
  genderPercent,
  signatoryAadhar,
  signedAadhar,
  aadharPercent,
  matchPercentage,
  estampCertificate,
  DocumentType,
  CallMechanism
) {

  logger.info('############################# Inside  UpdateNeSLDocumentData in DOCUMENT TABLE Method ##########################');
  logger.info(`PMSNumber   ${PMSNumber}`);
  logger.info(`JourneyID   ${JourneyID}`);
  logger.info(`NeslTranID   ${NeslTranID}`);
  logger.info(`esignStatus   ${esignStatus}`);
  logger.info(`esignDate   ${esignDate}`);
  logger.info(`estampStatus   ${estampStatus}`);
  logger.info(`estampDate   ${estampDate}`);
  logger.info(`signtryName   ${signtryName}`);
  logger.info(`signatoryYob   ${signatoryYob}`);
  logger.info(`signedYob   ${signedYob}`);
  logger.info(`yobPercent   ${yobPercent}`);
  logger.info(`signatoryGender   ${signatoryGender}`);
  logger.info(`signedGender   ${signedGender}`);
  logger.info(`genderPercent   ${genderPercent}`);
  logger.info(`signatoryAadhar   ${signatoryAadhar}`);
  logger.info(`signedAadhar   ${signedAadhar}`);
  logger.info(`aadharPercent   ${aadharPercent}`);
  logger.info(`matchPercentage   ${matchPercentage}`);
  logger.info(`estampCertificate   ${estampCertificate}`);
  logger.info(`DocumentType   ${DocumentType}`);

  let strNeSL_eStampID =
    estampCertificate !== null && estampCertificate !== undefined
      ? estampCertificate.toString()
      : '';

  let varesignDate =
    esignDate !== null && esignDate !== undefined
      ? moment(esignDate, 'DD-MM-YYYY').format('YYYY-MM-DD')
      : '';

  let varestampDate =
    estampDate && moment(estampDate, 'DD-MM-YYYY').isValid()
      ? moment(estampDate, 'DD-MM-YYYY').format('YYYY-MM-DD')
      : '';

  return new Promise((resolve, reject) => {
    try {
      getPool()
        .then(pool => {
          const request = pool.request();

          request
            .input('PMSNumber', sql.NVarChar, PMSNumber)
            .input('JourneyID', sql.VarChar, JourneyID)
            .input('NeSL_Tran_ID', sql.VarChar, NeslTranID)
            .input('Document_Byte', sql.VarBinary(sql.MAX), DoccumetByteArray)
            .input('NeSL_StatusCode', sql.VarChar, statuscode)
            .input('NeSL_StatusMsg', sql.VarChar, statusmsg)
            .input('NeSL_eSignStatus', sql.VarChar, esignStatus)
            .input('NeSL_eSignDate', sql.VarChar, varesignDate)
            .input('NeSL_eStampStatus', sql.VarChar, estampStatus)
            .input('NeSL_eStampDate', sql.VarChar, varestampDate)
            .input('NeSL_SigntryName', sql.VarChar, signtryName)
            .input('NeSL_SignedName', sql.VarChar, signedName)
            .input('NeSL_SignatoryYob', sql.VarChar, signatoryYob)
            .input('NeSL_SignedYob', sql.VarChar, signedYob)
            .input('NeSL_yobPercent', sql.VarChar, yobPercent)
            .input('NeSL_SignatoryGender', sql.VarChar, signatoryGender)
            .input('NeSL_SignedGender', sql.VarChar, signedGender)
            .input('NeSL_GenderPercent', sql.VarChar, genderPercent)
            .input('NeSL_SignatoryAadhar', sql.VarChar, signatoryAadhar)
            .input('NeSL_SignedAadhar', sql.VarChar, signedAadhar)
            .input('NeSL_AadharPercent', sql.VarChar, aadharPercent)
            .input('NeSL_MatchPercentage', sql.VarChar, matchPercentage.toString())
            .input('NeSL_eStampID', sql.NVarChar, strNeSL_eStampID)
            .input('CallMechanism', sql.NVarChar, CallMechanism)
            .input('Operation', sql.VarChar, DocumentType)
            .output('p_OutStatusCode', sql.NVarChar)
            .execute('proc_NeSLPDF_Update', function (err, queryResult) {

              logger.info(`queryResult: ${JSON.stringify(queryResult)}`);
              logger.info(`err: ${err}`);
              logger.info(`Rows Affacted: ${queryResult.rowsAffected[0]}`);

              if (
                queryResult.output.p_OutStatusCode == '200' &&
                queryResult.rowsAffected[0] > 0
              ) {
                response = {
                  "ErrorCode": "00",
                  "ErrorMsg": "NeSL response updated in Document Table"
                };
                resolve(response);
              } else {
                response = {
                  "ErrorCode": "01",
                  "ErrorMsg": err
                };
                resolve(response);
              }
            });
        })
        .catch(poolErr => {
          logger.error('DB Pool Error:', poolErr);
          reject(poolErr);
        });
    } catch (err1) {
      logger.error(`Exception in UpdateNeSLDocumentData Method ${err1}`);
      reject(err1);
    }
  });
}





function GetNeslLink(PMSNumber, JourneyID, NeSLTxnID) {
  console.log('***********************Inside GetNeslLink Method******************************');
  console.log('JourneyID ', JourneyID);
  // console.log('statusResponse ',JSON.stringify(statusResponse));

  let NeSLAuthorisation = "UE5CUE1TVkFOSURISTpOb1RZWEF0TA=="; //await GetKeyConfigurationValue('NeslAuthorization');////"UE5CUE1TVkFOSURISTo2Q21OWEcxWg==";
  const NeSLeSignLinkAPI_URL = 'https://api.nesl.co.in/DDEEsignLinkAPI/request/getesignlink/loans/'; //await GetKeyConfigurationValue('NeSLESignLink');////'https://stg.nesl.co.in/DDEEsignLinkAPI/request/getesignlink/loans/';
  
  // let NeSLAuthorisation;
// let NeSLeSignLinkAPI_URL;

// Promise.all([
  // GetKeyConfigurationValue('NeslAuthorization'),
  // GetKeyConfigurationValue('NeSLESignLink')
// ]).then(([auth, url]) => {
  // NeSLAuthorisation = auth;
  // NeSLeSignLinkAPI_URL = url;

  // // ⬇️ keep your existing logic BELOW this point exactly as-is
// });


  return new Promise(async (resolve, reject) => {
    try {

      headers = {
        'Client-Id': 'LocalTesting', // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Basic ' + NeSLAuthorisation
      }

      PlainRequest = {
        loanno: PMSNumber,
        transId: NeSLTxnID
      };
      console.log("PlainRequest For NeSL Link API ", JSON.stringify(PlainRequest));
      logError.APIRequestResponseLogs(PMSNumber, JourneyID, "GetNeslLink", JSON.stringify(PlainRequest), JSON.stringify(PlainRequest), null, null, null, "Insert").then(async (APILogsResp) => {
        console.log("API Log Insert code for NeSL Link API " + APILogsResp.ErrorCode)
        if (APILogsResp.ErrorCode == "00") {
          console.log('Here we are calling NeSL Link Data API Axios');
          await axios.post(NeSLeSignLinkAPI_URL, JSON.stringify(PlainRequest), { headers, httpsAgent: ProxyAgent }).then(async NeSLLinkData => {
            console.log('Response: NeSL Link API', JSON.stringify(NeSLLinkData.data, null, 2));
            if (JSON.stringify(NeSLLinkData.data, null, 2) != null) {

              logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(NeSLLinkData.data), JSON.stringify(NeSLLinkData.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                console.log("API Log Update code for NeSL Link API " + APILogsResp.ErrorCode)
                if (APILogsResp.ErrorCode == "00") {
                  resolve(NeSLLinkData.data);

                }
                else {
                  resolve(null);
                }
              });
            }
          }).catch(error => {
            console.error('Error posting to GetNeslLink API:', error);
            // console.error('Error Loan Status Inquiry API Error Response:',error.response);
            // console.error('Error Loan Status Inquiry API Error Response Text:',error.response.statusText);
            // console.error('Error Loan Status Inquiry API Error Response data:',error.response.data);
            logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "GetNeslLink").then(async (ErrorLogResp) => {
              ExceptionResp = {
                "ErrorCode": "01",
                "ErrorMsg": error.response.status + " - " + error.response.statusText,
              }
              resolve(ExceptionResp);
            });
          });
        }
      });
    } catch (err1) {
      console.log('Exception err1: ', +err1);
      reject(err1);
    }
  });
}

class NeSLReturnObj {
  constructor(txnID, status, rsp_msg, matchPercentage) {
    this.txnID = txnID || '';
    this.status = status || '';
    this.rsp_msg = rsp_msg || '';
    this.matchPercentage = matchPercentage || '';
    this.nesl_api_signer = ''; // You can set this later if needed
  }

  // Method to update the return object
  async updateReturnObj(appID) {
    return await NeSLDBO.updateDocumentNeslRsp(this, appID);
  }
}

function PostNeslData(
  PMSNumber,
  JourneyID,
  objCityKYCInfoData,
  objBranchInformation,
  objCustomerJourneyData,
  objNeSLDocumentData,
  objCustomerDetails,
  aadhar
) {

  logger.info("================================================================================");
  logger.info("🚀 START :: PostNeslData");
  logger.info("--------------------------------------------------------------------------------");
  logger.info(`🔑 PMSNumber   : ${PMSNumber}`);
  logger.info(`🧭 JourneyID   : ${JourneyID}`);
  logger.info(`📄 NeSLTxnID   : ${objNeSLDocumentData?.NeSL_Tran_ID}`);
  logger.info(`🕒 Start Time  : ${new Date().toISOString()}`);
  logger.info(`🕒 aadhar  : ${aadhar}`);
  logger.info("================================================================================");

  return new Promise(async (resolve, reject) => {
    try {

      /* =======================
         INPUT OBJECT LOGGING
      ======================== */

      logger.info("📥 INPUT DATA RECEIVED");
      logger.info("--------------------------------------------------------------------------------");
      logger.info(`CustomerDetails        : ${JSON.stringify(objCustomerDetails, null, 2)}`);
      logger.info(`CityKYCInfoData         : ${JSON.stringify(objCityKYCInfoData, null, 2)}`);
      logger.info(`BranchInformation       : ${JSON.stringify(objBranchInformation, null, 2)}`);
      logger.info(`CustomerJourneyData     : ${JSON.stringify(objCustomerJourneyData, null, 2)}`);
      logger.info(`NeSLDocumentData        : ${JSON.stringify(objNeSLDocumentData, null, 2)}`);
      logger.info("--------------------------------------------------------------------------------");

      /* =======================
         LOAD CONFIGURATION
      ======================== */

      const NeslAuthorization = await GetKeyConfigurationValue('NeslAuthorization');
      const NeslAPIKey = await GetKeyConfigurationValue('NeslAPIKey');
      const NeslClientID = await GetKeyConfigurationValue('NeslClientID');
      const DDE_API_URL = await GetKeyConfigurationValue('NeSL_DDE_URL');
      const NeslRepURL = await GetKeyConfigurationValue('NeslRepURL');

      logger.info("⚙️ CONFIGURATION LOADED");
      logger.info("--------------------------------------------------------------------------------");
      logger.info(`DDE_API_URL  : ${DDE_API_URL}`);
      logger.info(`NeslClientID : ${NeslClientID}`);
      logger.info(`NeslRepURL   : ${NeslRepURL}`);
      logger.info("--------------------------------------------------------------------------------");

      /* =======================
         ENCRYPT METADATA
      ======================== */

      logger.info("🔐 STARTING METADATA ENCRYPTION");
      logger.info("--------------------------------------------------------------------------------");

      EncryptData(
        PMSNumber,
        JourneyID,
        objCityKYCInfoData,
        objBranchInformation,
        objCustomerJourneyData,
        objNeSLDocumentData,
        objCustomerDetails,
		aadhar
      ).then(async (objEncryptDataResp) => {

        if (!objEncryptDataResp) {
          logger.error("❌ Encryption returned NULL");
          return reject("Encryption failed");
        }

        logger.info("✅ METADATA ENCRYPTED SUCCESSFULLY");
        logger.info(`Encrypted META_DATA Length : ${objEncryptDataResp.length}`);
        logger.info("--------------------------------------------------------------------------------");

        /* =======================
           BUILD NeSL HTML FORM
        ======================== */

        // const postJSUAT = `
// <!DOCTYPE html>
// <html>
// <head></head>
// <body onload='document.forms[0].submit()'>
  // <form action="${DDE_API_URL}" method="post">
    // <input id="api-key" name="api-key" type="hidden" value="${NeslAPIKey}" />
    // <input id="Authorization" name="Authorization" type="hidden" value="Basic ${NeslAuthorization}" />
    // <input id="META_DATA" name="META_DATA" type="hidden" value="${objEncryptDataResp}" />
    // <input id="clientID" name="clientID" type="hidden" value="${NeslClientID}" />
    // <input id="resp-url" name="resp-url" type="hidden" value="${NeslRepURL}" />
  // </form>
// </body>
// </html>`;

		const redirectPayload = {
		  DDE_API_URL,
		  apiKey: NeslAPIKey,
		  authorization: NeslAuthorization,
		  metaData: objEncryptDataResp,
		  clientID: NeslClientID,
		  respUrl: NeslRepURL
		};

        logger.info("📤 NeSL FORM PAYLOAD GENERATED");
        logger.info("--------------------------------------------------------------------------------");
        //logger.info(`HTML Payload Size : ${postJSUAT.length}`);
        logger.info("--------------------------------------------------------------------------------");

        /* =======================
           WRITE PAYLOAD TO FILE
        ======================== */

        // const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSLRequestFiles');
        // const fileName = `NeslRequestPayLoad_${objNeSLDocumentData.NeSL_Tran_ID}.txt`;
        // const filePath = path.join(outputDir, fileName);

        // fs.writeFileSync(filePath, postJSUAT);
		
		const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSLRequestFiles');
		const fileName = `NeslRequestPayLoad_${objNeSLDocumentData.NeSL_Tran_ID}.json`;
		const filePath = path.join(outputDir, fileName);

		fs.writeFileSync(filePath, JSON.stringify(redirectPayload, null, 2));

        logger.info("📁 NeSL REQUEST PAYLOAD WRITTEN TO FILE");
        logger.info("--------------------------------------------------------------------------------");
        logger.info(`File Path : ${filePath}`);
        logger.info("--------------------------------------------------------------------------------");

        logger.info("================================================================================");
        logger.info("✅ END :: PostNeslData");
        logger.info("================================================================================");

        //return resolve(postJSUAT);
		return resolve(redirectPayload);
      });

    } catch (err) {

      logger.error("🔥 EXCEPTION IN PostNeslData");
      logger.error("--------------------------------------------------------------------------------");
      logger.error(err.stack || err);
      logger.error("--------------------------------------------------------------------------------");

      reject(err);
    }
  });
}


function EncryptData(PMSNumber, JourneyID, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objNeSLDocumentData, objCustomerDetails,aadhar) {
  logger.info('');
  logger.info('');
  logger.info('*******************Inside EncryptData Method********************');
  // console.log('*******************Inside EncryptData Method********************');
  // console.log('***************************************');
  return new Promise(async (resolve, reject) => {
    try {
		
		
	
      // console.log('Unsign_Doc_Byte', objNeSLDocumentData.Unsign_Doc_Byte); 
      // Access the data property directly from the Buffer object
      const bufferData = Buffer.from(objNeSLDocumentData.Unsign_Doc_Byte);

      // Convert the Buffer to base64
      const DocBase64Byte = bufferData.toString('base64');
      logger.info('Document data in base64:' + DocBase64Byte.length);
      // fs.writeFileSync('test5.pdf', docData);

      const outputDir1 = path.resolve(__dirname, '..', 'Logs', 'TestDocs');
      const filePath1 = path.join(outputDir1, "abc.pdf");
      fs.writeFileSync(filePath1, DocBase64Byte);// Write the PDF

      const NeSLTxn_ID = objNeSLDocumentData.NeSL_Tran_ID;
      //console.log('objNeSLDocumentData:', JSON.stringify(objNeSLDocumentData));
      //  console.log('NeSLTxn_ID:', NeSLTxn_ID);

      let eStampStatus = objNeSLDocumentData.NeSL_eStampStatus
      logger.info(`########## eStampStatus: ${eStampStatus} ##########`);
      let isEligibleForeStamp;
      if (eStampStatus == "Success")
        isEligibleForeStamp = "N"
      else
        isEligibleForeStamp = "Y"


      logger.info(`########## is Eligible For eStamp: ${isEligibleForeStamp} ##########`);

      const neslsign = new NeSLJsonObject(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp,aadhar);

      //logger.info('Out NeSLJsonObject', neslsign);
      //console.log('Out NeSLJsonObject', neslsign);
      //fs.writeFileSync('../Logs/NeSLRequestFiles/NeslPlainRequestJSON_'+JourneyID+'.txt', JSON.stringify(neslsign));

      const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSLRequestFiles');
      const filePath = path.join(outputDir, 'NeslPlainRequestJSON_' + JourneyID + '.txt');
      fs.writeFileSync(filePath, JSON.stringify(neslsign));// Write the PDF


      const key = crypto.randomBytes(32); // For AES-256, use 32 bytes
      logger.info(`Generated AES Key:${key.toString('hex')}`);
      //console.log('Generated AES Key:', key.toString('hex'));
      const sessionId = key.toString('base64');
      //console.log('Plain SessionID: ',sessionId);
      logger.info(`Plain SessionID: ${sessionId}`);

      const EncSessionID = objCommonFunction.EncryptSessionKey(sessionId);
      logger.info(`Enc SessionID: ${EncSessionID}`);

      const EncRequest = objCommonFunction.PKCS5PaddingEncrypt(JSON.stringify(neslsign), key);
      //console.log('Enc Request: ',EncRequest);

      // console.log('Enc SessionID: ',EncSessionID);
      let combinedEncRequest = EncSessionID + ":" + EncRequest;
      resolve(combinedEncRequest);
    } catch (err1) {
      logger.error('Exception in EncryptData Method: ', err1);
      reject(err1);
    }
  });


}

class NeSLJsonObject {
  constructor(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp,aadhar) {
    // console.log('Inside Loan', DocBase64Byte);
    this.loan = new Loan(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp,aadhar);
  }
}

class Loan {
  constructor(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp,aadhar) {
    this.loanno = PMSNumber || '';
    this.snctnno = PMSNumber || '';
    this.regType = '1';
    this.signFlag = '1';
    this.txnID = NeSLTxn_ID;
    this.loanDocFlag = null;
    this.estampFlag = isEligibleForeStamp;
    this.f2f = 'Y';
    this.state = 'DL';
    this.estampdtls = [new EstampDetail(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp)];
    this.prtcptentty = [new ParticipantEntity(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp,aadhar)];
    this.loandtls = new LoanDetails(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp);
    this.documentdtls = [new DocumentDetail(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp)];

    this.scrtydtls = null;
    this.eSignCordinates = [new ESignCordinate()];
  }
}

class EstampDetail {
  constructor(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp) {
    this.firstparty = objCustomerJourneyData.CustomerName;
    this.considerationPrice = objCustomerJourneyData.LoanAmount;
    this.stampDutyAmount = '10';
    this.stampdutyPaidby = objCustomerJourneyData.CustomerName;
    this.secondparty = 'Punjab National Bank';
    this.documentID = '1';
    this.articleCode = '1097';
    this.descriptionofDocument = 'Personal loan';
  }
}

class ParticipantEntity {
  constructor(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp,aadhar) {
    this.prtcptenttyId = '1';
    this.altemlid = '';
    this.altmobno = '';
    this.cntrprtyaddr = objCustomerDetails.PermAddress1 + ' ' + objCustomerDetails.PermAddress2;//Permanent Address
    this.cntrprtycntmobno = objCustomerJourneyData.MobileNo;
    this.cntrprtycntnm = '';
    this.comaddr = objCustomerDetails.CommAddr1 + ' ' + objCustomerDetails.CommAddr2;//Communication Address
    this.doi = objCustomerDetails.Actual_Date_of_Birth;
    this.lglcnstn = 'Resident Individual';
    this.emlid = '';
    this.fulnm = objCustomerJourneyData.CustomerName;
    this.panno = '';
    this.partytyp = 'Indian Entity';
    this.pin = objCustomerDetails.CommPINCode;
    this.regoffpin = '';
    this.reltocntrct = 'debtor';
    this.ovdtype = 'others';
    this.ovdid = aadhar.substring(8, aadhar.length);//objCustomerJourneyData.AadhaarNo.substring(8, objCustomerJourneyData.AadhaarNo.length);
    this.documentID = [1];
    this.seqno = 1;
    this.signatoryGender = objCustomerDetails.Gender;
    this.signatoryAadhar = aadhar.substring(8, aadhar.length);//objCustomerJourneyData.AadhaarNo.substring(8, objCustomerJourneyData.AadhaarNo.length);
  }
}

class LoanDetails {
  constructor(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp) {
    this.chgamt = '0.00';
    this.crdtsubtyp = 'NPL';//National Portal Loans
    this.currofsanc = 'INR';
    this.dtofsnctn = objCustomerJourneyData.SanctionedOrRejectedDate;
    this.fcltynm = 'Personal Loan';
    this.fundtyp = 'Funded';
    this.isacctclosed = 'No';
    this.ntrofcrdt = 'financial';
    this.rtofint = '13.12';
    this.snctnamt = objCustomerJourneyData.LoanAmount;
    this.emiamt = objCustomerJourneyData.EMI;
    this.tenure = objCustomerJourneyData.LoanTenure;
    this.toutstndamt = objCustomerJourneyData.TotalPayableAmount;
  }
}

class DocumentDetail {
  constructor(PMSNumber, JourneyID, NeSLTxn_ID, DocBase64Byte, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objCustomerDetails, isEligibleForeStamp) {
    this.docData = DocBase64Byte;
    this.documentID = 1;
    // this.prtcptenttyId = 1;
  }
}

class ESignCordinate {
  constructor() {
    this.prtcptenttyId = 1;
    this.documentID = 1;
    this.coordinates = [
      "2, 360, 240",
      "3, 447, 770",
      "4, 447, 770",
      "5, 350, 420",
      "8, 447, 770",
      "9, 447, 770"
    ];
  }
}



function StateCodeName(CommStateName) {
  console.log('**************** Inside StateCodeName Method for State ' + CommStateName);
  return new Promise((resolve, reject) => {
    try {
      const query = `
        SELECT [State_Name],[State_Code_Word],[State_Code_Number]
        FROM [PMSvanidhiDB].[dbo].[SVND_STATE_MASTER]
        WHERE State_Name=@CommStateName
      `;

      getPool()
        .then(async (pool) => {
          const result = await pool.request()
            .input('CommStateName', sql.VarChar, CommStateName)
            .query(query);

          const jsonString = JSON.stringify(result.recordset, null, 2);
          formattedString = jsonString.slice(1, -1);
          // console.log('results:', formattedString);
          resolve(formattedString);
        })
        .catch(poolErr => {
          reject(poolErr);
        });

    } catch (err1) {
      reject(err1);
    }
  });
}




module.exports = { BindTrancheWisePDFDocument, CallStatusData, GetNeslLink, PostNeslData, StateCodeName, GetKeyConfigurationValue, updateNeSLResponse, Sanctioned_Rejected_Suspended_CustomerJourney, getPDFDocumentContext };