// CBSLayer.js


// const path = require('path');
// require('dotenv').config({ path: path.join(__dirname, '../.env') });//It Works

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';// Disable ssl check due to bank's proxy server

const express = require("express");
const axios = require('axios');
//const sql = require("mssql");
const app = express();
var cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { sql, getPool } = require('./db');

app.use(express.json())
app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

const { HttpsProxyAgent } = require('https-proxy-agent');//for System Proxy
const https = require('https');

const fs = require('fs');

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('CBSDataLayer');
 //const objGeneralOperation = require('./GeneralDataLayer');
const logError = require('./ErrorLog');
const objCommonFunction = require('./CommonFunctions');
const objNeSLLayer = require('./NeSLDataLayer.js');
const objAadhaarDataLayer = require('./AadhaarDataLayer');
const objGeneralOperation = require('./GeneralDataLayer.js');
// Set up cookie parser middleware
app.use(cookieParser());

//SQL Server configuration
// var config = {
//  user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000
//   },
//   "options": {
//     "encrypt": false
//   }
// }


var config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

// Define your proxy URL (you can get this from environment variables or hardcode it)
// const proxyUrl =process.env.HTTPS_PROXY ;
// const ProxyAgent = new HttpsProxyAgent(proxyUrl);


// const agent = new https.Agent({
//    rejectUnauthorized: false, // Set to false to bypass certificate verification 
//    HttpsProxyAgent:proxyUrl 
// });

const httpAgent = new https.Agent({
  rejectUnauthorized: false, // Set to false to bypass certificate verification
});



function generateCBSTokenAPI(PMSNumber, JourneyID) {
  logger.info('Inside generateCBSAPIToken');

  return new Promise(async (resolve, reject) => {
    try {
      const TOKEN_API_URL = await GetKeyConfigurationValue('CBS_TokenAPI_URL');
      const UserID = await GetKeyConfigurationValue('CBS_API_UserID');
      const Password = await GetKeyConfigurationValue('CBS_API_Password');
      logger.info('TOKEN API URL: ' + TOKEN_API_URL);
      Plainbody = 'grant_type=password&username=' + UserID + '&password=' + Password;
      //Plainbody='grant_type=password&username=ESVNUSer&password=pnb@12345';
      //logger.info('body: '+Plainbody);
      logger.info(`Plain Body ${JSON.stringify(Plainbody)}`);
      logger.info('Body: ' + JSON.stringify(Plainbody));
      //Insert Error Log
      logError.APIRequestResponseLogs(PMSNumber, JourneyID, "generateCBSTokenAPI", JSON.stringify(Plainbody), JSON.stringify(Plainbody), null, null, null, "Insert").then(async (APILogsResp) => {
        logger.info("Insert ErrorCode in generateCBSTokenAPI " + APILogsResp.ErrorCode)
        logger.info(`API Log Insert With ErrorCode as here ${APILogsResp.ErrorCode}`);
        if (APILogsResp.ErrorCode == "00") {

          await axios.post(TOKEN_API_URL, Plainbody).then(async Response => {
            logger.info(`CBS Response for Token Generate API  ${Response.data}`);
            //logger.info('CBS Response for Token Generate API: ',Response.data.expires_in);
            // Response.data={
            //   access_token: 'rFe0hdJV5z6hIIJtHdlqzr8p0Sg8qIiiKH6vFJuEJZoDJGKV18cTJb-ojmIDnJF6PlMse2Mjrbrsm5UZ0fMQVsU9rbbKGEODHtQ5eEPSTJ8Bj9MRLfwtASgM4G076l-FqALfkb__u44MgxKlnUzSIe4-rDfVuDu5v2Jk2uFug-1czbRJC7NpLcSb9R-gsAdWy9U3RA45pP2-h1QuO9b3tIYq-LXSI7XWWnYYj3JvD8A51ky_fnVaV-xsOzBr0yB63zvdtMLLwBbOc2U9ENbomLLl4XHrVV5iU3UqvVhGnPqLHI1O0bi0ZKpWeL15e-EJ',
            //   token_type: 'bearer',
            //   expires_in: 86399
            // };
            // logger.info('CBS Response for Token Generate API: ',Response.data);
            // logger.info('CBS Response for Token Generate API: ',Response.data.expires_in);
            if (Response.data != null) {
              logger.info('Log RequestID', APILogsResp.RequestId);

              logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(Response.data), JSON.stringify(Response.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {

                logger.info("API Log Updated With ErrorCode " + APILogsResp.ErrorCode)
                if (APILogsResp.ErrorCode == "00") {
                  CBSToken_Insert(Response.data).then(async (APITokenInsert) => {
                    logger.info(`Out CBSToken_Insert Result  ${JSON.stringify(APITokenInsert)}`);
                    //  logger.info('Out CBSToken_Insert Result: ', APITokenInsert.ErrorCode);
                    //  logger.info('Out CBSToken_Insert Result: ', APITokenInsert.ErrorMsg);
                    if (APITokenInsert.ErrorCode == "00") {
                      resp = {
                        "ErrorCode": "00",
                        "ErrorMsg": "Token successfully generated and saved in database",
                        "AccessToken": Response.data.access_token
                      }
                      resolve(resp);
                    }
                  });
                }
              });
            }
          }).catch(error => {
           
            console.error('Error Loan Status Inquiry API Error Response Text:', error.response.statusText);
            console.error('Error Loan Status Inquiry API Error Response data:', error.response.data);
            logger.error(`Error posting to CBS Token Generate API  ${error}`);
            logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSTokenGenerateAPI").then(async (ErrorLogResp) => {
              resp = {
                "ErrorCode": "01",
                "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
              }
              resolve(resp);
            });
          });
        }
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}

// function CBSToken_Insert(TokenAPIResp) {
  // logger.info('Inside CBSToken_Insert Complete String: ' + TokenAPIResp.expires_in);
  // logger.info('Inside CBSToken_Insert Access Token: ' + TokenAPIResp.access_token);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `INSERT INTO SVND_CBS_API_TOKEN (access_token, token_type, expire,EntryBy) VALUES (@access_token, @token_type, @expires,@EntryBy)`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // logger.info('Query: ' + query);
        // const result = await pool.request()
          // .input('access_token', sql.Text, TokenAPIResp.access_token)
          // .input('token_type', sql.VarChar, TokenAPIResp.token_type)
          // .input('expires', sql.Int, TokenAPIResp.expires_in)
          // .input('EntryBy', sql.VarChar, "System")
          // .query(query);
        // logger.info('Result Length: ' + JSON.stringify(result));
        // logger.info('Rows Affacted: ' + result.rowsAffected[0]);
        // if (result.recordsets && result.rowsAffected[0] == 1) {
          // formattedString = {
            // "ErrorCode": "00",
            // "ErrorMsg": "CBS API Token Inserted Successfully."
          // }
          // resolve(formattedString);
        // }
        // else {
          // logger.info('else:');
          // formattedString1 = {
            // "ErrorCode": "01",
            // "ErrorMsg": "Error to insert CBS API Token in database."
          // }
          // resolve(formattedString1);
        // }
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function CBSToken_Insert(TokenAPIResp) {
  // logger.info('Inside CBSToken_Insert Complete String: ' + TokenAPIResp.expires_in);
  // logger.info('Inside CBSToken_Insert Access Token: ' + TokenAPIResp.access_token);

  // return new Promise(async (resolve, reject) => {
    // try {
      // const query = `
        // INSERT INTO SVND_CBS_API_TOKEN (access_token, token_type, expire, EntryBy)
        // VALUES (@access_token, @token_type, @expires, @EntryBy)
      // `;

      // const pool = await getPool();
      // const request = pool.request();

      // const result = await request
        // .input('access_token', sql.Text, TokenAPIResp.access_token)
        // .input('token_type', sql.VarChar, TokenAPIResp.token_type)
        // .input('expires', sql.Int, TokenAPIResp.expires_in)
        // .input('EntryBy', sql.VarChar, "System")
        // .query(query);

      // logger.info('Result: ' + JSON.stringify(result));
      // logger.info('Rows Affected: ' + result.rowsAffected[0]);

      // if (result.rowsAffected && result.rowsAffected[0] === 1) {
        // resolve({
          // "ErrorCode": "00",
          // "ErrorMsg": "CBS API Token Inserted Successfully."
        // });
      // } else {
        // resolve({
          // "ErrorCode": "01",
          // "ErrorMsg": "Error to insert CBS API Token in database."
        // });
      // }

    // } catch (err) {
      // logger.error('CBSToken_Insert Error:', err);
      // reject(err);
    // }
  // });
// }

function CBSToken_Insert(TokenAPIResp) {
  logger.info('Inside CBSToken_Insert Access Token insert');

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        INSERT INTO SVND_CBS_API_TOKEN
        (access_token, token_type, expire, EntryBy)
        VALUES (@access_token, @token_type, @expires, @EntryBy)
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('access_token', sql.Text, TokenAPIResp?.access_token || null)
        .input('token_type', sql.VarChar, TokenAPIResp?.token_type || null)
        .input('expires', sql.Int, TokenAPIResp?.expires_in || 0)
        .input('EntryBy', sql.VarChar, 'System')
        .query(query);

      logger.info('Rows Affected: ' + result.rowsAffected[0]);

      if (result.rowsAffected && result.rowsAffected[0] === 1) {
        resolve({
          ErrorCode: '00',
          ErrorMsg: 'CBS API Token Inserted Successfully.'
        });
      } else {
        resolve({
          ErrorCode: '01',
          ErrorMsg: 'Error inserting CBS API Token in database.'
        });
      }

    } catch (err) {
      logger.error('CBSToken_Insert Error:', err);
      //reject(err);
	  resolve({
          ErrorCode: '01',
          ErrorMsg: 'Error inserting CBS API Token in database.'
        });
    }
  });
}

//APIM Calling 
function generateAPIMTokenAPI(PMSNumber, JourneyID) {
  logger.info('Inside generateAPIMAPIToken');

  return new Promise(async (resolve, reject) => {
    try {
     // const TOKEN_API_URL = await GetKeyConfigurationValue('APIMAccess token');

  const TOKEN_API_URL='https://apim.pnbuat.bank.in/apimgateway/1/OAuthChannel/OAuth2SG/v1/AccessTokenService'
      const UserID = await GetKeyConfigurationValue('CBS_API_UserID');
      const Password = await GetKeyConfigurationValue('CBS_API_Password');
      logger.info('TOKEN API URL: ' + TOKEN_API_URL);
      Plainbody = 'grant_type=password&username=' + UserID + '&password=' + Password;
      //Plainbody='grant_type=password&username=ESVNUSer&password=pnb@12345';
      logger.info('body: '+Plainbody);
      logger.info(`Plain Body ${JSON.stringify(Plainbody)}`);
      logger.info('Body: ' + JSON.stringify(Plainbody));
      //Insert Error Log
      logError.APIRequestResponseLogs(PMSNumber, JourneyID, "generateAPIMTokenAPI", JSON.stringify(Plainbody), JSON.stringify(Plainbody), null, null, null, "Insert").then(async (APILogsResp) => {
        logger.info("Insert ErrorCode in generateCBSTokenAPI " + APILogsResp.ErrorCode)
        logger.info(`API Log Insert With ErrorCode as here ${APILogsResp.ErrorCode}`);
        if (APILogsResp.ErrorCode == "00") {


await axios.post(TOKEN_API_URL, Plainbody.trim(), {
  headers: {
    'Content-Type': 'text/plain'
  }
}).then(async (Response) => {
         // await axios.post(TOKEN_API_URL, Plainbody).then(async Response => {
            logger.info(`APIM response for Token Generate API  ${Response.data}`);
            //logger.info('CBS Response for Token Generate API: ',Response.data.expires_in);
            // Response.data={
            //   access_token: 'rFe0hdJV5z6hIIJtHdlqzr8p0Sg8qIiiKH6vFJuEJZoDJGKV18cTJb-ojmIDnJF6PlMse2Mjrbrsm5UZ0fMQVsU9rbbKGEODHtQ5eEPSTJ8Bj9MRLfwtASgM4G076l-FqALfkb__u44MgxKlnUzSIe4-rDfVuDu5v2Jk2uFug-1czbRJC7NpLcSb9R-gsAdWy9U3RA45pP2-h1QuO9b3tIYq-LXSI7XWWnYYj3JvD8A51ky_fnVaV-xsOzBr0yB63zvdtMLLwBbOc2U9ENbomLLl4XHrVV5iU3UqvVhGnPqLHI1O0bi0ZKpWeL15e-EJ',
            //   token_type: 'bearer',
            //   expires_in: 86399
            // };
            // logger.info('CBS Response for Token Generate API: ',Response.data);
            // logger.info('CBS Response for Token Generate API: ',Response.data.expires_in);
            if (Response.data != null) {
              logger.info('Log RequestID', APILogsResp.RequestId);

              logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(Response.data), JSON.stringify(Response.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {

                logger.info("API Log Updated With ErrorCode " + APILogsResp.ErrorCode)
                if (APILogsResp.ErrorCode == "00") {
                  APIMToken_Insert(Response.data).then(async (APITokenInsert) => {
                    logger.info(`Out CBSToken_Insert Result  ${JSON.stringify(APITokenInsert)}`);
                    //  logger.info('Out CBSToken_Insert Result: ', APITokenInsert.ErrorCode);
                    //  logger.info('Out CBSToken_Insert Result: ', APITokenInsert.ErrorMsg);
                    if (APITokenInsert.ErrorCode == "00") {
                      resp = {
                        "ErrorCode": "00",
                        "ErrorMsg": "Token successfully generated and saved in database",
                        "AccessToken": Response.data.access_token
                      }
                      resolve(resp);
                    }
                  });
                }
              });
            }
          }).catch(error => {
            // console.error('Error posting to Loan Status API:',error);
            // console.error('Error Loan Status Inquiry API Error Response:',error.response);
            console.error('APIM TOKEN API :', error.response.statusText);
            console.error('APIM TOKEN API Error Response data:', error.response.data);
            logger.error(`Error posting to APIM Token Generate API  ${error}`);
            logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSTokenGenerateAPI").then(async (ErrorLogResp) => {
              resp = {
                "ErrorCode": "01",
                "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
              }
              resolve(resp);
            });
          });
        }
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}





function APIMToken_Insert(TokenAPIResp) {
  logger.info('Inside CBSToken_Insert Complete String: ' + TokenAPIResp.expires_in);
  logger.info('Inside CBSToken_Insert Access Token: ' + TokenAPIResp.access_token);
  return new Promise((resolve, reject) => {
    try {
      const query = `INSERT INTO SVND_CBS_API_TOKEN (access_token, token_type, expire,EntryBy) VALUES (@access_token, @token_type, @expires,@EntryBy)`;
      var conn = new sql.ConnectionPool(config);
      conn.connect().then(async function (pool) {
        logger.info('Query: ' + query);
        const result = await pool.request()
          .input('access_token', sql.Text, TokenAPIResp.access_token)
          .input('token_type', sql.VarChar, TokenAPIResp.token_type)
          .input('expires', sql.Int, TokenAPIResp.expires_in)
          .input('EntryBy', sql.VarChar, "System")
          .query(query);
        logger.info('Result Length: ' + JSON.stringify(result));
        logger.info('Rows Affacted: ' + result.rowsAffected[0]);
        if (result.recordsets && result.rowsAffected[0] == 1) {
          formattedString = {
            "ErrorCode": "00",
            "ErrorMsg": "CBS API Token Inserted Successfully."
          }
          resolve(formattedString);
        }
        else {
          logger.info('else:');
          formattedString1 = {
            "ErrorCode": "01",
            "ErrorMsg": "Error to insert CBS API Token in database."
          }
          resolve(formattedString1);
        }
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}
function CallCityKYCInfoAPIForSOLValidate(AadhaarNumber, PMSNumber, AccessToken, BOUserSOL) {
  logger.info('******************************* Inside CityKYCInfoAPI *******************************');
  logger.info('Aadhaar No ' + AadhaarNumber);
  return new Promise(async (resolve, reject) => {
    try {
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';
      logger.info('API_URL ', API_URL);
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + AccessToken
      }
      logger.info('headers ', headers);
      let AadharData = {
        "Aadhar": AadhaarNumber
      }
      let Plainbody = {
        "OperationName": "CityInfoKYCStatus",
        "RequestData": JSON.stringify(AadharData)
      }
      logger.info('Plain Request ', Plainbody);

      objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Request: ' + JSON.stringify(body));

          axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
            logger.info('Enc Response ', resp.data);

            let encresp = JSON.parse(JSON.stringify(resp.data));
            //logger.info('encresp.EncRespData: '+encresp.EncRespData)
            //Decrypt CityKYCStatus Response
            objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
              if (PlainResponse != null) {
                logger.info("Plain Response: " + PlainResponse)
                //Insert data in database
                let ParseCityKYCRespSatus = JSON.parse(PlainResponse);
                logger.info('ParseCityKYCRespSatus' + ParseCityKYCRespSatus);
                logger.info('Status' + ParseCityKYCRespSatus.Status);
                logger.info('ResponseData' + ParseCityKYCRespSatus.ResponseData);
                if (ParseCityKYCRespSatus.Status == "Success") {
                  let ParseCityKYCRespData = JSON.parse(ParseCityKYCRespSatus.ResponseData);
                  logger.info('ParseCityKYCRespData', ParseCityKYCRespData);


                  logger.info('Login user SOLID' + BOUserSOL);
                  ParseCityKYCRespData.Sol = ParseCityKYCRespData.Sol;                       '236900'; //010710//236900
                  logger.info('Customer SOLID' + ParseCityKYCRespData.Sol);

                  if (BOUserSOL != ParseCityKYCRespData.Sol) {
                    outResp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "This application does not pertains to your sol"
                    }
                    resolve(outResp);
                  }
                  else {
                    let CityKYCInsertResponse = {
                      "ErrorCode": "00",
                      "ErrorMsg": "SOl ID Validation pass"
                    }
                    resolve(CityKYCInsertResponse);
                  }
                }
                else {
                  let CityKYCInsertResponse = {
                    "ErrorCode": "01",
                    "ErrorMsg": ParseCityKYCRespSatus.ResponseData,
                    "StatusCode": ParseCityKYCRespSatus.Status
                  }
                  resolve(CityKYCInsertResponse);
                }
              }
            });
          }).catch(error => {
            console.error('Error posting to CallCityKYCInfoAPIForSOLValidate:', error);
            
            console.error('Error in CallCityKYCInfoAPIForSOLValidate Error Response Text:', error.response.statusText);
            console.error('Error in CallCityKYCInfoAPIForSOLValidate API Error Response data:', error.response.data);
            logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSCityKYCInfoAPI").then(async (ErrorLogResp) => {
              resp = {
                "ErrorCode": "01",
                "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
              }
              resolve(resp);
            });
          });

        }
      });
    } catch (err1) {
      logger.info("Error Raised at CallCityKYCInfoAPIForSOLValidate: "+err1);
      reject(err1);
    }
  });
}

async function fetchRefKeyByAadhaar(AadhaarNumber) {
    try {
        const respfromuid = await objAadhaarDataLayer.GetDataByUIDAPI(AadhaarNumber);

        const vaultData = respfromuid?.Data?.vaultData;
        const refKey = vaultData?.refKey;

        logger.info("vaultData:", vaultData);
        logger.info("refKey:", refKey);

        return refKey;
    } catch (err) {
        logger.error("Error in fetchRefKeyByAadhaar:", err);
        return null;
    }
}


function CityKYCInfoAPI(AadhaarNumber, PMSNumber, JourneyID, AccessToken) {

  logger.info('******************************* Inside CityKYCInfoAPI *******************************');
  logger.info('Aadhaar No ' + AadhaarNumber);
  logger.info('JourneyID ' + JourneyID);

    


  return new Promise(async (resolve, reject) => {
    try {
refKey=AadhaarNumber;


      //  // ✅ ✅ ✅ CALL YOUR NEW FUNCTION HERE
      // let refKey = await fetchRefKeyByAadhaar(AadhaarNumber);
      // logger.info("RefKey received inside CityKYCInfoAPI:", refKey);

      // if (!refKey) {
      //   return resolve({
      //     ErrorCode: "01",
      //     ErrorMsg: "Unable to fetch Aadhaar refKey. Please retry."
      //   });
      // } 

      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';
      logger.info('API_URL is '+ API_URL);
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + AccessToken
      }
      logger.info('headers ', headers);
      let AadharData = {
        "Aadhar": AadhaarNumber    
      }
      let Plainbody = {
        "OperationName": "CityInfoKYCStatus",
        "RequestData": JSON.stringify(AadharData)
      }
      logger.info('Plain Request ', Plainbody);

      objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Request: ' + JSON.stringify(body));
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CityKYCInfoAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("API Log Insert ErrorCode CityKYCInfoAPI " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                logger.info('Enc Response ', resp.data);

                let encresp = JSON.parse(JSON.stringify(resp.data));
                //logger.info('encresp.EncRespData: '+encresp.EncRespData)
                //Decrypt CityKYCStatus Response
                objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logger.info("Plain Response: " + PlainResponse)
                    //Insert data in database
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("API Log Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        let ParseCityKYCRespSatus = JSON.parse(PlainResponse);
                        logger.info('ParseCityKYCRespSatus', ParseCityKYCRespSatus);
                        logger.info('Status', ParseCityKYCRespSatus.Status);
                        logger.info('ResponseData', ParseCityKYCRespSatus.ResponseData);
                        if (ParseCityKYCRespSatus.Status == "Success") {
                          let ParseCityKYCRespData = JSON.parse(ParseCityKYCRespSatus.ResponseData); 
                         logger.info('HIIIIIIParseCityKYCRespData ',ParseCityKYCRespData);
                          CBSCityKYCStatus_Insert(ParseCityKYCRespData, refKey, PMSNumber, JourneyID).then(async (CityKycRespInsert) => {
                            if (CityKycRespInsert.ErrorCode == "00") {


                         
                            if (ParseCityKYCRespData && ParseCityKYCRespData.Sol) {
  let sol = ParseCityKYCRespData.Sol;
 // console.log("Sol value:", sol);  // Expected output: "036710"
} else {
  console.log("Sol is not available in the response");
}
                           // const solid = ParseCityKYCRespData.Sol;

 //logger.info('BTHHHHParseCityKYCRespDataSolid55678',  (JSON.parse(ParseCityKYCRespData).solid));
                            
                              //change as per latest pmsvanidhi requirment
                             



                                  const { getBranchInformation } = await import('./GeneralDataLayer.js');
    
    // Call the getBranchInformation function from GeneralDataLayer
    const RespBranchInformation = await getBranchInformation(ParseCityKYCRespData.Sol);

    // Continue with your logic after retrieving the branch information
    logger.info("RespBranchInformation: " + JSON.stringify(RespBranchInformation));
    let ParseRespBranchInformation = JSON.parse(RespBranchInformation);
            






                            //objGeneralOperation.getBranchInformation(ParseCityKYCRespData.Sol).then(async (RespBranchInformation) =>
                              {

                             //  objGeneralOperation.getBranchInformation(JSON.parse(ParseCityKYCRespData).Sol).then(async (RespBranchInformation) => {
                              // logger.info("RespCustomerJourneyData"+JSON.stringify(RespCustomerJourneyData));
                              //let ParseRespBranchInformation=JSON.parse(RespBranchInformation);
                             // Check for account open date validation
                              const AccountOpenDate=ParseCityKYCRespData.AcctOpenDate;
                              logger.info(`AccountOpenDate: ${AccountOpenDate}`)
                              // logger.info(CityKYCResp.AcctOpenDate)
                              const [day, month, year] = AccountOpenDate.split('-');
                              const formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;                       
                              const acctOpenDate = new Date(formattedDate);
                              const currentDate = new Date();//Today Date Time
                              const differenceInTime = currentDate.getTime() - acctOpenDate.getTime();
                              const differenceInDays = Math.floor(differenceInTime / (1000 * 3600 * 24));

                              logger.info('Account Older Days: '+differenceInDays);
                              logger.info("KYC Status: ",ParseCityKYCRespData.Kyc)
                              let outResp="";
                              if(differenceInDays<90 )//Current date is more than 90 days from  account open date
                              { 
                                outResp={
                                  "ErrorCode":"01",
                                  "ErrorMsg":"You are not eligible for Digital Journey,please contact the concerned PNB branch"   //Account must be older than 3 months.
                                }                                          
                                resolve(outResp);  
                              }
                            
                              if (ParseCityKYCRespData.Kyc != "S") {
                                outResp = {
                                  "ErrorCode": "01",
                                  "ErrorMsg": "Your KYC Status is not complied as per our records. Please visit your PNB Branch for further assistance."
                                }
                                resolve(outResp);
                              }
                              else {
                                let CityKYCInsertResponse = {
                                  "ErrorCode": CityKycRespInsert.ErrorCode,
                                  "ErrorMsg": CityKycRespInsert.ErrorMsg
                                }
                                resolve(CityKYCInsertResponse);
                              }
                                }//);
                            }
                            else {
                              let CityKYCInsertResponse = {
                                "ErrorCode": CityKycRespInsert.ErrorCode,
                                "ErrorMsg": CityKycRespInsert.ErrorMsg
                              }
                              resolve(CityKYCInsertResponse);
                            }
                          });
                        }
                        else if (ParseCityKYCRespSatus.Status == "Failure") {
                          let CityKYCInsertResponse = {
                            "ErrorCode": "01",
                            "ErrorMsg": ParseCityKYCRespSatus.ResponseData,
                            "StatusCode": ParseCityKYCRespSatus.Status
                          }
                          resolve(CityKYCInsertResponse);
                        }

                      }
                    });
                  }
                });
              }).catch(error => {
                console.error('Error posting to CityKYCInfoAPI:', error);
                
                console.error('Error in CityKYCInfoAPI Error Response Text:', error.response.statusText);
                console.error('Error in CityKYCInfoAPI Error Response data:', error.response.data);
                logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSCityKYCInfoAPI").then(async (ErrorLogResp) => {
                  resp = {
                    "ErrorCode": "01",
                    "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                  }
                  resolve(resp);
                });
              });
            }
          });
        }
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}


// Inside your CBSDataLayer.js

// Inside CBSDataLayer.js














// async function CityKYCInfoAPI1(AadhaarNumber, PMSNumber, JourneyID, AccessToken) {
//   logger.info('******************************* Inside CityKYCInfoAPI *******************************');
//   logger.info(`Aadhaar No: ${AadhaarNumber}`);
//   logger.info(`JourneyID: ${JourneyID}`);

//   return new Promise(async (resolve, reject) => {
//     try {
//       const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
//       const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
//       const headers = {
//         'Client-Id': ClientID,
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${AccessToken}`,
//       };

//       logger.info(`API_URL: ${API_URL}`);
//       logger.info(`Headers: ${JSON.stringify(headers)}`);

//       const Plainbody = {
//         OperationName: 'CityInfoKYCStatus',
//         RequestData: JSON.stringify({ Aadhar: AadhaarNumber }),
//       };

//       logger.info(`Plain Request: ${JSON.stringify(Plainbody)}`);

//       const EncResponse = await objCommonFunction.Encrypt(JSON.stringify(Plainbody));
//       if (!EncResponse) throw new Error('Encryption failed');

//       const body = { EncReqData: EncResponse };
//       logger.info(`Enc Request: ${JSON.stringify(body)}`);

//       const APILogsResp = await logError.APIRequestResponseLogs(
//         PMSNumber, JourneyID, 'CityKYCInfoAPI',
//         JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, 'Insert'
//       );

//       logger.info(`API Log Insert ErrorCode CityKYCInfoAPI: ${APILogsResp.ErrorCode}`);

//       if (APILogsResp.ErrorCode !== '00')
//         throw new Error('Failed to insert API request logs');

//       // 🔹 Call CBS API
//       const resp = await axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent });
//       logger.info(`Enc Response: ${JSON.stringify(resp.data)}`);

//       const encresp = resp.data;
//       const PlainResponse = await objCommonFunction.Decrypt(encresp.EncRespData);

//       if (!PlainResponse) throw new Error('Decryption returned null');

//       logger.info(`Plain Response: ${PlainResponse}`);

//       // 🔹 Update API log
//       await logError.APIRequestResponseLogs(
//         PMSNumber, JourneyID, null, null, null,
//         JSON.stringify(PlainResponse), JSON.stringify(resp.data),
//         APILogsResp.RequestId, 'Update'
//       );

//       const ParseCityKYCRespStatus = typeof PlainResponse === 'string' ? JSON.parse(PlainResponse) : PlainResponse;

//       logger.info(`ParseCityKYCRespStatus: ${JSON.stringify(ParseCityKYCRespStatus)}`);

//       if (ParseCityKYCRespStatus.Status === 'Success') {
//         const ParseCityKYCRespData =
//           typeof ParseCityKYCRespStatus.ResponseData === 'string'
//             ? JSON.parse(ParseCityKYCRespStatus.ResponseData)
//             : ParseCityKYCRespStatus.ResponseData;

//         const CityKycRespInsert = await CBSCityKYCStatus_Insert(ParseCityKYCRespData, AadhaarNumber, PMSNumber, JourneyID);

//         if (CityKycRespInsert.ErrorCode === '00') {
//           try {
//           //  // const solId = ParseCityKYCRespData.Sol || ParseCityKYCRespData.solid;
//           //   const solId = ParseCityKYCRespData.Sol;
//           //   const RespBranchInformation = await objGeneralOperation.getBranchInformation(solId);
//           //   const ParseRespBranchInformation =
//           //     typeof RespBranchInformation === 'string'
//           //       ? JSON.parse(RespBranchInformation)
//           //       : RespBranchInformation;

//           //   const AccountOpenDate = ParseCityKYCRespData.AcctOpenDate;
//           //   logger.info(`AccountOpenDate: ${AccountOpenDate}`);

//           //   const [day, month, year] = AccountOpenDate.split('-');
//           //   const formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
//           //   const acctOpenDate = new Date(formattedDate);
//           //   const differenceInDays = Math.floor((Date.now() - acctOpenDate.getTime()) / (1000 * 3600 * 24));

//           //   logger.info(`Account Older Days: ${differenceInDays}`);
//           //   logger.info(`KYC Status: ${ParseCityKYCRespData.Kyc}`);

//           //   if (differenceInDays < 90) {
//           //     return resolve({
//           //       ErrorCode: '01',
//           //       ErrorMsg: 'You are not eligible for Digital Journey, please contact the concerned PNB branch',
//           //     });
//           //   }

//             if (ParseCityKYCRespData.Kyc !== 'S') {
//               return resolve({
//                 ErrorCode: '01',
//                 ErrorMsg: 'Your KYC Status is not complied as per our records. Please visit your PNB Branch for further assistance.',
//               });
//             }

//             return resolve({
//               ErrorCode: CityKycRespInsert.ErrorCode,
//               ErrorMsg: CityKycRespInsert.ErrorMsg,
//             });
//           } catch (innerErr) {
//             logger.error(`Error inside branch info or KYC validation: ${innerErr.stack || innerErr}`);
//             return resolve({
//               ErrorCode: '01',
//               ErrorMsg: 'Error while validating branch or KYC data',
//             });
//           }
//         } else {
//           return resolve({
//             ErrorCode: CityKycRespInsert.ErrorCode,
//             ErrorMsg: CityKycRespInsert.ErrorMsg,
//           });
//         }
//       } else {
//         return resolve({
//           ErrorCode: '01',
//           ErrorMsg: ParseCityKYCRespStatus.ResponseData || 'CBS API returned failure',
//           StatusCode: ParseCityKYCRespStatus.Status,
//         });
//       }
//     } catch (err) {
//       logger.error(`CityKYCInfoAPI failed: ${err.stack || err}`);
//       try {
//         await logError.ErrorLogs(PMSNumber, JourneyID, err.status || '500', err.message, 'CBSCityKYCInfoAPI');
//       } catch (logErr) {
//         logger.error(`Error while logging exception: ${logErr.stack || logErr}`);
//       }

//       resolve({
//         ErrorCode: '01',
//         ErrorMsg: 'System error occurred. Please retry after sometime or contact your branch for further assistance.',
//       });
//     } finally {
//       logger.info('******************************* End CityKYCInfoAPI *******************************');
//     }
//   });
// }


function CBSCityKYCStatus_Insert(CityKYCRespData, AadhaarNumber, PMSNumber, JourneyID) {

  logger.info('**************************Inside CBSCityKYCStatus_Insert ************************');
  logger.info('inside CBSCityKYCStatus_Insert AadhaarNumber is ' + AadhaarNumber);
  logger.info('inside CBSCityKYCStatus_Insert PMSNumber is ' + PMSNumber);
  logger.info('inside CBSCityKYCStatus_Insert JourneyID is ' + JourneyID);
  logger.info('inside CBSCityKYCStatus_Insert CityKYCRespData is ' + JSON.stringify(CityKYCRespData));

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('AadhaarNumber', sql.VarChar, AadhaarNumber)
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('CustomerID', sql.VarChar, CityKYCRespData.Custid)
        .input('CommunicationCity', sql.VarChar, CityKYCRespData.CommCity)
        .input('CommunicationZIP', sql.VarChar, CityKYCRespData.CommZIP)
        .input('KYCStatus', sql.VarChar, CityKYCRespData.Kyc)
        .input('AccountNo', sql.VarChar, CityKYCRespData.Acct)
        .input('AcctOpenDate', sql.VarChar, CityKYCRespData.AcctOpenDate)
        .input('solid', sql.VarChar, CityKYCRespData.Sol)
        .execute('proc_CBS_CityKYCInfo_InsertUpdate');

     // //logger.info('QueryResult ' + JSON.stringify(result));

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({
          "ErrorCode": "00",
          "ErrorMsg": "CBS API City KYC status saved successfully."
        });
      } else {
        resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error to save City kyc details in database."
        });
      }

    } catch (err) {
      logger.error('CBSCityKYCStatus_Insert Error:', err);
//      reject(err);

resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error to save City kyc details in database."
        });
    }
  });
}

function CityKYCInfoAPIM(AadhaarNumber, PMSNumber, JourneyID, AccessToken) {

  logger.info('******************************* Inside CityKYCInfoAPIM *******************************');
  logger.info('Aadhaar No ' + AadhaarNumber);
  logger.info('JourneyID ' + JourneyID);
  return new Promise(async (resolve, reject) => {
    try {
       refKey=AadhaarNumber;


      //  // ✅ ✅ ✅ CALL YOUR NEW FUNCTION HERE
      // let refKey = await fetchRefKeyByAadhaar(AadhaarNumber);
      // logger.info("RefKey received inside CityKYCInfoAPI:", refKey);

      // if (!refKey) {
      //   return resolve({
      //     ErrorCode: "01",
      //     ErrorMsg: "Unable to fetch Aadhaar refKey. Please retry."
      //   });
      // } 

         const API_URL = await GetKeyConfigurationValue('APIMCityKYCStatus');
      const ClientID = await GetKeyConfigurationValue('APIMClientID');
      logger.info('API_URL is '+ API_URL);
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + AccessToken
      }

    
      logger.info('headers ', headers);
      let AadharData = {
        "Aadhar": AadhaarNumber    
      }
      let Plainbody = {
        "OperationName": "CityInfoKYCStatus",
        "RequestData": JSON.stringify(AadharData)
      }
      logger.info('Plain Request ', Plainbody);

  objCommonFunction.APIMEncrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Request: ' + JSON.stringify(body));
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CityKYCInfoAPIMAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("API Log Insert ErrorCode CityKYCInfoAPIMAPI " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                logger.info('Enc Response ', resp.data);

                let encresp = JSON.parse(JSON.stringify(resp.data));
                //logger.info('encresp.EncRespData: '+encresp.EncRespData)
                //Decrypt CityKYCStatus Response
                objCommonFunction.APIMDecrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logger.info("Plain Response: " + JSON.stringify(PlainResponse));
                    //Insert data in database
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CityKYCInfoAPIMAPI", null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("API Log Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        let ParseCityKYCRespSatus = JSON.parse(JSON.stringify(PlainResponse));
                        logger.info('ParseCityKYCRespSatus', JSON.stringify(ParseCityKYCRespSatus));
                        logger.info('Status', JSON.stringify(ParseCityKYCRespSatus.Status));
                        logger.info('ResponseData', JSON.stringify(ParseCityKYCRespSatus.ResponseData));
                        if (ParseCityKYCRespSatus.Status == "Success") {
                          let ParseCityKYCRespData = JSON.parse(JSON.stringify(ParseCityKYCRespSatus.ResponseData)); 
                         logger.info('HIIIIIIParseCityKYCRespData ',ParseCityKYCRespData);
                         
                          CBSCityKYCStatus_InsertAPIM(ParseCityKYCRespData, refKey, PMSNumber, JourneyID).then(async (CityKycRespInsert) => {
                         
                  
                            if (CityKycRespInsert.ErrorCode == "00") {

                         
                            if (ParseCityKYCRespData && ParseCityKYCRespData.Sol) {
                          let sol = ParseCityKYCRespData.Sol;

                               } else {
                                  console.log("Sol is not available in the response");
                               }
                           // const solid = ParseCityKYCRespData.Sol;

 //logger.info('BTHHHHParseCityKYCRespDataSolid55678',  (JSON.parse(ParseCityKYCRespData).solid));
                            
                              //change as per latest pmsvanidhi requirment
                             



                                  const { getBranchInformation } = await import('./GeneralDataLayer.js');
    
    // Call the getBranchInformation function from GeneralDataLayer
    const RespBranchInformation = await getBranchInformation(ParseCityKYCRespData.Sol);

    // Continue with your logic after retrieving the branch information
    logger.info("RespBranchInformation: " + JSON.stringify(RespBranchInformation));
    let ParseRespBranchInformation = JSON.parse(RespBranchInformation);
            






                            //objGeneralOperation.getBranchInformation(ParseCityKYCRespData.Sol).then(async (RespBranchInformation) =>
                              {

                             //  objGeneralOperation.getBranchInformation(JSON.parse(ParseCityKYCRespData).Sol).then(async (RespBranchInformation) => {
                              // logger.info("RespCustomerJourneyData"+JSON.stringify(RespCustomerJourneyData));
                              //let ParseRespBranchInformation=JSON.parse(RespBranchInformation);
                             // Check for account open date validation
                              const AccountOpenDate=ParseCityKYCRespData.AcctOpenDate;
                              logger.info(`AccountOpenDate: ${AccountOpenDate}`)
                              // logger.info(CityKYCResp.AcctOpenDate)
                              const [day, month, year] = AccountOpenDate.split('-');
                              const formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;                       
                              const acctOpenDate = new Date(formattedDate);
                              const currentDate = new Date();//Today Date Time
                              const differenceInTime = currentDate.getTime() - acctOpenDate.getTime();
                              const differenceInDays = Math.floor(differenceInTime / (1000 * 3600 * 24));

                              logger.info('Account Older Days: '+differenceInDays);
                              logger.info("KYC Status: "+ParseCityKYCRespData.Kyc)
                              let outResp="";
                              if(differenceInDays<90 )//Current date is more than 90 days from  account open date
                              { 
                                outResp={
                                  "ErrorCode":"01",
                                  "ErrorMsg":"You are not eligible for Digital Journey,please contact the concerned PNB branch"   //Account must be older than 3 months.
                                }                                          
                                resolve(outResp);  
                              }
                            
                              if (ParseCityKYCRespData.Kyc != "S") {
                                outResp = {
                                  "ErrorCode": "01",
                                  "ErrorMsg": "Your KYC Status is not complied as per our records. Please visit your PNB Branch for further assistance."
                                }
                                resolve(outResp);
                              }
                              else {
                                let CityKYCInsertResponse = {
                                  "ErrorCode": CityKycRespInsert.ErrorCode,
                                  "ErrorMsg": CityKycRespInsert.ErrorMsg
                                }
                                resolve(CityKYCInsertResponse);
                              }
                                }//);
                            }
                            else {
                              let CityKYCInsertResponse = {
                                "ErrorCode": CityKycRespInsert.ErrorCode,
                                "ErrorMsg": CityKycRespInsert.ErrorMsg
                              }
                              resolve(CityKYCInsertResponse);
                            }
                          });
                        }
                        else if (ParseCityKYCRespSatus.Status == "Failure") {
                          let CityKYCInsertResponse = {
                            "ErrorCode": "01",
                            "ErrorMsg": ParseCityKYCRespSatus.ResponseData,
                            "StatusCode": ParseCityKYCRespSatus.Status
                          }
                          resolve(CityKYCInsertResponse);
                        }

                      }
                    });
                  }
                });
              }).catch(error => {
                console.error('Error posting to APIM CITYKYC Status:', error);
                // console.error('Error Loan Status Inquiry API Error Response:',error.response);
                console.error('Error APIM CITYKYC Status API Error Response Text:', error.response.statusText);
                console.error('Error APIM CITYKYC Status API Error Response data:', error.response.data);
                logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSCityKYCInfoAPI").then(async (ErrorLogResp) => {
                  resp = {
                    "ErrorCode": "01",
                    "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                  }
                  resolve(resp);
                });
              });
            }
          });
        }
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}


function CBSCityKYCStatus_InsertAPIM(CityKYCRespData, AadhaarNumber, PMSNumber, JourneyID) {

  logger.info('**************************Inside CBSCityKYCStatus_InsertAPIM ************************')
logger.info('inside CBSCityKYCStatus_Insert AadhaarNumber is '+AadhaarNumber);
//  let CityKYCRespSatus=JSON.parse(CityKYCPlainResp);
//let CityKYCRespSatus=JSON.parse(CityKYCRespData);
  return new Promise(async (resolve, reject) => {

  //  let CityKYCRespData=JSON.parse(CityKYCRespSatus.ResponseData);


    try {

      // const date1=DatePart();
      var conn = new sql.ConnectionPool(config);
      conn.connect().then(function (pool) {
        var request = new sql.Request(pool); // Create a new request object for every row insert                            

        request.input('AadhaarNumber', sql.VarChar, AadhaarNumber)
        request.input('PMSNumber', sql.VarChar, PMSNumber)
        request.input('JourneyID', sql.VarChar, JourneyID)
        request.input('CustomerID', sql.VarChar, CityKYCRespData.Custid)
        request.input('CommunicationCity', sql.VarChar, CityKYCRespData.CommCity)
        request.input('CommunicationZIP', sql.VarChar, CityKYCRespData.CommZIP)
        request.input('KYCStatus', sql.VarChar, CityKYCRespData.Kyc)
        request.input('AccountNo', sql.VarChar, CityKYCRespData.Acct)
        request.input('AcctOpenDate', sql.VarChar, CityKYCRespData.AcctOpenDate)
        request.input('solid', sql.VarChar,CityKYCRespData.Sol )//CityKYCRespData.Sol
        request.execute('proc_CBS_CityKYCInfo_InsertUpdate', function (err, queryResult) {
          logger.info('QueryResult ' + JSON.stringify(queryResult));
          logger.info('Error ' + err);
          if (queryResult.rowsAffected[0] > 0) {
            response = {
              "ErrorCode": "00",
              "ErrorMsg": "CBS API City KYC status saved successfully."
            }
            logger.info(JSON.stringify(response));
            resolve(response);
          }
          else {
            logger.info('else:');
            response = {
              "ErrorCode": "01",
              "ErrorMsg": "Error to save City kyc details in database."
            }
            resolve(response);
          }
        });
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }

  });
}


// function CBSCityKYCStatus_Insert(CityKYCRespData, AadhaarNumber, PMSNumber, JourneyID) {

  // logger.info('**************************Inside CBSCityKYCStatus_Insert ************************')
// logger.info('inside CBSCityKYCStatus_Insert AadhaarNumber is '+AadhaarNumber);
// logger.info('inside CBSCityKYCStatus_Insert PMSNumber is '+PMSNumber);
// logger.info('inside CBSCityKYCStatus_Insert JourneyID is '+JourneyID);
// logger.info('inside CBSCityKYCStatus_Insert CityKYCRespData is '+JSON.stringify(CityKYCRespData));
// //  let CityKYCRespSatus=JSON.parse(CityKYCPlainResp);
// //let CityKYCRespSatus=JSON.parse(CityKYCRespData);

// //logger.info('inside CBSCityKYCStatus_Insert CityKYCRespSatus is '+CityKYCRespSatus);
  // return new Promise(async (resolve, reject) => {

  // //  let CityKYCRespData=JSON.parse(CityKYCRespSatus.ResponseData);
	
// //logger.info('inside CBSCityKYCStatus_Insert CityKYCRespData is '+CityKYCRespData);

    // try {

      // // const date1=DatePart();
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool); // Create a new request object for every row insert                            

        // request.input('AadhaarNumber', sql.VarChar, AadhaarNumber)
        // request.input('PMSNumber', sql.VarChar, PMSNumber)
        // request.input('JourneyID', sql.VarChar, JourneyID	)
        // request.input('CustomerID', sql.VarChar, CityKYCRespData.Custid)
        // request.input('CommunicationCity', sql.VarChar, CityKYCRespData.CommCity)
        // request.input('CommunicationZIP', sql.VarChar, CityKYCRespData.CommZIP)
        // request.input('KYCStatus', sql.VarChar, CityKYCRespData.Kyc)
        // request.input('AccountNo', sql.VarChar, CityKYCRespData.Acct)
        // request.input('AcctOpenDate', sql.VarChar, CityKYCRespData.AcctOpenDate)
        // request.input('solid', sql.VarChar,CityKYCRespData.Sol )//CityKYCRespData.Sol
        // request.execute('proc_CBS_CityKYCInfo_InsertUpdate', function (err, queryResult) {
          // //logger.info('QueryResult ' + JSON.stringify(queryResult));
          // logger.info('Error ' + err);
		  // //if()
          // if (queryResult.rowsAffected!=null && queryResult.rowsAffected[0] > 0) {
            // response = {
              // "ErrorCode": "00",
              // "ErrorMsg": "CBS API City KYC status saved successfully."
            // }
            // logger.info(JSON.stringify(response));
            // resolve(response);
          // }
          // else {
            // logger.info('else:');
            // response = {
              // "ErrorCode": "01",
              // "ErrorMsg": "Error to save City kyc details in database."
            // }
            // resolve(response);
          // }
        // });
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }

  // });
// }

// function CBSCityKYCStatus_Insert(CityKYCRespData, AadhaarNumber, PMSNumber, JourneyID) {
    // logger.info('************************** Inside CBSCityKYCStatus_Insert ************************');
    
    // Construct T-SQL style log for debugging
    // const sqlExecutionLog = `EXEC [dbo].[proc_CBS_CityKYCInfo_InsertUpdate] ` +
        // `@AadhaarNumber='${AadhaarNumber || ''}', ` +
        // `@PMSNumber='${PMSNumber || ''}', ` +
        // `@JourneyID='${JourneyID || ''}', ` +
        // `@CustomerID='${CityKYCRespData.Custid || ''}', ` +
        // `@CommunicationCity='${CityKYCRespData.CommCity || ''}', ` +
        // `@CommunicationZIP='${CityKYCRespData.CommZIP || ''}', ` +
        // `@KYCStatus='${CityKYCRespData.Kyc || ''}', ` +
        // `@AccountNo='${CityKYCRespData.Acct || ''}', ` +
        // `@AcctOpenDate='${CityKYCRespData.AcctOpenDate || ''}', ` +
        // `@solid='${CityKYCRespData.Sol || ''}'`;

    // logger.info('SQL EXECUTION STRING: ' + sqlExecutionLog);

    // return new Promise((resolve, reject) => {
        // try {
            // var conn = new sql.ConnectionPool(config);
            // conn.connect().then(function (pool) {
                // var request = new sql.Request(pool);

                // request.input('AadhaarNumber', sql.VarChar, AadhaarNumber);
                // request.input('PMSNumber', sql.VarChar, PMSNumber);
                // request.input('JourneyID', sql.VarChar, JourneyID);
                // request.input('CustomerID', sql.VarChar, CityKYCRespData.Custid);
                // request.input('CommunicationCity', sql.VarChar, CityKYCRespData.CommCity);
                // request.input('CommunicationZIP', sql.VarChar, CityKYCRespData.CommZIP);
                // request.input('KYCStatus', sql.VarChar, CityKYCRespData.Kyc);
                // request.input('AccountNo', sql.VarChar, CityKYCRespData.Acct);
                // request.input('AcctOpenDate', sql.VarChar, CityKYCRespData.AcctOpenDate);
                // request.input('solid', sql.VarChar, CityKYCRespData.Sol);

                // request.execute('proc_CBS_CityKYCInfo_InsertUpdate', function (err, queryResult) {
                    
                    // if (err) {
                        // logger.error('PROCEDURE ERROR: ' + err.message);
                        // Log the SQL string again on error for easier copy-pasting
                        // logger.error('FAILED SQL: ' + sqlExecutionLog);
                        
                        // let response = {
                            // "ErrorCode": "01",
                            // "ErrorMsg": "Error to save City kyc details: " + err.message
                        // };
                        // return resolve(response);
                    // }

                    // let totalAffected = 0;
                    // if (queryResult && queryResult.rowsAffected) {
                        // totalAffected = queryResult.rowsAffected.reduce((a, b) => a + b, 0);
                    // }

                    // logger.info('Rows Affected: ' + totalAffected);

                    // if (totalAffected > 0) {
                        // let response = {
                            // "ErrorCode": "00",
                            // "ErrorMsg": "CBS API City KYC status saved successfully."
                        // };
                        // logger.info('Success Response: ' + JSON.stringify(response));
                        // resolve(response);
                    // } else {
                        // logger.warn('Else: No rows affected in database.');
                        // logger.warn('CHECK THIS SQL IN SSMS: ' + sqlExecutionLog);
                        
                        // let response = {
                            // "ErrorCode": "01",
                            // "ErrorMsg": "Error to save City kyc details in database (No records found to update)."
                        // };
                        // resolve(response);
                    // }
                // });
            // }).catch(function (connErr) {
                // logger.error('Connection Pool Failed: ' + connErr);
                // resolve({ "ErrorCode": "01", "ErrorMsg": "Database connection failed." });
            // });
        // } catch (err1) {
            // logger.error('Try-Catch Error: ' + err1);
            // reject(err1);
        // }
    // });
// }

// function CustomerDetailsAPI(PMSNumber, JourneyID, CityKYCInfoParse, AccessToken, PMSDataParse) {
  // logger.info('************************ Inside CustomerDetailsAPI ************************');
  // //logger.info('Customer ID: ' + CityKYCInfoParse.CustomerID);    
  // return new Promise(async (resolve, reject) => {
    // try {
      // //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';            
      // const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      // const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      // headers = {
        // 'Client-Id': ClientID, // Replace with your custom header value
        // 'Content-Type': 'application/json',  // Replace with another custom header value
        // 'Authorization': 'Bearer ' + AccessToken
      // }

      // logger.info('Header', headers);
      // let CustomerData = {
        // "CustId": CityKYCInfoParse.CustomerID         //"O61917622"       
      // }
      // let Plainbody = {
        // "OperationName": "CustDetails",
        // "RequestData": JSON.stringify(CustomerData)
      // }
      // //Call Enc
      // logger.info(`Plain Request ${JSON.stringify(Plainbody)}`);

      // objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        // body = {
          // "EncReqData": EncResponse
        // }
        // logger.info('Enc Request: ' + JSON.stringify(body));
        // logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CustomerInfoAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
          // logger.info("API Log Insert ErrorCode " + APILogsResp.ErrorCode)
          // if (APILogsResp.ErrorCode == "00") {
            // axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
              // logger.info('Enc Response', resp.data);

              // let encresp = JSON.parse(JSON.stringify(resp.data));
              // // logger.info('encresp.EncRespData: '+encresp.EncRespData)

              // objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                // logger.info("Plain Response: " + PlainResponse)
                // logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                  // logger.info("API Log Update ErrorCode " + APILogsResp.ErrorCode)
                  // if (APILogsResp.ErrorCode == "00") {
                    // //{"Status":"F","ResponseData":"{\"Status\":\"F\",\"Message\":\"Error While fetching the status. Please contact PNB Team\"}"}


                    // let CustomerDetailsRespStatus = JSON.parse(PlainResponse);
                    // if (CustomerDetailsRespStatus.Status == "Success") {
                      // logger.info(`CustomerDetailsRespStatus ${JSON.stringify(CustomerDetailsRespStatus)}`);
                      // logger.info(CustomerDetailsRespStatus.Status);

                      // let CustomerDetailsRespData = JSON.parse(CustomerDetailsRespStatus.ResponseData);
                      // logger.info(CustomerDetailsRespData.Remarks);
                      // logger.info("*********************CustomerDetailsRespData***************************"+CustomerDetailsRespData.result);

                      // logger.info('Cust_Full_Name ' + JSON.parse(JSON.stringify(CustomerDetailsRespData.result)).Cust_Full_Name);
                      // let CustomerDetailsRespResult = JSON.parse(JSON.stringify(CustomerDetailsRespData.result));



                      // CBSCustomerDetails_Insert(PMSNumber, JourneyID, PlainResponse, CityKYCInfoParse.CustomerID).then(async (CustomerDetailsRespInsert) => {
                        // logger.info('Out Insert Customer Details in Database:' + JSON.stringify(CustomerDetailsRespInsert));

                        // let outResp = "";
                        // if (CustomerDetailsRespInsert.ErrorCode == "00") {

                          // logger.info(PMSDataParse.APPLICANTNAME)

                          // logger.info(`CustName Before: ${CustomerDetailsRespResult.Cust_Full_Name}`)

                          // const NewCustName = separateNameAndRelation(CustomerDetailsRespResult.Cust_Full_Name);

                          // let CustomerName;

                          // if (NewCustName != null) {
                            // CustomerName = NewCustName.CustomerName
                          // }
                          // else {
                            // CustomerName = CustomerDetailsRespResult.Cust_Full_Name;
                          // }

                          // logger.info(`CustName After: ${CustomerName}`)
                          // logger.info(`PMSDataParse.MOBILENO: ${PMSDataParse.MOBILENO}`)
                          // logger.info(`CustomerDetailsRespResult.MobileNo: ${CustomerDetailsRespResult.MobileNo}`)
                          // logger.info(`PMSDataParse.ACCOUNTNO: ${PMSDataParse.ACCOUNTNO}`)
                          // logger.info(`CityKYCInfoParse.AccountNo: ${CityKYCInfoParse.AccountNo}`)


                          // //logger.info(PMSDataParse.MOBILENO)
                          // //logger.info(CustomerDetailsRespResult.MobileNo)

                          // logger.info(CustomerDetailsRespResult.Constitution_Type)

                         // //  CustomerDetailsRespResult.Minor="Y"
                          // if (PMSDataParse.APPLICANTNAME.toUpperCase() != CustomerName.toUpperCase()) {
                            // outResp = {
                              // "ErrorCode": "01",
                              // "ErrorMsg": "Your name is not match as per our bank records.Please contact your branch for further assistance."
                            // }
                            // resolve(outResp);
                          // }
                          // // else if (PMSDataParse.MOBILENO != CustomerDetailsRespResult.MobileNo) { //111111000000
                          // // //else if (PMSDataParse.MOBILENO == CustomerDetailsRespResult.MobileNo) {
                            // // outResp = {
                              // // "ErrorCode": "01",
                              // // "ErrorMsg": "Your mobile number is not match as per our bank records.Please contact your branch for further assistance."
                            // // }
                            // // resolve(outResp);
                          // // }
						  // // else if (PMSDataParse.MOBILENO != CustomerDetailsRespResult.MobileNo) { 
                         
                           // // if  (PMSDataParse.ACCOUNTNO.toUpperCase() !=  CityKYCInfoParse.AccountNo.toUpperCase())
                          // // {                        
                           // // outResp = {
                              // // "ErrorCode": "01",
                              // // "ErrorMsg": "Your mobile number and Account No is not match as per our bank records.Please contact your branch for further assistance."
                            // // }
                            // // resolve(outResp);
                          // // }
                        // // }
						
													// else if (PMSDataParse.MOBILENO !== CustomerDetailsRespResult.MobileNo) { 
								
								// // Check if AccountNo exists before calling toUpperCase() to avoid crashes
								// const pmsAcc = (PMSDataParse.ACCOUNTNO || "").toUpperCase();
								// const kycAcc = (CityKYCInfoParse.AccountNo || "").toUpperCase();

								// if (pmsAcc !== kycAcc) {                        
									// outResp = {
										// "ErrorCode": "01",
										// "ErrorMsg": "Your mobile number and account number do not match our bank records. Please contact your branch for further assistance."
									// };
									// logger.warn(`Validation Failed for PMS: ${PMSDataParse.PMSNUMBER}. Mobile or Account mismatch.`);
									// return resolve(outResp);
								// }
							// //}

                          // else if (CustomerDetailsRespResult.Constitution_Type != "001") {
                            // outResp = {
                              // "ErrorCode": "01",
                              // "ErrorMsg": "This application is only for Self operated accounts. Kindly contact nearest PNB branch."
                            // }
                            // resolve(outResp);
                          // }
                           
                           // else if(CustomerDetailsRespResult.Minor=="Y")
                          // {
                                 // outResp={
                                  // "ErrorCode":"01",
                                  // "ErrorMsg":"Account entered belongs to Minor. Account is not eligibile for e PM SVANidhi loan."
                                // }
                                // resolve(outResp);                        
                          // }
                          // else if(CustomerDetailsRespResult.Staff_Flag=="Y")
                          // {
                                 // outResp={
                                  // "ErrorCode":"01",
                                  // "ErrorMsg":"Account entered belongs to Staff category. Account is not eligibile for e PM SVANidhi loan."
                                // }
                                // resolve(outResp);                        
                          // }
                          // }
						  // //CBS Branch Master and SIDBI Comm Data
						  
                          // else {
                            // outResp = {
                              // "ErrorCode": CustomerDetailsRespInsert.ErrorCode,
                              // "ErrorMsg": CustomerDetailsRespInsert.ErrorMsg
                            // }
                            // resolve(outResp);
                          // }
                        // }
                        // else {
                          // outResp = {
                            // "ErrorCode": CustomerDetailsRespInsert.ErrorCode,
                            // "ErrorMsg": CustomerDetailsRespInsert.ErrorMsg
                          // }
                          // resolve(outResp);
                        // }
                      // });
                    // }
                    // else if (CustomerDetailsRespStatus.Status == "F") {
                      // logger.info(`CustomerDetailsRespStatus ${JSON.stringify(CustomerDetailsRespStatus)}`);
                      // logger.info(CustomerDetailsRespStatus.Status);
                      // const responseData = JSON.parse(CustomerDetailsRespStatus.ResponseData);
                      // console.log(responseData.Status);
                      // console.log(responseData.Message);

                      // outResp = {
                        // "ErrorCode": "01",
                        // "ErrorMsg": responseData.Message
                      // }
                      // resolve(outResp);
                    // }
                  // }
                // });
              // });
            // }).catch(error => {
              // // console.error('Error posting to Loan Status API:',error);
              // // console.error('Error Loan Status Inquiry API Error Response:',error.response);
              // console.error('Error Loan Status Inquiry API Error Response Text:', error.response.statusText);
              // console.error('Error Loan Status Inquiry API Error Response data:', error.response.data);
              // logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CustomerInfoAPI").then(async (ErrorLogResp) => {
                // resp = {
                  // "ErrorCode": "01",
                  // "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance.",
                // }
                // resolve(resp);
              // });
            // });
          // }
        // });
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function CustomerDetailsAPI(PMSNumber, JourneyID, CityKYCInfoParse, AccessToken, PMSDataParse) {
  logger.info('************************ Inside CustomerDetailsAPI ************************');

  return new Promise((resolve, reject) => {
    try {
      GetKeyConfigurationValue('CBS_API_URL').then(async (API_URL) => {
        const ClientID = await GetKeyConfigurationValue('CBS_ClientID');

        const headers = {
          'Client-Id': ClientID,
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + AccessToken
        };

        let CustomerData = { "CustId": CityKYCInfoParse.CustomerID };
        let Plainbody = {
          "OperationName": "CustDetails",
          "RequestData": JSON.stringify(CustomerData)
        };

        objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then((EncResponse) => {
          let body = { "EncReqData": EncResponse };

          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CustomerInfoAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then((APILogsResp) => {

            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {

                let encresp = JSON.parse(JSON.stringify(resp.data));
                objCommonFunction.Decrypt(encresp.EncRespData).then((PlainResponse) => {

                  logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then((APILogsRespUpdate) => {

                    if (APILogsRespUpdate.ErrorCode == "00") {
                      let CustomerDetailsRespStatus = JSON.parse(PlainResponse);

                      if (CustomerDetailsRespStatus.Status == "Success") {
                        let CustomerDetailsRespData = JSON.parse(CustomerDetailsRespStatus.ResponseData);
                        let CustomerDetailsRespResult = CustomerDetailsRespData.result;

                        CBSCustomerDetails_Insert(PMSNumber, JourneyID, PlainResponse, CityKYCInfoParse.CustomerID).then((CustomerDetailsRespInsert) => {

                          if (CustomerDetailsRespInsert.ErrorCode == "00") {
                            const NewCustName = separateNameAndRelation(CustomerDetailsRespResult.Cust_Full_Name);
                            let CustomerName = NewCustName ? NewCustName.CustomerName : CustomerDetailsRespResult.Cust_Full_Name;

                            let outResp = "";
                            const pmsAcc = (PMSDataParse.ACCOUNTNO || "").toUpperCase();
                            const kycAcc = (CityKYCInfoParse.AccountNo || "").toUpperCase();

                            // --- START VALIDATION CHAIN ---
                            if (PMSDataParse.APPLICANTNAME.toUpperCase() != CustomerName.toUpperCase()) {
                              outResp = { "ErrorCode": "01", "ErrorMsg": "Your name does not match our bank records. Please contact branch." };
                              resolve(outResp);
                            }
							const mobile = (CustomerDetailsRespResult.MobileNo || "").toString().trim();

							  if (!/^\d{10}$/.test(mobile)) {
								logger.warn(
								  `PMSOTPValidate | Invalid / Missing Mobile Number for PMS: ${PMSNumber} | MobileFromDB: [${mobile}]`
								);

								let outResp = {
								  "ErrorCode": "01",
								  "ErrorMsg": "Mobile number not found in bank records. Please contact branch."
								};

								  resolve(outResp);
							  }
                            // Logic: If Mobile doesn't match, check Account. 
                            else if (PMSDataParse.MOBILENO != CustomerDetailsRespResult.MobileNo) {
                              if (pmsAcc != kycAcc) {
                                outResp = { "ErrorCode": "01", "ErrorMsg": "Your mobile number and account number does not match our bank records." };
                                resolve(outResp);
                              } else {
                                // Mobile didn't match, but Account DID match. 
                                // Moving to other checks as requested.
                                if (CustomerDetailsRespResult.Constitution_Type != "001") {
                                  resolve({ "ErrorCode": "01", "ErrorMsg": "This application is only for Self operated accounts." });
                                } else if (CustomerDetailsRespResult.Minor == "Y") {
                                  resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Minor. Not eligible for loan." });
                                } else if (CustomerDetailsRespResult.Staff_Flag == "Y") {
                                  resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Staff category. Not eligible for loan." });
                                } else {
                                  resolve({ "ErrorCode": "00", "ErrorMsg": "Success" });
                                }
                              }
                            }
                            // If Mobile matched perfectly, skip account check and run business rules
                            else {
                              if (CustomerDetailsRespResult.Constitution_Type != "001") {
                                resolve({ "ErrorCode": "01", "ErrorMsg": "This application is only for Self operated accounts." });
                              } else if (CustomerDetailsRespResult.Minor == "Y") {
                                resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Minor. Not eligible for loan." });
                              } else if (CustomerDetailsRespResult.Staff_Flag == "Y") {
                                resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Staff category. Not eligible for loan." });
                              } else {
                                resolve({ "ErrorCode": "00", "ErrorMsg": "Success" });
                              }
                            }
                            // --- END VALIDATION CHAIN ---

                          } else {
                            resolve({ "ErrorCode": "01", "ErrorMsg": "Database Insertion Failed: " + CustomerDetailsRespInsert.ErrorMsg });
                          }
                        });
                      } else {
                        let errData = JSON.parse(CustomerDetailsRespStatus.ResponseData || "{}");
                        resolve({ "ErrorCode": "01", "ErrorMsg": errData.Message || "Error fetching details." });
                      }
                    } else {
                      resolve({ "ErrorCode": "01", "ErrorMsg": "API Log Update Failed." });
                    }
                  });
                });
              }).catch(error => {
                logError.ErrorLogs(PMSNumber, JourneyID, "500", "Axios Error", "CustomerInfoAPI").then(() => {
                  resolve({ "ErrorCode": "01", "ErrorMsg": "System error occurred. Please contact branch." });
                });
              });
            } else {
              resolve({ "ErrorCode": "01", "ErrorMsg": "API Log Insert Failed." });
            }
          });
        });
      });
    } catch (err1) {
      logger.error("Global Catch: " + err1);
      reject(err1);
    }
  });
}


function CustomerDetailsAPIM(PMSNumber, JourneyID, CityKYCInfoParse, AccessToken, PMSDataParse) {
  logger.info('************************ Inside CustomerDetailsAPIM ************************');

  return new Promise((resolve, reject) => {
    try {
      GetKeyConfigurationValue('APIMCustomerDetails').then(async (API_URL) => {
        const ClientID = await GetKeyConfigurationValue('APIMClientID');
        const headers = {
          'Client-Id': ClientID,
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + AccessToken
        };

        let CustomerData = { "CustId": CityKYCInfoParse.CustomerID };
        let Plainbody = {
          "OperationName": "CustDetails",
          "RequestData": JSON.stringify(CustomerData)
        };

        objCommonFunction.APIMEncrypt(JSON.stringify(Plainbody)).then((EncResponse) => {
          let body = { "EncReqData": EncResponse };

          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CustomerInfoAPIM", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then((APILogsResp) => {

            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {

                let encresp = JSON.parse(JSON.stringify(resp.data));
                objCommonFunction.APIMDecrypt(encresp.EncRespData).then((PlainResponse) => {
                  logger.info("HHHHHHHHHHHHHHHHHHHHHHHHHHHH"+PlainResponse)
                  logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then((APILogsRespUpdate) => {

                    if (APILogsRespUpdate.ErrorCode == "00") {
                        let CustomerDetailsRespStatus = JSON.parse(JSON.stringify(PlainResponse));

                    logger.info(`Status: ${JSON.stringify(CustomerDetailsRespStatus.Status)}`);
                    logger.info(`ResponseData: ${JSON.stringify(CustomerDetailsRespStatus.ResponseData)}`);

                      if (CustomerDetailsRespStatus.Status == "Success") {

                        let CustomerDetailsRespData = CustomerDetailsRespStatus.ResponseData;                   
                      logger.info("*********************CustomerDetailsRespData***************************"+CustomerDetailsRespData.result);
                             let CustomerDetailsRespResult = JSON.parse(JSON.stringify(CustomerDetailsRespData.result));
                      logger.info('Cust_Full_Name ' + JSON.parse(JSON.stringify(CustomerDetailsRespData.result)).Cust_Full_Name);
                   
                        CBSCustomerDetails_InsertAPIM(PMSNumber, JourneyID, PlainResponse, CityKYCInfoParse.CustomerID).then((CustomerDetailsRespInsert) => {

                          if (CustomerDetailsRespInsert.ErrorCode == "00") {
                            const NewCustName = separateNameAndRelation(CustomerDetailsRespResult.Cust_Full_Name);
                            let CustomerName = NewCustName ? NewCustName.CustomerName : CustomerDetailsRespResult.Cust_Full_Name;

                            let outResp = "";
                            const pmsAcc = (PMSDataParse.ACCOUNTNO || "").toUpperCase();
                            const kycAcc = (CityKYCInfoParse.AccountNo || "").toUpperCase();

                            // --- START VALIDATION CHAIN ---
                            if (PMSDataParse.APPLICANTNAME.toUpperCase() != CustomerName.toUpperCase()) {
                              outResp = { "ErrorCode": "01", "ErrorMsg": "Your name does not match our bank records. Please contact branch." };
                              resolve(outResp);
                            }
						               	const mobile = (CustomerDetailsRespResult.MobileNo || "").toString().trim();

							  if (!/^\d{10}$/.test(mobile)) {
								logger.warn(
								  `PMSOTPValidate | Invalid / Missing Mobile Number for PMS: ${PMSNumber} | MobileFromDB: [${mobile}]`
								);

								let outResp = {
								  "ErrorCode": "01",
								  "ErrorMsg": "Mobile number not found in bank records. Please contact branch."
								};

								  resolve(outResp);
							  }
                            // Logic: If Mobile doesn't match, check Account. 
                            else if (PMSDataParse.MOBILENO != CustomerDetailsRespResult.MobileNo) {
                              if (pmsAcc != kycAcc) {
                                outResp = { "ErrorCode": "01", "ErrorMsg": "Your mobile number and account number does not match our bank records." };
                                resolve(outResp);
                              } else {
                                // Mobile didn't match, but Account DID match. 
                                // Moving to other checks as requested.
                                if (CustomerDetailsRespResult.Constitution_Type != "001") {
                                  resolve({ "ErrorCode": "01", "ErrorMsg": "This application is only for Self operated accounts." });
                                } else if (CustomerDetailsRespResult.Minor == "Y") {
                                  resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Minor. Not eligible for loan." });
                                } else if (CustomerDetailsRespResult.Staff_Flag == "Y") {
                                  resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Staff category. Not eligible for loan." });
                                } else {
                                  resolve({ "ErrorCode": "00", "ErrorMsg": "Success" });
                                }
                              }
                            }
                            // If Mobile matched perfectly, skip account check and run business rules
                            else {
                              if (CustomerDetailsRespResult.Constitution_Type != "001") {
                                resolve({ "ErrorCode": "01", "ErrorMsg": "This application is only for Self operated accounts." });
                              } else if (CustomerDetailsRespResult.Minor == "Y") {
                                resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Minor. Not eligible for loan." });
                              } else if (CustomerDetailsRespResult.Staff_Flag == "Y") {
                                resolve({ "ErrorCode": "01", "ErrorMsg": "Account belongs to Staff category. Not eligible for loan." });
                              } else {
                                resolve({ "ErrorCode": "00", "ErrorMsg": "Success" });
                              }
                            }
                            // --- END VALIDATION CHAIN ---

                          } else {
                            resolve({ "ErrorCode": "01", "ErrorMsg": "Database Insertion Failed: " + CustomerDetailsRespInsert.ErrorMsg });
                          }
                        });
                      } else {
                        let errData = JSON.parse(CustomerDetailsRespStatus.ResponseData || "{}");
                        resolve({ "ErrorCode": "01", "ErrorMsg": errData.Message || "Error fetching details." });
                      }
                    } else {
                      resolve({ "ErrorCode": "01", "ErrorMsg": "API Log Update Failed." });
                    }
                  });
                });
              }).catch(error => {
                logError.ErrorLogs(PMSNumber, JourneyID, "500", "Axios Error", "CustomerInfoAPI").then(() => {
                  resolve({ "ErrorCode": "01", "ErrorMsg": "System error occurred. Please contact branch." });
                });
              });
            } else {
              resolve({ "ErrorCode": "01", "ErrorMsg": "API Log Insert Failed." });
            }
          });
        });
      });
    } catch (err1) {
      logger.error("Global Catch: " + err1);
      reject(err1);
    }
  });
}







function CBSCustomerDetails_InsertAPIM(PMSNumber, JourneyID, CustomerDetailsPlainResp, CustomerID) {
  logger.info('CBS Cust Data insert in databse' + CustomerID);
  let CustomerDetailsRespStatus = CustomerDetailsPlainResp;
  // logger.info(CustomerDetailsRespStatus.Status);
  let CustomerDetailsRespData = CustomerDetailsRespStatus.ResponseData;
  // logger.info(CustomerDetailsRespData.Remarks);

  // logger.info('+'+JSON.parse(JSON.stringify(CustomerDetailsRespData.result)).Cust_Full_Name);


  let CustomerDetailsRespResult = JSON.parse(JSON.stringify(CustomerDetailsRespData.result));
  // logger.info(CustomerDetailsRespResult.Cust_Full_Name);

  let CustomerDetailsRespCommAddress = JSON.parse(JSON.stringify(CustomerDetailsRespResult.CommunicationAddress));
  // logger.info(CustomerDetailsRespCommAddress.Address1);
  let CustomerDetailsRespPermAddress = JSON.parse(JSON.stringify(CustomerDetailsRespResult.PermanentAddress));
  // logger.info(CustomerDetailsRespPermAddress.Address1);

  const NewCustName = separateNameAndRelation(CustomerDetailsRespResult.Cust_Full_Name);

  let CustomerName;

  if (NewCustName != null) {

    CustomerName = NewCustName.CustomerName
    logger.info(`Inside if block CustName After: ${CustomerName}`)
  }
  else {
    CustomerName = CustomerDetailsRespResult.Cust_Full_Name;
    logger.info(`Inside else block CustName After: ${CustomerName}`)
  }

  logger.info(`CustName After: ${CustomerName}`)

  return new Promise((resolve, reject) => {
    try {
      var conn = new sql.ConnectionPool(config);
      conn.connect().then(function (pool) {
        var request = new sql.Request(pool);
        request.input('p_CustomerID', sql.NVarChar, CustomerID)
          .input('p_PMSNumber', sql.NVarChar, PMSNumber)
          .input('p_JourneyID', sql.NVarChar, JourneyID)
          .input('p_Cust_Full_Name', sql.NVarChar, CustomerName)
          .input('p_Date_of_Birth', sql.NVarChar, CustomerDetailsRespResult.Date_of_Birth)
          .input('p_F_H_Name', sql.NVarChar, CustomerDetailsRespResult.F_H_Name)
          .input('p_Mother_Name', sql.NVarChar, CustomerDetailsRespResult.Mother_Name)
          .input('p_Gender', sql.NVarChar, CustomerDetailsRespResult.Gender)
          .input('p_Religion', sql.NVarChar, CustomerDetailsRespResult.Religion)
          .input('p_PANCard', sql.NVarChar, CustomerDetailsRespResult.PANCard)
          .input('p_Constitution_Type', sql.NVarChar, CustomerDetailsRespResult.Constitution_Type)
          .input('p_Occupation_Type', sql.NVarChar, CustomerDetailsRespResult.Occupation_Type)
          .input('p_MobileNo', sql.NVarChar, CustomerDetailsRespResult.MobileNo)
          .input('p_Email_ID', sql.NVarChar, CustomerDetailsRespResult.Email_ID)
          .input('p_Minor', sql.NVarChar, CustomerDetailsRespResult.Minor)
          .input('p_IncomeCategory', sql.NVarChar, CustomerDetailsRespResult.IncomeCategory)
          .input('p_StaffFlag', sql.NVarChar, CustomerDetailsRespResult.Staff_Flag)
          .input('p_CommunicationAddress', sql.Text, JSON.stringify(CustomerDetailsRespCommAddress))
          .input('p_CommunicationAddress_Address1', sql.NVarChar, CustomerDetailsRespCommAddress.Address1)
          .input('p_CommunicationAddress_Address2', sql.NVarChar, CustomerDetailsRespCommAddress.Address2)
          .input('p_CommunicationAddress_City', sql.NVarChar, CustomerDetailsRespCommAddress.City)
          .input('p_CommunicationAddress_State', sql.NVarChar, CustomerDetailsRespCommAddress.State)
          .input('p_CommunicationAddress_PINCode', sql.NVarChar, CustomerDetailsRespCommAddress.PINCode)
          .input('p_CommunicationAddress_Country', sql.NVarChar, CustomerDetailsRespCommAddress.Country)
          .input('p_PermanentAddress', sql.Text, JSON.stringify(CustomerDetailsRespPermAddress))
          .input('p_PermanentAddress_Address1', sql.NVarChar, CustomerDetailsRespPermAddress.Address1)
          .input('p_PermanentAddress_Address2', sql.NVarChar, CustomerDetailsRespPermAddress.Address2)
          .input('p_PermanentAddress_City', sql.NVarChar, CustomerDetailsRespPermAddress.City)
          .input('p_PermanentAddress_State', sql.NVarChar, CustomerDetailsRespPermAddress.State)
          .input('p_PermanentAddress_PINCode', sql.NVarChar, CustomerDetailsRespPermAddress.PINCode)
          .input('p_PermanentAddress_Country', sql.NVarChar, CustomerDetailsRespPermAddress.Country)
          .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          .execute('proc_CBS_CustomerDetails_Insert', function (err, queryResult) {
            logger.info("Error :- " + err);
            logger.info('QueryResult:', queryResult); // Retrieve output parameter      
            logger.info('Out Variable: ', queryResult.output.p_OutStatusCode); // Retrieve output parameter                                           
            // logger.info('response affect:' + queryResult.rowsAffected[0]);
            if (queryResult.output.p_OutStatusCode == '200' && queryResult.rowsAffected[0] > 0) {
              //logger.info('response isDataInsert:' + queryResult.output.p_OutStatusCode);                              
              conn.close();

              response = {
                "ErrorCode": "00",
                "ErrorMsg": "Customer Details saved Successfully.",
              }
              resolve(response);
            }
            else {

              response = {
                "ErrorCode": "01",
                "ErrorMsg": "Error to save customer details in database."
              }
              logger.info("Error while insert in database :- " + err);
              // res.json(err); 
              resolve(response);
            }
          });
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}















function BGCustomerDetailsAPI(PMSNumber, JourneyID, CityKYCInfoParse, AccessToken, PMSDataParse, custDataCheck) {
  logger.info('************************ Inside CustomerDetailsAPI ************************');
  //logger.info('Customer ID: ' + CityKYCInfoParse.CustomerID);    
  return new Promise(async (resolve, reject) => {
    try {
      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';            
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + AccessToken
      }

      logger.info('Header', headers);
      let CustomerData = {
        "CustId": CityKYCInfoParse.CustomerID         //"O61917622"       
      }
      let Plainbody = {
        "OperationName": "CustDetails",
        "RequestData": JSON.stringify(CustomerData)
      }
      //Call Enc
      logger.info(`Plain Request ${JSON.stringify(Plainbody)}`);

      objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        body = {
          "EncReqData": EncResponse
        }
        logger.info('Enc Request: ' + JSON.stringify(body));
        logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CustomerInfoAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
          logger.info("API Log Insert ErrorCode " + APILogsResp.ErrorCode)
          if (APILogsResp.ErrorCode == "00") {
            axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
              logger.info('Enc Response', resp.data);

              let encresp = JSON.parse(JSON.stringify(resp.data));
              // logger.info('encresp.EncRespData: '+encresp.EncRespData)

              objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                logger.info("Plain Response: " + PlainResponse)
                logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                  logger.info("API Log Update ErrorCode " + APILogsResp.ErrorCode)
                  if (APILogsResp.ErrorCode == "00") {
                    //{"Status":"F","ResponseData":"{\"Status\":\"F\",\"Message\":\"Error While fetching the status. Please contact PNB Team\"}"}


                    let CustomerDetailsRespStatus = JSON.parse(PlainResponse);
                    if (CustomerDetailsRespStatus.Status == "Success") {
                      logger.info(`CustomerDetailsRespStatus ${JSON.stringify(CustomerDetailsRespStatus)}`);
                      logger.info(CustomerDetailsRespStatus.Status);

                      let CustomerDetailsRespData = JSON.parse(CustomerDetailsRespStatus.ResponseData);
                      logger.info(CustomerDetailsRespData.Remarks);
                      logger.info('Cust_Full_Name ' + JSON.parse(JSON.stringify(CustomerDetailsRespData.result)).Cust_Full_Name);
                      let CustomerDetailsRespResult = JSON.parse(JSON.stringify(CustomerDetailsRespData.result));



                      CBSCustomerDetails_Insert(PMSNumber, JourneyID, PlainResponse, CityKYCInfoParse.CustomerID).then(async (CustomerDetailsRespInsert) => {
                        logger.info('Out Insert Customer Details in Database:' + JSON.stringify(CustomerDetailsRespInsert));

                        let outResp = "";
                        if (CustomerDetailsRespInsert.ErrorCode == "00") {

                          logger.info('old Name: ' + PMSDataParse.APPLICANTNAME);

                          logger.info(`CustName Before: ${CustomerDetailsRespResult.Cust_Full_Name}`)

                          const NewCustName = separateNameAndRelation(CustomerDetailsRespResult.Cust_Full_Name);

                          let CustomerName;

                          if (NewCustName != null) {
                            CustomerName = NewCustName.CustomerName
                          }
                          else {
                            CustomerName = CustomerDetailsRespResult.Cust_Full_Name;
                          }

                          logger.info(`CustName After: ${CustomerName}`)


                          logger.info(PMSDataParse.MOBILENO)
                          logger.info(CustomerDetailsRespResult.MobileNo)

                          //PMSDataParse.APPLICANTNAME = 'VISH RAM MEENA';
                          //logger.info('new Name: ' + PMSDataParse.APPLICANTNAME)
                          logger.info('custDataCheck at CBS Data Layer: ' + custDataCheck)
                          if (custDataCheck != true) {
                            logger.info('Inside true custDataCheck ');
                            if (PMSDataParse.APPLICANTNAME.toUpperCase() != CustomerName.toUpperCase()) {
                              outResp = {
                                "ErrorCode": "02",
                                "ErrorMsg": "Customer details mismatch. Kindly provide consent to proceed further"
                              }
                              resolve(outResp);
                            }
                            else if (PMSDataParse.MOBILENO != CustomerDetailsRespResult.MobileNo) { //111111000000
                           // else if (PMSDataParse.MOBILENO == CustomerDetailsRespResult.MobileNo) {
                              outResp = {
                                "ErrorCode": "02",
                                "ErrorMsg": "Customer details mismatch. Kindly provide consent to proceed further"
                              }
                              resolve(outResp);
                            }
                            else {
                              outResp = {
                                "ErrorCode": CustomerDetailsRespInsert.ErrorCode,
                                "ErrorMsg": CustomerDetailsRespInsert.ErrorMsg
                              }
                              resolve(outResp);
                            }
                          }
                          else {
                            //Update Flag in Journey Table

                            outResp = {
                              "ErrorCode": CustomerDetailsRespInsert.ErrorCode,
                              "ErrorMsg": CustomerDetailsRespInsert.ErrorMsg
                            }
                            resolve(outResp);
                          }
                        }
                        else {
                          outResp = {
                            "ErrorCode": CustomerDetailsRespInsert.ErrorCode,
                            "ErrorMsg": CustomerDetailsRespInsert.ErrorMsg
                          }
                          resolve(outResp);
                        }
                      });
                    }
                    else if (CustomerDetailsRespStatus.Status == "F") {
                      logger.info(`CustomerDetailsRespStatus ${JSON.stringify(CustomerDetailsRespStatus)}`);
                      logger.info(CustomerDetailsRespStatus.Status);
                      const responseData = JSON.parse(CustomerDetailsRespStatus.ResponseData);
                      console.log(responseData.Status);
                      console.log(responseData.Message);

                      outResp = {
                        "ErrorCode": "01",
                        "ErrorMsg": responseData.Message
                      }
                      resolve(outResp);
                    }
                  }
                });
              });
            }).catch(error => {
              
              console.error('Error Loan Status Inquiry API Error Response Text:', error.response.statusText);
              console.error('Error Loan Status Inquiry API Error Response data:', error.response.data);
              logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CustomerInfoAPI").then(async (ErrorLogResp) => {
                resp = {
                  "ErrorCode": "01",
                  "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                }
                resolve(resp);
              });
            });
          }
        });
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}

function separateNameAndRelation(input) {
  // Define the regex pattern to separate name and relation parts
  const regex = /^([A-Za-z\s]+)\s(S\/O|W\/O|F\/O|D\/O|SO|WO|FO|DO)\s([A-Za-z\s]+)$/;

  // Match the input string
  const match = input.match(regex);

  if (match) {
    // Extract name, relationship and father's name
    let CustomerName = match[1].trim();  // First part (Name)
    logger.info(`inside separateNameAndRelation name: ${CustomerName}`)
    // const relation = match[2].trim();  // Second part (Relationship)
    // const fatherName = match[3].trim();  // Father's name
    //return { name, relation, fatherName };
    return { CustomerName };
  } else {
    logger.info(`Else separateNameAndRelation : ${input}`)
    return null;  // Return null if the format doesn't match
  }
}

// function CBSCustomerDetails_Insert(PMSNumber, JourneyID, CustomerDetailsPlainResp, CustomerID) {
  // logger.info('CBS Cust Data insert in databse' + CustomerID);
  // let CustomerDetailsRespStatus = JSON.parse(CustomerDetailsPlainResp);
  // // logger.info(CustomerDetailsRespStatus.Status);
  // let CustomerDetailsRespData = JSON.parse(CustomerDetailsRespStatus.ResponseData);
  // // logger.info(CustomerDetailsRespData.Remarks);

  // // logger.info('+'+JSON.parse(JSON.stringify(CustomerDetailsRespData.result)).Cust_Full_Name);


  // let CustomerDetailsRespResult = JSON.parse(JSON.stringify(CustomerDetailsRespData.result));
  // // logger.info(CustomerDetailsRespResult.Cust_Full_Name);

  // let CustomerDetailsRespCommAddress = JSON.parse(JSON.stringify(CustomerDetailsRespResult.CommunicationAddress));
  // // logger.info(CustomerDetailsRespCommAddress.Address1);
  // let CustomerDetailsRespPermAddress = JSON.parse(JSON.stringify(CustomerDetailsRespResult.PermanentAddress));
  // // logger.info(CustomerDetailsRespPermAddress.Address1);

  // const NewCustName = separateNameAndRelation(CustomerDetailsRespResult.Cust_Full_Name);

  // let CustomerName;

  // if (NewCustName != null) {

    // CustomerName = NewCustName.CustomerName
    // logger.info(`Inside if block CustName After: ${CustomerName}`)
  // }
  // else {
    // CustomerName = CustomerDetailsRespResult.Cust_Full_Name;
    // logger.info(`Inside else block CustName After: ${CustomerName}`)
  // }

  // logger.info(`CustName After: ${CustomerName}`)

  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('p_CustomerID', sql.NVarChar, CustomerID)
          // .input('p_PMSNumber', sql.NVarChar, PMSNumber)
          // .input('p_JourneyID', sql.NVarChar, JourneyID)
          // .input('p_Cust_Full_Name', sql.NVarChar, CustomerName)
          // .input('p_Date_of_Birth', sql.NVarChar, CustomerDetailsRespResult.Date_of_Birth)
          // .input('p_F_H_Name', sql.NVarChar, CustomerDetailsRespResult.F_H_Name)
          // .input('p_Mother_Name', sql.NVarChar, CustomerDetailsRespResult.Mother_Name)
          // .input('p_Gender', sql.NVarChar, CustomerDetailsRespResult.Gender)
          // .input('p_Religion', sql.NVarChar, CustomerDetailsRespResult.Religion)
          // .input('p_PANCard', sql.NVarChar, CustomerDetailsRespResult.PANCard)
          // .input('p_Constitution_Type', sql.NVarChar, CustomerDetailsRespResult.Constitution_Type)
          // .input('p_Occupation_Type', sql.NVarChar, CustomerDetailsRespResult.Occupation_Type)
          // .input('p_MobileNo', sql.NVarChar, CustomerDetailsRespResult.MobileNo)
          // .input('p_Email_ID', sql.NVarChar, CustomerDetailsRespResult.Email_ID)
          // .input('p_Minor', sql.NVarChar, CustomerDetailsRespResult.Minor)
          // .input('p_IncomeCategory', sql.NVarChar, CustomerDetailsRespResult.IncomeCategory)
          // .input('p_StaffFlag', sql.NVarChar, CustomerDetailsRespResult.Staff_Flag)
          // .input('p_CommunicationAddress', sql.Text, JSON.stringify(CustomerDetailsRespCommAddress))
          // .input('p_CommunicationAddress_Address1', sql.NVarChar, CustomerDetailsRespCommAddress.Address1)
          // .input('p_CommunicationAddress_Address2', sql.NVarChar, CustomerDetailsRespCommAddress.Address2)
          // .input('p_CommunicationAddress_City', sql.NVarChar, CustomerDetailsRespCommAddress.City)
          // .input('p_CommunicationAddress_State', sql.NVarChar, CustomerDetailsRespCommAddress.State)
          // .input('p_CommunicationAddress_PINCode', sql.NVarChar, CustomerDetailsRespCommAddress.PINCode)
          // .input('p_CommunicationAddress_Country', sql.NVarChar, CustomerDetailsRespCommAddress.Country)
          // .input('p_PermanentAddress', sql.Text, JSON.stringify(CustomerDetailsRespPermAddress))
          // .input('p_PermanentAddress_Address1', sql.NVarChar, CustomerDetailsRespPermAddress.Address1)
          // .input('p_PermanentAddress_Address2', sql.NVarChar, CustomerDetailsRespPermAddress.Address2)
          // .input('p_PermanentAddress_City', sql.NVarChar, CustomerDetailsRespPermAddress.City)
          // .input('p_PermanentAddress_State', sql.NVarChar, CustomerDetailsRespPermAddress.State)
          // .input('p_PermanentAddress_PINCode', sql.NVarChar, CustomerDetailsRespPermAddress.PINCode)
          // .input('p_PermanentAddress_Country', sql.NVarChar, CustomerDetailsRespPermAddress.Country)
          // .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          // .execute('proc_CBS_CustomerDetails_Insert', function (err, queryResult) {
            // logger.info("Error :- " + err);
            // //logger.info('QueryResult:', queryResult); // Retrieve output parameter      
            // logger.info('Out Variable: ', queryResult.output.p_OutStatusCode); // Retrieve output parameter                                           
            // // logger.info('response affect:' + queryResult.rowsAffected[0]);
            // if (queryResult.output.p_OutStatusCode == '200' && queryResult.rowsAffected[0] > 0) {
              // //logger.info('response isDataInsert:' + queryResult.output.p_OutStatusCode);                              
              // conn.close();

              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "Customer Details saved Successfully.",
              // }
              // resolve(response);
            // }
            // else {

              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": "Error to save customer details in database."
              // }
              // logger.info("Error while insert in database :- " + err);
              // // res.json(err); 
              // resolve(response);
            // }
          // });
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function CBSCustomerDetails_Insert(PMSNumber, JourneyID, CustomerDetailsPlainResp, CustomerID) {
  logger.info('CBS Cust Data insert in database ' + CustomerID);

  return new Promise(async (resolve, reject) => {
    try {
      const CustomerDetailsRespStatus = JSON.parse(CustomerDetailsPlainResp);
      const CustomerDetailsRespData = JSON.parse(CustomerDetailsRespStatus.ResponseData);
      const CustomerDetailsRespResult = CustomerDetailsRespData.result;
      const CustomerDetailsRespCommAddress = CustomerDetailsRespResult.CommunicationAddress;
      const CustomerDetailsRespPermAddress = CustomerDetailsRespResult.PermanentAddress;

      const NewCustName = separateNameAndRelation(CustomerDetailsRespResult.Cust_Full_Name);

      let CustomerName;
      if (NewCustName != null) {
        CustomerName = NewCustName.CustomerName;
        logger.info(`Inside if block CustName After: ${CustomerName}`);
      } else {
        CustomerName = CustomerDetailsRespResult.Cust_Full_Name;
        logger.info(`Inside else block CustName After: ${CustomerName}`);
      }

      logger.info(`CustName After: ${CustomerName}`);

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('p_CustomerID', sql.NVarChar, CustomerID)
        .input('p_PMSNumber', sql.NVarChar, PMSNumber)
        .input('p_JourneyID', sql.NVarChar, JourneyID)
        .input('p_Cust_Full_Name', sql.NVarChar, CustomerName)
        .input('p_Date_of_Birth', sql.NVarChar, CustomerDetailsRespResult.Date_of_Birth)
        .input('p_F_H_Name', sql.NVarChar, CustomerDetailsRespResult.F_H_Name)
        .input('p_Mother_Name', sql.NVarChar, CustomerDetailsRespResult.Mother_Name)
        .input('p_Gender', sql.NVarChar, CustomerDetailsRespResult.Gender)
        .input('p_Religion', sql.NVarChar, CustomerDetailsRespResult.Religion)
        .input('p_PANCard', sql.NVarChar, CustomerDetailsRespResult.PANCard)
        .input('p_Constitution_Type', sql.NVarChar, CustomerDetailsRespResult.Constitution_Type)
        .input('p_Occupation_Type', sql.NVarChar, CustomerDetailsRespResult.Occupation_Type)
        .input('p_MobileNo', sql.NVarChar, CustomerDetailsRespResult.MobileNo)
        .input('p_Email_ID', sql.NVarChar, CustomerDetailsRespResult.Email_ID)
        .input('p_Minor', sql.NVarChar, CustomerDetailsRespResult.Minor)
        .input('p_IncomeCategory', sql.NVarChar, CustomerDetailsRespResult.IncomeCategory)
        .input('p_StaffFlag', sql.NVarChar, CustomerDetailsRespResult.Staff_Flag)
        .input('p_CommunicationAddress', sql.Text, JSON.stringify(CustomerDetailsRespCommAddress))
        .input('p_CommunicationAddress_Address1', sql.NVarChar, CustomerDetailsRespCommAddress.Address1)
        .input('p_CommunicationAddress_Address2', sql.NVarChar, CustomerDetailsRespCommAddress.Address2)
        .input('p_CommunicationAddress_City', sql.NVarChar, CustomerDetailsRespCommAddress.City)
        .input('p_CommunicationAddress_State', sql.NVarChar, CustomerDetailsRespCommAddress.State)
        .input('p_CommunicationAddress_PINCode', sql.NVarChar, CustomerDetailsRespCommAddress.PINCode)
        .input('p_CommunicationAddress_Country', sql.NVarChar, CustomerDetailsRespCommAddress.Country)
        .input('p_PermanentAddress', sql.Text, JSON.stringify(CustomerDetailsRespPermAddress))
        .input('p_PermanentAddress_Address1', sql.NVarChar, CustomerDetailsRespPermAddress.Address1)
        .input('p_PermanentAddress_Address2', sql.NVarChar, CustomerDetailsRespPermAddress.Address2)
        .input('p_PermanentAddress_City', sql.NVarChar, CustomerDetailsRespPermAddress.City)
        .input('p_PermanentAddress_State', sql.NVarChar, CustomerDetailsRespPermAddress.State)
        .input('p_PermanentAddress_PINCode', sql.NVarChar, CustomerDetailsRespPermAddress.PINCode)
        .input('p_PermanentAddress_Country', sql.NVarChar, CustomerDetailsRespPermAddress.Country)
        .output('p_OutStatusCode', sql.NVarChar)
        .execute('proc_CBS_CustomerDetails_Insert');

      ////logger.info('QueryResult: ' + JSON.stringify(result));
      //logger.info('Out Variable: ' + result.output.p_OutStatusCode);

      if (result.output.p_OutStatusCode === '200' &&
          result.rowsAffected &&
          result.rowsAffected[0] > 0) {

        resolve({
          "ErrorCode": "00",
          "ErrorMsg": "Customer Details saved Successfully."
        });
      } else {
        resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error to save customer details in database."
        });
      }

    } catch (err) {
      logger.error('CBSCustomerDetails_Insert Error:', err);
  
	   resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error to save customer details in database."
        });
    }
  });
}


function LoanStatusInquiryAPI(PMSNumber, JourneyID, objloanStatusInquiry) {
  logger.info('');
  logger.info('***************************Inside LoanStatusInquiryAP Method***************************');
  let objloanStatusInquiryParsed = JSON.parse(objloanStatusInquiry);

  logger.info('CustomerID: ' + objloanStatusInquiryParsed.CustomerID);
  logger.info('Loan Amount: ' + objloanStatusInquiryParsed.LoanAmount);

  let loanStatusInquiryResponse;
  return new Promise(async (resolve, reject) => {
    try {

      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest'; //process.env.CBS_API_URL;
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      logger.info('API URL', API_URL);

      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + objloanStatusInquiryParsed.Access_Token
      }
      logger.info('Request Header ', headers);

      let CustomerData = {
        "CustId":     objloanStatusInquiryParsed.CustomerID            ,         // 'DGR015678' ,                    //  objloanStatusInquiryParsed.CustomerID,     //'O70648194',//C01083839,U42362448//'O70648194' // objloanStatusInquiryParsed.CustomerID
        "LoanAmount": objloanStatusInquiryParsed.LoanAmount,
      }
      let Plainbody = {
        "OperationName": "LoanStatusInquiry",
        "RequestData": JSON.stringify(CustomerData)
      }
      //Call Enc
      logger.info('Plain Request: ' + JSON.stringify(Plainbody));

      objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Request: ' + JSON.stringify(body));
          //Insert Error Log
          logger.info('');
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "LoanStatusInquiryAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("APILog Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              logger.info('Call axios.post here');
              axios.post(API_URL, JSON.stringify(body), { headers }).then(resp => {
                //logger.info('Enc Response: ', resp.data);

                let encresp = JSON.parse(JSON.stringify(resp.data));
                //logger.info('encresp.EncRespData: '+encresp.EncRespData)                     
                objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("APILog Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        //logger.info("Plain Response: ",JSON.stringify(PlainResponse));

                        //PlainResponse='{"Status":"Success","ResponseData":"{\"Response\":\"CustomerID Validated\"}"}';                               

                        //logger.info("Plain Status: ", JSON.parse(PlainResponse).Status);

                        let parsedData = JSON.parse(PlainResponse);
                        logger.info(`CBS parse Data: ${JSON.stringify(parsedData)}`);
                        const status = parsedData.Status; // "Failure"
                        const responseData = parsedData.ResponseData;
                        logger.info(`parsedData Status: ${status}`);
                        logger.info(`parsedData responseData: ${responseData}`);

                        if (JSON.parse(PlainResponse).Status == "Success") {
                          loanStatusInquiryResponse = {
                            "ErrorCode": "00",
                            "ErrorStatus": parsedData.Status,
                            "ErrorMsg": "CustomerID Validated"
                          }
                          logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
                          resolve(loanStatusInquiryResponse);
                        }
                        else if (parsedData.Status == "Failure" && responseData.Response == "Some Error Occurred. Please contact PNB Team.") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorStatus": parsedData.Status,
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);

                        }
                        else if (parsedData.Status == "Failure" && responseData.Response == "Fail while calling ESVN LoanStatusInquiry in Core banking solution") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorStatus": "",
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                        else {
                          loanStatusInquiryResponse = {
                            "ErrorCode": "03",
                            "ErrorStatus": JSON.parse(PlainResponse).Status,
                            "ErrorMsg": JSON.parse(PlainResponse).ResponseData.split(':')[1]
                          }
                          logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
                          resolve(loanStatusInquiryResponse);
                        }
                      }
                    });
                  }
                });
              })
                .catch(error => {
                  console.error('Error posting to Loan Status API:', error);
                  
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "LoanStatusInquiryAPI").then(async (ErrorLogResp) => {
                    ExceptionResp = {
                      "ErrorCode": "01",
                      "ErrorMsg": 'System error occurred. Please retry after sometime or contact your branch for further assistance',
                    }
                    resolve(ExceptionResp);
                  });
                });
            }
          });
        }
      });
    } catch (err1) {
      logger.info('Exception:', err1);
      reject(err1);
    }
  });
}

function LoanStatusInquiryAPIM(PMSNumber, JourneyID, objloanStatusInquiry) {
  logger.info('');
  logger.info('***************************Inside LoanStatusInquiryAPIM Method***************************');
  let objloanStatusInquiryParsed = JSON.parse(objloanStatusInquiry);

  logger.info('CustomerID: ' + objloanStatusInquiryParsed.CustomerID);
  logger.info('Loan Amount: ' + objloanStatusInquiryParsed.LoanAmount);

  let loanStatusInquiryResponse;
  return new Promise(async (resolve, reject) => {
    try {

      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest'; //process.env.CBS_API_URL;
       const API_URL = await GetKeyConfigurationValue('APIMLoanStatusInquiry');
      const ClientID = await GetKeyConfigurationValue('APIMClientID');
      logger.info('API URL', API_URL);

      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + objloanStatusInquiryParsed.Access_Token
      }
      logger.info('Request Header ', headers);

      let CustomerData1 = {
        "CustId":     objloanStatusInquiryParsed.CustomerID,         // 'DGR015678' ,                    //  objloanStatusInquiryParsed.CustomerID,     //'O70648194',//C01083839,U42362448//'O70648194' // objloanStatusInquiryParsed.CustomerID
        "LoanAmount": objloanStatusInquiryParsed.LoanAmount,
      }
 let CustomerData = {
        "CustId":     objloanStatusInquiryParsed.CustomerID,         // 'DGR015678' ,                    //  objloanStatusInquiryParsed.CustomerID,     //'O70648194',//C01083839,U42362448//'O70648194' // objloanStatusInquiryParsed.CustomerID
        "LoanAmount": objloanStatusInquiryParsed.LoanAmount.toString(),
      }


  
      let Plainbody = {
        "OperationName": "LoanStatusInquiry",
        "RequestData": JSON.stringify(CustomerData)
      }
      
      //Call Enc
      logger.info('Plain Request: ' + JSON.stringify(Plainbody));

      objCommonFunction.APIMEncrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Request: ' + JSON.stringify(body));
          //Insert Error Log
          logger.info('');
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "LoanStatusInquiryAPIM", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("APILog Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              logger.info('Call axios.post here');
              axios.post(API_URL, JSON.stringify(body), { headers }).then(resp => {
                //logger.info('Enc Response: ', resp.data);

                let encresp = JSON.parse(JSON.stringify(resp.data));
                //logger.info('encresp.EncRespData: '+encresp.EncRespData)                     
                objCommonFunction.APIMDecrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("APILog Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        //logger.info("Plain Response: ",JSON.stringify(PlainResponse));

                        //PlainResponse='{"Status":"Success","ResponseData":"{\"Response\":\"CustomerID Validated\"}"}';                               

                        //logger.info("Plain Status: ", JSON.parse(PlainResponse).Status);

                        let parsedData = PlainResponse;
                        logger.info(`CBS parse Data: ${JSON.stringify(parsedData)}`);
                        const status = parsedData.Status; // "Failure"
                        const responseData = parsedData.ResponseData;
                        logger.info(`parsedData Status: ${status}`);
                        logger.info(`parsedData responseData: ${responseData}`);

                        if (parsedData.Status == "Success") {
                          loanStatusInquiryResponse = {
                            "ErrorCode": "00",
                            "ErrorStatus": parsedData.Status,
                            "ErrorMsg": "CustomerID Validated"
                          }
                          logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
                          resolve(loanStatusInquiryResponse);
                        }
                        else if (parsedData.Status == "Failure" && responseData.Response == "Some Error Occurred. Please contact PNB Team.") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorStatus": parsedData.Status,
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);

                        }
                        else if (parsedData.Status == "Failure" && responseData.Response == "Fail while calling ESVN LoanStatusInquiry in Core banking solution") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorStatus": "",
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                        else {
                          loanStatusInquiryResponse = {
                            "ErrorCode": "03",
                            "ErrorStatus": parsedData.Status,
                            "ErrorMsg":  PlainResponse.ERRORDESC
                          }
                          logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
                          resolve(loanStatusInquiryResponse);
                        }
                      }
                    });
                  }
                });
              })
                .catch(error => {
                  console.error('Error posting to Loan Status APIM:', error);
                  
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "LoanStatusInquiryAPIM").then(async (ErrorLogResp) => {
                    ExceptionResp = {
                      "ErrorCode": "01",
                      "ErrorMsg": 'System error occurred. Please retry after sometime or contact your branch for further assistance',
                    }
                    resolve(ExceptionResp);
                  });
                });
            }
          });
        }
      });
    } catch (err1) {
      logger.info('Exception:', err1);
      reject(err1);
    }
  });
}


function NPAStatusInquiryAPI(PMSNumber, JourneyID, objNPAStatusInquiry) {
  logger.info('***************************Inside NPAStatusInquiry Method***************************');
  logger.info('CustomerID ' + objNPAStatusInquiry.CustomerID);
  return new Promise(async (resolve, reject) => {
    try {
      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';            
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + objNPAStatusInquiry.Access_Token
      }
      let CustomerData = {
        "CustId": objNPAStatusInquiry.CustomerID    //NPA CUSTID: ABD008865   ,O70648194 No issue     //"O70648194"  //objNPAStatusInquiry.CustomerID
      }
      let Plainbody = {
        "OperationName": "NPAStatusInquiry",
        "RequestData": JSON.stringify(CustomerData)
      }

      logger.info(`Plain Request: ${JSON.stringify(Plainbody)}`);
      objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }

          logger.info(`Enc request ${JSON.stringify(body)}`);
          //logger.info('Body: '+JSON.stringify(body));
          //Insert Error Log
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "NPAStatusInquiryAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info(`Insert ErrorCode ${APILogsResp.ErrorCode}`);
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                //logger.info('CBS Response for Customer Details API data:', resp.data);

                let encresp = JSON.parse(JSON.stringify(resp.data));
                //logger.info('encresp.EncRespData: '+encresp.EncRespData)                      
                objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        let parsedData = JSON.parse(PlainResponse);
                        logger.info(`CBS parse Data: ${JSON.stringify(parsedData)}`);
                        const status = parsedData.Status; // "Failure"
                        const responseData = parsedData.ResponseData;
                        logger.info(`parsedData Status: ${status}`);
                        logger.info(`parsedData responseData: ${responseData}`);

                        if (status == "Success") {
                          //const responseData = JSON.parse(parsedData.ResponseData);
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "00",
                            "ErrorMsg": responseData,
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                        else if (status == "Failure" && responseData == "Some Error Occurred. Please contact PNB Team.") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);

                        }
                        else if (status == "Failure" && responseData == "Fail while calling ESVN NPAStatusInquiry in Core banking solution") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                        else {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "03",
                            "ErrorMsg": responseData,
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                      }
                    });
                  }
                });
              })
                .catch(error => {
                  console.error('Error posting to SIDBI Status API:', error);
                  // console.error('Error NPA Status Inquiry API Error Response:',error.response);
                  // console.error('Error NPA Status Inquiry API Error Response Text:',error.response.statusText);
                  // console.error('Error NPA Status Inquiry API Error Response data:',error.response.data);                      
                  //Insert Error Log
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "NPAStatusInquiryAPI").then(async (ErrorLogResp) => {
                    resp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                    }
                    resolve(resp);
                  });
                });
            }
          });
        }
      });
    } catch (exception) {
      logger.info(exception);
      logError.ErrorLogs(PMSNumber, "Catch Exception", exception, "NPAStatusInquiryAPI").then(async (ErrorLogResp) => {
        reject(exception);
      });
    }
  });
}

function NPAStatusInquiryAPIM(PMSNumber, JourneyID, objNPAStatusInquiry) {
  logger.info('***************************Inside NPAStatusInquiryAPIM Method***************************');
  logger.info('CustomerID ' + objNPAStatusInquiry.CustomerID);
  return new Promise(async (resolve, reject) => {
    try {
      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';            
      
        const API_URL = await GetKeyConfigurationValue('APIMNPAStatusInquiry');
      const ClientID = await GetKeyConfigurationValue('APIMClientID');
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + objNPAStatusInquiry.Access_Token
      }
      let CustomerData = {
        "CustId": objNPAStatusInquiry.CustomerID    //NPA CUSTID: ABD008865   ,O70648194 No issue     //"O70648194"  //objNPAStatusInquiry.CustomerID
      }
      let Plainbody = {
        "OperationName": "NPAStatusInquiry",
        "RequestData": JSON.stringify(CustomerData)
      }

      logger.info(`Plain Request: ${JSON.stringify(Plainbody)}`);
      objCommonFunction.APIMEncrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }

          logger.info(`Enc request ${JSON.stringify(body)}`);
          //logger.info('Body: '+JSON.stringify(body));
          //Insert Error Log
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "NPAStatusInquiryAPIM", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info(`Insert ErrorCode ${APILogsResp.ErrorCode}`);
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                //logger.info('CBS Response for Customer Details API data:', resp.data);

                let encresp = JSON.parse(JSON.stringify(resp.data));
                //logger.info('encresp.EncRespData: '+encresp.EncRespData)                      
                objCommonFunction.APIMDecrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                      // let parsedData = JSON.parse(PlainResponse);
                      let parsedData =PlainResponse;
                        logger.info(`CBS parse Data: ${JSON.stringify(parsedData)}`);
                        const status = parsedData.Status; // "Failure"
                        const responseData = parsedData.ResponseData;
                        logger.info(`parsedData Status: ${status}`);
                        logger.info(`parsedData responseData: ${responseData}`);

                        if (status == "Success") {
                          //const responseData = JSON.parse(parsedData.ResponseData);
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "00",
                            "ErrorMsg": responseData,
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                        else if (status == "Failure" && responseData == "Some Error Occurred. Please contact PNB Team.") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);

                        }
                        else if (status == "Failure" && responseData == "Fail while calling ESVN NPAStatusInquiryAPIM in Core banking solution") {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "02",
                            "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                        else {
                          //Insert data in database
                          let NPAStatusInquiryResponse = {
                            "ErrorCode": "03",
                            "ErrorMsg": responseData,
                            "StatusCode": status
                          }
                          //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
                          resolve(NPAStatusInquiryResponse);
                        }
                      }
                    });
                  }
                });
              })
                .catch(error => {
                  console.error('Error posting to NAP Status  APIM:', error);
                  // console.error('Error NPA Status Inquiry API Error Response:',error.response);
                  // console.error('Error NPA Status Inquiry API Error Response Text:',error.response.statusText);
                  // console.error('Error NPA Status Inquiry API Error Response data:',error.response.data);                      
                  //Insert Error Log
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "NPAStatusInquiryAPIM").then(async (ErrorLogResp) => {
                    resp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                    }
                    resolve(resp);
                  });
                });
            }
          });
        }
      });
    } catch (exception) {
      logger.info(exception);
      logError.ErrorLogs(PMSNumber, "Catch Exception", exception, "NPAStatusInquiryAPI").then(async (ErrorLogResp) => {
        reject(exception);
      });
    }
  });
}


//Combine Both Functinality in one API Loan Status and NPA
// function APIMLoanStatusInquiryAPI(PMSNumber, JourneyID, objloanStatusInquiry) {
//   logger.info('');
//   logger.info('***************************Inside APIMLoanStatusInquiryAPI Method***************************');
//   let objloanStatusInquiryParsed = JSON.parse(objloanStatusInquiry);

//  logger.info('objloanStatusInquiry' + objloanStatusInquiry);
//   logger.info('CustomerID: ' + objloanStatusInquiryParsed.CustomerID);
//   logger.info('Loan Amount: ' + objloanStatusInquiryParsed.LoanAmount);
//  logger.info('Scheme Code:' + objloanStatusInquiryParsed.SchmCode);
//   let loanStatusInquiryResponse;
//   return new Promise(async (resolve, reject) => {
//     try {

//       //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest'; //process.env.CBS_API_URL;
//       const API_URL = await GetKeyConfigurationValue('APIMLoanStatus');
//       const ClientID = await GetKeyConfigurationValue('APIMClientID');
//       logger.info('API URL', API_URL);

//       headers = {
//         'Client-Id': ClientID, // Replace with your custom header value
//         'Content-Type': 'application/json',  // Replace with another custom header value
//         'Authorization': 'Bearer ' + objloanStatusInquiryParsed.Access_Token
//       }
//       logger.info('Request Header ', headers);

//       let CustomerData = {
//         "custId":    objloanStatusInquiryParsed.CustomerID ,             //'DGR015678' ,            ,         //                     //  objloanStatusInquiryParsed.CustomerID,     //'O70648194',//C01083839,U42362448//'O70648194' // objloanStatusInquiryParsed.CustomerID
//         // "LoanAmount": objloanStatusInquiryParsed.LoanAmount,
//         "schmCode": objloanStatusInquiryParsed.SchmCode
//       }

//       let Plainbody1 = CustomerData
 

//       let Plainbody= {
//        "OperationName": "LoanStatus",
//         "RequestData": JSON.stringify(CustomerData)
//       }
//       //Call Enc
//       logger.info('Plain Request: ' + JSON.stringify(Plainbody));

//       objCommonFunction.APIMEncrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
//         if (EncResponse != null) {
//           body = {
//             "EncReqData": EncResponse
//           }
//           logger.info('Enc Request: ' + JSON.stringify(body));
//           //Insert Error Log
//           logger.info('');
//           logError.APIRequestResponseLogs(PMSNumber, JourneyID, "LoanStatusInquiryAPIM", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
//             logger.info("APILog Insert ErrorCode " + APILogsResp.ErrorCode)
//             if (APILogsResp.ErrorCode == "00") {
//               logger.info('Call axios.post here');
//               axios.post(API_URL, JSON.stringify(body), { headers }).then(resp => {
//                 //logger.info('Enc Response: ', resp.data);

//                 let encresp = JSON.parse(JSON.stringify(resp.data));
//                 logger.info('encresp.EncRespData: '+encresp.EncRespData)                     
//                 objCommonFunction.APIMDecrypt(encresp.EncRespData).then(async (PlainResponse) => {
//                   if (PlainResponse != null) {
//                     logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
//                       logger.info("APILog Update ErrorCode " + APILogsResp.ErrorCode)
//                       if (APILogsResp.ErrorCode == "00") {
//                         logger.info("Plain Response: ",JSON.stringify(PlainResponse));

//                         //PlainResponse='{"Status":"Success","ResponseData":"{\"Response\":\"CustomerID Validated\"}"}';                               

//                       //  logger.info("Plain Status: ", JSON.parse(PlainResponse).Status);

//                         let parsedData = PlainResponse;
//                         logger.info(`CBS parse Data: ${JSON.stringify(parsedData)}`);
//                         const status = parsedData.ResponseStatus; // "Failure"
//                         const responseData = parsedData.ResponseData;
//                         logger.info(`parsedData Status: ${status}`);
//                         logger.info(`parsedData responseData: ${responseData}`);

//                         if (parsedData.ResponseStatus == "Success") {
//                           loanStatusInquiryResponse = {
//                             "ErrorCode": "00",
//                             "ErrorStatus": parsedData.ResponseStatus,
//                             "ErrorMsg": "CustomerID Validated"
//                           }
//                           logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
//                           resolve(loanStatusInquiryResponse);
//                         }
//                         else if (parsedData.Status == "Failure" && responseData.Response == "Some Error Occurred. Please contact PNB Team.") {
//                           //Insert data in database
//                           let NPAStatusInquiryResponse = {
//                             "ErrorCode": "02",
//                             "ErrorStatus": parsedData.ResponseStatus,
//                             "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
//                           }
//                           //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
//                           resolve(NPAStatusInquiryResponse);

//                         }
//                         else if (parsedData.Status == "Failure" && responseData.Response == "Fail while calling ESVN LoanStatusInquiry in Core banking solution") {
//                           //Insert data in database
//                           let NPAStatusInquiryResponse = {
//                             "ErrorCode": "02",
//                             "ErrorStatus": "",
//                             "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
//                           }
//                           //logger.info('NPAStatusInquiryResponse: '+JSON.stringify(NPAStatusInquiryResponse));
//                           resolve(NPAStatusInquiryResponse);
//                         }
//                         else {
//                           loanStatusInquiryResponse = {
//                             "ErrorCode": "03",
//                             "ErrorStatus": parsedData.Status,
//                             "ErrorMsg": parsedData.ResponseData
//                           }
//                           logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
//                           resolve(loanStatusInquiryResponse);
//                         }
//                       }
//                     });
//                   }
//                 });
//               })
//                 .catch(error => {
//                   console.error('Error posting to Loan Status APIM:', error);
               
//                   //Insert Error Log
//                   logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "LoanStatusInquiryAPIM").then(async (ErrorLogResp) => {
//                     ExceptionResp = {
//                       "ErrorCode": "01",
//                       "ErrorMsg": 'System error occurred. Please retry after sometime or contact your branch for further assistance',
//                     }
//                     resolve(ExceptionResp);
//                   });
//                 });
//             }
//           });
//         }
//       });
//     } catch (err1) {
//       logger.info('Exception:', err1);
//       reject(err1);
//     }
//   });
// }



function APIMLoanStatusInquiryAPI(PMSNumber, JourneyID, objloanStatusInquiry) {

  logger.info('***************************Inside APIMLoanStatusInquiryAPI Method***************************');

  let objloanStatusInquiryParsed = JSON.parse(objloanStatusInquiry);

  logger.info('CustomerID: ' + objloanStatusInquiryParsed.CustomerID);
  logger.info('Loan Amount: ' + objloanStatusInquiryParsed.LoanAmount);
  logger.info('Scheme Code:' + objloanStatusInquiryParsed.SchmCode);

  let loanStatusInquiryResponse;
  return new Promise(async (resolve, reject) => {

    try {

      const API_URL = await GetKeyConfigurationValue('APIMLoanStatus');
      const ClientID = await GetKeyConfigurationValue('APIMClientID');

      headers = {
        'Client-Id': ClientID,
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + objloanStatusInquiryParsed.Access_Token
      }

      let CustomerData = {
        "custId":   objloanStatusInquiryParsed.CustomerID,
        "schmCode": objloanStatusInquiryParsed.SchmCode
      }

      let Plainbody = {
        "OperationName": "LoanStatus",
        "RequestData": JSON.stringify(CustomerData)
      }

      logger.info('Plain Request: ' + JSON.stringify(Plainbody));

      objCommonFunction.APIMEncrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {

        if (EncResponse != null) {

          body = { "EncReqData": EncResponse }

          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "LoanStatusInquiryAPIM",
            JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert")
            .then(async (APILogsResp) => {

              if (APILogsResp.ErrorCode == "00") {

                axios.post(API_URL, JSON.stringify(body), { headers }).then(resp => {

                  let encresp = JSON.parse(JSON.stringify(resp.data));

                  objCommonFunction.APIMDecrypt(encresp.EncRespData).then(async (PlainResponse) => {

                    if (PlainResponse != null) {

                      logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null,
                        JSON.stringify(PlainResponse), JSON.stringify(resp.data),
                        APILogsResp.RequestId, "Update");

                      let parsedData = PlainResponse;

                      const status = parsedData.ResponseStatus;
                      const message = parsedData.ResponseData;

                      logger.info(`CBS Response: ${JSON.stringify(parsedData)}`);

                      if (status == "Success") {

                        // Step 15 Final Success
                        loanStatusInquiryResponse = {
                          "ErrorCode": "00",
                          "ErrorStatus": "Success",
                          "ErrorMsg": "CustomerID Validated"
                        };

                        return resolve(loanStatusInquiryResponse);
                      }

                      if (status == "Failure") {

                        let errorMsg = message;

                        // Step 1
                        if (errorMsg.includes("Input missing for opening A/C")) {
                          return resolve({ ErrorCode: "01",ErrorStatus: "Failure", ErrorMsg: "Input missing for opening A/C" });
                        }

                        // Step 2
                        if (errorMsg.includes("Scheme code missing")) {
                          return resolve({ ErrorCode: "01", ErrorStatus: "Failure",ErrorMsg: "Scheme code missing for opening A/C" });
                        }

                        // Step 3 & 4
                        if (errorMsg.includes("Invalid Cust Id")) {
                          return resolve({ ErrorCode: "01", ErrorStatus: "Failure",ErrorMsg: "Invalid Cust Id" });
                        }

                        // Step 5
                        if (errorMsg.includes("Business loan exists")) {
                          return resolve({
                            ErrorCode: "06",
                            ErrorStatus: "Failure",
                            ErrorMsg: "Business loan exists against this customer ID"
                          });
                        }

                        // Step 6
                        if (errorMsg.includes("PM-SVANIDHI account is NPA")) {
                          return resolve({
                            ErrorCode: "05",
                            ErrorStatus: "Failure",
                            ErrorMsg: "Either a current PM-SVANIDHI account is NPA or a PM-SVANIDHI account was closed with NPA status previously"  ///reject
                            
                          });
                        }

                        // Step 7
                        if (errorMsg.includes("NPA account exists")) {
                          return resolve({
                            ErrorCode: "05",
                            ErrorStatus: "Failure",
                            ErrorMsg: "NPA account exists against this customer ID"  //reject
                          });
                        }

                        // Step 8
                        if (errorMsg.includes("active PM-SVANIDHI account exists")) {
                          return resolve({
                            ErrorCode: "01",
                            ErrorStatus: "Failure",
                            ErrorMsg: "Customer ID is not eligible as an active PM-SVANIDHI account exists"
                          });
                        }

                        // Step 9 & 10
                        if (errorMsg.includes("not eligible as per scheme guidelines")) {
                          return resolve({
                            ErrorCode: "01",
                            ErrorStatus: "Failure",
                            ErrorMsg: "This Customer is not eligible as per scheme guidelines"
                          });
                        }

                        // Step 11
                        if (errorMsg.includes("not availed loan under Tranche 1")) {
                          return resolve({
                            ErrorCode: "01",
                            ErrorStatus: "Failure",
                            ErrorMsg: "Account cannot be opened as customer has not availed loan under Tranche 1"
                          });
                        }

                        // Step 12
                        if (errorMsg.includes("not fully disbursed")) {
                          return resolve({
                            ErrorCode: "01",
                            ErrorStatus: "Failure",
                            ErrorMsg: "Account cannot be opened as Tranche 1 account was not fully disbursed"
                          });
                        }

                        // Step 13
                        if (errorMsg.includes("not availed loan under Tranche 2")) {
                          return resolve({
                            ErrorCode: "01",
                            ErrorStatus: "Failure",
                            ErrorMsg: "Account cannot be opened as customer has not availed loan under Tranche 2"
                          });
                        }

                        // Step 14
                        if (errorMsg.includes("Tranche 2 account was not fully disbursed")) {
                          return resolve({
                            ErrorCode: "01",
                            ErrorStatus: "Failure",
                            ErrorMsg: "Account cannot be opened as Tranche 2 account was not fully disbursed"
                          });
                        }

                        else if (errorMsg && errorMsg.includes("Difference between sanction date of Tranche 2 and 3 should be greater than 6 months")) {
                        return resolve({
                      ErrorCode: "02",
                      ErrorStatus: "Failure",
                      ErrorMsg: "Difference between sanction date of Tranche 2 and 3 should be greater than 6 months"
                    });
                  }
                        // System error
                        if (errorMsg.includes("Some Error Occurred")) {
                          return resolve({
                            ErrorCode: "02",
                            ErrorStatus: "Failure",
                            ErrorMsg: "System error occurred. Please retry after sometime or contact your branch for further assistance"
                          });
                        }

                        // Default fallback
                        return resolve({
                          ErrorCode: "03",
                          ErrorMsg: errorMsg
                        });

                      }

                    }

                  });

                })
                  .catch(error => {

                    logError.ErrorLogs(PMSNumber, JourneyID,
                      error.response?.status,
                      error.response?.statusText,
                      "LoanStatusInquiryAPIM");

                    return resolve({
                      ErrorCode: "01",
                      ErrorMsg: "System error occurred. Please retry after sometime or contact your branch for further assistance"
                    });

                  });

              }

            });

        }

      });

    }
    catch (err1) {

      logger.info('Exception:', err1);

      reject(err1);

    }

  });

}







function BalanceInquiryAPI(PMSNumber, JourneyID, BalanceInquiryAPIReq, parsePMSDetails) {
  logger.info('************************ Inside BalanceInquiryAPI Method *************************');
  logger.info('AccountNo: ' + JSON.parse(BalanceInquiryAPIReq).AccountNo);
  logger.info('Access_Token: ' + JSON.parse(BalanceInquiryAPIReq).Access_Token);
  let BalInquiryResp;
  return new Promise(async (resolve, reject) => {
    try {

      //const API_URL=process.env.CBS_API_URL;
      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';    
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      logger.info('API_URL ' + API_URL);

      let token = JSON.parse(BalanceInquiryAPIReq).Access_Token;

      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + token
      }
      let AccountData = {
        "AcctNo": JSON.parse(BalanceInquiryAPIReq).AccountNo
      }
      let Plainbody = {
        "OperationName": "BalanceInquiry",
        "RequestData": JSON.stringify(AccountData)
      }
      //Call Enc
      logger.info('Body plain ' + JSON.stringify(Plainbody));

      objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Body: ' + JSON.stringify(body));
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "BalanceInquiryAPI", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                logger.info('CBS Response for Balance Enquiry API data:', resp.data);
                let encresp = JSON.parse(JSON.stringify(resp.data));
                // logger.info('encresp.EncRespData: '+encresp.EncRespData)
                objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    //logger.info("PlainResponse: "+ (PlainResponse));

                    const Resp = JSON.parse(PlainResponse);

                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        //logger.info("Status "+ Resp.Status);

                        logger.info("EffectiveAvlAmt "+JSON.parse(Resp.ResponseData).EffectiveAvlAmt);                            
                        if (Resp.Status == "Success") {
                          CustomerJourneyDataUpdate(PMSNumber, JourneyID, JSON.parse(Resp.ResponseData).EffectiveAvlAmt, null, "BalanceInquiry").then(async (BalanceInquiryResp) => {
                            logger.info("Customer Journey BalanceInquiry Updated in Database" + JSON.stringify(BalanceInquiryResp));
                            if (BalanceInquiryResp.ErrorCode == "00") {
                              BalInquiryResp = {
                                "ErrorCode": "00",
                                "ErrorMsg": "CBS API successfully pull effective available balance in operative account",
                                "EffectiveAvlAmt": JSON.parse(Resp.ResponseData).EffectiveAvlAmt
                              }
                              resolve(BalInquiryResp);
                            }
                            else {
                              BalInquiryResp = {
                                "ErrorCode": "01",
                                "ErrorMsg": "Error to update balance inquiry in database",
                                "EffectiveAvlAmt": 0
                              }
                              resolve(BalInquiryResp);
                            }
                            // logger.info("App_LoanTerm ",parsePMSDetails.TRENCH);
                            // logger.info("App_LoanTerm ",JSON.stringify(parsePMSDetails));
                            // logger.info("EffectiveAvlAmt ",JSON.parse(Resp.ResponseData).EffectiveAvlAmt);


                          });
                        }
                        if (Resp.Status == "Failure") {
                          BalInquiryResp = {
                            "ErrorCode": "01",
                            "ErrorMsg": Resp.Status,
                            "EffectiveAvlAmt": 0
                          }
                          resolve(BalInquiryResp);
                        }
                      }
                    });

                  }
                });
              })
                .catch(error => {
                  console.error('Error posting to BalanceInquiry API:', error);
                  // console.error('Error Loan Status Inquiry API Error Response:',error.response);
                  console.error('Error Loan Status BalanceInquiry API Error Response Text:', error.response.statusText);
                  console.error('Error Loan Status BalanceInquiry API Error Response data:', error.response.data);
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "BalanceInquiryAPI").then(async (ErrorLogResp) => {
                    resp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                    }
                    resolve(resp);
                  });
                });
            }
          });

        }
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}


function BalanceInquiryAPIM(PMSNumber, JourneyID, BalanceInquiryAPIReq, parsePMSDetails) {
  logger.info('************************ Inside BalanceInquiryAPIM Method *************************');
  logger.info('AccountNo: ' + JSON.parse(BalanceInquiryAPIReq).AccountNo);
  logger.info('Access_Token: ' + JSON.parse(BalanceInquiryAPIReq).Access_Token);
  let BalInquiryResp;
  return new Promise(async (resolve, reject) => {
    try {

      //const API_URL=process.env.CBS_API_URL;
      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest';    
      const API_URL = await GetKeyConfigurationValue('APIMBalanceInquiry');
      const ClientID = await GetKeyConfigurationValue('APIMClientID');
      logger.info('API_URL ' + API_URL);

      let token = JSON.parse(BalanceInquiryAPIReq).Access_Token;

      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + token
      }
      let AccountData = {
        "AcctNo": JSON.parse(BalanceInquiryAPIReq).AccountNo
      }
      let Plainbody = {
        "OperationName": "BalanceInquiry",
        "RequestData": JSON.stringify(AccountData)
      }
      //Call Enc
      logger.info('Body plain ' + JSON.stringify(Plainbody));

      objCommonFunction.APIMEncrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Body: ' + JSON.stringify(body));
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "BalanceInquiryAPIM", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                logger.info('CBS Response for Balance Enquiry APIM data:', resp.data);
                let encresp = JSON.parse(JSON.stringify(resp.data));
                // logger.info('encresp.EncRespData: '+encresp.EncRespData)
                objCommonFunction.APIMDecrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logger.info("PlainResponse: "+ (PlainResponse));

                    //const Resp = JSON.parse(PlainResponse);
                    const Resp = PlainResponse;
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        //logger.info("Status "+ Resp.Status);

                        logger.info("EffectiveAvlAmt "+Resp.ResponseData.EffectiveAvlAmt);                            
                        if (Resp.Status == "Success") {
                          CustomerJourneyDataUpdate(PMSNumber, JourneyID, Resp.ResponseData.EffectiveAvlAmt, null, "BalanceInquiryAPI").then(async (BalanceInquiryResp) => {
                            logger.info("Customer Journey BalanceInquiry Updated in Database" + JSON.stringify(BalanceInquiryResp));
                                //  if (BalanceInquiryResp.ErrorCode == "00") {  //111000
                            if (BalanceInquiryResp.ErrorCode != "00") {
                              BalInquiryResp = {
                                "ErrorCode": "00",
                                "ErrorMsg": "CBS API successfully pull effective available balance in operative account",
                                "EffectiveAvlAmt": Resp.ResponseData.EffectiveAvlAmt
                              }
                              resolve(BalInquiryResp);
                            }
                            else {
                              BalInquiryResp = {
                                "ErrorCode": "01",
                                "ErrorMsg": "Error to update balance inquiry in database",
                                "EffectiveAvlAmt": 0
                              }
                              resolve(BalInquiryResp);
                            }
                            // logger.info("App_LoanTerm ",parsePMSDetails.TRENCH);
                            // logger.info("App_LoanTerm ",JSON.stringify(parsePMSDetails));
                            // logger.info("EffectiveAvlAmt ",JSON.parse(Resp.ResponseData).EffectiveAvlAmt);


                          });
                        }
                        if (Resp.Status == "Failure") {
                          BalInquiryResp = {
                            "ErrorCode": "01",
                            "ErrorMsg": Resp.Status,
                            "EffectiveAvlAmt": 0
                          }
                          resolve(BalInquiryResp);
                        }
                      }
                    });

                  }
                });
              })
                .catch(error => {
                  console.error('Error posting to BalanceInquiry APIM:', error);
                  // console.error('Error Loan Status Inquiry API Error Response:',error.response);
                  console.error('Error  BalanceInquiry APIM Error Response Text:', error.response.statusText);
                  console.error('Error  BalanceInquiry APIM Error Response data:', error.response.data);
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "BalanceInquiryAPIM").then(async (ErrorLogResp) => {
                    resp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                    }
                    resolve(resp);
                  });
                });
            }
          });

        }
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}




function CBSChargeCollectionAPI(PMSNumber, JourneyID, ChargeType, CBSAPIToken, CityKYCStatusDetails) {
  logger.info('Inside CBSChargeCollectionAPI Req: ' + ChargeType);
  return new Promise(async (resolve, reject) => {
    try {

      let JSONRequestObj;
      //const API_URL=process.env.CBS_API_URL;
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');

      JSONRequestObj = new ChargeCollectionRequestBody(PMSNumber, ChargeType, CityKYCStatusDetails);
      logger.info("JSONRequestObj: " + JSON.stringify(JSONRequestObj));
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + CBSAPIToken
      }
      //Encrypt CityKYCStatus Request
      objCommonFunction.Encrypt(JSON.stringify(JSONRequestObj)).then(async (EncReq) => {
        logger.info("Token: " + CBSAPIToken);
        Body = {
          EncReqData: EncReq
        }
        logger.info("Enc Req Body: " + JSON.stringify(Body));
        //Insert Error Log
        logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CBSChargeCollectionAPI", JSON.stringify(JSONRequestObj), JSON.stringify(Body), null, null, null, "Insert").then(async (APILogsResp) => {
          logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
          if (APILogsResp.ErrorCode == "00") {
            axios.post(API_URL, JSON.stringify(Body), { headers, httpsAgent: httpAgent }).then(resp => {
              logger.info('CBS Response for Charge Collection: ', resp.data);

              let encresp = JSON.parse(JSON.stringify(resp.data));
              logger.info('encresp.EncRespData: ' + encresp.EncRespData)
              //Decrypt CityKYCStatus Response
              objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                if (PlainResponse != null) {
                  logger.info("Plain Response: " + PlainResponse);
                  logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                    logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                    if (APILogsResp.ErrorCode == "00") {
                      const response = JSON.parse(PlainResponse);
                      // Log the results
                      logger.info(`Status: ${response.Status}`);
                      logger.info(`Transaction Data: ${response.ResponseData}`);
                      //logger.info(`tranIdcharg ID: ${JSON.parse(response.ResponseData).tranIdcharg}`);
                      if (response.Status == "Success") {
                        CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, JSON.parse(response.ResponseData).tranIdcharg, ChargeType).then(async (BalanceInquiryResp) => {
                          logger.info(JSON.stringify(BalanceInquiryResp));
                          if (BalanceInquiryResp.ErrorCode == "00") {

                            StatusAPIResponse = {
                              "ErrorCode": "00",
                              "ErrorMsg": "Stamp charge successfully debited",
                            }
                            logger.info(StatusAPIResponse)
                            resolve(StatusAPIResponse);
                          }
                        });
                      }
                      else if (response.Status == "Failure" && response.ResponseData == "Duplicate Stamp Charges found for the application") {
                        logger.info("Else for Failue but Duplicate Stamp Charges found for the application ");
                        CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, response.ResponseData, ChargeType).then(async (BalanceInquiryResp) => {
                          logger.info(JSON.stringify(BalanceInquiryResp));
                          if (BalanceInquiryResp.ErrorCode == "00") {
                            StatusAPIResponse = {
                              "ErrorCode": "00",
                              "ErrorMsg": "Stamp charge successfully debited"
                            }
                            logger.info(StatusAPIResponse)
                            resolve(StatusAPIResponse);
                          }
                        });
                      }
                      else {
                        logger.info("Else condition failed");
                        StatusAPIResponse = {
                          "ErrorCode": "01",
                          "ErrorMsg": "Else Response from CBS for stamp charge collection API"
                        }
                        logger.info(StatusAPIResponse)
                        resolve(StatusAPIResponse);
                      }
                    }
                    //{"Status":"Success","ResponseData":"{\"tranIdcharg\":\"S8980989\"}"}
                    //{"Status":"Failure","ResponseData":"Duplicate Stamp Charges found for the application"}
                  });
                }
              });
            })
              .catch(error => {
                console.error('Error Loan Status Inquiry API Error Response Text:', error.response.statusText);
                console.error('Error Loan Status Inquiry API Error Response data:', error.response.data);
                logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSChargeCollectionAPI").then(async (ErrorLogResp) => {
                  resp = {
                    "ErrorCode": "01",
                    "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                  }
                  resolve(resp);
                });
              });
          }
        });
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}

class ChargeCollectionRequestBody {
  constructor(PMSNumber, ChargeType, CityKYCStatusDetails) {
    this.OperationName = "ChargeCollection";
    this.RequestData = {
      cicchk: ChargeType == "CIBILCharge" ? "Y" : "N",
      cicamt: ChargeType == "CIBILCharge" ? "118" : "118",
      procchk: "N",
      procamt: "10",
      Stampchk: ChargeType == "StampCharge" ? "Y" : "N",
      stampamt: ChargeType == "StampCharge" ? "10" : "0",
      cgtmsechk: "N",
      cgtmseamt: "5",
      docchk: "N",
      docamt: "5",
      otherchk: "N",
      otheramt: "120",
      otherchgacct: "NIL",
      otherremark: "GST",
      othergst: "N",
      loanacct: "",
      opracct: JSON.parse(CityKYCStatusDetails).AccountNo,
      solId: JSON.parse(CityKYCStatusDetails).solid,
      ApplicationRefNo: PMSNumber,
      ApplicationName: "PMSVANIDHI"
    };
  }

  toJSON() {
    return {
      OperationName: this.OperationName,
      RequestData: JSON.stringify(this.RequestData) // Stringify the RequestData object
    };
  }
}




function CBSChargeCollectionAPIM(PMSNumber, JourneyID, ChargeType, CBSAPIToken, CityKYCStatusDetails) {
  logger.info('Inside CBSChargeCollectionAPI Req: ' + ChargeType);
  return new Promise(async (resolve, reject) => {
    try {

      let JSONRequestObj;
      //const API_URL=process.env.CBS_API_URL;
      const API_URL = await GetKeyConfigurationValue('APIMChargeCollection');
      const ClientID = await GetKeyConfigurationValue('APIMClientID');

      JSONRequestObj = new ChargeCollectionRequestBodyAPIM(PMSNumber, ChargeType, CityKYCStatusDetails);
      logger.info("JSONRequestObj: " + JSON.stringify(JSONRequestObj));
      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + CBSAPIToken
      }
      //Encrypt CityKYCStatus Request
      objCommonFunction.APIMEncrypt(JSON.stringify(JSONRequestObj)).then(async (EncReq) => {
        logger.info("Token: " + CBSAPIToken);
        Body = {
          EncReqData: EncReq
        }
        logger.info("Enc Req Body: " + JSON.stringify(Body));
        //Insert Error Log
        logError.APIRequestResponseLogs(PMSNumber, JourneyID, "CBSChargeCollectionAPIM", JSON.stringify(JSONRequestObj), JSON.stringify(Body), null, null, null, "Insert").then(async (APILogsResp) => {
          logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
          if (APILogsResp.ErrorCode == "00") {
            axios.post(API_URL, JSON.stringify(Body), { headers, httpsAgent: httpAgent }).then(resp => {
              logger.info('CBS Response for Charge Collection: ', resp.data);

              let encresp = JSON.parse(JSON.stringify(resp.data));
              logger.info('encresp.EncRespData: ' + encresp.EncRespData)
              //Decrypt CityKYCStatus Response
              objCommonFunction.APIMDecrypt(encresp.EncRespData).then(async (PlainResponse) => {
                if (PlainResponse != null) {
                  logger.info("Plain Response: " + PlainResponse);
                  logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                    logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                    if (APILogsResp.ErrorCode == "00") {
                      const response = PlainResponse;
                      // Log the results
                      logger.info(`Status: ${response.Status}`);
                      logger.info(`Transaction Data: ${response.ResponseData}`);
                      //logger.info(`tranIdcharg ID: ${JSON.parse(response.ResponseData).tranIdcharg}`);
                      if (response.Status == "Success") {
                        CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, response.ResponseData.tranIdcharg, ChargeType).then(async (BalanceInquiryResp) => {
                          logger.info(JSON.stringify(BalanceInquiryResp));
                          if (BalanceInquiryResp.ErrorCode == "00") {

                            StatusAPIResponse = {
                              "ErrorCode": "00",
                              "ErrorMsg": "Stamp charge successfully debited",
                            }
                            logger.info(StatusAPIResponse)
                            resolve(StatusAPIResponse);
                          }
                        });
                      }
                      // else if (response.Status == "Failure" && response.ResponseData == "Duplicate Stamp Charges found for the application") {
                      //   logger.info("Else for Failue but Duplicate Stamp Charges found for the application ");
                      //   CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, response.ResponseData, ChargeType).then(async (BalanceInquiryResp) => {
                      //     logger.info(JSON.stringify(BalanceInquiryResp));
                      //     if (BalanceInquiryResp.ErrorCode == "00") {
                      //       StatusAPIResponse = {
                      //         "ErrorCode": "00",
                      //         "ErrorMsg": "Stamp charge successfully debited"
                      //       }
                      //       logger.info(StatusAPIResponse)
                      //       resolve(StatusAPIResponse);
                      //     }
                      //   });
                      // }

                      //Change response as per APIM
                      else if (response.Status == "F" && response.ResponseData == "Charges already collected for the loan account") {
                        logger.info("Else for Failue but Duplicate Stamp Charges found for the application ");
                        CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, response.ResponseData, ChargeType).then(async (BalanceInquiryResp) => {
                          logger.info(JSON.stringify(BalanceInquiryResp));
                          if (BalanceInquiryResp.ErrorCode == "00") {
                            StatusAPIResponse = {
                              "ErrorCode": "00",
                              "ErrorMsg": "Stamp charge successfully debited"
                            }
                            logger.info(StatusAPIResponse)
                            resolve(StatusAPIResponse);
                          }
                        });
                      }
                      else {
                        logger.info("Else condition failed");
                        StatusAPIResponse = {
                          "ErrorCode": "01",
                          "ErrorMsg": " Response from CBS for stamp charge collection API"
                        }
                        logger.info(StatusAPIResponse)
                        resolve(StatusAPIResponse);
                      }
                    }
                    
                  });
                }
              });
            })
              .catch(error => {
                console.error('Error CBSChargeCollectionAPIM  Error Response Text:', error.response.statusText);
                console.error('Error CBSChargeCollectionAPIM  Error Response data:', error.response.data);
                logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSChargeCollectionAPIM").then(async (ErrorLogResp) => {
                  resp = {
                    "ErrorCode": "01",
                    "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                  }
                  resolve(resp);
                });
              });
          }
        });
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}



class ChargeCollectionRequestBodyAPIM {
  constructor(PMSNumber, ChargeType, CityKYCStatusDetails) {
    const cityKYC = JSON.parse(CityKYCStatusDetails);

    this.OperationName = "ChargeCollection";

    // Build RequestData object first
    const requestData = {
      Cicchk: ChargeType === "CIBILCharge" ? "Y" : "N",
      Cicamt: "118",
      Procchk: "N",
      Procamt: "10",
      Stampchk: ChargeType === "StampCharge" ? "Y" : "N",
      Stampamt: ChargeType === "StampCharge" ? "10" : "0",
      Cgtmsechk: "N",
      Cgtmseamt: "5",
      Docchk: "N",
      Docamt: "5",
      Otherchk: "N",
      Otheramt: "120",
      Otherchgacct: "NIL",
      Otherremark: "GST",
      Othergst: "N",
      Opracct: cityKYC.AccountNo,
      SolId: cityKYC.solid,
      applnum: PMSNumber
    };

    // Stringify RequestData so it matches your expected API format
    this.RequestData = JSON.stringify(requestData);
  }
}






function CBSLoanAccountOpeningAPI(PMSNumber, JourneyID, CustomerID, AccessToken, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation) {
  logger.info('Inside CBSLoanAccountOpeningAPI Req: CustomerID ' + CustomerID);
  return new Promise(async (resolve, reject) => {
    try {
      // const API_URL=process.env.CBS_API_URL;
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      logger.info('API_URL ' + API_URL);
      let token = AccessToken;
      // logger.info('token '+token);

      JSONPlainRequest = new LoanAccountRequestBody(PMSNumber, CustomerID, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation);

      //logger.info("JSONHeaderObj: "+JSON.stringify(JSONHeaderObj));
      logger.info("JSONRequestObj: " + JSON.stringify(JSONPlainRequest));
      //logger.info("JSONReq: "+JSON.stringify(JSONReq)); 

      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + token
      }


      logger.info('Plain Req' + JSON.stringify(JSONPlainRequest));
      objCommonFunction.Encrypt(JSON.stringify(JSONPlainRequest)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Req: ' + JSON.stringify(body));
          //Insert Error Log

          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "LoanAccountOpeningAPI", JSON.stringify(JSONPlainRequest), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                logger.info('Enc Response:', resp.data);
                let encresp = JSON.parse(JSON.stringify(resp.data));
                logger.info('Enc Resp Body: ' + encresp.EncRespData)
                objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {

                        logger.info("Plain Response: " + JSON.stringify(PlainResponse))
                        const parsedData = JSON.parse(PlainResponse);
                        logger.info("Status " + parsedData.Status);

                        //Insert data in database
                        // if (parsedData.Status === "Success") {
                          // // Parse the ResponseData to get the inner account number
                          // const responseData = JSON.parse(parsedData.ResponseData).AcctNum;

                          // CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, JSON.parse(parsedData.ResponseData).AcctNum, "LoanAccounOpening").then(async (BalanceInquiryResp) => {
                            // let LoanAccOpenResponse = {
                              // "ErrorCode": "00",
                              // "ErrorMsg": "Loan Account Successfully opened.",
                              // "Status": parsedData.Status
                            // }
                            // resolve(LoanAccOpenResponse);
                          // });
                        // }
						if (parsedData.Status === "Success") {
							// 1. Parse the inner ResponseData once for efficiency
							const innerData = JSON.parse(parsedData.ResponseData);
							const acctNum = innerData.AcctNum;

							// 2. 🛡️ Validation: Check if AcctNum is blank or null
							if (!acctNum || acctNum.toString().trim() === "") {
								logger.error(`Validation Failed: AcctNum is null or blank for PMS: ${PMSNumber}`);
								
								let failureResponse = {
									"ErrorCode": "01",
									"ErrorMsg": "Some issue in Loan Account Opening. Please try in sometime.",
									"Status": "Failure"
								};
								
								return resolve(failureResponse); // Exit and return failure
							}

							// 3. Proceed with update if AcctNum is valid
							CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, acctNum, "LoanAccounOpening")
								.then(async (BalanceInquiryResp) => {
									let LoanAccOpenResponse = {
										"ErrorCode": "00",
										"ErrorMsg": "Loan Account Successfully opened.",
										"Status": parsedData.Status
									};
									resolve(LoanAccOpenResponse);
								})
								.catch((err) => {
									logger.error(`Error in CustomerJourneyDataUpdate: ${err.message}`);
									resolve({ "ErrorCode": "EX_02", "ErrorMsg": "Internal DB Update Error" });
								});
						}
                        else if (parsedData.Status === "Failure") {
                          let LoanAccOpenResponse = {
                            "ErrorCode": "01",
                            "ErrorMsg": parsedData.ResponseData,
                            "Status": parsedData.Status
                          }
                          resolve(LoanAccOpenResponse);
                        }
                      }
                    });

                  }
                });
              })
                .catch(error => {
                  logger.error('Error posting to CBSLoanAccountOpeningAPI:', error);
                  // console.error('Error NPA Status Inquiry API Error Response:',error.response);
                  // console.error('Error NPA Status Inquiry API Error Response Text:',error.response.statusText);
                  // console.error('Error NPA Status Inquiry API Error Response data:',error.response.data);                      
                  //Insert Error Log
                  //  console.error('Error Loan Status Inquiry API Error Response Text:',error.response.statusText);
                  //  console.error('Error Loan Status Inquiry API Error Response data:',error.response.data); 
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSLoanAccountOpeningAPI").then(async (ErrorLogResp) => {
                    resp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                    }
                    resolve(resp);
                  });
                });
            }
          });
        }
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}
class LoanAccountRequestBody1 {
  constructor(PMSNumber, CustomerID, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation) {
    //   this.OperationName = "AccountOpening";
    //   this.RequestData = {
    //     CustId:"O33954000",
    //     SolId: "216110",
    //     LoanAmt:"10000",
    //     LoanPeriod: "12",
    //     FreeText2:"50000",
    //     SchmCode: "TLSVN",
    //     IntTblCode: "RF387",
    //     OperativeAcct: "00612191009887"   
    //   };
    // }
logger.info("CityKYCStatusDetails " + CityKYCStatusDetails);
logger.info("RespCustomerJourneyData" + RespCustomerJourneyData);
logger.info("RespBranchInformation " + RespBranchInformation);
    this.OperationName = "AccountOpening";
      const loanPeriod = JSON.parse(RespCustomerJourneyData).LoanTenure;
      let schmCode=''; 
    // Determine SchmCode based on LoanPeriod
  
    if (loanPeriod == 12) {
      schmCode = "TLSVF";
    } else if (loanPeriod == 18) {
      schmCode = "TLSVS";
    } else if (loanPeriod == 36) {
      schmCode = "TLSVT";
    }
     logger.info("schmCode " + schmCode);
    this.RequestData = {
      CustId: CustomerID,
      SolId: JSON.parse(CityKYCStatusDetails).solid,
      LoanAmt: JSON.parse(RespCustomerJourneyData).LoanAmount,
      LoanPeriod: loanPeriod,
      FreeText2: "50000",
      SchmCode: schmCode,
      IntTblCode: "GB190",   //RF387
      OperativeAcct: JSON.parse(CityKYCStatusDetails).AccountNo
    };
  }

  toJSON() {
    return {
      OperationName: this.OperationName,
      RequestData: JSON.stringify(this.RequestData) // Stringify the RequestData object
    };
  }
}


class LoanAccountRequestBody {
  constructor(PMSNumber, CustomerID, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation) {
    //   this.OperationName = "AccountOpening";
    //   this.RequestData = {
    //     CustId:"O33954000",
    //     SolId: "216110",
    //     LoanAmt:"10000",
    //     LoanPeriod: "12",
    //     FreeText2:"50000",
    //     SchmCode: "TLSVN",
    //     IntTblCode: "RF387",
    //     OperativeAcct: "00612191009887",



// latest account opening as per new changes

// OperationName: "AccountOpening",
// CustId: "O28238500",
// SolId: "015300",
// LoanAmt: "10000",
// LoanPeriod: "12",
// FreeText2: "",
// SchmCode: "TLSVF",
// IntTblCode: "GB190",
// OperativeAcct: "0702000200304903",
// SanctAuth: "083",
// SanctLvl: "004",
// SanctDate: "10-10-2025",
// DocDate: "10-10-2025",
// BorrCat: "ZOTHR",
// NtbFlg: "N",
// PurpofAdv: "15039",
// ProjectFinance: "N",
// TakeoverFlg: "N",
// FlowStartDate: "05-02-2026",
// SectorCode: "SERMI",
// SubSectorCode: "SER07",
// OccupationCode: "EPSUS",
// PurpofAdvn: "15039",
// NatureOfAdvn: "001",
// ModeOfAdvn: "DIRCT",
// TypeOfAdvn: "002",
// PeggedFlg: "N",
// PegFrequencyInMonths: "N",
// SanctRef: "5155561)95220",
// ExpiryDate: "06-10-2030",
// FreeCode2: "",
// FreeCode3: "003",
// FreeCode4: "999",
// FreeCode5: "PRIOR",
// FreeCode6: "OTHER",
// FreeCode10: "PMST1",
// FreeText1: "83.64",
// FreeText4: "",
// FreeText5: "PNB-DSG-200825-0000011",
// FreeText7: "38341-2790-UAT1",
// FreeText10: "",
// GuaranteeCode: "CGSVN",
// CrncyCode: "INR",
// ModOper: "SELF",
// ValAsset: "40000.00",
// FlowFreqType: "M",
// AcctLabelId: "",
// DpInd: "Derived",
// DpAmt: "",
// DpPcnt: "",
// LoanMonths: "12",
// DefUptoDt: "",
// MaxCoBorrowerCnt: "0",
// CustIdC1: "O28238500",
// RelationTypeC1: "C",
// RelationCodeC1: "004",
// CustIdC2: "MZH000167",
// RelationTypeC2: "C",
// RelationCodeC2: "001",
// MaxGuarCnt: "1",
// CustIdG1: "FZQ005094",
// RelationTypeG1: "G",
// RelationCodeG1: "999",
// LoanDays: ""
//   };
    // }
   logger.info("CityKYCStatusDetails " + CityKYCStatusDetails);
logger.info("RespCustomerJourneyData" + RespCustomerJourneyData);
logger.info("RespBranchInformation " + RespBranchInformation);
    this.OperationName = "AccountOpening";
    const loanTrench = JSON.parse(RespCustomerJourneyData).LoanTranche;
      const loanPeriod = JSON.parse(RespCustomerJourneyData).LoanTenure;
      
     const StampChargeTime=JSON.parse(RespCustomerJourneyData).StampChargeTime;
   
    
      let schmCode=''; 
      let freecode10='';
  
  // Use current date as LoanAccountOpenDate
  const loanOpenDate = new Date();






 function formatDateToDDMMYY(date) {
   const day = date.getDate().toString().padStart(2, '0');  // Ensure two digits for day
   const month = (date.getMonth() + 1).toString().padStart(2, '0');  // Ensure two digits for month
   const year = date.getFullYear().toString().slice(-2);  // Get last two digits of year
   return `${day}-${month}-${year}`;
 }

function formatDateToDDMMYYYY(date) {
  // Use UTC methods to avoid timezone issues
  const day = date.getUTCDate().toString().padStart(2, '0');  // Ensure two digits for day
  const month = (date.getUTCMonth() + 1).toString().padStart(2, '0');  // Ensure two digits for month
  const year = date.getUTCFullYear();  // Use the full year (no need to slice)
  
  return `${day}-${month}-${year}`;
}



// Calculate expiry date by adding loanPeriod months to loanOpenDate
const expiryDateObj = new Date(loanOpenDate);
expiryDateObj.setMonth(expiryDateObj.getMonth() + loanPeriod);
const expiryDate = formatDateToDDMMYY(expiryDateObj);
logger.info("Expiry Date: " + expiryDate);

// Calculate flow start date by adding 1 month to loanOpenDate
const flowStartDateObj = new Date(loanOpenDate);
flowStartDateObj.setMonth(flowStartDateObj.getMonth() + 1);
const flowStartDate = formatDateToDDMMYYYY(flowStartDateObj);
logger.info("Flow Start Date: " + flowStartDate);




// Convert StampChargeTime to a Date object
// const DocumenttDateObj = new Date(StampChargeTime);

// // Format DocumenttDate as ddmmyy
// const DocumenttDate = formatDateToDDMMYY(DocumenttDateObj);
// logger.info("DocumenttDate: " + DocumenttDate);

const DocumenttDateObj = new Date(StampChargeTime);

// Format DocumenttDate as dd-mm-yyyy in UTC
const DocumenttDate = formatDateToDDMMYYYY(DocumenttDateObj);
logger.info("DocumenttDate: " + DocumenttDate);








  // Calculate expiry date by adding loanPeriod months
  // const expiryDateObj = new Date(loanOpenDate);
  // expiryDateObj.setMonth(expiryDateObj.getMonth() + loanPeriod);
  // const expiryDate = expiryDateObj.toISOString().split('T')[0];
  // logger.info("Expiry Date" + expiryDate);

  // // Calculate flow start date by adding 1 month to loanOpenDate
  // const flowStartDateObj = new Date(loanOpenDate);
  // flowStartDateObj.setMonth(flowStartDateObj.getMonth() + 1);
  //  flowStartDate = flowStartDateObj.toISOString().split('T')[0];
  // logger.info("Flow Start Date" + flowStartDate);

    // Determine SchmCode based on LoanPeriod
  
    if (loanTrench == 1) {
      schmCode = "TLSVF";
      freecode10="PMST1"
    } else if (loanTrench == 2) {
      schmCode = "TLSVS";
       freecode10="PMST2"
    } else if (loanTrench== 3) {
      schmCode = "TLSVT";
       freecode10="PMST3"
    }
     logger.info("schmCode " + schmCode);
    this.RequestData = {
      CustId: CustomerID,
      SolId: JSON.parse(CityKYCStatusDetails).solid,                           
      LoanAmt: JSON.parse(RespCustomerJourneyData).LoanAmount,
      LoanPeriod: loanPeriod,
      FreeText2: "50000",
      SchmCode: schmCode,
      IntTblCode: "GB190",   //RF387
      OperativeAcct: JSON.parse(CityKYCStatusDetails).AccountNo,
      SanctAuth: "235",
      SanctLvl: "234",
      SanctDate: JSON.parse(RespCustomerJourneyData).JourneySanctionedDate, //find   
      DocDate: DocumenttDate,    //find
      BorrCat: "ZOTHR",
      NtbFlg: "N",
      PurpofAdv: "14742",
      ProjectFinance: "N",
      TakeoverFlg: "N",
      FlowStartDate:flowStartDate, //find
      SectorCode: "SERMI",
      SubSectorCode: "SER16",
      OccupationCode: "OTHER",
      PurpofAdvn: "14742",
      NatureOfAdvn: "001",
      ModeOfAdvn: "DIRCT",
      TypeOfAdvn: "012",
      PeggedFlg: "N",
      PegFrequencyInMonths: "",
      SanctRef: "EPMSVANIDHI/STP", 
      ExpiryDate: expiryDate,  //find  
      FreeCode2: "MICRO",
      FreeCode3: "",
      FreeCode4: "999",
      FreeCode5: "PRIOR",
      FreeCode6: "OTHER",
      FreeCode10: freecode10,  // find through code
      FreeText1: "",
      FreeText4: "",
      FreeText5: PMSNumber,  
      FreeText7: "EPMSVANIDHI/SYSTEM",
      FreeText10: JSON.parse(RespCustomerJourneyData).LoanTranche, //find trench
      GuaranteeCode: "CGSVN",
      CrncyCode: "INR",
      ModOper: "SELF",
      ValAsset: "",
      FlowFreqType: "M",
      AcctLabelId: "",
      DpInd: "E",
      DpAmt: JSON.parse(RespCustomerJourneyData).LoanAmount,  // find sanction amount
      DpPcnt: "100",
      LoanMonths: loanPeriod,
      DefUptoDt: "",
      MaxCoBorrowerCnt: "",
      CustIdC1: "",
      RelationTypeC1: "",
      RelationCodeC1: "",
      CustIdC2: "",
      RelationTypeC2: "",
      RelationCodeC2: "",
      MaxGuarCnt: "",
      CustIdG1: "",
      RelationTypeG1: "",
      RelationCodeG1: "",
      LoanDays: ""

    };
  }

  toJSON() {
    return {
      OperationName: this.OperationName,
      RequestData: JSON.stringify(this.RequestData) // Stringify the RequestData object
    };
  }
}

// class RequestHeaders {
//   constructor(clientId, cbsApiToken) {
//     this.const headers = {
//       'Client-Id': clientId || 'LocalTesting', // Default to 'LocalTesting' if not provided
//       'Content-Type': 'application/json',       // Fixed value
//       'Authorization': `Bearer ${cbsApiToken}`  // Bearer token
//     };
//   }
//   toJSON() {
//     return this.headers; // Return the headers object
//   }
// }

function CBSLoanAccountOpeningAPIM(PMSNumber, JourneyID, CustomerID, AccessToken, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation) {
  logger.info('Inside CBSLoanAccountOpeningAPI Req: CustomerID ' + CustomerID);
  return new Promise(async (resolve, reject) => {
    try {
      // const API_URL=process.env.CBS_API_URL;
      const API_URL = await GetKeyConfigurationValue('APIMAccountOpeningAPI');
      const ClientID = await GetKeyConfigurationValue('APIMClientID');
      logger.info('API_URL ' + API_URL);
      let token = AccessToken;
      // logger.info('token '+token);

      JSONPlainRequest = new LoanAccountRequestBody(PMSNumber, CustomerID, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation);

      //logger.info("JSONHeaderObj: "+JSON.stringify(JSONHeaderObj));
      logger.info("JSONRequestObj: " + JSON.stringify(JSONPlainRequest));
      //logger.info("JSONReq: "+JSON.stringify(JSONReq)); 

      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + token
      }


      logger.info('Plain Req' + JSON.stringify(JSONPlainRequest));
      objCommonFunction.Encrypt(JSON.stringify(JSONPlainRequest)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Req: ' + JSON.stringify(body));
          //Insert Error Log

          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "LoanAccountOpeningAPI", JSON.stringify(JSONPlainRequest), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              axios.post(API_URL, JSON.stringify(body), { headers, httpsAgent: httpAgent }).then(resp => {
                logger.info('Enc Response:', resp.data);
                let encresp = JSON.parse(JSON.stringify(resp.data));
                logger.info('Enc Resp Body: ' + encresp.EncRespData)
                objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {

                        logger.info("Plain Response: " + JSON.stringify(PlainResponse))
                        const parsedData = JSON.parse(PlainResponse);
                        logger.info("Status " + parsedData.Status);

                        //Insert data in database
                        // if (parsedData.Status === "Success") {
                          // // Parse the ResponseData to get the inner account number
                          // const responseData = JSON.parse(parsedData.ResponseData).AcctNum;

                          // CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, JSON.parse(parsedData.ResponseData).AcctNum, "LoanAccounOpening").then(async (BalanceInquiryResp) => {
                            // let LoanAccOpenResponse = {
                              // "ErrorCode": "00",
                              // "ErrorMsg": "Loan Account Successfully opened.",
                              // "Status": parsedData.Status
                            // }
                            // resolve(LoanAccOpenResponse);
                          // });
                        // }
						if (parsedData.Status === "Success") {
							// 1. Parse the inner ResponseData once for efficiency
							const innerData = JSON.parse(parsedData.ResponseData);
							const acctNum = innerData.AcctNum;

							// 2. 🛡️ Validation: Check if AcctNum is blank or null
							if (!acctNum || acctNum.toString().trim() === "") {
								logger.error(`Validation Failed: AcctNum is null or blank for PMS: ${PMSNumber}`);
								
								let failureResponse = {
									"ErrorCode": "01",
									"ErrorMsg": "Some issue in Loan Account Opening. Please try in sometime.",
									"Status": "Failure"
								};
								
								return resolve(failureResponse); // Exit and return failure
							}

							// 3. Proceed with update if AcctNum is valid
							CustomerJourneyDataUpdate(PMSNumber, JourneyID, null, acctNum, "LoanAccounOpening")
								.then(async (BalanceInquiryResp) => {
									let LoanAccOpenResponse = {
										"ErrorCode": "00",
										"ErrorMsg": "Loan Account Successfully opened.",
										"Status": parsedData.Status
									};
									resolve(LoanAccOpenResponse);
								})
								.catch((err) => {
									logger.error(`Error in CustomerJourneyDataUpdate: ${err.message}`);
									resolve({ "ErrorCode": "EX_02", "ErrorMsg": "Internal DB Update Error" });
								});
						}
                        else if (parsedData.Status === "Failure") {
                          let LoanAccOpenResponse = {
                            "ErrorCode": "01",
                            "ErrorMsg": parsedData.ResponseData,
                            "Status": parsedData.Status
                          }
                          resolve(LoanAccOpenResponse);
                        }
                      }
                    });

                  }
                });
              })
                .catch(error => {
                  logger.error('Error posting to CBSLoanAccountOpeningAPI:', error);
                  // console.error('Error NPA Status Inquiry API Error Response:',error.response);
                  // console.error('Error NPA Status Inquiry API Error Response Text:',error.response.statusText);
                  // console.error('Error NPA Status Inquiry API Error Response data:',error.response.data);                      
                  //Insert Error Log
                  //  console.error('Error Loan Status Inquiry API Error Response Text:',error.response.statusText);
                  //  console.error('Error Loan Status Inquiry API Error Response data:',error.response.data); 
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CBSLoanAccountOpeningAPI").then(async (ErrorLogResp) => {
                    resp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                    }
                    resolve(resp);
                  });
                });
            }
          });
        }
      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}










function PushQRCodeData(PMSNumber, JourneyID, objPushQRCodeData, CBSToken) {
  logger.info('');
  logger.info('***************************Inside PushQRCodeData Method***************************');
  let objPushQRCodeDataParsed = JSON.parse(objPushQRCodeData);

  logger.info('CustomerID: ' + objPushQRCodeDataParsed.CustomerName);
  logger.info('MobileNo: ' + objPushQRCodeDataParsed.MobileNo);
  logger.info('CBSToken: ' + CBSToken);

  let loanStatusInquiryResponse;
  return new Promise(async (resolve, reject) => {
    try {

      //const API_URL='https://10.192.33.103/bankapi/api/ESVANidhi/ProcessRequest'; //process.env.CBS_API_URL;
      const API_URL = await GetKeyConfigurationValue('CBS_API_URL');
      const ClientID = await GetKeyConfigurationValue('CBS_ClientID');
      logger.info('API URL', API_URL);

      const headers = {
        'Client-Id': ClientID, // Replace with your custom header value
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': 'Bearer ' + CBSToken
      }
      logger.info('Request Header ', headers);

      let QRPushDataJSON = {
        "AccountNumber": objPushQRCodeDataParsed.CustomerID,
        "MerchantName": objPushQRCodeDataParsed.CustomerName,
        "Mobile": objPushQRCodeDataParsed.MobileNo,
        "DOB": objPushQRCodeDataParsed.Date_of_Birth,
        "Address1": objPushQRCodeDataParsed.CommAddress_Address1,
        "Address2": objPushQRCodeDataParsed.CommAddress_Address2,
        "Address3": '',
        "City": objPushQRCodeDataParsed.CommAddress_City,
        "State": objPushQRCodeDataParsed.CommAddress_State,
        "PIN": objPushQRCodeDataParsed.CommAddress_PINCode,
        "SolId": objPushQRCodeDataParsed.solid,
        "EmailId": objPushQRCodeDataParsed.EmailId
      }
      let Plainbody = {
        "OperationName": "QRDataPush",
        "RequestData": JSON.stringify(QRPushDataJSON)
      }
      //Call Enc
      logger.info('Plain Request: ' + JSON.stringify(Plainbody));

      objCommonFunction.Encrypt(JSON.stringify(Plainbody)).then(async (EncResponse) => {
        if (EncResponse != null) {
          body = {
            "EncReqData": EncResponse
          }
          logger.info('Enc Request: ' + JSON.stringify(body));
          //Insert Error Log
          logger.info('');
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "PushQRCodeData", JSON.stringify(Plainbody), JSON.stringify(body), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("APILog Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              logger.info('Call axios.post here');
              axios.post(API_URL, JSON.stringify(body), { headers }).then(resp => {
                logger.info('Enc Response: ', resp.data);

                let encresp = JSON.parse(JSON.stringify(resp.data));
                logger.info('encresp.EncRespData: ' + encresp.EncRespData)
                objCommonFunction.Decrypt(encresp.EncRespData).then(async (PlainResponse) => {
                  if (PlainResponse != null) {
                    logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(PlainResponse), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                      logger.info("APILog Update ErrorCode " + APILogsResp.ErrorCode)
                      if (APILogsResp.ErrorCode == "00") {
                        logger.info("Plain Response: ", PlainResponse);

                        // {"Status":"Success","ResponseData":"{\"Status\":\"S\",\"Message\":\"Details Pushed Successfully\"}"}                          

                        logger.info("Plain Status: ", JSON.parse(PlainResponse).Status);

                        // Step 1: Parse the outer JSON response
                        const response = JSON.parse(PlainResponse);

                        logger.info("Plain Status: ", response.Status);

                        // Step 2: Parse the nested JSON in the "ResponseData" field
                        const responseData = JSON.parse(response.ResponseData);

                        logger.info('Internal Status:', responseData.Status);  // Output: Response Status: S

                        logger.info('Message:', responseData.Message);  // Output: Message: Details Pushed Successfully

                        if (JSON.parse(PlainResponse).Status == "Failure") {
                          loanStatusInquiryResponse = {
                            "ErrorCode": "01",
                            "ErrorStatus": responseData.Status,
                            "ErrorMsg": responseData.Message
                          }
                          logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
                          resolve(loanStatusInquiryResponse);
                        }
                        else {
                          loanStatusInquiryResponse = {
                            "ErrorCode": "00",
                            "ErrorStatus": responseData.Status,
                            "ErrorMsg": responseData.Message
                          }
                          logger.info('LoanStatusInquiryResponse: ' + JSON.stringify(loanStatusInquiryResponse));
                          resolve(loanStatusInquiryResponse);
                        }
                      }
                    });
                  }
                });
              })
                .catch(error => {
                  console.error('Error posting to PushQRCodeData API:', error);
                 
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "PushQRCodeData").then(async (ErrorLogResp) => {
                    ExceptionResp = {
                      "ErrorCode": "01",
                      "ErrorMsg": 'System error occurred. Please retry after sometime or contact your branch for further assistance',
                    }
                    resolve(ExceptionResp);
                  });
                });
            }
          });
        }
      });
    } catch (err1) {
      logger.info('Exception:', err1);
      reject(err1);
    }
  });
}

// async function GetKeyConfigurationValue(KeyName) {
  // // logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);
  // const query = `SELECT [KeyValue] FROM [dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;

  // try {
	  // const pool = await getPool();
	  // const request = pool.request();
    // //const pool = await sql.connect(config);
    // //logger.info('Connected to the database');

    // const result = await request
      // .input('KeyName', sql.VarChar, KeyName)
      // .query(query);

    // if (result.recordset.length > 0) {

      // const jsonString = JSON.stringify(result.recordset, null, 2);
      // formattedString = jsonString.slice(1, -1);
      // //  logger.info('Result: ',formattedString);               
      // //  logger.info('Parse Result: ',JSON.parse(formattedString));
      // const OutValue = JSON.parse(formattedString).KeyValue;
      // //  logger.info('OutValue', OutValue.toString());
      // return JSON.parse(formattedString).KeyValue; // Return the formatted string
    // } else {
      // logger.info('No results found for the provided KeyName.');
      // return null;
    // }
  // } catch (err) {
    // console.error('Error:', err);
    // return null;
  // } finally {
    // await sql.close(); // Ensure the connection is closed
  // }
// }

async function GetKeyConfigurationValue(KeyName) {
  logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  const query = `
    SELECT [KeyValue]
    FROM [dbo].[SVND_CONFIGURATION_DATA]
    WHERE KeyName = @KeyName
  `;

  try {
    const pool = await getPool();
    const request = pool.request();

    const result = await request
      .input('KeyName', sql.VarChar, KeyName)
      .query(query);

    if (result.recordset && result.recordset.length > 0) {
      const value = result.recordset[0].KeyValue;
      ////logger.info('KeyValue fetched: ' + value);
      return value;
    } else {
      logger.info('No results found for the provided KeyName.');
      return null;
    }

  } catch (err) {
    logger.error('GetKeyConfigurationValue Error:', err);
    return null;
  }
}

function CustomerJourneyDataUpdate(PMSNumber, JourneyID, InputOne, InputTwo, Operation) {
  logger.info('###############################Inside Customer Journey Data Update in Local Database ###############################');
  logger.info('JourneyID: ' + JourneyID);
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('InputOne: ' + InputOne);
  logger.info('InputTwo: ' + InputTwo);
  logger.info('Operation: ' + Operation);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('InputOne', sql.VarChar, InputOne)
        .input('InputTwo', sql.VarChar, InputTwo)
        .input('Operation', sql.VarChar, Operation)
        .execute('proc_CustomerJourneyDataUpdate');

      ////logger.info('QueryResult ' + JSON.stringify(result));

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({
          "ErrorCode": "00",
          "ErrorMsg": "Customer Journey Data Part Successfully updated for " + Operation
        });
      } else {
        resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error to update Customer Journey data part."
        });
      }

    } catch (err) {
      logger.error('CustomerJourneyDataUpdate Error:', err);
      //reject(err);
	  resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error to update Customer Journey data part."
        });
    }
  });
}


// function CustomerJourneyDataUpdate(PMSNumber, JourneyID, InputOne, InputTwo, Operation) {
  // logger.info('###############################Inside Customer Journey Data Update in Local Database ###############################');
  // logger.info('JourneyID: ' + JourneyID);
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('InputOne: ' + InputOne);//Amount/
  // logger.info('InputTwo: ' + InputTwo);//Any Txn/LoanAcc number
  // logger.info('Operation: ' + Operation);


  // return new Promise((resolve, reject) => {
    // try {

      // // const date1=DatePart();
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool); // Create a new request object for every row insert

        // request.input('PMSNumber', sql.VarChar, PMSNumber);
        // request.input('JourneyID', sql.VarChar, JourneyID);
        // request.input('InputOne', sql.VarChar, InputOne);
        // request.input('InputTwo', sql.VarChar, InputTwo);
        // request.input('Operation', sql.VarChar, Operation)
        // request.execute('proc_CustomerJourneyDataUpdate', function (err, queryResult) {
          // //logger.info('QueryResult ' + JSON.stringify(queryResult));
          // logger.info('Error ' + err);
          // if (queryResult.rowsAffected[0] > 0) {
            // formattedString = {
              // "ErrorCode": "00",
              // "ErrorMsg": "Customer Journey Data Part Successfully updated for " + Operation
            // }
            // resolve(formattedString);
          // }
          // else {
            // logger.info('else:' + err);
            // formattedString = {
              // "ErrorCode": "01",
              // "ErrorMsg": "Error to update Customer Journey data part."
            // }
            // resolve(formattedString);
          // }
        // });
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }



function BankSignAffix(PMSNumber, JourneyID, NeSL_Tran_ID, BankCert, DocumentBase64) {
  logger.info('***************************Inside CBS Layer BankSignAffix Method***************************');

  return new Promise(async (resolve, reject) => {
    try {
      const API_URL = await GetKeyConfigurationValue('Bank_SignAffix_URL');
      //const API_URL='https://10.192.3.99/digitalservices/gateway/GeneralService/SignDocument';

      const UserID = await GetKeyConfigurationValue('Bank_SignAffix_UserID');//'RetailUser';//
      const Password = await GetKeyConfigurationValue('Bank_SignAffix_Password');//'pnb@12345';//
      const BankCertificate_Password = await GetKeyConfigurationValue('BankCertificate_Password');

      logger.info('API URL ' + API_URL);
      logger.info('AadhaarAPIUserID ' + UserID);
      logger.info('AadhaarAPIPassword ' + Password);
      logger.info('BankCertificate_Password ' + BankCertificate_Password);

      let authorizationData = 'Basic ' + btoa(UserID + ':' + Password);

      const headers = {
        'Content-Type': 'application/json',  // Replace with another custom header value
        'Authorization': authorizationData
      }
      let JSONBankSignAffix = {
        'CertData': BankCert,
        'CertPassword': BankCertificate_Password,
        'Document': DocumentBase64,
        'Purpose': 'Affix bank DSC after Nesl signature',
        'pageCoordinates': [{
          'pageNumber': '3',
          'xCoordinates': '90',
          'yCoordinates': '520'
        },
        {
          'pageNumber': '10',
          'xCoordinates': '90',
          'yCoordinates': '80'
        }
        ]
      }

      logger.info('Plain Request: ' + JSON.stringify(JSONBankSignAffix));

      // fs.writeFileSync('../Logs/BankSignAffix.txt', JSON.stringify(CustomerData));
      //Insert Error Log
      logError.APIRequestResponseLogs(PMSNumber, JourneyID, "BankSignAffix", JSON.stringify(JSONBankSignAffix), null, null, null, null, "Insert").then(async (APILogsResp) => {
        logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
        if (APILogsResp.ErrorCode == "00") {
          logger.info("Insert ErrorCode for 00");
          axios.post(API_URL, JSON.stringify(JSONBankSignAffix), { headers }, { httpsAgent: httpAgent }).then(resp => {
            logger.info('BankSign Affix Response: ' + JSON.stringify(resp.data));
            //fs.writeFileSync('../Logs/BankSignAffix.txt', JSON.stringify(data));                          
            if (resp.data != null) {
              logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(resp.data), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                // Step 1: Parse the JSON string into a JavaScript object
                const parsedData = JSON.parse(resp.data);

                const status = parsedData.Status;
                const message = parsedData.Message;
                logger.info(status);
                logger.info(message);
                let respObj;
                if (APILogsResp.ErrorCode == "00") {
                  if (parsedData.Status === "S") {
                     objGeneralOperation.DownloadDocumentUpdate(decResponse.PMSNumber).then(async (respDownloadDocument) => {
                   respDownloadDocument = {
                      "ErrorCode": "00",
                      "ErrorStatus": respDownloadDocument.Status,
                      "ErrorMsg": respDownloadDocument.Message,
                      "DocData": respDownloadDocument.DocData
                    }
                    resolve(respDownloadDocument);
                    respObj = {
                      "ErrorCode": "00",
                      "ErrorStatus": parsedData.Status,
                      "ErrorMsg": parsedData.Message,
                      "DocData": parsedData.DocData
                    }
                    resolve(respObj);
                  })}
                  else {
                    respObj = {
                      "ErrorCode": "01",
                      "ErrorStatus": parsedData.Status,
                      "ErrorMsg": parsedData.Message,
                      "DocData": null
                    }
                  }
                  resolve(respObj);
                }
              });
            }
          })
            .catch(error => {
              console.error('Error posting to BankSignAffix API:', error);
              // console.error('Error NPA Status Inquiry API Error Response:',error.response);
              // console.error('Error NPA Status Inquiry API Error Response Text:',error.response.statusText);
              // console.error('Error NPA Status Inquiry API Error Response data:',error.response.data);                      
              //Insert Error Log
              logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "BankSignAffix").then(async (ErrorLogResp) => {
                resp = {
                  "ErrorCode": "01",
                  "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                }
                resolve(resp);
              });
            });
        }
      });
    } catch (exception) {
      logger.info(exception);
      logError.ErrorLogs(PMSNumber, "Catch Exception", exception, "BankSignAffixAPI").then(async (ErrorLogResp) => {
        reject(exception);
      });
    }
  });
}

// function UpdateNeSLDocumentData(PMSNumber, JourneyID, NeslTranID, DocumentByteArray, statuscode, statusmsg, esignStatus, esignDate, estampStatus, estampDate
  // , signtryName, signedName, signatoryYob, signedYob, yobPercent, signatoryGender, signedGender, genderPercent,
  // signatoryAadhar, signedAadhar, aadharPercent, matchPercentage, NeSL_eStampID, DocumentType, CallMechanism) {

  // logger.info('############################# Inside  UpdateNeSLDocumentData in DOCUMENT TABLE Method ##########################');
  // logger.info(`PMSNumber   ${PMSNumber}`);
  // logger.info(`JourneyID   ${JourneyID}`);
  // logger.info(`NeslTranID   ${NeslTranID}`);
  // logger.info(`DocumentType   ${DocumentType}`);
  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('PMSNumber', sql.NVarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('NeSL_Tran_ID', sql.VarChar, NeslTranID)
          // .input('Document_Byte', sql.VarBinary(sql.MAX), DocumentByteArray)
          // .input('NeSL_StatusCode', sql.VarChar, statuscode)
          // .input('NeSL_StatusMsg', sql.VarChar, statusmsg)
          // .input('NeSL_eSignStatus', sql.VarChar, esignStatus)
          // .input('NeSL_eSignDate', sql.VarChar, esignDate)
          // .input('NeSL_eStampStatus', sql.VarChar, estampStatus)
          // .input('NeSL_eStampDate', sql.VarChar, estampDate)
          // .input('NeSL_SigntryName', sql.VarChar, signtryName)
          // .input('NeSL_SignedName', sql.VarChar, signedName)
          // .input('NeSL_SignatoryYob', sql.VarChar, signatoryYob)
          // .input('NeSL_SignedYob', sql.VarChar, signedYob)
          // .input('NeSL_yobPercent', sql.VarChar, yobPercent)
          // .input('NeSL_SignatoryGender', sql.VarChar, signatoryGender)
          // .input('NeSL_SignedGender', sql.VarChar, signedGender)
          // .input('NeSL_GenderPercent', sql.VarChar, genderPercent)
          // .input('NeSL_SignatoryAadhar', sql.VarChar, signatoryAadhar)
          // .input('NeSL_SignedAadhar', sql.VarChar, signedAadhar)
          // .input('NeSL_AadharPercent', sql.VarChar, aadharPercent)
          // .input('NeSL_MatchPercentage', sql.VarChar, matchPercentage)
          // .input('NeSL_eStampID', sql.NVarChar, NeSL_eStampID)
          // .input('CallMechanism', sql.NVarChar, CallMechanism)
          // .input('Operation', sql.VarChar, DocumentType)
          // .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          // .execute('proc_NeSLPDF_Update', function (err, queryResult) {
            // //logger.info('QueryResult:' + JSON.stringify(queryResult));
            // //logger.info('QueryResult:' + JSON.stringify(queryResult));
            // logger.info('err:' + err);
            // logger.info('Rows Affacted::' + queryResult.rowsAffected[0]);
            // if (queryResult.output.p_OutStatusCode == '200' && queryResult.rowsAffected[0] > 0) {
              // logger.info(`Update success`);
              // conn.close();

              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "NeSL response updated in Document Table"
              // }
              // resolve(response);
            // }
            // else {
              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": err
              // }
              // logger.info(`Error while save NeSL Document ${err}`);
              // resolve(response);
            // }
          // });
      // });
    // } catch (err1) {
      // logger.error(`Exception in UpdateNeSLDocumentData Method ${err1}`);
      // // reject(err1);
    // }
  // });
// }

function UpdateNeSLDocumentData(
  PMSNumber, JourneyID, NeslTranID, DocumentByteArray, statuscode, statusmsg,
  esignStatus, esignDate, estampStatus, estampDate,
  signtryName, signedName, signatoryYob, signedYob, yobPercent,
  signatoryGender, signedGender, genderPercent,
  signatoryAadhar, signedAadhar, aadharPercent, matchPercentage,
  NeSL_eStampID, DocumentType, CallMechanism
) {

  logger.info('############################# Inside UpdateNeSLDocumentData in DOCUMENT TABLE Method ##########################');
  logger.info(`PMSNumber   ${PMSNumber}`);
  logger.info(`JourneyID   ${JourneyID}`);
  logger.info(`NeslTranID  ${NeslTranID}`);
  logger.info(`DocumentType ${DocumentType}`);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('NeSL_Tran_ID', sql.VarChar, NeslTranID)
        .input('Document_Byte', sql.VarBinary(sql.MAX), DocumentByteArray)
        .input('NeSL_StatusCode', sql.VarChar, statuscode)
        .input('NeSL_StatusMsg', sql.VarChar, statusmsg)
        .input('NeSL_eSignStatus', sql.VarChar, esignStatus)
        .input('NeSL_eSignDate', sql.VarChar, esignDate)
        .input('NeSL_eStampStatus', sql.VarChar, estampStatus)
        .input('NeSL_eStampDate', sql.VarChar, estampDate)
        .input('NeSL_SigntryName', sql.VarChar, signtryName)
        .input('NeSL_SignedName', sql.VarChar, signedName)
        .input('NeSL_SignatoryYob', sql.VarChar, signatoryYob)
        .input('NeSL_SignedYob', sql.VarChar, signedYob)
        .input('NeSL_yobPercent', sql.VarChar, yobPercent)
        .input('NeSL_SignatoryGender', sql.VarChar, signatoryGender)
        .input('NeSL_SignedGender', sql.VarChar, signedGender)
        .input('NeSL_GenderPercent', sql.VarChar, genderPercent)
        .input('NeSL_SignatoryAadhar', sql.VarChar, signatoryAadhar)
        .input('NeSL_SignedAadhar', sql.VarChar, signedAadhar)
        .input('NeSL_AadharPercent', sql.VarChar, aadharPercent)
        .input('NeSL_MatchPercentage', sql.VarChar, matchPercentage)
        .input('NeSL_eStampID', sql.NVarChar, NeSL_eStampID)
        .input('CallMechanism', sql.NVarChar, CallMechanism)
        .input('Operation', sql.VarChar, DocumentType)
        .output('p_OutStatusCode', sql.NVarChar)
        .execute('proc_NeSLPDF_Update');

      logger.info('QueryResult: UpdateNeSLDocumentData: ' + JSON.stringify(result));
      //logger.info('Rows Affected: ' + (result.rowsAffected ? result.rowsAffected[0] : 0));
      //logger.info('Out Status: ' + result.output.p_OutStatusCode);

      if (result.output.p_OutStatusCode === '200' &&
          result.rowsAffected &&
          result.rowsAffected[0] > 0) {

        resolve({
          "ErrorCode": "00",
          "ErrorMsg": "NeSL response updated in Document Table"
        });
      } else {
        resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error while saving NeSL Document data"
        });
      }

    } catch (err) {
      logger.error(`Exception in UpdateNeSLDocumentData Method`, err);
      //reject(err);
	  resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error while saving NeSL Document data"
        });
    }
  });
}


module.exports = { generateCBSTokenAPI,generateAPIMTokenAPI, CallCityKYCInfoAPIForSOLValidate, CityKYCInfoAPI,CityKYCInfoAPIM, CustomerDetailsAPI,CustomerDetailsAPIM,CBSCustomerDetails_InsertAPIM, BGCustomerDetailsAPI, LoanStatusInquiryAPI,LoanStatusInquiryAPIM, NPAStatusInquiryAPI,NPAStatusInquiryAPIM, BalanceInquiryAPI,BalanceInquiryAPIM, CustomerJourneyDataUpdate, CBSChargeCollectionAPI,APIMLoanStatusInquiryAPI, CBSLoanAccountOpeningAPI,CBSChargeCollectionAPIM, GetKeyConfigurationValue, PushQRCodeData,ChargeCollectionRequestBodyAPIM,CBSLoanAccountOpeningAPIM, BankSignAffix, UpdateNeSLDocumentData,fetchRefKeyByAadhaar };
