//General Operation js file

const express = require("express");
const axios = require('axios');
//const sql = require("mssql");
const app = express();
app.use(express.json())
var cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');

const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');
const { sql, getPool } = require('./db');

app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('GeneralDataLayer');
const logError = require('./ErrorLog');
const objSIDBIDataLayer = require('./SIDBIDataLayer');
const objCIBILDataLayer = require('./CIBILDataLayer');
const objGeneralDataLayer = require('./GeneralDataLayer');
const objCBSDataLayer = require('./CBSDataLayer');

const objValueFirstDataLayer = require('./ValueFirstDataLayer');
const objCommonFunction = require('./CommonFunctions');
// Set up cookie parser middleware
app.use(cookieParser());

//SQL Server configuration
// var config = {
//   user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000
//   },
//   "options": {
//     "encrypt": false
//   }
// }

 var config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

// function getPMSData(PMSNumber, FreshOrOld) {
  // logger.info('********************* Inside getPMSData Method ************************');
  // logger.info('PMSNumber ' + PMSNumber);
  // logger.info('Journey Type ' + FreshOrOld);
  // let CustomQuery;
  // return new Promise((resolve, reject) => {
    // try {
      // if (FreshOrOld == 'FreshJourney') {
        // CustomQuery = `SELECT [App_PortalRefNo] APPLICATIONNO,FORMAT(CAST(App_ApplicationDate AS DATE), 'dd-MM-yyyy') APPLICATIONDATE
          // ,[App_ApplicationStateName] STATENAME,[App_BranchCode] PICKEDUPBRANCH,[App_ULBName] ULBNAME
          // ,[App_LoanTerm] AS TRENCH,[CurrentStatus],[Personal_ApplicantName] APPLICANTNAME,[Personal_MobileNo] MOBILENO,[CommAddr_Permanant_TownDist] DISTRICTNAME
          // ,[Business_VendingActivity_ActivityNameCode] ACTIVITYNAME,[Business_ProofOfVending_LoRStatus] LORSTATUS
          // ,[Verification_AadhaarBankAccount_BankName] PICKEDUPBANK,[Verification_AadhaarBankAccount_IFSC] PICKEDUPIFSC,[Verification_AadhaarBankAccount_AccountNo] ACCOUNTNO
          // ,[Loan_LoanAmountRequired_AmountValue] TOTALLOAN,[EntryDate] PICKEDUPDATE,CommAddr_Current_PIN,CommAddr_Current_TownDist,CommAddr_Current_State FROM [SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA]
                                    // WHERE App_PortalRefNo = @PMSNumber`;
      // }
      // else {
        // CustomQuery = `SELECT TOP 1 ConsumedRowID,[App_PortalRefNo] APPLICATIONNO,FORMAT(CAST(App_ApplicationDate AS DATE), 'dd-MM-yyyy') APPLICATIONDATE
                        // ,[App_ApplicationStateName] STATENAME,[App_BranchCode] PICKEDUPBRANCH,[App_ULBName] ULBNAME
                        // ,[App_LoanTerm] AS TRENCH,[CurrentStatus],[Personal_ApplicantName] APPLICANTNAME,[Personal_MobileNo] MOBILENO,[CommAddr_Permanant_TownDist] DISTRICTNAME
                        // ,[Business_VendingActivity_ActivityNameCode] ACTIVITYNAME,[Business_ProofOfVending_LoRStatus] LORSTATUS
                        // ,[Verification_AadhaarBankAccount_BankName] PICKEDUPBANK,[Verification_AadhaarBankAccount_IFSC] PICKEDUPIFSC,[Verification_AadhaarBankAccount_AccountNo] ACCOUNTNO
                        // ,[Loan_LoanAmountRequired_AmountValue] TOTALLOAN,[EntryDate] PICKEDUPDATE,CommAddr_Current_PIN,CommAddr_Current_TownDist,CommAddr_Current_State FROM [SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA_CONSUMED]
                        // WHERE App_PortalRefNo = @PMSNumber ORDER BY ConsumedRowID DESC`;
      // }


      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // //logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .query(CustomQuery);
        // logger.info('Result Length: ' + result.recordset.length);
        // if (result.recordset && result.recordset.length > 0) {
          // //logger.info('here '+JSON.stringify(JSON.parse(JSON.stringify(result.recordset))));
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //logger.info('results:', formattedString);
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function getPMSData(PMSNumber, FreshOrOld) {
  logger.info('********************* Inside getPMSData Method ************************');
  logger.info('PMSNumber ' + PMSNumber);
  logger.info('Journey Type ' + FreshOrOld);

  let CustomQuery;

  return new Promise(async (resolve, reject) => {
    try {
      if (FreshOrOld === 'FreshJourney') {
        CustomQuery = `
          SELECT
            [App_PortalRefNo] APPLICATIONNO,
            FORMAT(CAST(App_ApplicationDate AS DATE), 'dd-MM-yyyy') APPLICATIONDATE,
            [App_ApplicationStateName] STATENAME,
            [App_BranchCode] PICKEDUPBRANCH,
            [App_ULBName] ULBNAME,
            [App_LoanTerm] AS TRENCH,
            [CurrentStatus],
            [Personal_ApplicantName] APPLICANTNAME,
            [Personal_MobileNo] MOBILENO,
            [CommAddr_Permanant_TownDist] DISTRICTNAME,
            [Business_VendingActivity_ActivityNameCode] ACTIVITYNAME,
            [Business_ProofOfVending_LoRStatus] LORSTATUS,
            [Verification_AadhaarBankAccount_BankName] PICKEDUPBANK,
            [Verification_AadhaarBankAccount_IFSC] PICKEDUPIFSC,
            [Verification_AadhaarBankAccount_AccountNo] ACCOUNTNO,
            [Loan_LoanAmountRequired_AmountValue] TOTALLOAN,
            [EntryDate] PICKEDUPDATE,
            CommAddr_Current_PIN,
            CommAddr_Current_TownDist,
            CommAddr_Current_State
          FROM [SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA]
          WHERE App_PortalRefNo = @PMSNumber
        `;
      } else {
        CustomQuery = `
          SELECT TOP 1
            ConsumedRowID,
            [App_PortalRefNo] APPLICATIONNO,
            FORMAT(CAST(App_ApplicationDate AS DATE), 'dd-MM-yyyy') APPLICATIONDATE,
            [App_ApplicationStateName] STATENAME,
            [App_BranchCode] PICKEDUPBRANCH,
            [App_ULBName] ULBNAME,
            [App_LoanTerm] AS TRENCH,
            [CurrentStatus],
            [Personal_ApplicantName] APPLICANTNAME,
            [Personal_MobileNo] MOBILENO,
            [CommAddr_Permanant_TownDist] DISTRICTNAME,
            [Business_VendingActivity_ActivityNameCode] ACTIVITYNAME,
            [Business_ProofOfVending_LoRStatus] LORSTATUS,
            [Verification_AadhaarBankAccount_BankName] PICKEDUPBANK,
            [Verification_AadhaarBankAccount_IFSC] PICKEDUPIFSC,
            [Verification_AadhaarBankAccount_AccountNo] ACCOUNTNO,
            [Loan_LoanAmountRequired_AmountValue] TOTALLOAN,
            [EntryDate] PICKEDUPDATE,
            CommAddr_Current_PIN,
            CommAddr_Current_TownDist,
            CommAddr_Current_State
          FROM [SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA_CONSUMED]
          WHERE App_PortalRefNo = @PMSNumber
          ORDER BY ConsumedRowID DESC
        `;
      }

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .query(CustomQuery);

      logger.info('Result Length: ' + result.recordset.length);

      if (result.recordset && result.recordset.length > 0) {
        const formattedString = JSON.stringify(result.recordset[0]);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getPMSData Error:', err);
      //reject(err);
	   resolve(null);
    }
  });
}


// function isPMSNumberExist(PMSNumber) {
  // logger.info('********************* Inside isPMSNumberExist Method ************************');
  // logger.info('PMSNumber ' + PMSNumber);

  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT App_PortalRefNo AS APPLICATIONNO,[App_LoanTerm] AS TRENCH,[CurrentStatus],[Business_ProofOfVending_LoRStatus] LORSTATUS
              // ,[Loan_LoanAmountRequired_AmountValue] TOTALLOAN FROM [SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA] WHERE App_PortalRefNo = @PMSNumber`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // //logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .query(query);
        // logger.info('Result Length: ' + result.recordset.length);
        // if (result.recordset && result.recordset.length > 0) {
          // //logger.info('here '+JSON.stringify(JSON.parse(JSON.stringify(result.recordset))));
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //logger.info('results:', formattedString);
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function isPMSNumberExist(PMSNumber) {
  logger.info('********************* Inside isPMSNumberExist Method ************************');
  logger.info('PMSNumber ' + PMSNumber);

  const query = `
    SELECT
      App_PortalRefNo AS APPLICATIONNO,
      [App_LoanTerm] AS TRENCH,
      [CurrentStatus],
      [Business_ProofOfVending_LoRStatus] AS LORSTATUS,
      [Loan_LoanAmountRequired_AmountValue] AS TOTALLOAN
    FROM [SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA]
    WHERE App_PortalRefNo = @PMSNumber
  `;

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .query(query);

      logger.info('Result Length: ' + result.recordset.length);

      if (result.recordset && result.recordset.length > 0) {
        // Return single-row JSON string (same behavior as earlier)
        const formattedString = JSON.stringify(result.recordset[0]);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('isPMSNumberExist Error:', err);
      //reject(err);
	  resolve(null);
    }
  });
}


/**
 * Inserts landing data for a customer into the database
 * @param {string} PMSNumber 
 * @param {string} AadhaarNumber 
 * @param {string} refKey 
 */
function insertLandingData(PMSNumber, AadhaarNumber, refKey) {
  logger.info('********************* Inside insertLandingData Method ************************');
  logger.info('PMSNumber: ' + PMSNumber + ' | RefKey: ' + refKey);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        // Inputs as parameters (SQL injection safe)
        .input('PMSNumber', sql.VarChar(20), PMSNumber)
        .input('AadhaarNumber', sql.VarChar(12), AadhaarNumber)
        .input('RefKey', sql.VarChar(50), refKey)
        // Execute stored procedure
        .execute('usp_InsertLandingData');

      logger.info('Procedure executed successfully for PMSNumber: ' + PMSNumber);

      // Return proc result as-is (same behavior)
      resolve(result);

    } catch (err) {
      logger.error('Error in insertLandingData:', err);
      //reject(err);
	     resolve(null);
    }
  });
}


// function getEligibleDataFromMISD(CustomerID) {
  // logger.info('********************* getEligibleDataFromMISD Method ************************');
  // logger.info('CustomerID', CustomerID);

  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT [CAL_ID],[PPN_TMS],[IP_CODE],[ARNGMNT_NAME],[NAT_ID_CARD],[PAN],[ELIGIBLE_FOR_2ND_TRANCHNE],[ELIGIBLE_FOR_3RD_TRANCHNE],[DEL_FLG] FROM [PMSvanidhiDB].[dbo].[SVND_MISD_SECOND_THIRD_ELIGIBILITY_DATA] WHERE IP_CODE=@CustomerID`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // //logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('CustomerID', sql.VarChar, CustomerID)
          // .query(query);
        // logger.info('Result Length: ' + result.recordset.length);
        // if (result.recordset && result.recordset.length > 0) {
          // logger.info('here ' + JSON.stringify(JSON.parse(JSON.stringify(result.recordset))));
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // logger.info('results:', formattedString);
          // resolve(formattedString);
        // }
        // else {
          // logger.info('Else Part Called');
          // responseobj = {
            // "ErrorCode": "01",
            // "ErrorMsg": "No Data found for customerid"
          // }
          // resolve(JSON.stringify(responseobj));
        // }
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function getEligibleDataFromMISD(CustomerID) {
  logger.info('********************* getEligibleDataFromMISD Method ************************');
  logger.info('CustomerID', CustomerID);

  const query = `
    SELECT
      [CAL_ID],
      [PPN_TMS],
      [IP_CODE],
      [ARNGMNT_NAME],
      [NAT_ID_CARD],
      [PAN],
      [ELIGIBLE_FOR_2ND_TRANCHNE],
      [ELIGIBLE_FOR_3RD_TRANCHNE],
      [DEL_FLG]
    FROM [PMSvanidhiDB].[dbo].[SVND_MISD_SECOND_THIRD_ELIGIBILITY_DATA]
    WHERE IP_CODE = @CustomerID
  `;

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('CustomerID', sql.VarChar, CustomerID)
        .query(query);

      logger.info('Result Length: ' + result.recordset.length);

      if (result.recordset && result.recordset.length > 0) {
        const formattedString = JSON.stringify(result.recordset[0]);
        resolve(formattedString);
      } else {
        const responseobj = {
          ErrorCode: "01",
          ErrorMsg: "No Data found for customerid"
        };
        resolve(JSON.stringify(responseobj));
      }

    } catch (err) {
      logger.error('getEligibleDataFromMISD Error:', err);
      //reject(err);
	  resolve(null);
    }
  });
}


// function CBSToken(PMSNumber, JourneyID) {
  // logger.info('Inside getCBSToken to get if valid token available or not');
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT TOP 1 access_token from SVND_CBS_API_TOKEN WHERE expires_in>=(convert(varchar(10),getdate(),120)+' '+convert(varchar, getdate(), 108)) order by RowID desc;`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // logger.info('Query: ' + query);
        // const result = await pool.request()
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output = jsonString.slice(1, -1);
          // output = JSON.parse(output);
          // response = {
            // "ErrorCode": "00",
            // "ErrorMsg": "Token successfully retrieved",
            // "AccessToken": output.access_token
          // }
          // logger.info('Final Response:', response);

          // resolve(response);
        // }
        // else {
          // logger.info('else part');
          // objCBSDataLayer.generateCBSTokenAPI(PMSNumber, JourneyID).then(async (TokenAPIResp) => {
            // logger.info('Token API Response : ' + JSON.stringify(TokenAPIResp));
            // if (TokenAPIResp.ErrorCode == "00") {
              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "Token successfully generated.",
                // "AccessToken": TokenAPIResp.AccessToken
              // }
              // resolve(response);
            // }
          // });

        // }

      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function CBSToken(PMSNumber, JourneyID) {
  logger.info('Inside getCBSToken to get if valid token available or not');

  const query = `
    SELECT TOP 1 access_token
    FROM SVND_CBS_API_TOKEN
    WHERE expires_in >= (CONVERT(varchar(10), GETDATE(), 120) + ' ' + CONVERT(varchar, GETDATE(), 108))
    ORDER BY RowID DESC
  `;

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request.query(query);

      if (result.recordset && result.recordset.length > 0) {
        const output = result.recordset[0];

        const response = {
          ErrorCode: "00",
          ErrorMsg: "Token successfully retrieved",
          AccessToken: output.access_token
        };

        logger.info('Final Response:', response);
        resolve(response);
      } else {
        // Generate new token
        objCBSDataLayer.generateCBSTokenAPI(PMSNumber, JourneyID)
          .then(TokenAPIResp => {
            logger.info('Token API Response : ' + JSON.stringify(TokenAPIResp));

            if (TokenAPIResp.ErrorCode === "00") {
              resolve({
                ErrorCode: "00",
                ErrorMsg: "Token successfully generated.",
                AccessToken: TokenAPIResp.AccessToken
              });
            } else {
              resolve(TokenAPIResp);
            }
          })
          .catch(err => reject(err));
      }

    } catch (err) {
      logger.error('CBSToken Error:', err);
      //reject(err);
	  resolve(null);
    }
  });
}


// function SIDBICurrentStatus_Update(PMSNumber, JourneyID, LoRStatus, CurrentStatus) {
  // logger.info('******************************inside SIDBICurrentStatus_Update Method****************************************');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // logger.info('LoRStatus: ' + LoRStatus);
  // logger.info('CurrentStatus: ' + CurrentStatus);

  // return new Promise((resolve, reject) => {
    // try {
      // // const date1=DatePart();
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool); // Create a new request object for every row insert
        // request.input('PMSNumber', sql.VarChar, PMSNumber)
        // request.input('JourneyID', sql.VarChar, JourneyID)
        // request.input('LORStatus', sql.VarChar, LoRStatus)
        // request.input('CurrentStatus', sql.VarChar, CurrentStatus)

        // request.execute('proc_SIDBI_CurrentStatusUpdate', function (err, queryResult) {
          // //logger.info('QueryResult ' + JSON.stringify(queryResult));
          // logger.info('rowsAffected ' + queryResult.rowsAffected[0]);
          // logger.info('Error ' + err);
          // if (queryResult.rowsAffected[0] > 0) {
            // formattedString = {
              // "ErrorCode": "00",
              // "ErrorMsg": "SIDBI Current Status and LOR Status updated Successfully."
            // }
            // resolve(formattedString);
          // }
          // else {
            // logger.info('else:');
            // formattedString1 = {
              // "ErrorCode": "01",
              // "ErrorMsg": "Error to update sidbi current status and LOR status in database."
            // }
            // resolve(formattedString);
          // }
        // });
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function APIMToken(PMSNumber, JourneyID) {
  logger.info('Inside getAPIMToken to get if valid token available or not');
  return new Promise((resolve, reject) => {
    try {
      const query = `SELECT TOP 1 access_token from SVND_CBS_API_TOKEN WHERE expires_in>=(convert(varchar(10),getdate(),120)+' '+convert(varchar, getdate(), 108)) order by RowID desc;`;
      var conn = new sql.ConnectionPool(config);
      conn.connect().then(async function (pool) {
        logger.info('Query: ' + query);
        const result = await pool.request()
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          const jsonString = JSON.stringify(result.recordset, null, 2);
          output = jsonString.slice(1, -1);
          output = JSON.parse(output);
          response = {
            "ErrorCode": "00",
            "ErrorMsg": "Token successfully retrieved",
            "AccessToken": output.access_token
          }
          logger.info('Final Response:', response);

          resolve(response);
        }
        else {
          logger.info('APIM Calling');
          objCBSDataLayer.generateAPIMTokenAPI(PMSNumber, JourneyID).then(async (TokenAPIResp) => {
            logger.info('Token APIM Response : ' + JSON.stringify(TokenAPIResp));
            if (TokenAPIResp.ErrorCode == "00") {
              response = {
                "ErrorCode": "00",
                "ErrorMsg": "Token successfully generated.",
                "AccessToken": TokenAPIResp.AccessToken
              }
              resolve(response);
            }
          });

       }

      });
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}




function SIDBICurrentStatus_Update(PMSNumber, JourneyID, LoRStatus, CurrentStatus) {
  logger.info('******************************inside SIDBICurrentStatus_Update Method****************************************');
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('JourneyID: ' + JourneyID);
  logger.info('LoRStatus: ' + LoRStatus);
  logger.info('CurrentStatus: ' + CurrentStatus);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('LORStatus', sql.VarChar, LoRStatus)
        .input('CurrentStatus', sql.VarChar, CurrentStatus)
        .execute('proc_SIDBI_CurrentStatusUpdate');

      logger.info('rowsAffected ' + result.rowsAffected[0]);

      if (result.rowsAffected[0] > 0) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: "SIDBI Current Status and LOR Status updated Successfully."
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: "Error to update sidbi current status and LOR status in database."
        });
      }

    } catch (err) {
      logger.error('SIDBICurrentStatus_Update Error:', err);
      //reject(err);
	resolve({
          ErrorCode: "01",
          ErrorMsg: "Error to update sidbi current status and LOR status in database."
        });
    }
  });
}


// function getVFirstToken(PMSNumber, JourneyID) {
  // logger.info('Inside getVFirstToken to get if valid token available or not');
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT TOP 1 token from SVND_VALUEFIRST_TOKENS WHERE expiry>=(convert(varchar(10),getdate(),120)+' '+convert(varchar, getdate(), 108)) order by ID desc;`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // logger.info('Query: ' + query);
        // const result = await pool.request()
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output = jsonString.slice(1, -1);
          // output = JSON.parse(output);
          // response = {
            // "ErrorCode": "00",
            // "ErrorMsg": "VFirstToken successfully retrieved",
            // "VFirstToken": output.token
          // }
          // logger.info('Final Response:', response);

          // resolve(response);
        // }
        // else {
          // logger.info('No valid token in database. Token Generation API Call');
          // objValueFirstDataLayer.generateVFirstToken(PMSNumber, JourneyID).then(async (TokenAPIResp) => {
            // logger.info('Out generateVFirstToken Response : ' + JSON.stringify(TokenAPIResp));
            // if (TokenAPIResp.ErrorCode == "00") {
              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "Token successfully generated.",
                // "VFirstToken": TokenAPIResp.VFirstToken
              // }
              // resolve(response);
            // }
            // else {
              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": "Error While generating VFisrt Token for SMS Service",
              // }
              // resolve(response);
            // }
          // });
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function VerifyVFirstOTP(OTPReq) {
  // logger.info('Inside VerifyVFirstOTP Complete Request: ' + JSON.stringify(OTPReq));
  // // logger.info('Inside VFirstOTP_Insert OTPHash: ' + OTPReq.OTPHash);
  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('UserID', sql.NVarChar, OTPReq.UserID)
          // .input('PFNumber', sql.NVarChar, OTPReq.PFNumber)
          // .input('OTPHash', sql.NVarChar, OTPReq.OTPHash)
          // .input('OTPReqMsg', sql.NVarChar, OTPReq.OTPMsg)
          // .input('Operation', sql.NVarChar, 'Update')
          // .output('p_OutStatus', sql.NVarChar) // Define output parameter
          // .execute('proc_VFirstOTP_InsertUpdate', function (err, queryResult) {
            // //logger.info('QueryResult:', queryResult); // Retrieve output parameter 
            // if (queryResult.output.p_OutStatus.split(':')[0] == "200" && queryResult.rowsAffected[0] == '1') {
              // resp = {
                // "ErrorCode": "00",
                // "ErrorMsg": queryResult.output.p_OutStatus.split(':')[1]
              // }
              // resolve(resp);
            // }
            // else {
              // logger.info('else:');
              // resp = {
                // "ErrorCode": "01",
                // "ErrorMsg": queryResult.output.p_OutStatus.split(':')[1]
              // }
              // resolve(resp);
            // }
          // });
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }


// function getCustomerDetails(CustomerID) {
  // logger.info('inside getCustomerDetails method for customer id ' + CustomerID);
  // return new Promise((resolve, reject) => {
    // try {
      // if (CustomerID != null) {
        // const query = `SELECT A.[CustomerID],A.[Cust_Full_Name] AS CustomerName,A.[MobileNo],FORMAT(CAST(A.Date_of_Birth AS DATE), 'dd-MM-yyyy') Cust_DOB,FORMAT(CAST(A.Date_of_Birth AS DATE), 'ddMMyyyy') Date_of_Birth,A.Date_of_Birth AS Actual_Date_of_Birth,A.[Gender],A.PANCard,isnull(A.AadharNO,'NA') ,A.[CommAddress_Address1] CommAddr1,A.CommAddress_Address2 CommAddr2,A.CommAddress_City CommCity,A.CommAddress_State CommState,A.CommAddress_Country CommCountry,A.CommAddress_PINCode CommPINCode
                          // ,A.PermanentAddress_Address1 PermAddress1,A.PermanentAddress_Address2 PermAddress2,A.PermanentAddress_City PermCity,A.PermanentAddress_State PermState,A.PermanentAddress_Country PermCountry,A.PermanentAddress_PINCode PermPINCode,C.BRANCH
                          // FROM [PMSvanidhiDB].[dbo].[SVND_CBS_CUSTOMER_DETAILS] A
                          // INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                          // INNER JOIN SVND_BRANCH_MASTER C ON C.BRANCH_CODE=B.solid 
                          // WHERE A.CustomerID = @CustomerID`;
        // var conn = new sql.ConnectionPool(config);
        // conn.connect().then(async function (pool) {
          // logger.info('Query: ' + query);
          // const result = await pool.request()
            // .input('CustomerID', sql.VarChar, CustomerID)
            // .query(query);

          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //logger.info('results:', formattedString);                
          // resolve(formattedString);
        // });
      // }
    // } catch (err1) {
      // reject(err1);
    // }
  // });
// }


function getVFirstToken(PMSNumber, JourneyID) {
  logger.info('Inside getVFirstToken to get if valid token available or not');

  const query = `
    SELECT TOP 1 token
    FROM SVND_VALUEFIRST_TOKENS
    WHERE expiry >= (CONVERT(varchar(10), GETDATE(), 120) + ' ' + CONVERT(varchar, GETDATE(), 108))
    ORDER BY ID DESC;
  `;

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request.query(query);

      if (result.recordset && result.recordset.length > 0) {
        const output = result.recordset[0];

        const response = {
          ErrorCode: "00",
          ErrorMsg: "VFirstToken successfully retrieved",
          VFirstToken: output.token
        };

        logger.info('Final Response:', response);
        resolve(response);
      } else {
        logger.info('No valid token in database. Token Generation API Call');

        objValueFirstDataLayer.generateVFirstToken(PMSNumber, JourneyID)
          .then(TokenAPIResp => {
            logger.info('Out generateVFirstToken Response : ' + JSON.stringify(TokenAPIResp));

            if (TokenAPIResp.ErrorCode === "00") {
              resolve({
                ErrorCode: "00",
                ErrorMsg: "Token successfully generated.",
                VFirstToken: TokenAPIResp.VFirstToken
              });
            } else {
              resolve({
                ErrorCode: "01",
                ErrorMsg: "Error While generating VFisrt Token for SMS Service"
              });
            }
          })
          .catch(err => reject(err));
      }

    } catch (err) {
      logger.error('getVFirstToken Error:', err);
      resolve({
                ErrorCode: "01",
                ErrorMsg: "Exception While generating VFisrt Token for SMS Service"
              });
    }
  });
}


function VerifyVFirstOTP(OTPReq) {
  logger.info('Inside VerifyVFirstOTP Complete Request: ' + JSON.stringify(OTPReq));

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('UserID', sql.NVarChar, OTPReq.UserID)
        .input('PFNumber', sql.NVarChar, OTPReq.PFNumber)
        .input('OTPHash', sql.NVarChar, OTPReq.OTPHash)
        .input('OTPReqMsg', sql.NVarChar, OTPReq.OTPMsg)
        .input('Operation', sql.NVarChar, 'Update')
        .output('p_OutStatus', sql.NVarChar)
        .execute('proc_VFirstOTP_InsertUpdate');

      const statusParts = result.output.p_OutStatus.split(':');

      if (statusParts[0] === "200" && result.rowsAffected[0] == 1) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: statusParts[1]
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: statusParts[1]
        });
      }

    } catch (err) {
      logger.error('VerifyVFirstOTP Error:', err);
      reject(err);
    }
  });
}


function getCustomerDetails(CustomerID) {
  logger.info('inside getCustomerDetails method for customer id ' + CustomerID);

  const query = `
    SELECT
      A.CustomerID,
      A.Cust_Full_Name AS CustomerName,
      A.MobileNo,
      FORMAT(CAST(A.Date_of_Birth AS DATE), 'dd-MM-yyyy') Cust_DOB,
      FORMAT(CAST(A.Date_of_Birth AS DATE), 'ddMMyyyy') Date_of_Birth,
      A.Date_of_Birth AS Actual_Date_of_Birth,
      A.Gender,
      A.PANCard,
      ISNULL(A.AadharNO,'NA') AadharNO,
      A.CommAddress_Address1 CommAddr1,
      A.CommAddress_Address2 CommAddr2,
      A.CommAddress_City CommCity,
      A.CommAddress_State CommState,
      A.CommAddress_Country CommCountry,
      A.CommAddress_PINCode CommPINCode,
      A.PermanentAddress_Address1 PermAddress1,
      A.PermanentAddress_Address2 PermAddress2,
      A.PermanentAddress_City PermCity,
      A.PermanentAddress_State PermState,
      A.PermanentAddress_Country PermCountry,
      A.PermanentAddress_PINCode PermPINCode,
      C.BRANCH
    FROM SVND_CBS_CUSTOMER_DETAILS A
    INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID = A.CustomerID
    INNER JOIN SVND_BRANCH_MASTER C ON C.BRANCH_CODE = B.solid
    WHERE A.CustomerID = @CustomerID
  `;

  return new Promise(async (resolve, reject) => {
    try {
      if (!CustomerID) {
        resolve(null);
        return;
      }

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('CustomerID', sql.VarChar, CustomerID)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        resolve(JSON.stringify(result.recordset[0]));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getCustomerDetails Error:', err);
      reject(err);
    }
  });
}


// function getConsumerCIBIL(PMSNumber, JourneyID,isLoanAccountOpenedValue) {
  // logger.info('############################# Inside getConsumerCIBIL from Database Method ##########################');
  // logger.info(`PMSNumber ${PMSNumber}`);
  // logger.info(`JourneyID ${JourneyID}`);
  // logger.info(`isLoanAccountOpenedValue ${isLoanAccountOpenedValue}`);
  // return new Promise((resolve, reject) => {

    // try {     
       // let query;
     // if (isLoanAccountOpenedValue === true)
     // {
        // query = `SELECT B.[CICRefID],A.[PMSNumber],[JourneyRefID],[ApplicationId],[DocumentId],[ConsumerAPIDCRespStatus],[ConsumerAPICibilBureauRespStatus]
                // ,[ConsumerAPIMessage],[DocumentAPIRespStatus],[DocumentAPIMessage],DocumentByte
                // ,CONVERT(VARCHAR(10),ConsumerAPIResponseTime ,105) AS ConsumerAPIResponseTime
                // ,ErrorCode,ErrorMessage FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                // LEFT OUTER JOIN [PMSvanidhiDB].[dbo].[SVND_CIBIL_REQUEST_RESPONSE] B ON A.PMSNumber=B.PMSNumber AND A.JourneyID=B.JourneyRefID
                // WHERE A.PMSNumber=@PMSNumber AND A.JourneyID=@JourneyID AND isLoanAccountOpened=1 AND isJourneyActive=1 AND isCustomerJourneyCompleted=1`;
     // }
     // else
     // {
        // query = `SELECT B.[CICRefID],A.[PMSNumber],[JourneyRefID],[ApplicationId],[DocumentId],[ConsumerAPIDCRespStatus],[ConsumerAPICibilBureauRespStatus]
                // ,[ConsumerAPIMessage],[DocumentAPIRespStatus],[DocumentAPIMessage],DocumentByte
                // ,CONVERT(VARCHAR(10),ConsumerAPIResponseTime ,105) AS ConsumerAPIResponseTime
                // ,ErrorCode,ErrorMessage FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                // LEFT OUTER JOIN [PMSvanidhiDB].[dbo].[SVND_CIBIL_REQUEST_RESPONSE] B ON A.PMSNumber=B.PMSNumber AND A.JourneyID=B.JourneyRefID
                // WHERE A.PMSNumber=@PMSNumber AND A.JourneyID=@JourneyID AND isLoanAccountOpened=0 AND isJourneyActive=1 AND isCustomerJourneyCompleted=0`;
     // }
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
         // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //logger.info('results:', formattedString);                         
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // reject(err1);
    // }
  // });
// }

function getConsumerCIBIL(PMSNumber, JourneyID, isLoanAccountOpenedValue) {
  logger.info('############################# Inside getConsumerCIBIL from Database Method ##########################');
  logger.info(`PMSNumber ${PMSNumber}`);
  logger.info(`JourneyID ${JourneyID}`);
  logger.info(`isLoanAccountOpenedValue ${isLoanAccountOpenedValue}`);

  return new Promise(async (resolve, reject) => {
    try {
      let query;

      if (isLoanAccountOpenedValue === true) {
        query = `
          SELECT 
            B.CICRefID,
            A.PMSNumber,
            JourneyRefID,
            ApplicationId,
            DocumentId,
            ConsumerAPIDCRespStatus,
            ConsumerAPICibilBureauRespStatus,
            ConsumerAPIMessage,
            DocumentAPIRespStatus,
            DocumentAPIMessage,
            DocumentByte,
            CONVERT(VARCHAR(10), ConsumerAPIResponseTime, 105) AS ConsumerAPIResponseTime,
            ErrorCode,
            ErrorMessage
          FROM SVND_LOAN_JOURNEY_MASTER A
          LEFT OUTER JOIN SVND_CIBIL_REQUEST_RESPONSE B
            ON A.PMSNumber = B.PMSNumber
           AND A.JourneyID = B.JourneyRefID
          WHERE
            A.PMSNumber = @PMSNumber
            AND A.JourneyID = @JourneyID
            AND isLoanAccountOpened = 1
            AND isJourneyActive = 1
            AND isCustomerJourneyCompleted = 1
        `;
      } else {
        query = `
          SELECT 
            B.CICRefID,
            A.PMSNumber,
            JourneyRefID,
            ApplicationId,
            DocumentId,
            ConsumerAPIDCRespStatus,
            ConsumerAPICibilBureauRespStatus,
            ConsumerAPIMessage,
            DocumentAPIRespStatus,
            DocumentAPIMessage,
            DocumentByte,
            CONVERT(VARCHAR(10), ConsumerAPIResponseTime, 105) AS ConsumerAPIResponseTime,
            ErrorCode,
            ErrorMessage
          FROM SVND_LOAN_JOURNEY_MASTER A
          LEFT OUTER JOIN SVND_CIBIL_REQUEST_RESPONSE B
            ON A.PMSNumber = B.PMSNumber
           AND A.JourneyID = B.JourneyRefID
          WHERE
            A.PMSNumber = @PMSNumber
            AND A.JourneyID = @JourneyID
            AND isLoanAccountOpened = 0
            AND isJourneyActive = 1
            AND isCustomerJourneyCompleted = 0
        `;
      }

      const pool = await getPool();
      const request = pool.request();

      //logger.info('Query: ' + query);

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        const formattedString = jsonString.slice(1, -1);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getConsumerCIBIL Error:', err);
      reject(err);
    }
  });
}



function CreateLoanJourney(AadhaarNumber, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, UserID, UserSOL, ROI, ROIAddsTwentyFiveBasis, RLLR,BSP,RLLR_BSP, Spread, ServiceCharge, isExistingJourneyExpired, JourneyCreationReason) {
  logger.info('############################# Inside CreateLoanJourney method ##########################');
  logger.info(`PMSNumber ${PMSNumber}`);
  logger.info(`Operation ${Operation}`);
  logger.info(`JourneyCreationReason ${JourneyCreationReason}`);
  
  return new Promise((resolve, reject) => {
    try {
      getPMSData(PMSNumber, JourneyCreationReason).then(async (PMSDetails) => {
        logger.info('Output getPMSData' + JSON.stringify(PMSDetails));
        let PMSDataParse = JSON.parse(PMSDetails);
        if (Operation == "BranchJourney" && (PMSDataParse.TRENCH == "2" || PMSDataParse.TRENCH == "3") && isHigherTranchPassConsent == false)//TRENCH
        {
          JourneyInsertResp = {
            "ErrorCode": "02",
            "ErrorMsg": "Application pertains to second/third tranche. Please provide consent to proceed further"
          }
          logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
          resolve(JourneyInsertResp)
        }
        else {
          CustomerJourneyInsert(AadhaarNumber, PMSNumber, PMSDataParse, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, UserID, UserSOL, ROI, ROIAddsTwentyFiveBasis, RLLR,BSP,RLLR_BSP, Spread, ServiceCharge, isExistingJourneyExpired, JourneyCreationReason).then(async (objRespCustomerJourney) => {
            logger.info('Output CustomerJourneyInsert' + JSON.stringify(objRespCustomerJourney));
            if (objRespCustomerJourney.ErrorCode == "00") {
              JourneyInsertResp = {
                "ErrorCode": "00",
                "ErrorMsg": "Customer Journey created."
              }
              logger.info(`CustomerJourneyInsert Success Response: ${JSON.stringify(JourneyInsertResp)}`);
              resolve(JourneyInsertResp);
            }
            else {
              JourneyInsertResp = {
                "ErrorCode": objRespCustomerJourney.ErrorCode,
                "ErrorMessage": objRespCustomerJourney.ErrorMsg
              }
              logger.info(`CustomerJourneyInsert failure Response: ${JSON.stringify(JourneyInsertResp)}`);
              resolve(JourneyInsertResp);
            }
          });
        }
      });
    } catch (err1) {
      reject(err1);
    }
  });
}


// function getKFSAndSanctionLetterData(PMSNumber, CustmerID, JourneyID) {
  // logger.info('######################Inside getKFSAndSanctionLetterData ######################');
  // logger.info('Inside PMSNumber: ' + PMSNumber);
  // logger.info('Inside CustmerID: ' + CustmerID);
  // logger.info('Inside JourneyID: ' + JourneyID);
  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('PMSNumber', sql.NVarChar, PMSNumber)
          // .input('CustomerID', sql.VarChar, CustmerID)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .execute('proc_getKFSAndSanctionLetterData', function (err, queryResult) {
            // logger.info('Result Length: ' + queryResult.recordset.length);
            // logger.info('Result: ' + JSON.stringify(queryResult.recordset));
            // if (queryResult.recordset && queryResult.recordset.length > 0) {
              // conn.close();
              // const jsonString = JSON.stringify(queryResult.recordset, null, 2);
              // formattedString = jsonString.slice(1, -1);
              // resolve(formattedString);
            // }
            // else {
              // Errresponse = {
                // "ErrorCode": "01",
                // "ErrorMsg": err
              // }
              // logger.info("Error while insert in database :- " + err);
              // resolve(Errresponse);
            // }
          // });
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function getKFSAndSanctionLetterData(PMSNumber, CustmerID, JourneyID) {
  // logger.info('######################Inside getKFSAndSanctionLetterData ######################');
  // logger.info('Inside PMSNumber: ' + PMSNumber);
  // logger.info('Inside CustmerID: ' + CustmerID);
  // logger.info('Inside JourneyID: ' + JourneyID);

  // return new Promise((resolve, reject) => {
    // try {
      // const conn = new sql.ConnectionPool(config);

      // conn.connect().then(function (pool) {
        // const request = new sql.Request(pool);

        // request
          // .input('PMSNumber', sql.NVarChar, PMSNumber)
          // .input('CustomerID', sql.VarChar, CustmerID)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .execute('proc_getKFSAndSanctionLetterData', function (err, queryResult) {

            // if (err) {
              // logger.error('DB Error in getKFSAndSanctionLetterData: ', err);
              // conn.close();
              // return reject(err);
            // }

            // const rs = queryResult?.recordset || [];
            // logger.info('Result Length: ' + rs.length);
            // logger.info('Result: ' + JSON.stringify(rs));

            // if (rs.length > 0) {
              // const jsonString = JSON.stringify(rs, null, 2);
              // const formattedString = jsonString.slice(1, -1);
              // conn.close();
              // return resolve(formattedString);
            // } else {
              // // No data found – let caller decide to invoke CityKYC and retry
              // logger.info('No KFS/Sanction data found for PMSNumber: ' + PMSNumber);
              // conn.close();
              // return resolve(null);
            // }
          // });
      // }).catch(err2 => {
        // logger.error('Connection Error: ', err2);
        // reject(err2);
      // });

    // } catch (err1) {
      // logger.error(err1);
      // reject(err1);
    // }
  // });
// }


// function Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, JourneyID, LoanTranche, JourneyStatus, JourneyRejectionCode, JourneyRejectionReason, SidbiResponseCode) {
  // logger.info('############################# Called  Sanctioned_Rejected_Suspended_CustomerJourney Start ##########################');
  // logger.info('PMSNumber ' + PMSNumber);
  // logger.info('JourneyID ' + JourneyID);
   // logger.info('LoanTranche ' + LoanTranche);
  // logger.info('JourneyStatus ' + JourneyStatus);
 
  // logger.info('JourneyRejectionCode ' + JourneyRejectionCode);
  // logger.info('JourneyRejectionReason ' + JourneyRejectionReason);
  // logger.info('SidbiResponseCode ' + SidbiResponseCode);
  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('PMSNumber', sql.NVarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('LoanTranche', sql.Int, LoanTranche)
          // .input('JourneyStatus', sql.VarChar, JourneyStatus)
          // .input('JourneyRejectionCode', sql.VarChar, JourneyRejectionCode)
          // .input('JourneyRejectionReason', sql.VarChar, JourneyRejectionReason)
          // .input('SidbiResponseCode', sql.VarChar, SidbiResponseCode)
          // .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          // .execute('proc_Journey_SanctionedRejectedSuspendedResumeSuspension', function (err, queryResult) {
             // logger.info("queryResult: " + JSON.stringify(queryResult));
             // logger.info("Rows Affacted: " + queryResult.rowsAffected[0]);
            // if (queryResult.output.p_OutStatusCode == '200' && queryResult.rowsAffected[0] > 0) {
              // conn.close();
              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "Journey Status updated successfully.",
              // }
              // resolve(response);
            // }
            // else {
              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": err
              // }
              // logger.info("Error while update in database :- " + err);
              // resolve(response);
            // }
          // });
      // });
    // } catch (err1) {
      // logger.info(`Exception in Sanctioned_Rejected_Suspended_CustomerJourney Method  ${err1}`);
      // reject(err1);
    // }
  // });
// }


// function LogMakerConsent(PMSNumber, JourneyID, UserID, ActionEvent, Action, message) {
  // logger.info('############################# Called  LogMakerConsent Start ##########################');
  // logger.info('PMSNumber ' + PMSNumber);
  // logger.info('JourneyID ' + JourneyID);
  // logger.info('UserID ' + UserID);
  // logger.info('Action ' + Action);
  // logger.info('ActionEvent ' + ActionEvent);
  // logger.info('message ' + message);

  // let FinalAction = (Action == true || Action == 'Yes' || Action == 'Approve') ? 'Yes' : 'No';
  // logger.info('Final Action ' + FinalAction);

  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('PMSNumber', sql.NVarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('UserID', sql.VarChar, UserID)
          // .input('Action', sql.VarChar, FinalAction)
          // .input('ActionEvent', sql.VarChar, ActionEvent)
          // .input('message', sql.VarChar, message)
          // .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          // .execute('proc_MakerCheckerConsentLogs', function (err, queryResult) {
            // logger.info("queryResult: " + JSON.stringify(queryResult));
            // logger.info("err: " + err);
            // logger.info("Rows Affacted: " + queryResult.rowsAffected[0]);
            // if (queryResult.output.p_OutStatusCode == '200' && queryResult.rowsAffected[0] == '1') {
              // conn.close();
              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "User Consent updated successfully.",
              // }
              // resolve(response);
            // }
            // else {
              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": err
              // }
              // logger.info("Error while update in database :- " + err);
              // resolve(response);
            // }
          // });
      // });
    // } catch (err1) {
      // reject(err1);
    // }
  // });
// }




// function GetAmortizationSchedule(PMSNumber, JourneyID) {
  // logger.info('Inside GetAmortizationSchedule ');
  // logger.info('PMSNumber ', PMSNumber);

  // return new Promise((resolve, reject) => {
    // try {
      // const query1= `SELECT [installmentNo],[CustomerID],[PMSNumber],[outstandingPrincipal],[principal],[interest],[installmentAmount] FROM [PMSvanidhiDB].[dbo].[SVND_REPAYMENT_SCHEDULE]
            // WHERE PMSNumber=@PMSNumber AND JourneyID=@JourneyID ORDER BY principal`; //shows an wrong order of output so change
      // const query2= `SELECT [installmentNo],[CustomerID],[PMSNumber],[outstandingPrincipal],[principal],[interest],[installmentAmount] FROM [PMSvanidhiDB].[dbo].[SVND_REPAYMENT_SCHEDULE]
            // WHERE PMSNumber=@PMSNumber  AND JourneyID=@JourneyID ORDER BY   TRY_CAST(installmentNo AS INT)`; //shows an wrong order of output so change
          // const query3= `SELECT [installmentNo],[CustomerID],[PMSNumber],[outstandingPrincipal],[principal],[interest],[installmentAmount] FROM [PMSvanidhiDB].[dbo].[SVND_REPAYMENT_SCHEDULE]
            // WHERE PMSNumber=@PMSNumber  AND JourneyID=@JourneyID   ORDER BY CASE WHEN TRY_CAST(installmentNo AS INT) IS NULL THEN 1 ELSE 0 END`;   
            // const query=`SELECT
  // [installmentNo],
  // [CustomerID],
  // [PMSNumber],
  // [outstandingPrincipal],
  // [principal],
  // [interest],
  // [installmentAmount]
// FROM [PMSvanidhiDB].[dbo].[SVND_REPAYMENT_SCHEDULE]
// WHERE PMSNumber =@PMSNumber  
  // AND JourneyID = @JourneyID
// ORDER BY 
  // CASE WHEN TRY_CAST(installmentNo AS INT) IS NULL THEN 1 ELSE 0 END, 
  // TRY_CAST(installmentNo AS INT)`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // logger.info('Query: ' + query);
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // let output = JSON.stringify(result.recordset);
           // logger.info('output ' ,output);
          // //  const jsonString = JSON.stringify(result.recordset, null, 2); 
          // //  logger.info('jsonString ' ,jsonString);

          // // output =output.slice(1, -1);               


          // // logger.info('Final Response:', JSON.stringify(output));

          // resolve(output);
        // }
        // else {
          // resolve(null);
        // }

      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function getKFSAndSanctionLetterData(PMSNumber, CustmerID, JourneyID) {
  logger.info('######################Inside getKFSAndSanctionLetterData ######################');
  logger.info('Inside PMSNumber: ' + PMSNumber);
  logger.info('Inside CustmerID: ' + CustmerID);
  logger.info('Inside JourneyID: ' + JourneyID);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNumber)
        .input('CustomerID', sql.VarChar, CustmerID)
        .input('JourneyID', sql.VarChar, JourneyID)
        .execute('proc_getKFSAndSanctionLetterData');

      const rs = result.recordset || [];
      logger.info('Result Length: ' + rs.length);

      if (rs.length > 0) {
        const jsonString = JSON.stringify(rs, null, 2);
        resolve(jsonString.slice(1, -1));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('DB Error in getKFSAndSanctionLetterData:', err);
      reject(err);
    }
  });
}

function Sanctioned_Rejected_Suspended_CustomerJourney(
  PMSNumber,
  JourneyID,
  LoanTranche,
  JourneyStatus,
  JourneyRejectionCode,
  JourneyRejectionReason,
  SidbiResponseCode
) {
  logger.info('############################# Sanctioned_Rejected_Suspended_CustomerJourney ##########################');

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('LoanTranche', sql.Int, LoanTranche)
        .input('JourneyStatus', sql.VarChar, JourneyStatus)
        .input('JourneyRejectionCode', sql.VarChar, JourneyRejectionCode)
        .input('JourneyRejectionReason', sql.VarChar, JourneyRejectionReason)
        .input('SidbiResponseCode', sql.VarChar, SidbiResponseCode)
        .output('p_OutStatusCode', sql.NVarChar)
        .execute('proc_Journey_SanctionedRejectedSuspendedResumeSuspension');

      if (result.output.p_OutStatusCode === '200' && result.rowsAffected[0] > 0) {
        resolve({ ErrorCode: "00", ErrorMsg: "Journey Status updated successfully." });
      } else {
        resolve({ ErrorCode: "01", ErrorMsg: "Failed to update journey status." });
      }

    } catch (err) {
      logger.error('Exception in Sanctioned_Rejected_Suspended_CustomerJourney:', err);
      reject(err);
    }
  });
}

function LogMakerConsent(PMSNumber, JourneyID, UserID, ActionEvent, Action, message) {
  logger.info('############################# LogMakerConsent ##########################');

  const FinalAction = (Action === true || Action === 'Yes' || Action === 'Approve') ? 'Yes' : 'No';

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('UserID', sql.VarChar, UserID)
        .input('Action', sql.VarChar, FinalAction)
        .input('ActionEvent', sql.VarChar, ActionEvent)
        .input('message', sql.VarChar, message)
        .output('p_OutStatusCode', sql.NVarChar)
        .execute('proc_MakerCheckerConsentLogs');

      if (result.output.p_OutStatusCode === '200' && result.rowsAffected[0] === 1) {
        resolve({ ErrorCode: "00", ErrorMsg: "User Consent updated successfully." });
      } else {
        resolve({ ErrorCode: "01", ErrorMsg: "Consent update failed." });
      }

    } catch (err) {
      logger.error('LogMakerConsent Error:', err);
      reject(err);
    }
  });
}


function GetAmortizationSchedule(PMSNumber, JourneyID) {
  logger.info('Inside GetAmortizationSchedule');
  logger.info('PMSNumber ', PMSNumber);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT
          installmentNo,
          CustomerID,
          PMSNumber,
          outstandingPrincipal,
          principal,
          interest,
          installmentAmount
        FROM SVND_REPAYMENT_SCHEDULE
        WHERE PMSNumber = @PMSNumber
          AND JourneyID = @JourneyID
        ORDER BY
          CASE WHEN TRY_CAST(installmentNo AS INT) IS NULL THEN 1 ELSE 0 END,
          TRY_CAST(installmentNo AS INT)
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        resolve(JSON.stringify(result.recordset));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('GetAmortizationSchedule Error:', err);
      reject(err);
    }
  });
}



// function UpdateCustomerJourneyErrorUpdate(PMSNumber, JourneyID, ErrorReason) {
  // logger.info('################### Inside UpdateCustomerJourneyErrorUpdate Method ######################');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // logger.info('ErrorReason: ' + ErrorReason);
  // return new Promise((resolve, reject) => {
    // try {

      // const ErrorTime = DatePart();

      // const query = `UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isJourneyFailure=1,JourneyFailureReason=@ErrorReason,JourneyFailureTime=@ErrorTime WHERE PMSNumber=@PMSNumber AND JourneyID=@JourneyID AND isJourneyActive=1 AND isCustomerJourneyCompleted=0`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('ErrorReason', sql.VarChar, ErrorReason)
          // .input('ErrorTime', sql.VarChar, ErrorTime)
          // .query(query);
        // logger.info('Result Length: ' + JSON.stringify(result));
        // logger.info('Rows Affacted: ' + result.rowsAffected[0]);
        // if (result.recordsets && result.rowsAffected[0] > 0) {
          // formattedString = {
            // "ErrorCode": "00",
            // "ErrorMsg": "Customer Journey Error Updated Successfully."
          // }
          // resolve(formattedString);
        // }
        // else {
          // formattedString = {
            // "ErrorCode": "01",
            // "ErrorMsg": "Error to update Customer Journey Error Updated."
          // }
          // resolve(formattedString);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function UpdateCICPassFlag(PMSNumber, JourneyID, CICFlag, CICMsg) {
  // logger.info('################### Inside UpdateCICPassFlag Method ######################');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // logger.info('CICFlag: ' + CICFlag);
  // logger.info('CICMsg: ' + CICMsg);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isCICCheckPassed=@CICFlag,CICMessage=@CICMsg WHERE PMSNumber=@PMSNumber AND JourneyID=@JourneyID AND isJourneyActive=1 AND isCustomerJourneyCompleted=0`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('CICFlag', sql.Bit, CICFlag)
          // .input('CICMsg', sql.VarChar, CICMsg)

          // .query(query);
        // logger.info('Result Length: ' + JSON.stringify(result));
        // logger.info('Rows Affected: ' + result.rowsAffected);
        // if (result.rowsAffected && result.rowsAffected[0] > 0) {
          // formattedString = {
            // "ErrorCode": "00",
            // "ErrorMsg": "CIC Check flag " + CICFlag + " updated in journey"
          // }
          // resolve(formattedString);
        // }
        // else {
          // formattedString = {
            // "ErrorCode": "01",
            // "ErrorMsg": "Error to update Customer Journey Error Updated."
          // }
          // resolve(formattedString);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function CustomerJourneyInsert(AadhaarNo, PMSNo, PMSDataParse, Operation, MakerCBSAadharDataConsent, HigherTrancheConsent, EntryBy, UserSOL, ROI,BSP,RLLR_BSP, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, isExistingJourneyExpired, JourneyCreationReason) {
  // logger.info('###############################Inside CustomerJourneyInsert Method ###############################');
  // console.log('PMSDataParse' +PMSDataParse)
  // console.log('CurrentStatus ' + PMSDataParse.CurrentStatus);
  // console.log('LORSTATUS ' + PMSDataParse.LORSTATUS);
  // console.log('ROIAddsTwentyFiveBasis ' + ROIAddsTwentyFiveBasis);
  // console.log('MakerCBSAadharDataConsent ' + MakerCBSAadharDataConsent);
  // console.log('Existing Journey Expired ' + isExistingJourneyExpired);
  // let LoanTenure = 0;
  // if (PMSDataParse.TRENCH == 1)
    // LoanTenure = 12
  // else if (PMSDataParse.TRENCH == 2)
    // LoanTenure = 18
  // else if (PMSDataParse.TRENCH == 3)
    // LoanTenure = 36

  // return new Promise((resolve, reject) => {
    // try {

      // // const date1=DatePart();
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool); // Create a new request object for every row insert
        // request.input('AadhaarNo', sql.VarChar, AadhaarNo);
        // request.input('PMSNumber', sql.VarChar, PMSNo);
        // request.input('LoanAmount', sql.Int, PMSDataParse.TOTALLOAN);
        // request.input('LoanTranche', sql.Int, PMSDataParse.TRENCH);
        // request.input('LoanTenure', sql.Int, LoanTenure);
        // request.input('ROI', sql.Decimal(18, 2), parseFloat(ROI));
        // request.input('ROIAddsTwentyFiveBasis', sql.Decimal(18, 2), parseFloat(ROIAddsTwentyFiveBasis));
        // request.input('RLLR', sql.Decimal(18, 2), parseFloat(RLLR));
        // request.input('BSP', sql.Decimal(18, 2), parseFloat(BSP));
        // request.input('RLLR_BSP', sql.Decimal(18, 2), parseFloat(RLLR_BSP));
        // request.input('Spread', sql.Decimal(18, 2), parseFloat(Spread));
        // request.input('ServiceCharge', sql.Decimal(18, 2), parseFloat(ServiceCharge));
        // request.input('CurrentStatus', sql.VarChar, PMSDataParse.CurrentStatus);
        // request.input('LORStatus', sql.VarChar, PMSDataParse.LORSTATUS);
        // request.input('Milestone', sql.Int, 101);
        // request.input('MilestoneDesc', sql.VarChar, "Given PMS No is valid");
        // request.input('EntryBy', sql.VarChar, EntryBy)
        // request.input('UserSOL', sql.VarChar, UserSOL)
        // request.input('HigherTrancheConsent', sql.Bit, HigherTrancheConsent)
        // request.input('isExistingJourneyExpired', sql.Bit, isExistingJourneyExpired)
        // request.input('JourneyCreationReason', sql.VarChar, JourneyCreationReason)
        // request.input('MakerCBSAadharDataConsent', sql.Bit, MakerCBSAadharDataConsent)
        // request.input('Operation', sql.VarChar, Operation)
        // request.execute('proc_CustomerJourney_Insert', function (err, queryResult) {
          // //logger.info('QueryResult ' + JSON.stringify(queryResult));
          // logger.info('Error ' + err);
          // if (queryResult.rowsAffected[0] > 0) {
            // formattedString = {
              // "ErrorCode": "00",
              // "ErrorMsg": "Customer Journey Successfully Inserted"
            // }
            // resolve(formattedString);
          // }
          // else {
            // logger.info('else:' + err);
            // formattedString = {
              // "ErrorCode": "01",
              // "ErrorMsg": "Error to insert Customer Journey."
            // }
            // resolve(formattedString);
          // }
        // });
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function CustomerJourneyUpdate(PMSNumber, JourneyID, JourneyMilestone, JourneyMilestoneDesc, JourneyCurrentStatus, ChargeCollectionFlag, ChargeTranNo, LoanAccountFlag, LoanAccountNo, QRCodeFlag, Operation) {
  // logger.info('###############################Update Journey Current Status in Local Database ###############################');
  // logger.info('Inside CustomerJourneyUpdate Operation: ' + Operation);
  // logger.info('Inside CustomerJourneyUpdate JourneyMilestone: ' + JourneyMilestone);
  // logger.info('Inside CustomerJourneyUpdate JourneyMilestoneDesc: ' + JourneyMilestoneDesc);
  // logger.info('Inside CustomerJourneyUpdate PMSNumber: ' + PMSNumber);


  // return new Promise((resolve, reject) => {
    // try {

      // // const date1=DatePart();
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool); // Create a new request object for every row insert             
        // request.input('PMSNumber', sql.VarChar, PMSNumber);
        // request.input('JourneyID', sql.VarChar, JourneyID);
        // request.input('JourneyMilestone', sql.VarChar, JourneyMilestone);
        // request.input('JourneyMilestoneDesc', sql.VarChar, JourneyMilestoneDesc);
        // request.input('JourneyCurrentStatus', sql.VarChar, JourneyCurrentStatus);

        // request.input('ChargeCollectionFlag', sql.Bit, ChargeCollectionFlag);
        // request.input('ChargeTranNo', sql.VarChar, ChargeTranNo);
        // request.input('LoanAccountFlag', sql.Bit, LoanAccountFlag);
        // request.input('LoanAccountNo', sql.VarChar, LoanAccountNo);
        // request.input('QRCodeFlag', sql.Bit, QRCodeFlag);
        // request.input('Operation', sql.VarChar, Operation);
        // request.execute('proc_CustomerJourney_Update', function (err, queryResult) {
          // //logger.info('QueryResult ' + JSON.stringify(queryResult));
          // logger.info('Error ' + err);
          // if (queryResult.rowsAffected[0] == "1") {
            // formattedString = {
              // "ErrorCode": "00",
              // "ErrorMsg": "Customer Journey saved Successfully"
            // }
            // resolve(formattedString);
          // }
          // else {
            // logger.info('else:' + err);
            // formattedString = {
              // "ErrorCode": "01",
              // "ErrorMsg": "Error to save Customer Journey."
            // }
            // resolve(formattedString);
          // }
        // });
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function UpdateCustomerJourneyErrorUpdate(PMSNumber, JourneyID, ErrorReason) {
  logger.info('################### Inside UpdateCustomerJourneyErrorUpdate Method ######################');

  return new Promise(async (resolve, reject) => {
    try {
      const ErrorTime = DatePart();

      const query = `
        UPDATE SVND_LOAN_JOURNEY_MASTER
        SET
          isJourneyFailure = 1,
          JourneyFailureReason = @ErrorReason,
          JourneyFailureTime = @ErrorTime
        WHERE
          PMSNumber = @PMSNumber
          AND JourneyID = @JourneyID
          AND isJourneyActive = 1
          AND isCustomerJourneyCompleted = 0
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('ErrorReason', sql.VarChar, ErrorReason)
        .input('ErrorTime', sql.VarChar, ErrorTime)
        .query(query);

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({ ErrorCode: "00", ErrorMsg: "Customer Journey Error Updated Successfully." });
      } else {
        resolve({ ErrorCode: "01", ErrorMsg: "Error to update Customer Journey Error." });
      }

    } catch (err) {
      logger.error(err);
      reject(err);
    }
  });
}

function UpdateCICPassFlag(PMSNumber, JourneyID, CICFlag, CICMsg) {
  logger.info('################### Inside UpdateCICPassFlag Method ######################');

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        UPDATE SVND_LOAN_JOURNEY_MASTER
        SET
          isCICCheckPassed = @CICFlag,
          CICMessage = @CICMsg
        WHERE
          PMSNumber = @PMSNumber
          AND JourneyID = @JourneyID
          AND isJourneyActive = 1
          AND isCustomerJourneyCompleted = 0
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('CICFlag', sql.Bit, CICFlag)
        .input('CICMsg', sql.VarChar, CICMsg)
        .query(query);

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: `CIC Check flag ${CICFlag} updated in journey`
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: "Error to update CIC flag."
        });
      }

    } catch (err) {
      logger.error(err);
      reject(err);
    }
  });
}

function CustomerJourneyInsert(
  AadhaarNo,
  PMSNo,
  PMSDataParse,
  Operation,
  MakerCBSAadharDataConsent,
  HigherTrancheConsent,
  EntryBy,
  UserSOL,
  ROI,
  BSP,
  RLLR_BSP,
  ROIAddsTwentyFiveBasis,
  RLLR,
  Spread,
  ServiceCharge,
  isExistingJourneyExpired,
  JourneyCreationReason
) {
  logger.info('############################### Inside CustomerJourneyInsert ###############################');

  let LoanTenure = 0;
  if (PMSDataParse.TRENCH == 1) LoanTenure = 12;
  else if (PMSDataParse.TRENCH == 2) LoanTenure = 18;
  else if (PMSDataParse.TRENCH == 3) LoanTenure = 36;

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('AadhaarNo', sql.VarChar, AadhaarNo)
        .input('PMSNumber', sql.VarChar, PMSNo)
        .input('LoanAmount', sql.Int, PMSDataParse.TOTALLOAN)
        .input('LoanTranche', sql.Int, PMSDataParse.TRENCH)
        .input('LoanTenure', sql.Int, LoanTenure)
        .input('ROI', sql.Decimal(18, 2), parseFloat(ROI))
        .input('ROIAddsTwentyFiveBasis', sql.Decimal(18, 2), parseFloat(ROIAddsTwentyFiveBasis))
        .input('RLLR', sql.Decimal(18, 2), parseFloat(RLLR))
        .input('BSP', sql.Decimal(18, 2), parseFloat(BSP))
        .input('RLLR_BSP', sql.Decimal(18, 2), parseFloat(RLLR_BSP))
        .input('Spread', sql.Decimal(18, 2), parseFloat(Spread))
        .input('ServiceCharge', sql.Decimal(18, 2), parseFloat(ServiceCharge))
        .input('CurrentStatus', sql.VarChar, PMSDataParse.CurrentStatus)
        .input('LORStatus', sql.VarChar, PMSDataParse.LORSTATUS)
        .input('Milestone', sql.Int, 101)
        .input('MilestoneDesc', sql.VarChar, "Given PMS No is valid")
        .input('EntryBy', sql.VarChar, EntryBy)
        .input('UserSOL', sql.VarChar, UserSOL)
        .input('HigherTrancheConsent', sql.Bit, HigherTrancheConsent)
        .input('isExistingJourneyExpired', sql.Bit, isExistingJourneyExpired)
        .input('JourneyCreationReason', sql.VarChar, JourneyCreationReason)
        .input('MakerCBSAadharDataConsent', sql.Bit, MakerCBSAadharDataConsent)
        .input('Operation', sql.VarChar, Operation)
        .execute('proc_CustomerJourney_Insert');

      if (result.rowsAffected[0] > 0) {
        resolve({ ErrorCode: "00", ErrorMsg: "Customer Journey Successfully Inserted" });
      } else {
        resolve({ ErrorCode: "01", ErrorMsg: "Error to insert Customer Journey." });
      }

    } catch (err) {
      logger.error(err);
      reject(err);
    }
  });
}

function CustomerJourneyUpdate(
  PMSNumber,
  JourneyID,
  JourneyMilestone,
  JourneyMilestoneDesc,
  JourneyCurrentStatus,
  ChargeCollectionFlag,
  ChargeTranNo,
  LoanAccountFlag,
  LoanAccountNo,
  QRCodeFlag,
  Operation
) {
  logger.info('############################### CustomerJourneyUpdate ###############################');

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('JourneyMilestone', sql.VarChar, JourneyMilestone)
        .input('JourneyMilestoneDesc', sql.VarChar, JourneyMilestoneDesc)
        .input('JourneyCurrentStatus', sql.VarChar, JourneyCurrentStatus)
        .input('ChargeCollectionFlag', sql.Bit, ChargeCollectionFlag)
        .input('ChargeTranNo', sql.VarChar, ChargeTranNo)
        .input('LoanAccountFlag', sql.Bit, LoanAccountFlag)
        .input('LoanAccountNo', sql.VarChar, LoanAccountNo)
        .input('QRCodeFlag', sql.Bit, QRCodeFlag)
        .input('Operation', sql.VarChar, Operation)
        .execute('proc_CustomerJourney_Update');

      if (result.rowsAffected[0] === 1) {
        resolve({ ErrorCode: "00", ErrorMsg: "Customer Journey saved Successfully" });
      } else {
        resolve({ ErrorCode: "01", ErrorMsg: "Error to save Customer Journey." });
      }

    } catch (err) {
      logger.error(err);
      reject(err);
    }
  });
}





// const { v4: uuidv4 } = require('uuid');
// const pdfLib = require('pdf-lib');
// const sql = require('mssql');

async function DownloadDocumentUpdate(PMSNumber) {
  logger.info('############################### processDocumentDownload START ###############################');

  try {
    const pool = await getPool();

    // 1️⃣ Fetch NESL signed document byte
    const neslDocResult = await pool.request()
      .input('PMSNumber', sql.VarChar(50), PMSNumber)
      .query(`SELECT TOP 1 Signed_NeSL_Bank_Doc_Byte
              FROM SVND_NESL_DOCUMENT 
              WHERE PMSNumber=@PMSNumber 
              ORDER BY RowID DESC`);

    if (neslDocResult.recordset.length === 0) {
      return { ErrorCode: '01', ErrorMsg: 'NESL document not found' };
    }

    const neslDoc = neslDocResult.recordset[0];
    const docByte = neslDoc.Signed_NeSL_Bank_Doc_Byte;
 

    // 2️⃣ Fetch account number and DOB from CityKYCDetails
    const cityKYCResult = await pool.request()
         .input('PMSNumber', sql.VarChar(50), PMSNumber)
      .query(`SELECT TOP 1 AccountNo  FROM CityKYCDetails  WHERE PMSNumber=@PMSNumber`);

    if (cityKYCResult.recordset.length === 0) {
      return { ErrorCode: '01', ErrorMsg: 'Customer KYC details not found' };
    }

    const cityKYC = cityKYCResult.recordset[0];
    const accountNo = cityKYC.AccountNo;
  
    const customerdetailsResult = await pool.request()
         .input('PMSNumber', sql.VarChar(50), PMSNumber)
      .query(`SELECT TOP 1 Date_of_Birth  FROM [PMSvanidhiDB].[dbo].[SVND_CBS_CUSTOMER_DETAILS]  WHERE PMSNumber=@PMSNumber`);

    if (cityKYCResult.recordset.length === 0) {
      return { ErrorCode: '01', ErrorMsg: 'Customer KYC details not found' };
    }

   const customerdetails = customerdetailsResult.recordset[0];
    const Date_of_Birth  = customerdetails.Date_of_Birth ;


    // 3️⃣ Generate password
    const dobFormatted = Date_of_Birth ? Date_of_Birth.replace(/-/g, '').slice(0,6) : '000000'; // ddmmyy
    const last6Acc = accountNo.slice(-6);
    const password = `${last6Acc}$${dobFormatted}`;

    // 4️⃣ Create password-protected PDF
    const pdfDoc = await pdfLib.PDFDocument.load(docByte);
    pdfDoc.encrypt({
      ownerPassword: password,
      userPassword: password,
      permissions: { printing: 'lowResolution', modifying: false, copying: false }
    });
    const protectedPdfBytes = await pdfDoc.save();

    // 5️⃣ Insert into CustomerDocumentLinks table
    const docGuid = uuidv4();
    await pool.request()
      .input('AccountNo', sql.VarChar(50), accountNo)
      .input('DOB', sql.VarChar(50), Date_of_Birth)
      .input('Password', sql.VarChar(100), password)
      .input('DocByte', sql.VarBinary(sql.MAX), protectedPdfBytes)
      .input('Guid', sql.VarChar(50), docGuid)
      .input('DownloadAttempt', sql.Int, 0)
      .input('CreatedDate', sql.DateTime, new Date())
      .input('PMSNumber', sql.VarChar(50), PMSNumber)
      .query(`INSERT INTO CustomerDocumentLinks (CustomerID, AccountNo, DOB, Password, DocByte, Guid, DownloadAttempt, CreatedDate,PMSNumber)
              VALUES (@CustomerID, @AccountNo, @DOB, @Password, @DocByte, @Guid, @DownloadAttempt, @CreatedDate)`);

    logger.info('Document processing completed successfully. GUID: ' + docGuid);

    return {
      ErrorCode: '00',
      ErrorMsg: 'Document password-protected and journey updated successfully',
      Guid: docGuid,
      Password: password,
      JourneyUpdateResponse: journeyResp
    };

  } catch (err) {
    logger.error('Error in processDocumentDownload:', err);
    return { ErrorCode: '01', ErrorMsg: 'Internal server error' };
  }
}


// function getBranchInformation(solid) {
  // logger.info('Inside getBranchInformation: ' + solid);
  // return new Promise((resolve, reject) => {
    // try {
      // if (solid != null) {
        // const query = `SELECT [ZONE_CODE],[ZONE],[CIRCLE_CODE],[CIRCLE],[BRANCH_CODE],[BRANCH],[BRANCH_OPEN_DATE],[BRANCH_GROUP],[AREA],[BUSINESS_CATEGORY],[IFSC]
                            // ,[MICR],[E_MAIL],[BRANCH_PHONE],[ADDRESS],[PINCODE],[CITY],[DISTRICT],[STATE],[TERRITORY],[TAN],[INCUMBENT_EMP_ID],[INCUMBENT_PF_NO],[INCUMBENT_NAME]
                            // ,[INCUMBENT_SCALE],[INCUMBENT_DESIGNATION],[INCUMBENT_CONTACT],[RBI_PART_1],[RBI_PART_2],[ACTIVE_FLG]
                            // FROM [PMSvanidhiDB].[dbo].[SVND_BRANCH_MASTER] WHERE BRANCH_CODE=@solid`;
        // var conn = new sql.ConnectionPool(config);
        // conn.connect().then(async function (pool) {
          // // logger.info('Query: ' + query);                           
          // const result = await pool.request()
            // .input('solid', sql.VarChar, solid)
            // .query(query);
          // if (result.recordset && result.recordset.length > 0) {
            // const jsonString = JSON.stringify(result.recordset, null, 2);
            // formattedString = jsonString.slice(1, -1);
            // // logger.info('CityKYC Data got from database:', formattedString);                
            // resolve(formattedString);
          // }
          // else {
            // resolve(null);
          // }
        // });
      // }
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function getBranchInformation(solid) {
  logger.info('Inside getBranchInformation: ' + solid);

  return new Promise(async (resolve, reject) => {
    try {
      if (!solid) {
        return resolve(null);
      }

      const query = `
        SELECT
          ZONE_CODE, ZONE, CIRCLE_CODE, CIRCLE, BRANCH_CODE, BRANCH,
          BRANCH_OPEN_DATE, BRANCH_GROUP, AREA, BUSINESS_CATEGORY,
          IFSC, MICR, E_MAIL, BRANCH_PHONE, ADDRESS, PINCODE, CITY,
          DISTRICT, STATE, TERRITORY, TAN,
          INCUMBENT_EMP_ID, INCUMBENT_PF_NO, INCUMBENT_NAME,
          INCUMBENT_SCALE, INCUMBENT_DESIGNATION, INCUMBENT_CONTACT,
          RBI_PART_1, RBI_PART_2, ACTIVE_FLG
        FROM SVND_BRANCH_MASTER
        WHERE BRANCH_CODE = @solid
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('solid', sql.VarChar, solid)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        const formattedString = jsonString.slice(1, -1);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getBranchInformation Error:', err);
      reject(err);
    }
  });
}

async function getLoanAccountOpeningContext(PMSNumber, AadhaarNumber) {
  const pool = await getPool();
  const request = pool.request();

  const result = await request
    .input('PMSNumber', sql.NVarChar, PMSNumber)
    .input('AadhaarNumber', sql.NVarChar, AadhaarNumber)
    .execute('dbo.proc_GetLoanAccountOpeningContext');

  if (!result.recordsets || result.recordsets.length < 3) {
    throw new Error('Incomplete Loan Account Opening context');
  }

  return {
    journey: result.recordsets[0][0],
    cityKYC: result.recordsets[1][0],
    branch: result.recordsets[2][0]
  };
}


// function getCustomerJourneyData(PMSNumber) {
  // logger.info('***************Inside getCustomerJourneyData Method*****************');
  // logger.info('Inside PMSNumber: ' + PMSNumber);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT TOP 1 isJourneyActive,[JourneyID],[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],A.[MobileNo],[JourneyMilestone],[JourneyMilestoneDesc],[ROI],[LoanTranche],[LoanAmount],CICMessage
                  // ,[LoanTenure],[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                  // ,[isJourneySanctioned],CONVERT(VARCHAR(50),JourneySanctionedDate,105) as JourneySanctionedDate,[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime]
                  // ,[isJourneyRejected],[JourneyRejectedReason],CONVERT(VARCHAR(50),[JourneyRejectedDate],105) JourneyRejectedDate,[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isLoanAccountOpened]
                  // ,[LoanAccountNumber],[LoanAccountOpenDate],[isQRCodeGenerated],[QRCodeGeneratedDate]
                  // ,isCustomerJourneyCompleted,isSchedularJourneyCompleted,EntryBy,EntryDate,B.JourneyRejectionCode,B.JourneyRejectionReason
                  // ,A.isJourneyExpired,A.JourneyExpireReason,JourneyInitiationChannel,C.CommAddress_City AS CommAddress, A.isAadharValidated as isAadharValidated
                  // FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]  A
                  // LEFT OUTER JOIN SVND_JOURNEY_REJECTION_CODE B ON B.JourneyRejectionCode=A.JourneyRejectionCode
                  // LEFT OUTER JOIN SVND_CBS_CUSTOMER_DETAILS C ON A.CustomerID=C.CustomerID
                  // WHERE PMSNumber=@PMSNumber AND isJourneyActive=1 ORDER BY A.EntryDate DESC`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //  logger.info('Successfully got Customer Data from Database:', formattedString);                
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function getCustomerJourneyData(PMSNumber) {
  // logger.info('***************Inside getCustomerJourneyData Method*****************');
  // logger.info('Inside PMSNumber: ' + PMSNumber);

  // return new Promise((resolve, reject) => {
    // try {
      // const procName = 'dbo.proc_GetJourneyAndUpdateAadhaarStatus';

      // const conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {

        // const result = await pool.request()
          // .input('PMSNumber', sql.NVarChar, PMSNumber)
          // .execute(procName);

        // // Stored procedure returns a single result set
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // const formattedString = jsonString.slice(1, -1); // keep your existing format
          // resolve(formattedString);
        // } else {
          // resolve(null);
        // }

        // pool.close();
      // }).catch(err => {
        // logger.error('DB Connection Error in getCustomerJourneyData', err);
        // reject(err);
      // });

    // } catch (err1) {
      // logger.error('Exception in getCustomerJourneyData', err1);
      // reject(err1);
    // }
  // });
// }


// function getJourneyMileStone(PMSNumber) {
  // logger.info('Inside getJourneyMileStone: ' + PMSNumber);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT [JourneyID],[PMSNumber],[JourneyMilestone],[JourneyMilestoneDesc] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE PMSNumber=@PMSNumber AND isJourneyActive=1 AND isCustomerJourneyCompleted=0`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // logger.info('Query: ' + query);
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .query(query);
        // // logger.info('Result Length: '+result.recordset.length);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // // logger.info('formattedString '+formattedString);
          // resolve(formattedString);
        // }
        // else {
          // formattedString = null;
          // resolve(formattedString);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function getMilestoneFromMilestoneMaster(Milestone) {
  // logger.info('*********************Inside getMilestoneFromMilestoneMaster**********************');
  // logger.info('Milestone: ' + Milestone);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT * FROM [PMSvanidhiDB].[dbo].[SVND_MILESTONE_MASTER] WHERE MilestoneName=@MilestoneName`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // logger.info('Query: ' + query);
        // const result = await pool.request()
          // .input('MilestoneName', sql.VarChar, Milestone)
          // .query(query);
        // logger.info('Result Length: ' + result.recordset.length);
        // if (result.recordset && result.recordset.length > 0) {
          // //logger.info('here '+JSON.stringify(JSON.parse(JSON.stringify(result.recordset))));
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // resolve(formattedString)
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function getCityKYCInfoData(AadhaarNumber) {
  // logger.info('inside getCityKYCStatusData ' + AadhaarNumber);
  
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT [CustomerID],[CommunicationCity],[CommunicationZIP],[KYCStatus],[AccountNo],[AcctOpenDate],[solid] FROM [PMSvanidhiDB].[dbo].[SVND_CBS_CITY_KYC_STATUS] WHERE AadhaarNumber=@AadhaarNumber`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // //logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('AadhaarNumber', sql.VarChar, AadhaarNumber)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // // logger.info('CityKYC Data got from database:', formattedString);                
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });

    // } catch (err1) {
      // reject(err1);
    // }
  // });
// }

function getCustomerJourneyData(PMSNumber) {
  logger.info('***************Inside getCustomerJourneyData Method*****************');
  logger.info('Inside PMSNumber: ' + PMSNumber);

  return new Promise(async (resolve, reject) => {
    try {
      const procName = 'dbo.proc_GetJourneyAndUpdateAadhaarStatus';

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNumber)
        .execute(procName);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        const formattedString = jsonString.slice(1, -1);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('Exception in getCustomerJourneyData', err);
      reject(err);
    }
  });
}

function getJourneyMileStone(PMSNumber) {
  logger.info('Inside getJourneyMileStone: ' + PMSNumber);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT
          JourneyID,
          PMSNumber,
          JourneyMilestone,
          JourneyMilestoneDesc
        FROM SVND_LOAN_JOURNEY_MASTER
        WHERE PMSNumber = @PMSNumber
          AND isJourneyActive = 1
          AND isCustomerJourneyCompleted = 0
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        resolve(jsonString.slice(1, -1));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getJourneyMileStone Error', err);
      reject(err);
    }
  });
}


function getMilestoneFromMilestoneMaster(Milestone) {
  logger.info('*********************Inside getMilestoneFromMilestoneMaster**********************');
  logger.info('Milestone: ' + Milestone);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT *
        FROM SVND_MILESTONE_MASTER
        WHERE MilestoneName = @MilestoneName
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('MilestoneName', sql.VarChar, Milestone)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        resolve(jsonString.slice(1, -1));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getMilestoneFromMilestoneMaster Error', err);
      reject(err);
    }
  });
}


function getCityKYCInfoData(AadhaarNumber) {
  logger.info('inside getCityKYCInfoData ' + AadhaarNumber);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT
          CustomerID,
          CommunicationCity,
          CommunicationZIP,
          KYCStatus,
          AccountNo,
          AcctOpenDate,
          solid
        FROM SVND_CBS_CITY_KYC_STATUS
        WHERE AadhaarNumber = @AadhaarNumber
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('AadhaarNumber', sql.VarChar, AadhaarNumber)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        resolve(jsonString.slice(1, -1));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getCityKYCInfoData Error', err);
      reject(err);
    }
  });
}



// function SuspendedCustomerJourney(PMSNumber,JourneyID,SuspendedFlag,SuspendedReason) {
//   logger.info('###############################Inside Update Customer Journey Suspended Updated in Local Database ###############################');
//   logger.info('SuspendedReason: ' +SuspendedReason);
//   try {

//           const SuspendedTime=DatePart();
//           // logger.info('SuspendedTime '+SuspendedTime);
//           // logger.info('DateTime ', new Date());
//           const query = `UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isJourneySuspended=@SuspendedFlag,JourneySuspendedReason=@SuspendedReason,JourneySuspendedDate=@SuspendedTime WHERE PMSNumber=@PMSNumber AND JourneyID=@JourneyID`;
//           var conn = new sql.ConnectionPool(config);
//            conn.connect().then(async function (pool) 
//           {      
//             // logger.info('Query: ' + query);                           
//             const result = await pool.request()
//             .input('PMSNumber', sql.VarChar, PMSNumber)
//             .input('JourneyID', sql.VarChar, JourneyID)
//             .input('SuspendedFlag', sql.Bit, SuspendedFlag)
//             .input('SuspendedReason', sql.VarChar, SuspendedReason)
//             .input('SuspendedTime', sql.DateTime, SuspendedTime)              
//             .query(query);
//              logger.info('Result Length: '+JSON.stringify(result));
//              logger.info('Rows Affacted: '+result.rowsAffected[0]);
//             if(result.recordsets && result.rowsAffected[0]>0)
//             {
//             return "Success";
//             }
//             else{
//               return "Failure";
//             }
//           });                     
//   } catch (err1) {
//     logger.info(err1);
//   }    
// } 

// function getNeSLDocumentData(PMSNumber, JourneyID) {
  // logger.info('***************Inside getNeSLDocumentData method for below data*****************');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT A.[JourneyID],A.[PMSNumber],A.[LoanTranche],[NeSL_Tran_ID],[DocumentType],[NeSL_Sign_Coordinates],[Unsign_Doc_Byte],[UnSign_EntryTime],[NeSL_StatusCode]
                    // ,[NeSL_StatusMsg],[NeSL_eSignStatus],[NeSL_eStampStatus],[NeSL_eStampID],[NeSL_SignatoryName],[NeSL_MatchPercentage],[NeSL_Document_ID],[Signed_NeSL_Doc_Byte]
                    // ,[isPendingForNeSLeSign],[NeSL_Resp_Time],[isPendingForBankOfficialSign],[Bank_Sign_Resp_Time]
                    // FROM SVND_LOAN_JOURNEY_MASTER A
                    // INNER JOIN SVND_NESL_DOCUMENT B ON A.PMSNumber=B.PMSNumber AND A.JourneyID=B.JourneyID
                    // WHERE A.isJourneyActive=1 AND A.JourneyID=@JourneyID AND A.PMSNumber=@PMSNumber`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //  logger.info('Successfully got Customer Data from Database:', formattedString);                
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function StateCode(CommStateName) {
  // logger.info('**************** Inside StateCodeName Method for State ' + CommStateName);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT [State_Name],[State_Code_Word],[State_Code_Number] FROM [PMSvanidhiDB].[dbo].[SVND_STATE_MASTER] WHERE State_Name=@CommStateName`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // //     logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('CommStateName', sql.VarChar, CommStateName)
          // .query(query);

        // const jsonString = JSON.stringify(result.recordset, null, 2);
        // formattedString = jsonString.slice(1, -1);
        // logger.info('results:', formattedString);
        // resolve(formattedString);
      // });
    // } catch (err1) {
      // reject(err1);
    // }
  // });
// }


// function StateCodeWord(CommStateName) {
  // logger.info('**************** Inside StateCodeWord Method for State ' + CommStateName);

  // try {
    // const query = `SELECT [State_Code_Word] FROM [PMSvanidhiDB].[dbo].[SVND_STATE_MASTER] WHERE State_Name=@CommStateName`;
    // var conn = new sql.ConnectionPool(config);
    // conn.connect().then(async function (pool) {
      // //     logger.info('Query: ' + query);                           
      // const result = await pool.request()
        // .input('CommStateName', sql.VarChar, CommStateName)
        // .query(query);

      // const jsonString = JSON.stringify(result.recordset, null, 2);
      // formattedString = jsonString.slice(1, -1);
      // logger.info('StateCodeWord', formattedString);
      // return formattedString;
    // });
  // } catch (err1) {
    // reject(err1);
  // }

// }

// function GetKeyConfigurationValue(KeyName) {
  // logger.info('**************** Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  // const query = `SELECT [KeyValue] FROM [PMSvanidhiDB].[dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;
  // try {

    // var conn = new sql.ConnectionPool(config);
    // conn.connect().then(async function (pool) {
      // logger.info('Query: ' + query);
      // const result = await pool.request()
        // .input('KeyName', sql.VarChar, KeyName)
        // .query(query);

      // logger.info('Result Length: ' + JSON.stringify(result));
      // logger.info('Rows Affacted: ' + result.rowsAffected[0]);

      // if (result.recordsets && result.rowsAffected[0] > 0) {
        // conn.close();
        // const ourValue = result.recordset[0].KeyValue;  // Resolve the Promise with OutValue
        // logger.info('ourValue ', ourValue);
        // return ourValue;
      // }
      // else {
        // logger.info('else part');
        // conn.close();
        // return null;
      // }
    // });
  // } catch (err1) {
    // logger.info(err1);
  // }
// }

function getNeSLDocumentData(PMSNumber, JourneyID) {
  logger.info('***************Inside getNeSLDocumentData method*****************');
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('JourneyID: ' + JourneyID);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT
          A.JourneyID,
          A.PMSNumber,
          A.LoanTranche,
          NeSL_Tran_ID,
          DocumentType,
          NeSL_Sign_Coordinates,
          Unsign_Doc_Byte,
          UnSign_EntryTime,
          NeSL_StatusCode,
          NeSL_StatusMsg,
          NeSL_eSignStatus,
          NeSL_eStampStatus,
          NeSL_eStampID,
          NeSL_SignatoryName,
          NeSL_MatchPercentage,
          NeSL_Document_ID,
          Signed_NeSL_Doc_Byte,
          isPendingForNeSLeSign,
          NeSL_Resp_Time,
          isPendingForBankOfficialSign,
          Bank_Sign_Resp_Time
        FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_NESL_DOCUMENT B
          ON A.PMSNumber = B.PMSNumber
         AND A.JourneyID = B.JourneyID
        WHERE A.isJourneyActive = 1
          AND A.PMSNumber = @PMSNumber
          AND A.JourneyID = @JourneyID
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        resolve(jsonString.slice(1, -1));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getNeSLDocumentData Error', err);
      reject(err);
    }
  });
}

function StateCode(CommStateName) {
  logger.info('**************** Inside StateCode Method for State ' + CommStateName);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT
          State_Name,
          State_Code_Word,
          State_Code_Number
        FROM SVND_STATE_MASTER
        WHERE State_Name = @CommStateName
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('CommStateName', sql.VarChar, CommStateName)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        resolve(jsonString.slice(1, -1));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('StateCode Error', err);
      reject(err);
    }
  });
}

function StateCodeWord(CommStateName) {
  logger.info('**************** Inside StateCodeWord Method for State ' + CommStateName);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT State_Code_Word
        FROM SVND_STATE_MASTER
        WHERE State_Name = @CommStateName
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('CommStateName', sql.VarChar, CommStateName)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const value = result.recordset[0].State_Code_Word;
        logger.info('StateCodeWord:', value);
        resolve(value);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('StateCodeWord Error', err);
      reject(err);
    }
  });
}

function GetKeyConfigurationValue(KeyName) {
  logger.info('**************** Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT KeyValue
        FROM SVND_CONFIGURATION_DATA
        WHERE KeyName = @KeyName
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('KeyName', sql.VarChar, KeyName)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const value = result.recordset[0].KeyValue;
        logger.info('Config Value:', value);
        resolve(value);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('GetKeyConfigurationValue Error', err);
      reject(err);
    }
  });
}


// function GetKeyConfigurationValue(KeyName) {
//   logger.info('**************** Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

//     try {
//             const query = `SELECT [KeyValue] FROM [PMSvanidhiDB].[dbo].[SVND_CONFIGURATION] WHERE KeyName=@KeyName`;
//             var conn = new sql.ConnectionPool(config);
//              conn.connect().then(async function (pool) 
//             {      
//           //     logger.info('Query: ' + query);                           
//               const result = await pool.request()
//               .input('KeyName', sql.VarChar, KeyName)
//               .query(query);

//                const jsonString = JSON.stringify(result.recordset, null, 2);
//                formattedString = jsonString.slice(1, -1);
//                logger.info('Result: ',formattedString);               
//                logger.info('Parse Result: ',JSON.parse(formattedString));
//                const OutValue=JSON.parse(formattedString).KeyValue;
//                logger.info('OutValue', OutValue.toString());
//                return (OutValue);
//             });                
//     } catch (err1) {
//       reject(err1);
//     }

// }



// function SaveRepaymentSchedule(PMSNumber, JourneyID, CustomerID, AmortSchedule) {
  // logger.info('###############################Inside SaveRepaymentSchedule Method ###############################');
  // logger.info('Type of AmortSchedule:' + typeof AmortSchedule);
  // logger.info('AmortSchedule:' + AmortSchedule);
  // return new Promise((resolve, reject) => {
    // try {

      // if (typeof AmortSchedule === 'string') {
        // try {
          // AmortSchedule = JSON.parse(AmortSchedule);
        // } catch (error) {
          // console.error('Error parsing AmortSchedule:', error);
          // return; // Exit if parsing fails
        // }
      // }

      // if (!Array.isArray(AmortSchedule)) {
        // console.error('AmortSchedule is not an array:', AmortSchedule);
        // return; // Exit if not an array
      // } else {
        // var conn = new sql.ConnectionPool(config);
        // conn.connect().then(async function (pool) {

          // let index = 0;
          // AmortSchedule.forEach((installment) => {
            // index = index + 1;

            // var request = new sql.Request(pool); // Create a new request object for every row insert

            // // const query = `INSERT INTO SVND_REPAYMENT_SCHEDULE ([CustomerID],[PMSNumber],[installmentNo],[outstandingPrincipal],[principal],[interest],[installmentAmount]) 
            // // VALUES (@CustomerID_${index},@PMSNumber_${index},@installmentno_${index}, @outstandingPrincipal_${index}, @principal_${index}, @interest_${index}, @installmentAmount_${index})`;

            // request.input('CustomerID', sql.VarChar, CustomerID);
            // request.input('PMSNumber', sql.VarChar, PMSNumber);
            // request.input('JourneyID', sql.VarChar, JourneyID);
            // request.input('installmentNo', sql.VarChar, installment.InstallmentNo);
            // request.input('outstandingPrincipal', sql.Decimal(18, 2), installment.OutstandingAmount);
            // request.input('principal', sql.Decimal(18, 2), installment.PrincipalPart);
            // request.input('interest', sql.Decimal(18, 2), installment.InterestPart);
            // request.input('installmentAmount', sql.Decimal(18, 2), installment.InstallmentAmount);

            // // request.input(`CustomerID_${index}`, sql.VarChar, PMSNumber);
            // // request.input(`PMSNumber_${index}`, sql.VarChar, CustID);
            // // request.input(`installmentNo_${index}`, sql.Int, installment.installmentNo);
            // // request.input(`outstandingPrincipal_${index}`, sql.Decimal(18, 2), installment.outstandingPrincipal);
            // // request.input(`principal_${index}`, sql.Decimal(18, 2), installment.principal);
            // // request.input(`interest_${index}`, sql.Decimal(18, 2), installment.interest);
            // // request.input(`installmentAmount_${index}`, sql.Decimal(18, 2), installment.installmentAmount);

            // request.execute('proc_RepaymentSchedule_InsertUpdate', function (err, queryResult) {
              // if (err) {
                // console.error('Error:');
                // console.error('Error saving installment to database:', err);

              // }
              // else {
                // logger.info('Installment saved successfully!');
                // resolve(true);
              // }
            // });
          // });
        // });
      // }

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }
// function UpdateRepaymentData(PMSNumber, JourneyID, TotalPayableAmount, TotalInterestAmount, EMI1, EMI2) {
  // logger.info('***************Inside UpdateRepaymentData Method*****************');
  // logger.info('Inside PMSNumber: ' + PMSNumber);
  // logger.info('Inside JourneyID: ' + JourneyID);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `UPDATE SVND_LOAN_JOURNEY_MASTER SET TotalInterestAmount=@TotalInterestAmount,TotalPayableAmount=@TotalPayableAmount,EMI1=@EMI1,EMI2=@EMI2 WHERE PMSNumber=@PMSNUmber AND JourneyID=@JourneyID AND isJourneyActive=1 AND isCustomerJourneyCompleted=0`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('EMI1', sql.VarChar, EMI1)
          // .input('EMI2', sql.VarChar, EMI2)
          // .input('TotalPayableAmount', sql.VarChar, TotalPayableAmount)
          // .input('TotalInterestAmount', sql.VarChar, TotalInterestAmount)
          // .query(query);
        // logger.info('Result Length: ' + JSON.stringify(result));
        // logger.info('Rows Affacted: ' + result.rowsAffected[0]);
        // if (result.recordsets && result.rowsAffected[0] > 0) {
          // formattedString = {
            // "ErrorCode": "00",
            // "ErrorMsg": "Save Repayment Schedule Updated",
          // }
          // resolve(formattedString);
        // }
        // else {
          // logger.info('else:');
          // formattedString = {
            // "ErrorCode": "01",
            // "ErrorMsg": "Error Save Repayment Schedule Updated"
          // }
          // resolve(formattedString);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }


function SaveRepaymentSchedule(PMSNumber, JourneyID, CustomerID, AmortSchedule) {
  logger.info('###############################Inside SaveRepaymentSchedule Method ###############################');
  logger.info('Type of AmortSchedule:' + typeof AmortSchedule);

  return new Promise(async (resolve, reject) => {
    try {

      // Parse if string
      if (typeof AmortSchedule === 'string') {
        AmortSchedule = JSON.parse(AmortSchedule);
      }

      if (!Array.isArray(AmortSchedule) || AmortSchedule.length === 0) {
        logger.error('AmortSchedule is invalid or empty');
        return resolve(false);
      }

      const pool = await getPool();
      const transaction = new sql.Transaction(pool);

      await transaction.begin();

      try {
        for (const installment of AmortSchedule) {
          const request = new sql.Request(transaction);

          await request
            .input('CustomerID', sql.VarChar, CustomerID)
            .input('PMSNumber', sql.VarChar, PMSNumber)
            .input('JourneyID', sql.VarChar, JourneyID)
            .input('installmentNo', sql.VarChar, installment.InstallmentNo)
            .input('outstandingPrincipal', sql.Decimal(18, 2), installment.OutstandingAmount)
            .input('principal', sql.Decimal(18, 2), installment.PrincipalPart)
            .input('interest', sql.Decimal(18, 2), installment.InterestPart)
            .input('installmentAmount', sql.Decimal(18, 2), installment.InstallmentAmount)
            .execute('proc_RepaymentSchedule_InsertUpdate');
        }

        await transaction.commit();
        logger.info('All repayment schedule rows inserted successfully');
        resolve(true);

      } catch (txErr) {
        await transaction.rollback();
        logger.error('Transaction rolled back in SaveRepaymentSchedule', txErr);
        reject(txErr);
      }

    } catch (err) {
      logger.error('SaveRepaymentSchedule Error', err);
      reject(err);
    }
  });
}


function UpdateRepaymentData(PMSNumber, JourneyID, TotalPayableAmount, TotalInterestAmount, EMI1, EMI2) {
  logger.info('***************Inside UpdateRepaymentData Method*****************');
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('JourneyID: ' + JourneyID);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        UPDATE SVND_LOAN_JOURNEY_MASTER
        SET
          TotalInterestAmount = @TotalInterestAmount,
          TotalPayableAmount = @TotalPayableAmount,
          EMI1 = @EMI1,
          EMI2 = @EMI2
        WHERE PMSNumber = @PMSNumber
          AND JourneyID = @JourneyID
          AND isJourneyActive = 1
          AND isCustomerJourneyCompleted = 0
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('EMI1', sql.VarChar, EMI1)
        .input('EMI2', sql.VarChar, EMI2)
        .input('TotalPayableAmount', sql.Decimal(18, 2), TotalPayableAmount)
        .input('TotalInterestAmount', sql.Decimal(18, 2), TotalInterestAmount)
        .query(query);

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: "Save Repayment Schedule Updated"
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: "No journey record updated"
        });
      }

    } catch (err) {
      logger.error('UpdateRepaymentData Error', err);
      reject(err);
    }
  });
}


function DatePart() {
  const date = new Date();
  const day = (`0${date.getDate()}`).slice(-2);
  const month = (`0${date.getMonth() + 1}`).slice(-2);
  const year = date.getFullYear().toString().slice(-4);
  const hours = (`0${date.getHours()}`).slice(-2);
  const minutes = (`0${date.getMinutes()}`).slice(-2);
  const seconds = (`0${date.getSeconds()}`).slice(-2);
  return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
};

// function getAadhaarOTPData(PMSNumber, AadhaarNumber, JourneyID) {
  // logger.info('**************************** inside getAadhaarOTPData ******************************');
  // logger.info('Inside PMSNumber: ' + PMSNumber);
  // logger.info('Inside AadhaarNumber: ' + AadhaarNumber);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT TOP 1 AadhaarNo,PMSNumber,ReqTxn FROM SVND_AADHAAR_API_REQUEST_RESPONSE WHERE PMSNumber=@PMSNumber AND AadhaarNo=@AadhaarNumber ORDER BY ReqEntryDate DESC`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('AadhaarNumber', sql.VarChar, AadhaarNumber)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //  logger.info('Successfully got Customer Data from Database:', formattedString);                
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// async function getAadhaarOTPData(PMSNumber, AadhaarNumber, JourneyID) {
  // logger.info('**************************** inside getAadhaarOTPData ******************************');
  
  // return new Promise((resolve, reject) => {
    // const conn = new sql.ConnectionPool(config);
    
    // conn.connect().then(async (pool) => {
      // const transaction = new sql.Transaction(pool);
      
      // try {
        // await transaction.begin();

        // // 1. Select the top 1 record that hasn't been fetched yet
        // const selectQuery = `
          // SELECT TOP 1 AadhaarNo, PMSNumber, ReqTxn 
          // FROM SVND_AADHAAR_API_REQUEST_RESPONSE 
          // WHERE PMSNumber = @PMSNumber 
            // AND AadhaarNo = @AadhaarNo 
            // AND (isFetched IS NULL OR isFetched = 0) 
          // ORDER BY ReqEntryDate DESC`;

        // const result = await transaction.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('AadhaarNo', sql.VarChar, AadhaarNumber)
          // .query(selectQuery);

        // if (result.recordset && result.recordset.length > 0) {
			
			// const jsonString = JSON.stringify(result.recordset, null, 2);
			// formattedString = jsonString.slice(1, -1);
            // logger.info('Successfully got Customer Data from Database: '+ formattedString);                
         
		  
          // const row = result.recordset[0];
          // const txnId = row.ReqTxn;

          // // 2. Mark this specific record as fetched so it can't be used again
          // const updateQuery = `
            // UPDATE SVND_AADHAAR_API_REQUEST_RESPONSE 
            // SET isFetched = 1, FetchedDate = GETDATE() 
            // WHERE ReqTxn = @ReqTxn`;

          // await transaction.request()
            // .input('ReqTxn', sql.VarChar, txnId)
            // .query(updateQuery);

          // await transaction.commit();
          
          // logger.info(`OTP Data fetched and invalidated for Txn: ${txnId}`);
          // //resolve(JSON.stringify(row));
		   // resolve(formattedString);
        // } else {
          // await transaction.rollback();
          // logger.info('No unused OTP data found.');
          // resolve(null);
        // }
      // } catch (err) {
        // if (transaction) await transaction.rollback();
        // logger.error('Database Error:', err);
        // reject(err);
      // } finally {
        // conn.close(); // Always close connection
      // }
    // }).catch(err => {
      // logger.error('Connection Error:', err);
      // reject(err);
    // });
  // });
// }

// function GetLoanAccountData(PMSNumber, JourneyID, AadhaarNumber, CustomerID) {
  // logger.info('***********  Inside Push QR Code Data Method  *************');
  // logger.info('Inside PMSNumber: ' + PMSNumber);
  // return new Promise((resolve, reject) => {
    // try {

      // const query = `SELECT A.[JourneyID],A.[PMSNumber],A.[AadhaarNo],A.[CustomerID],A.[CustomerName],A.[MobileNo],A.[LoanAccountNumber],B.AccountNo,B.solid,C.Date_of_Birth,C.CommAddress_Address1
                        // ,C.CommAddress_Address2,C.CommAddress_City,C.CommAddress_State,C.CommAddress_PINCode,'na@pnb.co.in' AS EmailId
                        // FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                        // INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON A.AadhaarNo=B.AadhaarNumber
                        // INNER JOIN SVND_CBS_CUSTOMER_DETAILS C ON A.CustomerID=C.CustomerID
                        // WHERE A.AadhaarNo=@AadhaarNumber and A.CustomerID=@CustomerID and A.PMSNumber=@PMSNumber and A.JourneyID=@JourneyID AND A.isJourneyActive=1`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('AadhaarNumber', sql.VarChar, AadhaarNumber)
          // .input('CustomerID', sql.VarChar, CustomerID)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // logger.info('Successfully got Customer Data QR Push Data from Database:', formattedString);
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function getJourneyNeSLStatus(PMSNumber, JourneyID, NeSL_tran_ID) {
  // logger.info('***************Inside getJourneyNeSLStatus Method*****************');
  // logger.info('PMSNumber: ' + PMSNumber);
  // return new Promise((resolve, reject) => {
    // try {

      // const query = `SELECT A.PMSNumber,A.JourneyID,NeSL_Tran_ID,NeSL_eSignStatus,NeSL_eStampStatus,isPendingForNeSLeSign,isPendingForBankOfficialSign,NeSL_MatchPercentage,A.NeSLDDEStatus,A.NeSLDDEMessage
            // FROM SVND_LOAN_JOURNEY_MASTER A 
            // INNER JOIN SVND_NESL_DOCUMENT B ON A.JourneyID=B.JourneyID AND A.PMSNumber = B.PMSNumber
            // WHERE A.JourneyID=@JourneyID AND A.PMSNumber=@PMSNumber AND B.NeSL_Tran_ID=@NeSL_tran_ID AND A.isJourneyActive =1`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('NeSL_tran_ID', sql.VarChar, NeSL_tran_ID)
          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //logger.info(`Successfully got getJourneyNeSLStatus from Database: ${formattedString}`);
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function GetNeSLErrorCode(ErrorCode) {
  // logger.info('***************Inside GetNeSLErrorCode Method*****************');
  // logger.info('ErrorCode: ' + JSON.stringify(ErrorCode));



  // // Parse the JSON string into an object
  // const jsonObject = JSON.parse(JSON.stringify(ErrorCode));

  // // Access the value of "ErrorCode"
  // const errorCode = jsonObject.ErrorCode;
  // logger.info('errorCode errorCode: ' + errorCode);


  // return new Promise((resolve, reject) => {
    // try {

      // const query = `SELECT [ErrorCode],[ErrorDesc] FROM [PMSvanidhiDB].[dbo].[SVND_NESL_ERROR_MASTER] WHERE ErrorCode=@ErrorCode`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('ErrorCode', sql.VarChar, errorCode)

          // .query(query);
        // if (result.recordset && result.recordset.length > 0) {
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // formattedString = jsonString.slice(1, -1);
          // //logger.info(`Successfully got getJourneyNeSLStatus from Database: ${formattedString}`);
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

async function getAadhaarOTPData(PMSNumber, AadhaarNumber, JourneyID) {
  logger.info('**************************** inside getAadhaarOTPData ******************************');

  try {
    const pool = await getPool();
    const transaction = new sql.Transaction(pool);

    await transaction.begin();

    try {
      const selectQuery = `
        SELECT TOP 1 AadhaarNo, PMSNumber, ReqTxn
        FROM SVND_AADHAAR_API_REQUEST_RESPONSE
        WHERE PMSNumber = @PMSNumber
          AND AadhaarNo = @AadhaarNo
          AND (isFetched IS NULL OR isFetched = 0)
        ORDER BY ReqEntryDate DESC
      `;

      const selectResult = await new sql.Request(transaction)
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('AadhaarNo', sql.VarChar, AadhaarNumber)
        .query(selectQuery);

      if (!selectResult.recordset || selectResult.recordset.length === 0) {
        await transaction.rollback();
        logger.info('No unused OTP data found.');
        return null;
      }

      const row = selectResult.recordset[0];
      const formattedString = JSON.stringify(row);

      const updateQuery = `
        UPDATE SVND_AADHAAR_API_REQUEST_RESPONSE
        SET isFetched = 1, FetchedDate = GETDATE()
        WHERE ReqTxn = @ReqTxn
      `;

      await new sql.Request(transaction)
        .input('ReqTxn', sql.VarChar, row.ReqTxn)
        .query(updateQuery);

      await transaction.commit();
      logger.info(`OTP Data fetched and invalidated for Txn: ${row.ReqTxn}`);

      return formattedString;

    } catch (txErr) {
      await transaction.rollback();
      logger.error('Transaction Error in getAadhaarOTPData', txErr);
      throw txErr;
    }

  } catch (err) {
    logger.error('getAadhaarOTPData Error', err);
    throw err;
  }
}

function GetLoanAccountData(PMSNumber, JourneyID, AadhaarNumber, CustomerID) {
  logger.info('*********** Inside Push QR Code Data Method *************');
  logger.info('PMSNumber: ' + PMSNumber);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT A.[JourneyID],A.[PMSNumber],A.[AadhaarNo],A.[CustomerID],
               A.[CustomerName],A.[MobileNo],A.[LoanAccountNumber],
               B.AccountNo,B.solid,
               C.Date_of_Birth,C.CommAddress_Address1,
               C.CommAddress_Address2,C.CommAddress_City,
               C.CommAddress_State,C.CommAddress_PINCode,
               'na@pnb.co.in' AS EmailId
        FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON A.AadhaarNo = B.AadhaarNumber
        INNER JOIN SVND_CBS_CUSTOMER_DETAILS C ON A.CustomerID = C.CustomerID
        WHERE A.AadhaarNo = @AadhaarNumber
          AND A.CustomerID = @CustomerID
          AND A.PMSNumber = @PMSNumber
          AND A.JourneyID = @JourneyID
          AND A.isJourneyActive = 1
      `;

      const pool = await getPool();
      const result = await pool.request()
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('AadhaarNumber', sql.VarChar, AadhaarNumber)
        .input('CustomerID', sql.VarChar, CustomerID)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const formattedString = JSON.stringify(result.recordset[0]);
        logger.info('Successfully got QR Push Data:', formattedString);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('GetLoanAccountData Error', err);
      reject(err);
    }
  });
}


function getJourneyNeSLStatus(PMSNumber, JourneyID, NeSL_tran_ID) {
  logger.info('***************Inside getJourneyNeSLStatus Method*****************');
  logger.info('PMSNumber: ' + PMSNumber);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT A.PMSNumber,A.JourneyID,B.NeSL_Tran_ID,
               B.NeSL_eSignStatus,B.NeSL_eStampStatus,
               B.isPendingForNeSLeSign,B.isPendingForBankOfficialSign,
               B.NeSL_MatchPercentage,
               A.NeSLDDEStatus,A.NeSLDDEMessage
        FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_NESL_DOCUMENT B
          ON A.JourneyID = B.JourneyID
         AND A.PMSNumber = B.PMSNumber
        WHERE A.JourneyID = @JourneyID
          AND A.PMSNumber = @PMSNumber
          AND B.NeSL_Tran_ID = @NeSL_tran_ID
          AND A.isJourneyActive = 1
      `;

      const pool = await getPool();
      const result = await pool.request()
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('NeSL_tran_ID', sql.VarChar, NeSL_tran_ID)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        resolve(JSON.stringify(result.recordset[0]));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('getJourneyNeSLStatus Error', err);
      reject(err);
    }
  });
}


function GetNeSLErrorCode(ErrorCodeObj) {
  logger.info('***************Inside GetNeSLErrorCode Method*****************');

  const errorCode = ErrorCodeObj?.ErrorCode;
  logger.info('Resolved ErrorCode: ' + errorCode);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT ErrorCode, ErrorDesc
        FROM SVND_NESL_ERROR_MASTER
        WHERE ErrorCode = @ErrorCode
      `;

      const pool = await getPool();
      const result = await pool.request()
        .input('ErrorCode', sql.VarChar, errorCode)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        resolve(JSON.stringify(result.recordset[0]));
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('GetNeSLErrorCode Error', err);
      reject(err);
    }
  });
}




// function UpdateRespURL(NeSL_TranID, PMSNumber, JourneyID, RespURL) {
  // logger.info('################### Inside UpdateRespURL Method ######################');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // logger.info('RespURL: ' + RespURL);
  // return new Promise((resolve, reject) => {
    // try {

      // const ErrorTime = DatePart();

      // const query = `UPDATE [PMSvanidhiDB].[dbo].[SVND_NESL_DOCUMENT] SET NeslRetURL=@RespURL WHERE PMSNumber=@PMSNumber AND JourneyID=@JourneyID and NeSL_Tran_ID=@NeSL_Tran_ID`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('NeSL_Tran_ID', sql.VarChar, NeSL_TranID)
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('RespURL', sql.VarChar, RespURL)
          // .query(query);
        // logger.info('Result Length: ' + JSON.stringify(result));
        // logger.info('Rows Affacted: ' + result.rowsAffected[0]);
        // if (result.recordsets && result.rowsAffected[0] > 0) {
          // formattedString = {
            // "ErrorCode": "00",
            // "ErrorMsg": "Journey response url updated in database."
          // }
          // resolve(formattedString);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function GetDataBasedOnNeslTxnID(NeSL_TranID) {
  // // logger.info('********************* Inside GetDataBasedOnNeslTxnID Method ************************');
  // // logger.info('NeSL_TranID  ' + NeSL_TranID);

  // return new Promise((resolve, reject) => {

    // const query = `SELECT JourneyID,PMSNumber,NeSL_Tran_ID FROM [PMSvanidhiDB].[dbo].[SVND_NESL_DOCUMENT] WHERE NeSL_Tran_ID=@NeSL_TranID`;
    // var conn = new sql.ConnectionPool(config);
    // conn.connect().then(async function (pool) {

      // const result = await pool.request()
        // .input('NeSL_TranID', sql.VarChar, NeSL_TranID)
        // .query(query);
      // //logger.info('Result Length: ' + result.recordset.length);
      // if (result.recordset && result.recordset.length > 0) {
        // //logger.info('here ' + JSON.stringify(JSON.parse(JSON.stringify(result.recordset))));
        // const jsonString = JSON.stringify(result.recordset, null, 2);
        // formattedString = jsonString.slice(1, -1);
        // resolve(formattedString);
      // }
      // else {
        // resolve(null);
      // }
    // });
  // });
// }

// function DownloadLoanApplication(PMSNumber, JourneyID, NeslStatus) {
  // logger.info("################ Inside DownloadLoanApplication ################");
  // logger.info(`PMSNumber: ${PMSNumber}, JourneyID: ${JourneyID}, NeslStatus: ${NeslStatus}`);

  // let CustomQuery;

  // switch (NeslStatus) {
    // case "NeSLFailedLoanDoc":
      // CustomQuery = `
        // SELECT B.Signed_NeSL_Doc_Byte AS DocumentByte
        // FROM SVND_LOAN_JOURNEY_MASTER A
        // INNER JOIN SVND_NESL_DOCUMENT B 
          // ON B.PMSNumber = A.PMSNumber AND B.JourneyID = A.JourneyID
        // WHERE A.PMSNumber = @PMSNumber 
          // AND A.JourneyID = @JourneyID 
          // AND isJourneyActive = 1`;
      // break;

    // case "UploadBOSignedDoc":
      // CustomQuery = `
        // SELECT B.BranchUploadDocumentByte AS DocumentByte
        // FROM SVND_LOAN_JOURNEY_MASTER A
        // INNER JOIN SVND_NESL_DOCUMENT B 
          // ON B.PMSNumber = A.PMSNumber AND B.JourneyID = A.JourneyID
        // WHERE A.PMSNumber = @PMSNumber 
          // AND A.JourneyID = @JourneyID 
          // AND isJourneyActive = 1`;
      // break;

    // default:
      // CustomQuery = `
        // SELECT 
          // CASE 
            // WHEN B.BranchUploadDocumentByte IS NOT NULL 
              // THEN B.BranchUploadDocumentByte 
              // ELSE B.Signed_NeSL_Bank_Doc_Byte 
          // END AS DocumentByte
        // FROM SVND_LOAN_JOURNEY_MASTER A
        // INNER JOIN SVND_NESL_DOCUMENT B 
          // ON B.PMSNumber = A.PMSNumber AND B.JourneyID = A.JourneyID
        // WHERE A.PMSNumber = @PMSNumber 
          // AND A.JourneyID = @JourneyID 
          // AND isJourneyActive = 1`;
      // break;
  // }

  // logger.info("CustomQuery: " + CustomQuery);

  // return new Promise((resolve, reject) => {
    // const conn = new sql.ConnectionPool(config);

    // conn.connect()
      // .then(pool => {
        // return pool.request()
          // .input("PMSNumber", sql.VarChar, PMSNumber)
          // .input("JourneyID", sql.VarChar, JourneyID)
          // .query(CustomQuery);
      // })
      // .then(result => {
        // if (result.recordset && result.recordset.length > 0) {
          // const docRow = result.recordset[0];
          // // ✅ Ensure it's Buffer, not string
          // resolve({ DocumentByte: docRow.DocumentByte });
        // } else {
          // resolve(null);
        // }
      // })
      // .catch(err => {
        // logger.error("Error in DownloadLoanApplication: " + err);
        // reject(err);
      // });
  // });
// }

function UpdateRespURL(NeSL_TranID, PMSNumber, JourneyID, RespURL) {
  logger.info('################### Inside UpdateRespURL Method ######################');
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('JourneyID: ' + JourneyID);
  logger.info('RespURL: ' + RespURL);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        UPDATE SVND_NESL_DOCUMENT
        SET NeslRetURL = @RespURL
        WHERE PMSNumber = @PMSNumber
          AND JourneyID = @JourneyID
          AND NeSL_Tran_ID = @NeSL_Tran_ID
      `;

      const pool = await getPool();
      const result = await pool.request()
        .input('NeSL_Tran_ID', sql.VarChar, NeSL_TranID)
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('RespURL', sql.VarChar, RespURL)
        .query(query);

      logger.info('Rows Affected: ' + result.rowsAffected[0]);

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: "Journey response url updated in database."
        });
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('UpdateRespURL Error', err);
      reject(err);
    }
  });
}

function GetDataBasedOnNeslTxnID(NeSL_TranID) {
  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT JourneyID, PMSNumber, NeSL_Tran_ID
        FROM SVND_NESL_DOCUMENT
        WHERE NeSL_Tran_ID = @NeSL_TranID
      `;

      const pool = await getPool();
      const result = await pool.request()
        .input('NeSL_TranID', sql.VarChar, NeSL_TranID)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const formattedString = JSON.stringify(result.recordset[0]);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error('GetDataBasedOnNeslTxnID Error', err);
      reject(err);
    }
  });
}


function DownloadLoanApplication(PMSNumber, JourneyID, NeslStatus) {
  logger.info("################ Inside DownloadLoanApplication ################");
  logger.info(`PMSNumber: ${PMSNumber}, JourneyID: ${JourneyID}, NeslStatus: ${NeslStatus}`);

  let CustomQuery;

  switch (NeslStatus) {
    case "NeSLFailedLoanDoc":
      CustomQuery = `
        SELECT B.Signed_NeSL_Doc_Byte AS DocumentByte
        FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_NESL_DOCUMENT B
          ON B.PMSNumber = A.PMSNumber AND B.JourneyID = A.JourneyID
        WHERE A.PMSNumber = @PMSNumber
          AND A.JourneyID = @JourneyID
          AND A.isJourneyActive = 1`;
      break;

    case "UploadBOSignedDoc":
      CustomQuery = `
        SELECT B.BranchUploadDocumentByte AS DocumentByte
        FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_NESL_DOCUMENT B
          ON B.PMSNumber = A.PMSNumber AND B.JourneyID = A.JourneyID
        WHERE A.PMSNumber = @PMSNumber
          AND A.JourneyID = @JourneyID
          AND A.isJourneyActive = 1`;
      break;

    default:
      CustomQuery = `
        SELECT
          CASE
            WHEN B.BranchUploadDocumentByte IS NOT NULL
              THEN B.BranchUploadDocumentByte
              ELSE B.Signed_NeSL_Bank_Doc_Byte
          END AS DocumentByte
        FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_NESL_DOCUMENT B
          ON B.PMSNumber = A.PMSNumber AND B.JourneyID = A.JourneyID
        WHERE A.PMSNumber = @PMSNumber
          AND A.JourneyID = @JourneyID
          AND A.isJourneyActive = 1`;
      break;
  }

  logger.info("CustomQuery: " + CustomQuery);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const result = await pool.request()
        .input("PMSNumber", sql.VarChar, PMSNumber)
        .input("JourneyID", sql.VarChar, JourneyID)
        .query(CustomQuery);

      if (result.recordset && result.recordset.length > 0) {
        resolve({ DocumentByte: result.recordset[0].DocumentByte });
      } else {
        resolve(null);
      }

    } catch (err) {
      logger.error("Error in DownloadLoanApplication", err);
      reject(err);
    }
  });
}



function BankSignAffix(PMSNumber, JourneyID, objNeSLDocumentData) {
  logger.info('***************Inside BankSignAffix Method*****************');
  logger.info('PMSNumber: ' + PMSNumber);
  return new Promise((resolve, reject) => {
    try {
      logger.info('get NeSL Doc Data from Database for bank sign affix ');
      const p12Buffer = objCommonFunction.loadBankCertPfx();
      const PFXbase64Encoded = p12Buffer.toString('base64');
      logger.info('PFXbase64Encoded: ' + PFXbase64Encoded);
      const parsedData = JSON.parse(objNeSLDocumentData);
      let DocBase64Byte = '';
      if (parsedData && parsedData.Signed_NeSL_Doc_Byte) {
        const bufferData = Buffer.from(parsedData.Signed_NeSL_Doc_Byte);
        DocBase64Byte = bufferData.toString('base64');
        //fs.writeFileSync('NeSLSignDocTranch1.pdf', DocBase64Byte);
      }
      //const bufferData = Buffer.from(JSON.parse(objNeSLDocumentData).Signed_NeSL_Bank_Doc_Byte);


      //  const outputDir1 = path.resolve(__dirname, '..', 'Logs', 'NeSlSignedDoc');    
      //    const filePath1 = path.join(outputDir1,"NeSLSignDocTranch1.pdf");
      //    fs.writeFileSync(filePath1,  DocBase64Byte);// Write the PDF
      logger.info('DocBase64Byte: ' + DocBase64Byte);

      objCBSDataLayer.BankSignAffix(PMSNumber, JourneyID, parsedData.NeSL_Tran_ID, PFXbase64Encoded, DocBase64Byte).then(async (respBankSignAffix) => {
        /// logger.info('Output BankSignAffix: '+JSON.stringify(respBankSignAffix));
        logger.info('Output BankSignAffix ErrorStatus: ' + respBankSignAffix.ErrorStatus);
        logger.info('Output BankSignAffix ErrorMsg: ' + respBankSignAffix.ErrorMsg);

        const DoccumetByteArray = Buffer.from(respBankSignAffix.DocData, 'base64')
        objCBSDataLayer.UpdateNeSLDocumentData(PMSNumber, JourneyID, parsedData.NeSL_Tran_ID, DoccumetByteArray, null, null, null, null, null, null
          , null, null, null, null, null, null, null, null, null, null, null, null, null, 'BankSignDocument', null).then(async (respUpdateNeslResponseDatabase) => {
            if (respUpdateNeslResponseDatabase != null) {
              respJSON = {
                "ErrorCode": respUpdateNeslResponseDatabase.ErrorCode,
                "ErrorMsg": respUpdateNeslResponseDatabase.ErrorMsg
              }
              resolve(JSON.stringify(respJSON));
            }
            else {
              resolve(null);
            }
          });
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}

// function UploadCustomerSignedLoanDocument(PMSNumber, JourneyID, FileName, base64String, chkConsent, Action) {
  // logger.info('################### Inside UploadCustomerSignedLoanDocument Method ######################');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // logger.info('Action: ' + Action);

  // let ByteStream = null;
  // if (base64String != null) {
    // ByteStream = Buffer.from(base64String, 'base64')
  // }

  // return new Promise((resolve, reject) => {
    // try {
      // // const date1=DatePart();
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool); // Create a new request object for every row insert             
        // request.input('PMSNumber', sql.VarChar, PMSNumber);
        // request.input('JourneyID', sql.VarChar, JourneyID);
        // request.input('DocumentBytes', sql.VarBinary(sql.MAX), ByteStream);
        // request.input('DocumentName', sql.VarChar, FileName);
        // request.input('BranchConsent', sql.Bit, chkConsent);
        // request.input('Action', sql.VarChar, Action);
        // request.execute('proc_BranchUploadCustomerSignedDoc', function (err, queryResult) {
          // //logger.info('QueryResult ' + JSON.stringify(queryResult));
          // logger.info('Error ' + err);
          // if (queryResult.rowsAffected[0] == "1") {
            // formattedString = {
              // "ErrorCode": "00",
              // "ErrorMsg": "Record updated successfully"
            // }
            // resolve(formattedString);
          // }
          // else {
            // logger.info('else:' + err);
            // formattedString = {
              // "ErrorCode": "01",
              // "ErrorMsg": "Error to update journey"
            // }
            // resolve(formattedString);
          // }
        // });
      // });

    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

// function NeSLFailedDocSubmit(PMSNumber, JourneyID) {
  // logger.info('################### Inside NeSLFailedDocSubmit Method ######################');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // return new Promise((resolve, reject) => {
    // try {

      // const CustomDateTime = DatePart();
      // logger.info('CustomDateTime: ' + CustomDateTime);
      // const query = `UPDATE [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] SET isBranchUploadNeslFailedDoc=1,BranchUploadNeslFailedDocTime=@CustomDateTime
       // WHERE PMSNumber=@PMSNumber AND JourneyID=@JourneyID AND isJourneyActive=1 AND isBranchUploadNeslFailedDoc=0`;
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(async function (pool) {
        // // logger.info('Query: ' + query);                           
        // const result = await pool.request()
          // .input('PMSNumber', sql.VarChar, PMSNumber)
          // .input('JourneyID', sql.VarChar, JourneyID)
          // .input('CustomDateTime', sql.VarChar, CustomDateTime)
          // .query(query);
        // logger.info('Result Length: ' + JSON.stringify(result));
        // logger.info('Rows Affacted: ' + result.rowsAffected[0]);
        // if (result.recordsets && result.rowsAffected[0] > 0) {
          // formattedString = {
            // "ErrorCode": "00",
            // "ErrorMsg": "Customer Journey Updated Successfully."
          // }
          // resolve(formattedString);
        // }
        // else {
          // formattedString = {
            // "ErrorCode": "01",
            // "ErrorMsg": "Error to update Customer Journey Error Updated."
          // }
          // resolve(formattedString);
        // }
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function UploadCustomerSignedLoanDocument(
  PMSNumber,
  JourneyID,
  FileName,
  base64String,
  chkConsent,
  Action
) {
  logger.info('################### Inside UploadCustomerSignedLoanDocument Method ######################');
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('JourneyID: ' + JourneyID);
  logger.info('Action: ' + Action);

  let ByteStream = null;
  if (base64String != null) {
    ByteStream = Buffer.from(base64String, 'base64');
  }

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('DocumentBytes', sql.VarBinary(sql.MAX), ByteStream)
        .input('DocumentName', sql.VarChar, FileName)
        .input('BranchConsent', sql.Bit, chkConsent)
        .input('Action', sql.VarChar, Action)
        .execute('proc_BranchUploadCustomerSignedDoc');

      ////logger.info('QueryResult ' + JSON.stringify(result));

      if (result.rowsAffected && result.rowsAffected[0] === 1) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: "Record updated successfully"
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: "Error to update journey"
        });
      }

    } catch (err) {
      logger.error('UploadCustomerSignedLoanDocument Error', err);
      reject(err);
    }
  });
}

function NeSLFailedDocSubmit(PMSNumber, JourneyID) {
  logger.info('################### Inside NeSLFailedDocSubmit Method ######################');
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('JourneyID: ' + JourneyID);

  return new Promise(async (resolve, reject) => {
    try {
      const CustomDateTime = DatePart();
      logger.info('CustomDateTime: ' + CustomDateTime);

      const query = `
        UPDATE SVND_LOAN_JOURNEY_MASTER
        SET
          isBranchUploadNeslFailedDoc = 1,
          BranchUploadNeslFailedDocTime = @CustomDateTime
        WHERE PMSNumber = @PMSNumber
          AND JourneyID = @JourneyID
          AND isJourneyActive = 1
          AND isBranchUploadNeslFailedDoc = 0
      `;

      const pool = await getPool();
      const result = await pool.request()
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('CustomDateTime', sql.VarChar, CustomDateTime)
        .query(query);

      logger.info('Rows Affected: ' + result.rowsAffected[0]);

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: "Customer Journey Updated Successfully."
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: "Error to update Customer Journey Error Updated."
        });
      }

    } catch (err) {
      logger.error('NeSLFailedDocSubmit Error', err);
      reject(err);
    }
  });
}




module.exports = { isPMSNumberExist, getPMSData, CreateLoanJourney,DownloadDocumentUpdate, CustomerJourneyInsert, CustomerJourneyUpdate, getMilestoneFromMilestoneMaster, CBSToken,APIMToken, getCityKYCInfoData, UpdateRepaymentData, SIDBICurrentStatus_Update, getVFirstToken, VerifyVFirstOTP, getAadhaarOTPData, getCustomerDetails, getConsumerCIBIL, Sanctioned_Rejected_Suspended_CustomerJourney, GetAmortizationSchedule, getKFSAndSanctionLetterData, getBranchInformation, getCustomerJourneyData, getJourneyMileStone, SaveRepaymentSchedule, getNeSLDocumentData, DownloadLoanApplication, StateCodeWord, GetKeyConfigurationValue, getJourneyNeSLStatus, GetLoanAccountData, UpdateCustomerJourneyErrorUpdate, getEligibleDataFromMISD, GetDataBasedOnNeslTxnID, UpdateRespURL, GetNeSLErrorCode, LogMakerConsent, UpdateCICPassFlag, BankSignAffix, UploadCustomerSignedLoanDocument, NeSLFailedDocSubmit, insertLandingData, getLoanAccountOpeningContext };