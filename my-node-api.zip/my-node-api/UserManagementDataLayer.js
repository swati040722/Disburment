// UserManagementDataLayer.js


process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // Disable SSL check due to bank's proxy server

const express = require('express');
const cors = require('cors');
const sql = require('mssql');
//const logger = require('./logger');
const getLogger = require('./logger');
const logger = getLogger('UserManagementDataLayer');
//const { sql, getPool } = require('./db');
// // SQL Server configuration
// const config = {
//    user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000,
//   },
//   options: {
//     encrypt: true,
//     trustServerCertificate: true,
//   },
// };



const config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};




function BindDashboardData(deLoginResponse, JourneyType) {
  logger.info('**********************inside BindDashboardData Method**********************');
  logger.info('solid: ' + deLoginResponse.UserSOL);
  logger.info('JourneyType: ' + JourneyType);

  let CustomeQuery = "";

  return new Promise((resolve, reject) => {

    if (JourneyType == "ADMIN_DIY_DASHBOARD") {
      CustomeQuery = `SELECT 
                    COUNT(CASE WHEN A.isJourneySanctioned = 0 THEN 1 END) AS Total_PickedUp,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneySanctioned = 0 and MakerNonMandatoryConsentGivenBy IS NULL AND CheckerActionOnMakerDataGivenBy IS NULL),0) TotalPickedUpAmount,
                    COUNT(CASE WHEN A.isJourneySanctioned = 1 THEN 1 END) AS Total_Sanctioned,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneySanctioned = 1 and MakerNonMandatoryConsentGivenBy IS NULL AND CheckerActionOnMakerDataGivenBy IS NULL),0) TotalSanctionedAmount,
                    COUNT(CASE WHEN A.isLoanAccountOpened = 1 THEN 1 END) AS Total_LoanAccOpened,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isLoanAccountOpened = 1 and MakerNonMandatoryConsentGivenBy IS NULL AND CheckerActionOnMakerDataGivenBy IS NULL),0) TotalAccOpenedAmount,
                    COUNT(CASE WHEN A.isLoanDisbursed = 1 THEN 1 END) AS Total_AccDisbursed,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isLoanDisbursed = 1 and MakerNonMandatoryConsentGivenBy IS NULL AND CheckerActionOnMakerDataGivenBy IS NULL),0) TotalDisbursedAmount,
                    COUNT(CASE  WHEN A.isJourneyActive = 1 AND  A.isSchedularJourneyCompleted = 0 AND (A.isCustomerJourneyCompleted = 0) THEN 1 END) AS Total_InProgress_Journey,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneyActive = 1 AND  isSchedularJourneyCompleted = 0 AND (isCustomerJourneyCompleted = 0) and MakerNonMandatoryConsentGivenBy IS NULL AND CheckerActionOnMakerDataGivenBy IS NULL),0) TotalInProgressAmount,
                    COUNT(CASE WHEN A.JourneyInitiationChannel='CustomerJourney' THEN 1 END) AS Total_DIY_Journey,
                    COUNT(CASE WHEN A.JourneyInitiationChannel='BranchJourney' THEN 1 END) AS Total_Branch_Journey,
                    COUNT(CASE WHEN A.isJourneyRejected=1 THEN 1 END) AS Total_Rejected_Journey,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isLoanAccountOpened = 1 and MakerNonMandatoryConsentGivenBy IS NULL AND CheckerActionOnMakerDataGivenBy IS NULL),0) TotalRejectedAmount
                    FROM  SVND_LOAN_JOURNEY_MASTER A
                    INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON A.CustomerID=B.CustomerID
                    INNER JOIN SVND_CBS_CUSTOMER_DETAILS C ON B.CustomerID=C.CustomerID
                    WHERE (A.MakerNonMandatoryConsentGivenBy IS NULL AND A.CheckerActionOnMakerDataGivenBy IS NULL)`
    }
    else if (JourneyType == "ADMIN_BRANCH_DASHBOARD") {
        CustomeQuery = `SELECT 
                        COUNT(CASE WHEN A.isJourneySanctioned = 0 THEN 1 END) AS Total_PickedUp,
                        ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneySanctioned = 0),0) TotalPickedUpAmount,
                        COUNT(CASE WHEN A.isJourneySanctioned = 1 THEN 1 END) AS Total_Sanctioned,
                        ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneySanctioned = 1),0) TotalSanctionedAmount,
                        COUNT(CASE WHEN A.isLoanAccountOpened = '1' THEN 1 END) AS Total_LoanAccOpened,
                        ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isLoanAccountOpened = 1),0) TotalAccOpenedAmount,
                        COUNT(CASE WHEN A.isLoanDisbursed = '1' THEN 1 END) AS Total_AccDisbursed,
                        ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isLoanDisbursed = 1),0) TotalDisbursedAmount,
                        COUNT(CASE  WHEN A.isJourneyActive = '1' AND  A.isSchedularJourneyCompleted = '0' AND (A.isCustomerJourneyCompleted = '0') THEN 1 END) AS Total_InProgress_Journey,
                        ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneyActive = 1 AND  isSchedularJourneyCompleted = 0 AND (isCustomerJourneyCompleted = 0)),0) TotalInProgressAmount,
                        COUNT(CASE WHEN A.JourneyInitiationChannel='CustomerJourney' THEN 1 END) AS Total_DIY_Journey,
                        COUNT(CASE WHEN A.JourneyInitiationChannel='BranchJourney' THEN 1 END) AS Total_Branch_Journey,
                        COUNT(CASE WHEN A.isJourneyRejected=1 THEN 1 END) AS Total_Rejected_Journey,
                        ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneyRejected = 1),0) TotalRejectedAmount
                        FROM  SVND_LOAN_JOURNEY_MASTER A
                        INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON A.CustomerID=B.CustomerID
                        INNER JOIN SVND_CBS_CUSTOMER_DETAILS C ON B.CustomerID=C.CustomerID
                        WHERE (A.MakerNonMandatoryConsentGivenBy IS NOT NULL OR A.CheckerActionOnMakerDataGivenBy IS NOT NULL)`

    }
    else {
      logger.info('For Branch wise dashboard data');
      CustomeQuery = `SELECT 
                    COUNT(CASE WHEN A.isJourneySanctioned = 0 THEN 1 END) AS Total_PickedUp,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneySanctioned = 0 AND solid=@Usersol),0) TotalPickedUpAmount,
                    COUNT(CASE WHEN A.isJourneySanctioned = 1 THEN 1 END) AS Total_Sanctioned,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneySanctioned = 1 AND solid=@Usersol),0) TotalSanctionedAmount,
                    COUNT(CASE WHEN A.isLoanAccountOpened = '1' THEN 1 END) AS Total_LoanAccOpened,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isLoanAccountOpened = 1 AND solid=@Usersol),0) TotalAccOpenedAmount,
                    COUNT(CASE WHEN A.isLoanDisbursed = '1' THEN 1 END) AS Total_AccDisbursed,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isLoanDisbursed = 1 AND solid=@Usersol),0) TotalDisbursedAmount,
                    COUNT(CASE  WHEN A.isJourneyActive = '1' AND A.solid=@Usersol AND  A.isSchedularJourneyCompleted = '0' AND (A.isCustomerJourneyCompleted = '0') THEN 1 END) AS Total_InProgress_Journey,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneyActive = 1 AND solid=@Usersol AND  isSchedularJourneyCompleted = 0 AND (isCustomerJourneyCompleted = 0)),0) TotalInProgressAmount,
                    COUNT(CASE WHEN A.isJourneyRejected=1 THEN 1 END) AS Total_Rejected_Journey,
                    ISNULL((SELECT SUM(LoanAmount) FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE isJourneyRejected=1 AND solid=@Usersol ),0) TotalRejectedAmount
                    FROM  SVND_LOAN_JOURNEY_MASTER A
                    INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON A.CustomerID=B.CustomerID
                    INNER JOIN SVND_CBS_CUSTOMER_DETAILS C ON B.CustomerID=C.CustomerID
                    WHERE A.solid=@Usersol
                    GROUP BY A.solid`;
    }
    try {

      logger.info('Query ' + CustomeQuery);

      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .input('Usersol', sql.VarChar, deLoginResponse.UserSOL)
          .query(CustomeQuery);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}


function EsignData(deLoginResponse, JourneyType, fromDate, toDate) {
  console.log('**********************inside EsignData Method**********************');
  console.log('fromDate: ' + fromDate);
  console.log('JourneyType: ' + JourneyType);
  let CustomQuery = "";
  return new Promise((resolve, reject) => {
    try {

      if (JourneyType == "ADMIN_DIY_DASHBOARD") {
        console.log('Inside if');

        CustomQuery = `SELECT A.PMSNumber,NeSL_eSignStatus,NeSL_eSignDate,NeSL_eStampStatus,NeSL_eStampDate,NeSL_Resp_Time,
        [NeSL_MatchPercentage],[NeSL_SignatoryName],[NeSL_SignedName],[NeSL_SignatoryYob],[NeSL_SignedYob],[NeSL_SignatoryAadhar]
        ,[NeSL_SignedAadhar],[NeSL_SignatoryGender],[NeSL_SignedGender],A.MobileNo FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_NESL_DOCUMENT B ON A.PMSNumber=B.PMSNumber AND A.JourneyID=B.JourneyID
        WHERE (A.MakerNonMandatoryConsentGivenBy IS NULL AND A.CheckerActionOnMakerDataGivenBy IS NULL)
        AND B.NeSL_Resp_Time BETWEEN @fromDate AND @toDate`
      }
      else if (JourneyType == "ADMIN_BRANCH_DASHBOARD") {
        console.log('Inside else if');
        CustomQuery = `SELECT A.PMSNumber,NeSL_eSignStatus,NeSL_eSignDate,NeSL_eStampStatus,NeSL_eStampDate,NeSL_Resp_Time,
        [NeSL_MatchPercentage],[NeSL_SignatoryName],[NeSL_SignedName],[NeSL_SignatoryYob],[NeSL_SignedYob],[NeSL_SignatoryAadhar]
        ,[NeSL_SignedAadhar],[NeSL_SignatoryGender],[NeSL_SignedGender],A.MobileNo FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_NESL_DOCUMENT B ON A.PMSNumber=B.PMSNumber AND A.JourneyID=B.JourneyID
        WHERE (A.MakerNonMandatoryConsentGivenBy IS NOT NULL OR A.CheckerActionOnMakerDataGivenBy IS NOT NULL)
        AND B.NeSL_Resp_Time BETWEEN @fromDate AND @toDate`
      }
      else {
        console.log('Inside else');
        CustomQuery = ``
      }

      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('solid', sql.VarChar, deLoginResponse.UserSOL)
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(CustomQuery);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          resolve(output);

        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}

function DashboardExcelDownload(deLoginResponse, Action, JourneyType) {
  console.log('**********************inside DashboardExcelDownload Method**********************');
  console.log('Action: ' + Action);
  console.log('JourneyType: ' + JourneyType);
  let CustomQuery = "";
  return new Promise((resolve, reject) => {
    try {

      if (JourneyType == "ADMIN_BRANCH_DASHBOARD") {
        console.log('Inside if');

        if (Action = 'pickedUp') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
          WHERE isJourneySanctioned =0 and isJourneyActive=1 AND (MakerNonMandatoryConsentGivenBy IS NOT NULL OR CheckerActionOnMakerDataGivenBy IS NOT NULL)`;
        }
        else if (Action = 'sanctioned') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
          WHERE isJourneySanctioned =1 and isJourneyActive=1 AND (MakerNonMandatoryConsentGivenBy IS NOT NULL OR CheckerActionOnMakerDataGivenBy IS NOT NULL)`;
        }
        else if (Action = 'rejected') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
          WHERE isJourneyRejected =1 AND (MakerNonMandatoryConsentGivenBy IS NOT NULL OR CheckerActionOnMakerDataGivenBy IS NOT NULL)`;
        }
        else if (Action = 'inProgress') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
          WHERE isJourneyActive=1 AND isCustomerJourneyCompleted=0 AND (MakerNonMandatoryConsentGivenBy IS NOT NULL OR CheckerActionOnMakerDataGivenBy IS NOT NULL)`;
        }
        else if (Action = 'loanAccountOpened') {
          logger.info('Branch Dashboard for loanAccountOpened');
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
          WHERE isJourneyActive=1 AND isLoanAccountOpened=1 AND (MakerNonMandatoryConsentGivenBy IS NOT NULL OR CheckerActionOnMakerDataGivenBy IS NOT NULL)`;
        }
        else if (Action = 'accountsDisbursed') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
              WHERE isJourneyActive=1 AND isLoanDisbursed=1 AND (MakerNonMandatoryConsentGivenBy IS NOT NULL OR CheckerActionOnMakerDataGivenBy IS NOT NULL)`;
        }
        else if (Action = 'PendingForSchedular') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
              WHERE isJourneyActive=1 AND isCustomerJourneyCompleted=1 AND isSchedularJourneyCompleted=0 AND (MakerNonMandatoryConsentGivenBy IS NULL OR CheckerActionOnMakerDataGivenBy IS NULL)`;
        }
      }
      else if (JourneyType == "ADMIN_DIY_DASHBOARD") {
        if (Action = 'pickedUp') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]
              WHERE isJourneySanctioned =0 and isJourneyActive=1 AND (MakerNonMandatoryConsentGivenBy IS NULL OR CheckerActionOnMakerDataGivenBy IS NULL)`;
        }
        else if (Action = 'sanctioned') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
            ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
            ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
            ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
            ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
            ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
            ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
            ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
            ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
            ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
            ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
            ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
            ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
            ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
            FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER]  
            WHERE isJourneySanctioned =1 and isJourneyActive=1 AND (MakerNonMandatoryConsentGivenBy IS NULL OR CheckerActionOnMakerDataGivenBy IS NULL)`;
        }
        else if (Action = 'rejected') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
            ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
            ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
            ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
            ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
            ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
            ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
            ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
            ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
            ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
            ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
            ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
            ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
            ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
            FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] 
            WHERE isJourneyRejected =1 AND (MakerNonMandatoryConsentGivenBy IS NULL OR CheckerActionOnMakerDataGivenBy IS NULL)`;
        }
        else if (Action = 'inProgress') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
            ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
            ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
            ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
            ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
            ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
            ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
            ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
            ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
            ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
            ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
            ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
            ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
            ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
            FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] 
            WHERE isJourneyActive=1 AND isCustomerJourneyCompleted=0 AND (MakerNonMandatoryConsentGivenBy IS NULL OR CheckerActionOnMakerDataGivenBy IS NULL)`;
        }
        else if (Action = 'loanAccountOpened') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
            ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
            ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
            ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
            ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
            ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
            ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
            ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
            ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
            ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
            ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
            ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
            ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
            ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
            FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] 
            WHERE isJourneyActive=1 AND isLoanAccountOpened=1 AND (MakerNonMandatoryConsentGivenBy IS NULL OR CheckerActionOnMakerDataGivenBy IS NULL)`;
        }
        else if (Action = 'accountsDisbursed') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
            ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
            ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
            ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
            ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
            ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
            ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
            ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
            ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
            ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
            ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
            ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
            ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
            ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
            FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] 
            WHERE isJourneyActive=1 AND isLoanDisbursed=1 AND (MakerCBS_HigherTrancheByPass_By IS NULL OR CheckerApproveRejectMakerData_By IS NULL)`;
        }
        else if (Action = 'PendingForSchedular') {
          CustomQuery = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
              ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
              ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
              ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
              ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
              ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
              ,[EntryBy],[EntryDate],[ModifyBy],[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
              ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
              ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
              ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
              ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent],[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
              ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData],[CheckerActionOnMakerDataGivenBy]
              ,[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel],[JourneyInitiationReason],[isJourneyDowngrade]
              ,[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime],[JourneyDowngradeReason]
              FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] 
              WHERE isJourneyActive=1 AND isCustomerJourneyCompleted=1 AND isSchedularJourneyCompleted=0 AND (MakerNonMandatoryConsentGivenBy IS NULL OR CheckerActionOnMakerDataGivenBy IS NULL)`;
        }
      }
      else {
        if (Action = 'pickedUp') {
         // console.log('Yaha aaya');
          CustomQuery = `SELECT [JourneyID],A.[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
                            ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
                            ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                            ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
                            ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
                            ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
                            ,[EntryBy],A.[EntryDate],[ModifyBy],A.[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
                            ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
                            ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
                            ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
                            ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSAadharDataConsent],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent]
                            ,[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
                            ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData]
                            ,[CheckerActionOnMakerDataGivenBy],[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel]
                            ,[JourneyInitiationReason],[isJourneyDowngrade],[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime]
                            ,[JourneyDowngradeReason] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                            INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                            WHERE isJourneyRejected =0 and isJourneyActive=1`;
        }
        else if (Action = 'sanctioned') {
          CustomQuery = `SELECT [JourneyID],A.[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
                          ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
                          ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                          ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
                          ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
                          ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
                          ,[EntryBy],A.[EntryDate],[ModifyBy],A.[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
                          ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
                          ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
                          ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
                          ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSAadharDataConsent],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent]
                          ,[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
                          ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData]
                          ,[CheckerActionOnMakerDataGivenBy],[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel]
                          ,[JourneyInitiationReason],[isJourneyDowngrade],[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime]
                          ,[JourneyDowngradeReason] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                          INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                          WHERE isJourneyRejected =0 AND isJourneySanctioned=1 and isJourneyActive=1`;
        }
        else if (Action = 'rejected') {
          CustomQuery = `SELECT [JourneyID],A.[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
                          ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
                          ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                          ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
                          ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
                          ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
                          ,[EntryBy],A.[EntryDate],[ModifyBy],A.[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
                          ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
                          ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
                          ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
                          ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSAadharDataConsent],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent]
                          ,[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
                          ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData]
                          ,[CheckerActionOnMakerDataGivenBy],[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel]
                          ,[JourneyInitiationReason],[isJourneyDowngrade],[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime]
                          ,[JourneyDowngradeReason] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                          INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                          WHERE isJourneyRejected =1 and isJourneyActive=1`;
        }
        else if (Action = 'inProgress') {
          CustomQuery = `SELECT [JourneyID],A.[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
                          ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
                          ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                          ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
                          ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
                          ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
                          ,[EntryBy],A.[EntryDate],[ModifyBy],A.[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
                          ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
                          ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
                          ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
                          ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSAadharDataConsent],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent]
                          ,[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
                          ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData]
                          ,[CheckerActionOnMakerDataGivenBy],[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel]
                          ,[JourneyInitiationReason],[isJourneyDowngrade],[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime]
                          ,[JourneyDowngradeReason] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                          INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                          WHERE isJourneyRejected =0 and isJourneyActive=1`;
        }
        else if (Action = 'loanAccountOpened') {
          CustomQuery = `SELECT [JourneyID],A.[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
                          ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
                          ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                          ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
                          ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
                          ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
                          ,[EntryBy],A.[EntryDate],[ModifyBy],A.[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
                          ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
                          ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
                          ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
                          ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSAadharDataConsent],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent]
                          ,[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
                          ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData]
                          ,[CheckerActionOnMakerDataGivenBy],[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel]
                          ,[JourneyInitiationReason],[isJourneyDowngrade],[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime]
                          ,[JourneyDowngradeReason] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                          INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                          WHERE isJourneyRejected =0 and isLoanAccountOpened=1 and isJourneyActive=1`;
        }
        else if (Action = 'accountsDisbursed') {
          CustomQuery = `SELECT [JourneyID],A.[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
                          ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
                          ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                          ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
                          ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
                          ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
                          ,[EntryBy],A.[EntryDate],[ModifyBy],A.[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
                          ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
                          ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
                          ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
                          ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSAadharDataConsent],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent]
                          ,[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
                          ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData]
                          ,[CheckerActionOnMakerDataGivenBy],[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel]
                          ,[JourneyInitiationReason],[isJourneyDowngrade],[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime]
                          ,[JourneyDowngradeReason] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                          INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                          WHERE isJourneyRejected =0 and isLoanDisbursed=1 and isJourneyActive=1`;
        }
        else if (Action = 'PendingForSchedular') {
          CustomQuery = `SELECT [JourneyID],A.[PMSNumber],[AadhaarNo],A.[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone]
                          ,[JourneyMilestoneDesc],[ROI],[ROIAddsTwentyFiveBasis],[RLLR],[Spread],[ServiceCharge],[LoanTranche],[LoanAmount],[LoanTenure]
                          ,[EMI1],[EMI2],[TotalInterestAmount],[TotalPayableAmount],[CurrentStatus],[LORStatus],[EffectiveAvailBal],[CICRefID],[isCICCheckPassed]
                          ,[CICMessage],[isCIBILChargeCollected],[CIBILChargeTranNo],[CIBILChargeTime],[isJourneySanctioned],[JourneySanctionedDate]
                          ,[JourneyRejectedReason],[JourneyRejectedDate],[isStampChargeCollected],[StampChargeTranNo],[StampChargeTime],[isNeSLDigiSignAffixed]
                          ,[NeSLDigiSignAffixedMsg],[isBranchDigiSignAffixed],[isLoanAccountOpened],[LoanAccountNumber],[LoanAccountOpenDate]
                          ,[EntryBy],A.[EntryDate],[ModifyBy],A.[ModifyDate],[isJourneyActive],[isJourneyFailure],[JourneyFailureReason],[JourneyFailureTime],[isCustomerJourneyCompleted]
                          ,[CustomerJourneyCompletedTime],[isSIDBIDisbursementMark],[SIDBIDisbursementMarkTime],[SIDBIDisbursementMarkMessage],[IsSRMCreated],[SRMCreationRemarks]
                          ,[SRMCreationTime],[isLoanDisbursed],[LoanDisbursedTime],[LoanDisbursedRemarks],[isQRPushCode],[QRPushCodeTime],[QRPushCodeRemarks],[isSMSSent],[SMSSentTime]
                          ,[SMSSentRemarks],[isMailSent],[MailSentTime],[MailSentRemarks],[isCongratulationMsgSent],[isSchedularJourneyCompleted],[SchedulerJourneyCompletedTime]
                          ,[QRCodeGeneratedDate],[isQRCodeGenerated],[isMakerCBSAadharDataConsent],[isMakerCBSSidbiDataConsent],[isMakerHigherTrancheConsent]
                          ,[MakerNonMandatoryConsentGivenBy],[MakerNonMandatoryConsentGivenTime]
                          ,[isMakerCICConsent],[MakerCICConsentGivenBy],[MakerCICConsentGivenTime],[MakerCICConsentMessage],[isCheckerActionOnMakerData]
                          ,[CheckerActionOnMakerDataGivenBy],[CheckerActionOnMakerDataGivenTime],[CheckerActionOnMakerDataMessage],[JourneyInitiationChannel]
                          ,[JourneyInitiationReason],[isJourneyDowngrade],[JourneyDowngradeBy],[JourneyDowngradeUserSOL],[JourneyDowngradeTime]
                          ,[JourneyDowngradeReason] FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                          INNER JOIN SVND_CBS_CITY_KYC_STATUS B ON B.CustomerID=A.CustomerID
                          WHERE isJourneyRejected =0 and isCustomerJourneyCompleted=1 and isSchedularJourneyCompleted=0 and isJourneyActive=1`;
        }
      }
      // AND B.solid='216110'
      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .input('solid', sql.VarChar, deLoginResponse.UserSOL)
          .query(CustomQuery);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}









function InsertUpdate(strFormData) {
  console.log('********************Inside InsertUpdate Method **********************')
  console.log('strFormData ', strFormData);
  console.log('EmployeeID ', strFormData.EmployeeID);

  return new Promise(async (resolve, reject) => {
    try {
      var conn = new sql.ConnectionPool(config);
      conn.connect().then(function (pool) {
        var request = new sql.Request(pool);
        request.input('EmployeeID', sql.VarChar, strFormData.EmployeeID)
        request.input('Name', sql.VarChar, strFormData.Name);
        request.input('Designation', sql.VarChar, strFormData.Designation);
        request.input('CurrentSOLID', sql.VarChar, strFormData.CurrentSOLID);
        request.input('Address', sql.VarChar, strFormData.Address);
        request.input('MobileNumber', sql.VarChar, strFormData.MobileNumber);
        request.input('Status', sql.VarChar, strFormData.Status);
        request.input('UserRole', sql.VarChar, strFormData.UserRole);
        request.input('OperationType', sql.VarChar, strFormData.Action);
        request.execute('proc_ManagerUser', function (err, queryResult) {

          console.log('queryResult ', JSON.stringify(queryResult));
          console.log('err ', err);
          formattedString = {
            "ErrorCode": "00",
            "ErrorMsg": "Detail saved successfully"
          }
          resolve(formattedString);
        });
      });
    } catch (err1) {
      console.log(err1);
      //reject(err1);
	  formattedString = {
            "ErrorCode": "01",
            "ErrorMsg": "Detail could not be saved successfully"
          }
          resolve(formattedString);
    }
  });
}

function VerifyUpdate(EmployeeID, Status) {
  console.log('********************Inside VerifyUpdate Method **********************')
  console.log('Status ', Status);
  console.log('EmployeeID ', EmployeeID);

  console.log('**********************inside GetCustomerData Method**********************');

  return new Promise((resolve, reject) => {

    const query = `UPDATE SVND_ADMIN_USER_MASTER SET Status=@Status WHERE EmployeeID=@EmployeeID;`;

    try {

      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('EmployeeID', sql.VarChar, EmployeeID)
          .input('Status', sql.VarChar, Status)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        }
      });
    }
    catch (exception) {

    }
  });

}

function GetLoginVerify(decrypteduserID, token) {

  console.log('********************Inside GetLoginVerify Method **********************')
  const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
  // console.log(decrypteduserID );
  // console.log(token );
  // console.log(currentTime);
  return new Promise((resolve, reject) => {

    const query = ` INSERT INTO SVND_AdminSessions(userid, token, last_activity, status) VALUES (@decrypteduserID, @token, @currentTime, '1')`;
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {

        const result = await pool.request()
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);

          resolve(output);
        }
      });
    }
    catch (exception) {

    }
  });




}


function getEmployeeDetails(userId, CurrentSOL) {
  console.log('********************Inside getUserData Function**********************')
  let newCurrentSOL = '';
  if (CurrentSOL == '51750') {
    newCurrentSOL = '522800'
  }
  else {
    newCurrentSOL = CurrentSOL + '0';
  }


  console.log('********************Inside InsertUpdate Method **********************')
  console.log('userId ', userId);
  console.log('New Sol: ' + newCurrentSOL);
  return new Promise(async (resolve, reject) => {
    try {
      var conn = new sql.ConnectionPool(config);
      conn.connect().then(function (pool) {
        var request = new sql.Request(pool);
        request.input('PFNumber', sql.NVarChar, userId)
          .input('UserSOL', sql.VarChar, newCurrentSOL)
          .execute('proc_getEmployeeDetails', function (err, queryResult) {
            console.log('Result: ' + JSON.stringify(queryResult));
            //console.log('Result: '+JSON.stringify(queryResult.recordset[0]));
            if (queryResult.recordset != null) {
              conn.close();
              //  const jsonString = JSON.stringify(queryResult.recordset, null, 2);
              //  formattedString = jsonString.slice(1, -1);
              console.log('Final Result: ' + JSON.stringify(queryResult.recordset[0]));
              resolve(JSON.stringify(queryResult.recordset[0]));
            }
            else {
              conn.close();
              console.log("Error to get employee details");
              resolve(null);
            }
          });
      });
    } catch (err1) {
      console.log(err1);
      //reject(err1);
	  resolve(null);
    }
  });


  // console.log('New SOl: '+newCurrentSOL);
  // return new Promise((resolve, reject) => {

  //   const query = `WITH MaxGrade AS (
  //                   SELECT TOP 1 [GRADE]
  //                   FROM [DGold].[dbo].[EMPLOYEE_MASTER]
  //                   WHERE BRANCH_CODE = @CurrentSOL
  //                   ORDER BY CASE 
  //                               WHEN [GRADE] = 'S1' THEN 1
  //                               WHEN [GRADE] = 'S2' THEN 2
  //                               WHEN [GRADE] = 'S3' THEN 3
  //                               WHEN [GRADE] = 'S4' THEN 4
  //                               WHEN [GRADE] = 'S5' THEN 5
  //                               WHEN [GRADE] = 'S6' THEN 6
  //                               WHEN [GRADE] = 'S7' THEN 7
  //                               WHEN [GRADE] = 'S8' THEN 8
  //                               ELSE 0
  //                           END DESC
  //                   )
  //                   SELECT 
  //                       e.EMPLOYEE_ID,
  //                       e.BRANCH_CODE,     
  //                       e.EMPLOYEE_NAME, 
  //                       e.DESIGNATION,
  //                       e.MOBILE_NUMBER,
  //                       e.GRADE,
  //                       mg.[GRADE] AS MaxGrade,
  //                       CASE
  //                           WHEN e.Grade = mg.[Grade] THEN 'User has the max grade'
  //                           ELSE 'User does not have the max grade'
  //                       END AS ComparisonResult
  //                   FROM [DGold].[dbo].[EMPLOYEE_MASTER] e
  //                   CROSS JOIN MaxGrade mg
  //                   WHERE e.BRANCH_CODE = @CurrentSOL AND e.EMPLOYEE_ID = @UserID;`

  //   const conn = new sql.ConnectionPool(config);
  //   conn.connect().then(async (pool) => {

  //     const result = await pool.request()
  //     .input('UserID', sql.VarChar, userId)
  //     .input('CurrentSOL', sql.VarChar, newCurrentSOL)
  //     .query(query);
  //      if(result.recordset && result.recordset.length>0)
  //      {
  //         const jsonString = JSON.stringify(result.recordset, null, 2);
  //        output =jsonString.slice(1, -1); 
  //        resolve(output);
  //      }
  //      else{
  //        resolve(null);
  //      }
  //   });    
  // });

}

// all logs screen method here

function showErrorLogs(fromDate, toDate) {
  console.log('**********************inside     showErrorLogs Method**********************');

  return new Promise((resolve, reject) => {


    const query = `select PMSNumber,JourneyID,ErrorCode,ErrorDescription,LoggingStage,EntryDate from [PMSvanidhiDB].[dbo].[SVND_ERROR_LOG] WHERE EntryDate BETWEEN @fromDate AND @toDate;`
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        }
      });
    }
    catch (exception) {

    }
  });

}





function AadhaarErrorLogs(fromDate, toDate) {
  console.log('**********************inside    AadhaarErrorLogs Method**********************');

  return new Promise((resolve, reject) => {


    const query = `select AadhaarNo,PMSNumber,JourneyID,ReqRespCode,ReqRespDesc,ReqTxn,ReqCommunicationID,ReqEntryDate,RespResponseCode,RespResponseDesc,RespTxn,RespUIDDataPOACountry,RespUIDDataPOAPC,RespUIDDataPOAVTC,RespUIDDataPOAStreet,RespUIDDataPOADist,RespUIDDataPOAState,RespTS,RespUIDDataPOIDOB,RespUIDDataPOIName,RespUpdateDate from [PMSvanidhiDB].[dbo].[SVND_AADHAAR_API_REQUEST_RESPONSE] WHERE ReqEntryDate BETWEEN @fromDate AND @toDate;`
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          //  const jsonString = JSON.stringify(result.recordset, null, 2);
          //  output =jsonString.slice(1, -1);
          //  output=JSON.parse(output);
          resolve(output);
        }
      });
    }
    catch (exception) {

    }
  });

}


function getJourneyLogs(fromDate, toDate) {
  logger.info('**********************inside getJourneyLogs Method**********************');

  logger.info('From Date: ' + fromDate);
  logger.info('To Date: ' + toDate);

  return new Promise((resolve, reject) => {


    const query = `select PMSNumber,JourneyID,A.CustomerID,B.Cust_Full_Name,'APILogs' AS JourneyAPILogs,FORMAT(CAST(A.EntryDate AS DATE), 'dd-MM-yyyy') AS EntryDate FROM SVND_LOAN_JOURNEY_MASTER A
INNER JOIN SVND_CBS_CUSTOMER_DETAILS B ON B.CustomerID=A.CustomerID WHERE CONVERT(date,EntryDate) BETWEEN @fromDate AND @toDate`;
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('fromDate', sql.Date, fromDate)
          .input('toDate', sql.Date, toDate)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          //  const jsonString = JSON.stringify(result.recordset, null, 2);
          //  output =jsonString.slice(1, -1);
          //  output=JSON.parse(output);
          resolve(output);
        }
        else {
          resolve(null)
        }
      });
    }
    catch (exception) {

    }
  });

}

function getJourneyWiseAPILogs(PMSNumber, JourneyID, LogType) {
  console.log('**********************inside getJourneyWiseAPILogs Method**********************');

  logger.info('PMSNumber ' + PMSNumber);
  logger.info('JourneyID ' + JourneyID);
  logger.info('LogType ' + LogType);

  return new Promise((resolve, reject) => {

    let CustomQuery = '';

    if (LogType == "API Logs") {
      CustomQuery = `SELECT A.PMSNumber,A.JourneyID,CustomerID,CustomerName,B.RequestId,B.APIName,B.PlainRequest,convert(varchar(10), cast(B.RequestTime as date), 105) RequestTime,B.PlainResponse,convert(varchar(10), cast(B.ResponseTime as date), 105) ResponseTime 
                      FROM SVND_LOAN_JOURNEY_MASTER A
                      INNER JOIN SVND_ALL_API_REQUEST_RESPONSE_TRACKING B ON B.PMSNumber=A.PMSNumber AND B.JourneyID=A.JourneyID
                      WHERE A.PMSNumber=@PMSNumber AND A.JourneyID=@JourneyID
                      ORDER BY B.RequestId ASC`
    }
    else if (LogType == "Error Logs") {
      CustomQuery = `SELECT A.PMSNumber,A.JourneyID,CustomerID,CustomerName,B.RowID AS RequestId,B.LoggingStage AS APIName,(B.ErrorCode+' '+B.ErrorDescription) AS PlainRequest,convert(varchar(10), cast(B.EntryDate as date), 105)	 AS RequestTime,(B.ErrorCode +' '+ B.ErrorDescription) AS PlainResponse
                    ,convert(varchar(10), cast(B.EntryDate as date), 105) AS ResponseTime 
                    FROM SVND_LOAN_JOURNEY_MASTER A
                    INNER JOIN SVND_ERROR_LOG B ON B.PMSNumber=A.PMSNumber
                    WHERE A.PMSNumber=@PMSNumber AND A.JourneyID=@JourneyID
                    ORDER BY B.RowID ASC`
    }
    else if (LogType == "Cibil Logs") {
      CustomQuery = `
                      SELECT A.PMSNumber,A.JourneyID,CustomerName,B.ConsumerAPIRequest,convert(varchar(10), cast(B.ConsumerAPIRequestTime as date), 105) ConsumerAPIRequestTime
                      ,B.ConsumerAPIResponse,convert(varchar(10), cast(ConsumerAPIResponseTime as date), 105) AS ConsumerAPIResponseTime,B.ApplicationId,B.DocumentId,
                      B.ConsumerAPIDCRespStatus,B.DocumentAPIRequest,convert(varchar(10), cast( B.DocumentAPIRequestTime as date), 105) DocumentAPIRequestTime
                      ,B.DocumentAPIResponse,convert(varchar(10), cast(B.DocumentAPIResponseTime as date), 105) DocumentAPIResponseTime,B.DocumentAPIRespStatus 
                      FROM SVND_LOAN_JOURNEY_MASTER A
                      INNER JOIN SVND_CIBIL_REQUEST_RESPONSE B ON B.PMSNumber=A.PMSNumber
                      WHERE A.PMSNumber=@PMSNumber AND A.JourneyID=@JourneyID
                      ORDER BY B.CICRefID ASC
                      `
    }
    else {
      CustomQuery = `select PMSNumber,JourneyID,A.CustomerID,B.Cust_Full_Name,'APILogs' AS JourneyAPILogs,FORMAT(CAST(A.EntryDate AS DATE), 'dd-MM-yyyy') AS EntryDate FROM SVND_LOAN_JOURNEY_MASTER A
        INNER JOIN SVND_CBS_CUSTOMER_DETAILS B ON B.CustomerID=A.CustomerID`
    }

    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('PMSNumber', sql.VarChar, PMSNumber)
          .input('JourneyID', sql.VarChar, JourneyID)
          .query(CustomQuery);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          //  const jsonString = JSON.stringify(result.recordset, null, 2);
          //  output =jsonString.slice(1, -1);
          //  output=JSON.parse(output);
          resolve(output);
        }
        else {
          resolve(null)
        }
      });
    }
    catch (exception) {

    }
  });
}



function CibilErrorLogs(fromDate, toDate) {
  console.log('**********************inside     CibilErrorLogs Method**********************');

  return new Promise((resolve, reject) => {


    const query = `select PMSNumber,JourneyRefID,ConsumerAPIRequestTime,ConsumerAPIResponse,ConsumerAPIResponseTime,ApplicationId,DocumentId,ConsumerAPIDCRespStatus,ConsumerAPICibilBureauRespStatus,ConsumerAPIMessage,DocumentAPIRequestTime,DocumentAPIRespStatus,DocumentAPIMessage from [PMSvanidhiDB].[dbo].[SVND_CIBIL_REQUEST_RESPONSE] where CONVERT(date,ConsumerAPIRequestTime) BETWEEN @fromDate AND @toDate;`
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          //  const jsonString = JSON.stringify(result.recordset, null, 2);
          //  output =jsonString.slice(1, -1);
          //  output=JSON.parse(output);
          resolve(output);
        }
      });
    }
    catch (exception) {

    }
  });

}

function UserLoginTraceLogs(fromDate, toDate) {
  console.log('**********************inside     CibilErrorLogs Method**********************');
  return new Promise((resolve, reject) => {
    const query = `select JourneyID,PMSNumber,NeSL_Tran_ID,UnSign_EntryTime,NeSL_StatusCode,NeSL_StatusMsg,NeSL_eSignStatus,NeSL_eStampStatus,NeSL_eStampID,NeSL_SignatoryName,NeSL_MatchPercentage,NeSL_Document_ID,isPendingForNeSLeSign,NeSL_Resp_Time,isPendingForBankOfficialSign,Bank_Sign_Resp_Time from [PMSvanidhiDB].[dbo].[SVND_NESL_DOCUMENT] where CONVERT(date,UnSign_EntryTime) BETWEEN @fromDate AND @toDate;`
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          //  const jsonString = JSON.stringify(result.recordset, null, 2);
          //  output =jsonString.slice(1, -1);
          //  output=JSON.parse(output);
          resolve(output);
        }
      });
    }
    catch (exception) {
    }
  });
}

function logoutTrailUpdate(userID, OperationBy) {
  console.log('********************Inside logoutTrailUpdate Method **********************')
  console.log('USERID ', userID);
  return new Promise((resolve, reject) => {
    const DateTime = DatePart();
    logger.info('DateTime ' + DateTime);
    const query = `UPDATE SVND_USER_LOGIN_TRACE SET LOGOUTTIME=@LogoutTime,LogoutOperation=@OperationBy,IsAlreadyLogin=0 WHERE LOGINID=@userID and IsAlreadyLogin=1`;
    try {
      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .input('LogoutTime', sql.VarChar, DateTime)
          .input('OperationBy', sql.VarChar, OperationBy)
          .input('USERID', sql.VarChar, userID)
          .query(query);
        logger.info('recordset' + JSON.stringify(result));
        if (result.recordsets && result.rowsAffected[0] > 0) {
          jsonResp = {
            ErrorCode: "00",
            ErrorMsg: "Data Updated."
          }
          resolve(JSON.stringify(jsonResp));
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });
}

function DatePart() {
  const date = new Date();
  const day = (`0${date.getDate()}`).slice(-2);
  const month = (`0${date.getMonth() + 1}`).slice(-2);
  const year = date.getFullYear().toString().slice(-4);
  const hours = (`0${date.getHours()}`).slice(-2);
  const minutes = (`0${date.getMinutes()}`).slice(-2);
  const seconds = (`0${date.getSeconds()}`).slice(-2);
  return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
};

function GetEmployeeData(EmployeeID, Operation) {

  console.log('********************Inside GetEmployeeData Method **********************')
  console.log('Operation ' + Operation);
  let query;
  return new Promise((resolve, reject) => {
    try {
      if (Operation == 'VERIFY') {
        query = `SELECT  [EmployeeID],[Name],[Address],[Designation],[MobileNumber],[UserRole],[CurrentSOLID],[Status] FROM [PMSvanidhiDB].[dbo].[SVND_ADMIN_USER_MASTER]
           WHERE Status='Inactive'`;
      }
      else {
        query = `SELECT  [EmployeeID],[Name],[Address],[Designation],[MobileNumber],[UserRole],[CurrentSOLID],[Status] FROM [PMSvanidhiDB].[dbo].[SVND_ADMIN_USER_MASTER]
           WHERE EmployeeID=@EmployeeID`;
      }

      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {

        console.log('Query: ' + query);
        const result = await pool.request()
          .input('EmployeeID', sql.VarChar, EmployeeID)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        }
      });
    } catch (err1) {
      //reject(err1);
	  resolve(null);
    }
  });


}

function getUserSOL() {
  return new Promise((resolve, reject) => {
    const query = `SELECT  BRANCH_CODE + '_' + BRANCH AS BRANCH_NAME FROM [PMSvanidhiDB].[dbo].[SVND_BRANCH_MASTER] WHERE ZONE = 'HEAD OFFICE' and BRANCH_CODE='522800'`;
    const conn = new sql.ConnectionPool(config);
    conn.connect()
      .then(async (pool) => {
        try {
          // console.log('Query: ' + query);
          const result = await pool.request().query(query);
          if (result.recordset && result.recordset.length > 0) {
            let output = JSON.stringify(result.recordset);
            resolve(output);
          }

        } catch (queryErr) {
          console.error('Query error: ', queryErr);
          //reject(queryErr);
		  resolve(null);
        } finally {
          pool.close();
        }
      })
      .catch((connErr) => {
        console.error('Connection error: ', connErr);
        //reject(connErr);
		resolve(null);
      });
  });
}


function getUserDesignation() {
  console.log('**********************inside getUserDesignation Method**********************');

  return new Promise((resolve, reject) => {

    const query = `SELECT DISTINCT INCUMBENT_DESIGNATION FROM [PMSvanidhiDB].[dbo].[SVND_BRANCH_MASTER] WHERE ZONE = 'HEAD OFFICE' AND INCUMBENT_DESIGNATION IS NOT NULL;`;

    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {

        const result = await pool.request()

          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          resolve(output);
        } else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}



function GetCustomerTranchData(fromDate, toDate) {
  console.log('**********************inside   GetCustomerTranchData Method**********************');
  return new Promise((resolve, reject) => {

    const query = `SELECT IP_CODE AS CustomerID,ARNGMNT_NAME AS CustomerName,PAN,NAT_ID_CARD AS AadhaarLastSixDigit,ELIGIBLE_FOR_2ND_TRANCHNE,ELIGIBLE_FOR_3RD_TRANCHNE,DEL_FLG,EntryTime
  FROM SVND_MISD_SECOND_THIRD_ELIGIBILITY_DATA
  WHERE EntryTime BETWEEN  @fromDate AND @toDate`;

    try {
      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
          console.log(output)
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}




function getLoanJourneyData(deLoginResponse, JourneyType, fromDate, toDate) {
  console.log('**********************inside getLoanJourneyData Method**********************');
  console.log('solid: ' + deLoginResponse.UserSOL);
  console.log('JourneyType: ' + JourneyType);
  console.log('FromDate: ' + fromDate);
  console.log('ToDate: ' + toDate);

  let CustomerQuery = '';

  return new Promise((resolve, reject) => {
    if (JourneyType == "ADMIN_DIY_DASHBOARD") {
      CustomerQuery = `SELECT A.EntryDate,A.PMSNumber,A.CustomerID,JourneyID,A.MobileNo,A.JourneyMilestone,CONVERT(VARCHAR(10),A.JourneyMilestone)+'_'+A.JourneyMilestoneDesc AS JourneyStatusMilestone,A.LoanTranche,A.SchedulerJourneyCompletedTime,
      B.Cust_Full_Name,convert(varchar(10), cast(B.Date_of_Birth as date), 105) AS DOB ,D.BRANCH_CODE,D.DISTRICT, D.STATE
      FROM SVND_LOAN_JOURNEY_MASTER A
      INNER JOIN SVND_CBS_CUSTOMER_DETAILS B ON B.CustomerID=A.CustomerID
      INNER JOIN SVND_CBS_CITY_KYC_STATUS C ON C.CustomerID=B.CustomerID
      INNER JOIN SVND_BRANCH_MASTER D ON D.BRANCH_CODE=C.solid
                      WHERE A.EntryDate BETWEEN @fromDate AND @toDate AND A.MakerNonMandatoryConsentGivenBy IS NULL`;
    }
    else if (JourneyType == "ADMIN_BRANCH_DASHBOARD") {
      console.log('Welcome to HO User sol');
      CustomerQuery = `SELECT convert(varchar(10), cast(A.EntryDate as date), 105) EntryDate,A.PMSNumber,A.CustomerID,JourneyID,A.MobileNo,A.JourneyMilestone,CONVERT(VARCHAR(10),A.JourneyMilestone)+'_'+A.JourneyMilestoneDesc AS JourneyStatusMilestone,A.LoanTranche,A.SchedulerJourneyCompletedTime,
B.Cust_Full_Name,convert(varchar(10), cast(B.Date_of_Birth as date), 105) AS DOB ,D.BRANCH_CODE,D.DISTRICT, D.STATE,
(CASE WHEN A.JourneyMilestone!=108 THEN 'No loan Doc' ELSE 'Loan Document' END) AS DocName
FROM SVND_LOAN_JOURNEY_MASTER A
INNER JOIN SVND_CBS_CUSTOMER_DETAILS B ON B.CustomerID=A.CustomerID
INNER JOIN SVND_CBS_CITY_KYC_STATUS C ON C.CustomerID=B.CustomerID
INNER JOIN SVND_BRANCH_MASTER D ON D.BRANCH_CODE=C.solid
WHERE A.MakerNonMandatoryConsentGivenBy IS NOT NULL`;
    }
    else {
      CustomerQuery = `SELECT convert(varchar(10), cast(A.EntryDate as date), 105) EntryDate,A.PMSNumber,A.CustomerID,JourneyID,A.MobileNo,A.JourneyMilestone,CONVERT(VARCHAR(10),A.JourneyMilestone)+'_'+A.JourneyMilestoneDesc AS JourneyStatusMilestone,A.LoanTranche,A.SchedulerJourneyCompletedTime,
      B.Cust_Full_Name,convert(varchar(10), cast(B.Date_of_Birth as date), 105) AS DOB ,D.BRANCH_CODE,D.DISTRICT, D.STATE
      FROM SVND_LOAN_JOURNEY_MASTER A
      INNER JOIN SVND_CBS_CUSTOMER_DETAILS B ON B.CustomerID=A.CustomerID
      INNER JOIN SVND_CBS_CITY_KYC_STATUS C ON C.CustomerID=B.CustomerID
      INNER JOIN SVND_BRANCH_MASTER D ON D.BRANCH_CODE=C.solid
      WHERE A.solid=@UserSOL AND A.EntryDate BETWEEN @fromDate AND @toDate`;
      //AND C.solid='216110'
    }
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('UserSOL', sql.VarChar, deLoginResponse.UserSOL)
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(CustomerQuery);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        } else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}

function getSIDBISyncData(deLoginResponse, fromDate, toDate) {
  console.log('**********************inside getSIDBISyncData Method**********************');
  console.log('solid: ' + deLoginResponse.UserSOL);

  let CustomerQuery = '';

  return new Promise((resolve, reject) => {

    CustomerQuery = `SELECT App_PortalRefNo,Personal_ApplicantName,
convert(varchar(10), cast(Personal_ApplicantDOB as date), 105) AS Personal_ApplicantDOB
,Personal_MobileNo,CommAddr_Current_State,CommAddr_Current_TownDist,CommAddr_Current_PIN,CurrentStatus,Business_ProofOfVending_LoRStatus,App_ULBName,
App_LoanTerm,Loan_LoanAmountRequired_AmountValue, convert(varchar(10), cast(EntryDate as date), 105) AS EntryDate FROM SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA 
WHERE EntryDate BETWEEN @fromDate AND @toDate`;

    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {


        const result = await pool.request()
          .input('UserSOL', sql.VarChar, deLoginResponse.UserSOL)
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(CustomerQuery);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}


function GetCAMReportData(ApplicationNumber, JourneyID) {

  console.log('**********************inside GetCAMReportData Method**********************');
  console.log('ApplicationNumber', ApplicationNumber);
  console.log('JourneyID', JourneyID);
  return new Promise((resolve, reject) => {
    try {
      const query = `SELECT A.PMSNumber,A.JourneyID,A.AadhaarNo AS AadhaarNumber,FORMAT(CAST(A.EntryDate AS DATE), 'dd-MM-yyyy') AS ProposalStartDate,A.LoanAmount,A.LoanTranche,A.LoanTenure,FORMAT(CAST(A.JourneySanctionedDate AS DATE), 'dd-MM-yyyy') AS DigitalApprovalDate,FORMAT(CAST(G.NeSL_eSignDate AS DATE), 'dd-MM-yyyy') AS eSignEStampDate,
                  A.ROI,A.CICMessage,A.isCICCheckPassed,MakerCICConsentGivenBy,
                  A.isJourneyRejected,A.JourneyRejectedReason,A.LoanAccountNumber,FORMAT(CAST(A.LoanAccountOpenDate AS DATE), 'dd-MM-yyyy') LoanAccountOpenDate,FORMAT(CAST(A.LoanDisbursedTime AS DATE), 'dd-MM-yyyy') AS LoanDisbursedTime ,
                  C.MobileNo AS CBS_MobileNo,C.CustomerID AS CBS_CustomerID,C.AadharNO AS CBS_AadharNO,C.Date_of_Birth AS CBS_Date_of_Birth,
                  C.Cust_Full_Name AS CBS_CustName,C.F_H_Name AS CBS_FatherName,C.Mother_Name AS CBS_MotherName,C.Gender AS CBS_Gender,C.Email_ID AS CBS_EmailID,C.PANCard AS CBS_PAN,
                  (C.CommAddress_Address1+C.CommAddress_Address2) AS CBS_CommAddress,C.CommAddress_City AS CBS_CommAddress_City,
                  C.CommAddress_State AS CBS_CommAddress_State,C.CommAddress_PINCode AS CBS_CommAddress_PINCode,
                  (C.PermanentAddress_Address1+C.PermanentAddress_Address2) AS CBS_PermanentAddress,D.solid,F.BRANCH,B.App_PortalRefNo AS SIDBI_App_PortalRefNo,
                  FORMAT(CAST(B.App_ApplicationDate AS DATE), 'dd-MM-yyyy') AS SIDBI_App_ApplicationDate,B.App_LoanTerm AS SIDBI_App_LoanTerm,
                  B.Personal_ApplicantName AS SIDBI_Personal_ApplicantName,
                  B.Personal_ApplicantFatherName AS SIDBI_Personal_ApplicantFatherName,FORMAT(CAST(B.Personal_ApplicantDOB AS DATE), 'dd-MM-yyyy') AS SIDBI_Personal_ApplicantDOB,
                  B.Personal_MaritalStatus AS SIDBI_Personal_MaritalStatus,B.Personal_ApplicantGender AS SIDBI_Personal_ApplicantGender,B.Personal_MobileNo AS SIDBI_Personal_MobileNo,
                  B.Personal_KYC_AadhaarNo AS SIDBI_Personal_KYC_AadhaarNo,
                  (B.CommAddr_Current_HouseNo + B.CommAddr_Current_WardVillage) AS SIDBI_CurrentAddress,B.CommAddr_Current_TownDist AS SIDBI_CommAddr_Current_TownDist
                  ,B.CommAddr_Current_PIN AS SIDBI_CommAddr_Current_PIN,B.Business_VendingActivity_ActivityNameCode AS SIDBI_Business_VendingActivity_ActivityNameCode
                  ,B.App_ULBName AS SIDBI_App_ULBName,
                  B.CommAddr_Current_State AS SIDBI_CommAddr_Current_State,B.Verification_AadhaarBankAccount_BankName AS SIDBI_Verification_AadhaarBankAccount_BankName,
                  B.Verification_AadhaarBankAccount_IFSC  AS SIDBI_Verification_AadhaarBankAccount_IFSC,B.Verification_AadhaarBankAccount_AccountNo AS SIDBI_Verification_AadhaarBankAccount_AccountNo
                  ,B.Loan_LoanAmountRequired_AmountValue AS SIDBI_Loan_LoanAmountRequired_AmountValue,B.CurrentStatus AS SIDBI_CurrentStatus,
                  B.Business_ProofOfVending_LoRStatus AS SIDBI_Business_ProofOfVending_LoRStatus,
                  B.App_VendorCatagory AS SIDBI_App_VendorCatagory ,B.Verification_DigitalPayment_UPIID AS SIDBI_Verification_DigitalPayment_UPIID
                  FROM SVND_LOAN_JOURNEY_MASTER A
                  INNER JOIN SVND_SIDBI_CUSTOMER_ELIGIBILITY_DATA_CONSUMED B ON A.PMSNumber=B.App_PortalRefNo
                  INNER JOIN SVND_CBS_CUSTOMER_DETAILS C ON A.CustomerID=C.CustomerID
                  INNER JOIN SVND_CBS_CITY_KYC_STATUS D ON D.CustomerID=A.CustomerID
                  INNER JOIN SVND_BRANCH_MASTER F ON F.BRANCH_CODE=D.solid 
                  LEFT OUTER JOIN SVND_NESL_DOCUMENT G ON A.PMSNumber=G.PMSNumber AND A.JourneyID=G.JourneyID
                  WHERE A.PMSNumber=@ApplicationNumber AND A.JourneyID=@JourneyID AND isJourneyActive=1`;
      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .input('ApplicationNumber', sql.VarChar, ApplicationNumber)
          .input('JourneyID', sql.VarChar, JourneyID)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });
}


function GetCIBILReportData(ApplicationNumber, JourneyID) {
  console.log('**********************inside GetCIBILReportData Method**********************');
  console.log('ApplicationNumber', ApplicationNumber);

  return new Promise((resolve, reject) => {
    const query = `SELECT [DocumentByte] FROM [PMSvanidhiDB].[dbo].[SVND_CIBIL_REQUEST_RESPONSE] A
                INNER JOIN SVND_LOAN_JOURNEY_MASTER  B ON A.PMSNumber=B.PMSNumber AND A.JourneyRefID=B.JourneyID
                where B.PMSNumber=@ApplicationNumber AND B.JourneyID=@JourneyID AND B.isJourneyActive=1`;

    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {

        //       //console.log('Query: ' + query);
        const result = await pool.request()
          .input('ApplicationNumber', sql.VarChar, ApplicationNumber)
          .input('JourneyID', sql.VarChar, JourneyID)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);

          resolve(output);
        }
      });
    }
    catch (exception) {

    }
  });



}


function GetLoanDocument(PMSNumber,JourneyID) {
  console.log('**********************inside GetPMSCustomerDataShow Method**********************');
  console.log('PMSNumber', PMSNumber);
  console.log('JourneyID', JourneyID);
  return new Promise((resolve, reject) => {
    const query = `SELECT B.Signed_NeSL_Bank_Doc_Byte AS Signed_NeSL_Doc_Byte FROM SVND_LOAN_JOURNEY_MASTER A 
              INNER JOIN SVND_NESL_DOCUMENT B ON B.PMSNumber=A.PMSNumber AND B.JourneyID=A.JourneyID
              where A.PMSNumber=@PMSNumber AND A.JourneyID=@JourneyID AND isJourneyActive=1`;
    try {
      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .input('PMSNumber', sql.VarChar, PMSNumber)
          .input('JourneyID', sql.VarChar, JourneyID)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);

          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });



}


function getReconcilationData(deLoginResponse, JourneyType, fromDate, toDate) {
  console.log('**********************inside getReconcilationData Method**********************');
  console.log('solid: ' + deLoginResponse.UserSOL);
  console.log('JourneyType: ' + JourneyType);

  let CustomerQuery = "";
  return new Promise((resolve, reject) => {

    if (JourneyType == "ADMIN_DIY_DASHBOARD") {
      CustomerQuery = `SELECT A.PMSNumber AS SanctionNo,A.JourneyID,A.CurrentStatus,'PM Svanidhi' AS ProductName,'PNB' AS FirmName,'DELHI' AS StampExecutionState,
CASE WHEN  A.isStampChargeCollected=1 THEN '10' ELSE 'NA' END StampCharge, NeSL_Resp_Time, 
CASE WHEN  A.isStampChargeCollected=1 THEN 'Y' ELSE 'N' END StampChargeCollected
,B.NeSL_Tran_ID,B.NeSL_eStampDate,B.NeSL_eSignStatus,B.NeSL_eStampStatus,C.AccountNo,D.Cust_Full_Name FROM SVND_LOAN_JOURNEY_MASTER A
LEFT JOIN SVND_NESL_DOCUMENT B ON A.PMSNumber=B.PMSNumber AND A.JourneyID=B.JourneyID
LEFT JOIN SVND_CBS_CITY_KYC_STATUS C ON C.CustomerID=A.CustomerID
LEFT JOIN SVND_CBS_CUSTOMER_DETAILS D ON D.CustomerID=A.CustomerID
WHERE B.NeSL_Resp_Time BETWEEN @fromDate AND @toDate AND (A.MakerNonMandatoryConsentGivenBy IS NULL AND  A.CheckerActionOnMakerDataGivenBy IS NULL)	AND B.NeSL_Tran_ID IS NOT NULL`;
    }
    else if (JourneyType == "ADMIN_BRANCH_DASHBOARD") {
      console.log('Welcome ADMIN_BRANCH_DASHBOARD');
      CustomerQuery = `SELECT A.PMSNumber AS SanctionNo,A.JourneyID,A.CurrentStatus,'PM Svanidhi' AS ProductName,'PNB' AS FirmName,'DELHI' AS StampExecutionState,
CASE WHEN  A.isStampChargeCollected=1 THEN '10' ELSE 'NA' END StampCharge, NeSL_Resp_Time, 
CASE WHEN  A.isStampChargeCollected=1 THEN 'Y' ELSE 'N' END StampChargeCollected
,B.NeSL_Tran_ID,B.NeSL_eStampDate,B.NeSL_eSignStatus,B.NeSL_eStampStatus,C.AccountNo,D.Cust_Full_Name FROM SVND_LOAN_JOURNEY_MASTER A
LEFT JOIN SVND_NESL_DOCUMENT B ON A.PMSNumber=B.PMSNumber AND A.JourneyID=B.JourneyID
LEFT JOIN SVND_CBS_CITY_KYC_STATUS C ON C.CustomerID=A.CustomerID
LEFT JOIN SVND_CBS_CUSTOMER_DETAILS D ON D.CustomerID=A.CustomerID
WHERE (A.MakerNonMandatoryConsentGivenBy IS NOT NULL OR  A.CheckerActionOnMakerDataGivenBy IS NOT NULL) AND B.NeSL_Tran_ID IS NOT NULL`;
    }
    else {
      CustomerQuery = ``;
      // AND C.solid='216110'
    }
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {

        const result = await pool.request()
          .input('UserSOL', sql.VarChar, deLoginResponse.UserSOL)
          .input('fromDate', sql.VarChar, fromDate)
          .input('toDate', sql.VarChar, toDate)
          .query(CustomerQuery);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {

    }
  });

}


function GetBulkCICReport() {
  console.log('**********************inside GetBulkCICReport Method**********************');

  return new Promise((resolve, reject) => {

    const query = `select [DocumentName], [DocumentByte] from [PMSvanidhiDB].[dbo].[SVND_CIBIL_REQUEST_RESPONSE]`;

    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {

        const result = await pool.request()

          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          // const jsonString = JSON.stringify(result.recordset, null, 2);
          // output =jsonString.slice(1, -1);
          // output=JSON.parse(output);
          resolve(output);
        }
      });
    }
    catch (exception) {

    }
  });

}


function getPendingCheckerVerification() {
  console.log('**********************inside getPendingCheckerVerification Method**********************');

  return new Promise((resolve, reject) => {

    const query = `SELECT [JourneyID],[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone],[JourneyMilestoneDesc],[LoanTranche],isCheckerActionOnMakerData
,[LoanAmount],[LoanTenure],[isJourneyActive]FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] WHERE JourneyMilestone>=105  AND JourneyMilestone<108
AND isJourneyActive=1 AND isJourneyRejected=0 AND ((NeSLDDEStatus IS NULL AND isBranchUploadNeslFailedDoc=0) OR (NeSLDDEStatus='Failure' 
AND isBranchUploadNeslFailedDoc=1) OR (NeSLDDEStatus='Success' AND isBranchUploadNeslFailedDoc=0) )`;

    try {
      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {
      console.log('PendingCheckerVerification Exception ' + exception)
    }
  });
}

function getMakerChekerBypassFlags(PMSNumber, JourneyID) {
  console.log('**********************inside getMakerChekerBypassFlags Method**********************');
  return new Promise((resolve, reject) => {
    const query = `SELECT PMSNumber,JourneyID,AadhaarNo,CustomerID,isMakerCBSSidbiDataConsent,isMakerHigherTrancheConsent,isMakerCICConsent,MakerCICConsentMessage 
                       FROM SVND_LOAN_JOURNEY_MASTER WHERE PMSNumber=@PMSNumber AND JourneyID=@JourneyID and isJourneyActive=1`;
    try {
      const conn = new sql.ConnectionPool(config);

      conn.connect().then(async (pool) => {

        //       //console.log('Query: ' + query);
        const result = await pool.request()
          .input('PMSNumber', sql.VarChar, PMSNumber)
          .input('JourneyID', sql.VarChar, JourneyID)
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);

          resolve(output);
        }
      });
    }
    catch (exception) {
      console.log('PendingCheckerVerification Exception ' + exception)
    }
  });
}


function getNeslFailedApplications() {
  console.log('**********************inside getNeslFailedApplications Method**********************');

  return new Promise((resolve, reject) => {

    const query = `SELECT A.[JourneyID],A.[PMSNumber],[AadhaarNo],[CustomerID],[CustomerName],[MobileNo],[JourneyMilestone],[JourneyMilestoneDesc],A.[LoanTranche],isCheckerActionOnMakerData
                  ,[LoanAmount],[LoanTenure],[isJourneyActive],A.isBranchUploadNeslFailedDoc,B.BranchUploadDocumentName FROM [PMSvanidhiDB].[dbo].[SVND_LOAN_JOURNEY_MASTER] A
                  LEFT OUTER JOIN SVND_NESL_DOCUMENT B ON B.PMSNumber=A.PMSNumber AND B.JourneyID=A.JourneyID
                  WHERE JourneyMilestone=106 AND isJourneyActive=1 AND NeSLDDEStatus='Failure'`;

    try {
      const conn = new sql.ConnectionPool(config);
      conn.connect().then(async (pool) => {
        const result = await pool.request()
          .query(query);
        if (result.recordset && result.recordset.length > 0) {
          let output = JSON.stringify(result.recordset);
          resolve(output);
        }
        else {
          resolve(null);
        }
      });
    }
    catch (exception) {
      console.log('PendingCheckerVerification Exception ' + exception)
    }
  });
}














module.exports = { InsertUpdate, showErrorLogs, CibilErrorLogs, UserLoginTraceLogs, AadhaarErrorLogs, getJourneyLogs, getEmployeeDetails, VerifyUpdate, logoutTrailUpdate, GetLoginVerify, GetEmployeeData, GetCustomerTranchData, getUserSOL, getUserDesignation, getLoanJourneyData, GetCAMReportData, GetCIBILReportData, GetLoanDocument, getReconcilationData, GetBulkCICReport, BindDashboardData, EsignData, getPendingCheckerVerification, getMakerChekerBypassFlags, getSIDBISyncData, getJourneyWiseAPILogs, DashboardExcelDownload, getNeslFailedApplications };
