// //CIBILDataLayer.js
// const path = require('path');


process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';// Disable ssl check due to bank's proxy server


const express = require("express");
const axios = require('axios');
//const sql = require("mssql");
const app = express();
app.use(express.json())
var cors = require('cors')



const bodyParser = require('body-parser');
// const e = require("express");
// const { max } = require("rxjs");
const cookieParser = require('cookie-parser');
// const PDFDocument = require('pdfkit');
// const session = require('express-session');
// const MSSQLStore = require('connect-mssql-v2');
// const MySQLStore = require('express-mysql-session')(session); 
const CryptoJS = require('crypto-js');
const crypto = require('crypto');
const https = require('https');
// const { PassThrough } = require('stream');
const { HttpsProxyAgent } = require('https-proxy-agent');//for System Proxy
// const xmlBodyParser = require('express-xml-bodyparser');
// const xmljs = require('xml-js');
// const xmlbuilder = require('xmlbuilder');
const xml2js = require('xml2js');
// const puppeteer = require('puppeteer');

const fs = require('fs');

const os = require('os');

// const fs = require('fs');
// const path = require('path');

//const pdf = require('html-pdf');
// const pdf = require('pdf-creator-node');
const { Console } = require("console");

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('CibilDataLayer');
const logError = require('./ErrorLog');
const objSIDBILayer = require('./SIDBIDataLayer');
const objCIBILData = require('./CIBILDataLayer');
const objGeneralOperation = require('./GeneralDataLayer');
const objCBSLayer = require('./CBSDataLayer');

const objValueFirstDataLayer = require('./ValueFirstDataLayer');
const objCommonFunction = require('./CommonFunctions');
//const objAadhaarDataLayer = require('./AadhaarDataLayer');
 const objAadhaarDataLayer = require('./AadhaarDataLayer');

const ip = require('ip');
const { sql, getPool } = require('./db');

app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

// Middleware to handle application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware to handle text/xml
app.use(bodyParser.text({ type: 'text/xml' }));

// app.use(xmlBodyParser());
// Set up cookie parser middleware
app.use(cookieParser());

// SQL Server configuration

// var config = {
//    user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000
//   },
//   "options": {
//     "encrypt": false
//   }
// }


var config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};






// const proxyUser = '5216750';
// const proxyPass = 'Welcome#12345';
// const proxyHost = '10.192.34.167';
// const proxyPort = 3128;

// Construct correct proxy URL
//const proxyUrl = `http://${proxyUser}:${proxyPass}@${proxyHost}:${proxyPort}`;
//const agent = new HttpsProxyAgent(proxyUrl);




// SQUID PROXY USED IN PRODUCTION 'http://10.192.20.171:8001'

// Define your proxy URL (you can get this from environment variables or hardcode it)
const proxyUrl = process.env.HTTPS_PROXY || 'http://10.192.205.150:3128';  //http://corpoffice.pnb.net:3128 //http://10.192.34.167:3128 //http://dcproxy.pnb.net:3128
// Create a new agent instance
const ProxyAgent = new HttpsProxyAgent(proxyUrl);


// const agent = new https.Agent({
//    rejectUnauthorized: false, // Set to false to bypass certificate verification 
//    HttpsProxyAgent:proxyUrl 
// });
const httpAgent = new https.Agent({
  rejectUnauthorized: false, // Set to false to bypass certificate verification 

});

function isValidPAN(pan) {
  return /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan);
}

function isValidAadhaar(uid) {
  return /^[0-9]{12}$/.test(uid);
}

async function funCIBILRequestXML(CustomerDetails, PMSDetails, CutomerJourneyData) {
  logger.info('**************** Inside funCIBILRequestXML **********************');
  let userId = await GetKeyConfigurationValue('CIBIL_UserID');
  let password = await GetKeyConfigurationValue('CIBIL_Password');
  let SolutionSetId = await GetKeyConfigurationValue('CIBIL_SolutionSetID');
  let MemberCode = await GetKeyConfigurationValue('CIBIL_MemberCode');
  let MemPassword = await GetKeyConfigurationValue('CIBIL_MemberPassword');

  let NameArray = CustomerDetails.CustomerName.split(' ');

const FirstName = NameArray[0] || "";  // Assign FirstName if exists, else empty string
const MiddleName = NameArray[1] || (NameArray[2] ? NameArray[2] :"");  // If no MiddleName, assign LastName if it exists, else null
const LastName = NameArray[2] || "";   // Assign LastName if exists, else empty string



  // const FirstName = NameArray[0];
  // const MiddleName = NameArray[2] == null ? "" : NameArray[1];
  // const LastName = NameArray[2] == null ? NameArray[1] : NameArray[2];
  const AadhaarNo = CutomerJourneyData.AadhaarNo;
  const MobileNo = CustomerDetails.MobileNo;
  const DOB = CustomerDetails.Date_of_Birth.toString("ddMMyyyy");
  const CityName = CustomerDetails.CommCity;
  const Gender = CustomerDetails.Gender;
  const Address1 = CustomerDetails.CommAddr1;
  const PINCode = CustomerDetails.CommPINCode;
  const TotalLoan = CutomerJourneyData.LoanAmount;

  return new Promise((resolve, reject) => {
    try {
      let StateCode = 0;
      GetStateCode(CustomerDetails.CommState).then(async (objStateCode) => {
        logger.info("Response From State Code "+ JSON.stringify(objStateCode));
        StateCode = JSON.parse(objStateCode).StateCode;


        let IDType = '';
        let IDValue = ''

        // if (CustomerDetails.PANCard != null) {
          // IDType = '01';
          // IDValue = CustomerDetails.PANCard;
        // }
		// if (CustomerDetails.PANCard && CustomerDetails.PANCard.length === 10) {
		  // IDType = '01';
		  // IDValue = CustomerDetails.PANCard;
		// }
        // else {
          // IDType = '06';
          // IDValue = CutomerJourneyData.AadhaarNo;
        // }
		
		// ================= PAN =================
		  const pan = CustomerDetails?.PANCard?.toUpperCase()?.trim();
		  if (pan && isValidPAN(pan)) {
			 IDType= '01'; 
			 IDValue= pan ;
		  }
else {
		  // ================= AADHAAR =================
		  const aadhaarInput = CutomerJourneyData?.AadhaarNo?.trim();
		  if (!aadhaarInput) {
			throw new Error("No PAN or Aadhaar available");
		  }

		  // Case 1: Direct UID
		  if (isValidAadhaar(aadhaarInput)) {
			IDType= '06'; IDValue= aadhaarInput ;
		  }
else
		  // Case 2: refKey
		  if (aadhaarInput.length > 12) {
			const uid = await getUidByRefKeyOnce(aadhaarInput);
			 IDType= '06'; IDValue= uid ;
			 logger.info("Aadhaar NO "+ uid);
		  }
}
		
 logger.info("IDType: "+ IDType);
   
        //if (IDType != null && IDValue != null) {
			if (IDType && IDValue) {
          Request = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
                     <soapenv:Header/>
                     <soapenv:Body>
                         <tem:ExecuteXMLString>
                             <!--Optional:-->
                             <tem:request>
                                 <![CDATA[ 
                 
                 <DCRequest xmlns="http://transunion.com/dc/extsvc"><Authentication type="OnDemand"><UserId>${userId}</UserId><Password>${password}</Password></Authentication><RequestInfo><SolutionSetId>${SolutionSetId}</SolutionSetId><ExecuteLatestVersion>true</ExecuteLatestVersion><ExecutionMode>NewWithContext</ExecutionMode></RequestInfo><Fields><Field key="Applicants">
                 &lt;Applicants&gt;
                 &lt;Applicant&gt;
                 &lt;ApplicantType&gt;Main&lt;/ApplicantType&gt;
                 &lt;ApplicantFirstName&gt;${FirstName}&lt;/ApplicantFirstName&gt;
                 &lt;ApplicantMiddleName&gt;${MiddleName}&lt;/ApplicantMiddleName&gt;
                 &lt;ApplicantLastName&gt; ${LastName}&lt;/ApplicantLastName&gt;
                 &lt;DateOfBirth&gt;${DOB}&lt;/DateOfBirth&gt;
                 &lt;Gender&gt;${Gender}&lt;/Gender&gt;
                 &lt;EmailAddress&gt;&lt;/EmailAddress&gt;
                 &lt;CompanyName&gt;&lt;/CompanyName&gt;
                 &lt;Identifiers&gt;
                 &lt;Identifier&gt;
                 &lt;IdNumber&gt;${IDValue}&lt;/IdNumber&gt;
                 &lt;IdType&gt;${IDType}&lt;/IdType&gt;
                 &lt;/Identifier&gt;
                 &lt;/Identifiers&gt;
                 &lt;Telephones&gt;
                 &lt;Telephone&gt;
                 &lt;TelephoneExtension&gt;&lt;/TelephoneExtension&gt;
                 &lt;TelephoneNumber&gt;${MobileNo}&lt;/TelephoneNumber&gt;
                 &lt;TelephoneType&gt;01&lt;/TelephoneType&gt;
                 &lt;/Telephone&gt;
                 &lt;/Telephones&gt;
                 &lt;Addresses&gt;
                 &lt;Address&gt;
                 &lt;AddressLine1&gt;${Address1}&lt;/AddressLine1&gt;
                 &lt;AddressLine2&gt;&lt;/AddressLine2&gt;
                 &lt;AddressLine3&gt;&lt;/AddressLine3&gt;
                 &lt;AddressLine4&gt;&lt;/AddressLine4&gt;
                 &lt;AddressLine5&gt;&lt;/AddressLine5&gt;
                 &lt;AddressType&gt;01&lt;/AddressType&gt;
                 &lt;City&gt;${CityName}&lt;/City&gt;
                 &lt;PinCode&gt;${PINCode}&lt;/PinCode&gt;
                 &lt;ResidenceType&gt;01&lt;/ResidenceType&gt;
                 &lt;StateCode&gt;${StateCode}&lt;/StateCode&gt;
                 &lt;/Address&gt;
                 &lt;/Addresses&gt;
                 &lt;NomineeRelation&gt;&lt;/NomineeRelation&gt;
                 &lt;NomineeName&gt;&lt;/NomineeName&gt;
                 &lt;Accounts&gt;
                 &lt;Account&gt;
                 &lt;AccountNumber&gt;&lt;/AccountNumber&gt;
                 &lt;/Account&gt;
                 &lt;/Accounts&gt;
                 &lt;/Applicant&gt;
                 &lt;/Applicants&gt;</Field><Field key="ApplicationData">
                 &lt;ApplicationData&gt;
                 &lt;Purpose&gt;51&lt;/Purpose&gt;
                 &lt;Amount&gt;${TotalLoan}&lt;/Amount&gt;
                 &lt;ScoreType&gt;08&lt;/ScoreType&gt;
                 &lt;GSTStateCode&gt;${StateCode}&lt;/GSTStateCode&gt;
                 &lt;MemberCode&gt;${MemberCode}&lt;/MemberCode&gt;
                 &lt;Password&gt;${MemPassword}&lt;/Password&gt;
                 &lt;CibilBureauFlag&gt;False&lt;/CibilBureauFlag&gt;
                 &lt;DSTuNtcFlag&gt;True&lt;/DSTuNtcFlag&gt;
                 &lt;IDVerificationFlag&gt;True&lt;/IDVerificationFlag&gt;
                 &lt;MFIBureauFlag&gt;True&lt;/MFIBureauFlag&gt;
                 &lt;NTCProductType&gt;CDL&lt;/NTCProductType&gt;
                 &lt;ConsumerConsentForUIDAIAuthentication&gt;N&lt;/ConsumerConsentForUIDAIAuthentication&gt;
                 &lt;MFICenterReferenceNo&gt;&lt;/MFICenterReferenceNo&gt;
                 &lt;MFIBranchReferenceNo&gt;&lt;/MFIBranchReferenceNo&gt;
                 &lt;FormattedReport&gt;True&lt;/FormattedReport&gt;
                 &lt;/ApplicationData&gt;</Field></Fields></DCRequest>
                      ]]>
                 
                 </tem:request>
                 </tem:ExecuteXMLString>
                 </soapenv:Body>
                 </soapenv:Envelope>`;
				 
				 //logger.info('Request:\n '+Request);
          resolve(Request);
        }
        else {
          resolve(null);
        }
      });
    } catch (err1) {
        logger.info('error at funCIBILRequestXML as '+err1);
		resolve(null);
    }
  });
}

// async function funCIBILRequestXML(CustomerDetails, PMSDetails, CutomerJourneyData) {
  // logger.info('**************** Inside funCIBILRequestXML **********************');
  // let userId = await GetKeyConfigurationValue('CIBIL_UserID');
  // let password = await GetKeyConfigurationValue('CIBIL_Password');
  // let SolutionSetId = await GetKeyConfigurationValue('CIBIL_SolutionSetID');
  // let MemberCode = await GetKeyConfigurationValue('CIBIL_MemberCode');
  // let MemPassword = await GetKeyConfigurationValue('CIBIL_MemberPassword');

  // let NameArray = CustomerDetails.CustomerName.split(' ');

// const FirstName = NameArray[0] || "";  // Assign FirstName if exists, else empty string
// const MiddleName = NameArray[1] || (NameArray[2] ? NameArray[2] : null);  // If no MiddleName, assign LastName if it exists, else null
// const LastName = NameArray[2] || "";   // Assign LastName if exists, else empty string



  // // const FirstName = NameArray[0];
  // // const MiddleName = NameArray[2] == null ? "" : NameArray[1];
  // // const LastName = NameArray[2] == null ? NameArray[1] : NameArray[2];
  // const AadhaarNo = CutomerJourneyData.AadhaarNo;
  // const MobileNo = CustomerDetails.MobileNo;
  // const DOB = CustomerDetails.Date_of_Birth.toString("ddMMyyyy");
  // const CityName = CustomerDetails.CommCity;
  // const Gender = CustomerDetails.Gender;
  // const Address1 = CustomerDetails.CommAddr1;
  // const PINCode = CustomerDetails.CommPINCode;
  // const TotalLoan = CutomerJourneyData.LoanAmount;

  // return new Promise((resolve, reject) => {
    // try {
      // let StateCode = 0;
      // GetStateCode(CustomerDetails.CommState).then(async (objStateCode) => {
        // logger.info("Response From State Code", JSON.stringify(objStateCode));
        // StateCode = JSON.parse(objStateCode).StateCode;


        // let IDType = '';
        // let IDValue = ''

        // if (CustomerDetails.PANCard != null) {
          // IDType = '01';
          // IDValue = CustomerDetails.PANCard;
        // }
        // else {
          // IDType = '06';
          // IDValue = CutomerJourneyData.AadhaarNo;
        // }

                 // logger.info("IDType", IDType);
                 // logger.info("Aadhaar NO", CutomerJourneyData.AadhaarNo);
				   // logger.info("IDValue",   IDValue);

        // if (IDType != null && IDValue != null) {
          // Request = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
                     // <soapenv:Header/>
                     // <soapenv:Body>
                         // <tem:ExecuteXMLString>
                             // <!--Optional:-->
                             // <tem:request>
                                 // <![CDATA[ 
                 
                 // <DCRequest xmlns="http://transunion.com/dc/extsvc"><Authentication type="OnDemand"><UserId>${userId}</UserId><Password>${password}</Password></Authentication><RequestInfo><SolutionSetId>${SolutionSetId}</SolutionSetId><ExecuteLatestVersion>true</ExecuteLatestVersion><ExecutionMode>NewWithContext</ExecutionMode></RequestInfo><Fields><Field key="Applicants">
                 // &lt;Applicants&gt;
                 // &lt;Applicant&gt;
                 // &lt;ApplicantType&gt;Main&lt;/ApplicantType&gt;
                 // &lt;ApplicantFirstName&gt;${FirstName}&lt;/ApplicantFirstName&gt;
                 // &lt;ApplicantMiddleName&gt;${MiddleName}&lt;/ApplicantMiddleName&gt;
                 // &lt;ApplicantLastName&gt; ${LastName}&lt;/ApplicantLastName&gt;
                 // &lt;DateOfBirth&gt;${DOB}&lt;/DateOfBirth&gt;
                 // &lt;Gender&gt;${Gender}&lt;/Gender&gt;
                 // &lt;EmailAddress&gt;&lt;/EmailAddress&gt;
                 // &lt;CompanyName&gt;&lt;/CompanyName&gt;
                 // &lt;Identifiers&gt;
                 // &lt;Identifier&gt;
                 // &lt;IdNumber&gt;${IDValue}&lt;/IdNumber&gt;
                 // &lt;IdType&gt;${IDType}&lt;/IdType&gt;
                 // &lt;IdNumber&gt;&lt;/IdNumber&gt;
                 // &lt;IdType&gt;${IDType}&lt;/IdType&gt;
                 // &lt;/Identifier&gt;
                 // &lt;/Identifiers&gt;
                 // &lt;Telephones&gt;
                 // &lt;Telephone&gt;
                 // &lt;TelephoneExtension&gt;&lt;/TelephoneExtension&gt;
                 // &lt;TelephoneNumber&gt;${MobileNo}&lt;/TelephoneNumber&gt;
                 // &lt;TelephoneType&gt;01&lt;/TelephoneType&gt;
                 // &lt;/Telephone&gt;
                 // &lt;/Telephones&gt;
                 // &lt;Addresses&gt;
                 // &lt;Address&gt;
                 // &lt;AddressLine1&gt;${Address1}&lt;/AddressLine1&gt;
                 // &lt;AddressLine2&gt;&lt;/AddressLine2&gt;
                 // &lt;AddressLine3&gt;&lt;/AddressLine3&gt;
                 // &lt;AddressLine4&gt;&lt;/AddressLine4&gt;
                 // &lt;AddressLine5&gt;&lt;/AddressLine5&gt;
                 // &lt;AddressType&gt;01&lt;/AddressType&gt;
                 // &lt;City&gt;${CityName}&lt;/City&gt;
                 // &lt;PinCode&gt;${PINCode}&lt;/PinCode&gt;
                 // &lt;ResidenceType&gt;01&lt;/ResidenceType&gt;
                 // &lt;StateCode&gt;${StateCode}&lt;/StateCode&gt;
                 // &lt;/Address&gt;
                 // &lt;/Addresses&gt;
                 // &lt;NomineeRelation&gt;&lt;/NomineeRelation&gt;
                 // &lt;NomineeName&gt;&lt;/NomineeName&gt;
                 // &lt;Accounts&gt;
                 // &lt;Account&gt;
                 // &lt;AccountNumber&gt;&lt;/AccountNumber&gt;
                 // &lt;/Account&gt;
                 // &lt;/Accounts&gt;
                 // &lt;/Applicant&gt;
                 // &lt;/Applicants&gt;</Field><Field key="ApplicationData">
                 // &lt;ApplicationData&gt;
                 // &lt;Purpose&gt;51&lt;/Purpose&gt;
                 // &lt;Amount&gt;${TotalLoan}&lt;/Amount&gt;
                 // &lt;ScoreType&gt;08&lt;/ScoreType&gt;
                 // &lt;GSTStateCode&gt;${StateCode}&lt;/GSTStateCode&gt;
                 // &lt;MemberCode&gt;${MemberCode}&lt;/MemberCode&gt;
                 // &lt;Password&gt;${MemPassword}&lt;/Password&gt;
                 // &lt;CibilBureauFlag&gt;False&lt;/CibilBureauFlag&gt;
                 // &lt;DSTuNtcFlag&gt;True&lt;/DSTuNtcFlag&gt;
                 // &lt;IDVerificationFlag&gt;True&lt;/IDVerificationFlag&gt;
                 // &lt;MFIBureauFlag&gt;True&lt;/MFIBureauFlag&gt;
                 // &lt;NTCProductType&gt;CDL&lt;/NTCProductType&gt;
                 // &lt;ConsumerConsentForUIDAIAuthentication&gt;N&lt;/ConsumerConsentForUIDAIAuthentication&gt;
                 // &lt;MFICenterReferenceNo&gt;&lt;/MFICenterReferenceNo&gt;
                 // &lt;MFIBranchReferenceNo&gt;&lt;/MFIBranchReferenceNo&gt;
                 // &lt;FormattedReport&gt;True&lt;/FormattedReport&gt;
                 // &lt;/ApplicationData&gt;</Field></Fields></DCRequest>
                      // ]]>
                 
                 // </tem:request>
                 // </tem:ExecuteXMLString>
                 // </soapenv:Body>
                 // </soapenv:Envelope>`;
          // resolve(Request);
        // }
        // else {
          // resolve(null);
        // }
      // });
    // } catch (err1) {
      // logger.info('error at funCIBILRequestXML as '+err1);
	  // resolve(null);
    // }
  // });
// }


// function GetStateCode(CommStateName) {
  // logger.info('**************** Inside GetStateCode Method for State ' + CommStateName);
  // return new Promise((resolve, reject) => {
    // try {
      // const query = `SELECT StateCode,StateName FROM [PMSvanidhiDB].[dbo].[SVND_CIBIL_STATE_MASTER] WHERE StateName=@CommStateName`;
	  // const pool = await getPool();
	// const request = pool.request();

    // //  var conn = new sql.ConnectionPool(config);
     // // conn.connect().then(async function (pool) {
        // //     logger.info('Query: ' + query);                           
        // const result = await request
       // // const result = await pool.request()
          // .input('CommStateName', sql.VarChar, CommStateName)
          // .query(query);

        // const jsonString = JSON.stringify(result.recordset, null, 2);
        // formattedString = jsonString.slice(1, -1);
        // logger.info('GetStateCode results:', formattedString);
        // resolve(formattedString);
      // });
    // } catch (err1) {
      // reject(err1);
    // }
  // });
// }

function GetStateCode(CommStateName) {
  logger.info('**************** Inside GetStateCode Method for State ' + CommStateName);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        SELECT StateCode, StateName
        FROM [PMSvanidhiDB].[dbo].[SVND_CIBIL_STATE_MASTER]
        WHERE StateName = @CommStateName
      `;

      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('CommStateName', sql.VarChar, CommStateName)
        .query(query);

      if (result.recordset && result.recordset.length > 0) {
        const jsonString = JSON.stringify(result.recordset, null, 2);
        const formattedString = jsonString.slice(1, -1);
        logger.info('GetStateCode results:', formattedString);
        resolve(formattedString);
      } else {
        resolve(null);
      }

    } catch (err1) {
      logger.error('GetStateCode Error:', err1);
      reject(err1);
    }
  });
}


// function CIBILData_Insert(CICXMLRequest, PMSNo, JourneyID) {
  // logger.info('###################Inside CIBILRequest_Insert Method ###################');
  // logger.info('PMSNo: ' + PMSNo);
  // logger.info('JourneyIDg: ' + JourneyID);
  // return new Promise((resolve, reject) => {
    // try {
      // //const query = `INSERT INTO SVND_CIBIL_REQUEST_RESPONSE([PMSNumber],[ApplicationRefNo],[CICRequest],[CICRequestTime]) VALUES(@PMSNumber,@ApplicationRefNo,@CICRequest,@CICRequestTime)`;

      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('PMSNumber', sql.NVarChar, PMSNo)
          // .input('JourneyRefID', sql.VarChar, JourneyID)
          // .input('ConsumerAPIRequest', sql.VarChar(sql.MAX), CICXMLRequest)
          // .input('Operation', sql.VarChar, "Insert")
          // .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          // .execute('proc_CIBILData_InsertUpdate', function (err, queryResult) {
            // logger.info("queryResult: " + JSON.stringify(queryResult));
            // logger.info("Err: " + err);
            // if (queryResult.output.p_OutStatusCode == 200 && queryResult.rowsAffected[1] > 0) {
              // conn.close();
              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "CIBIL Request Inserted Successfully.",
              // }
              // resolve(response);
            // }
            // else {
              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": err
              // }
              // logger.info("Error while insert in database :- " + err);
              // resolve(response);
            // }
          // });
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }


function CIBILData_Insert(CICXMLRequest, PMSNo, JourneyID) {
  logger.info('################### Inside CIBILData_Insert Method ###################');
  logger.info('PMSNo: ' + PMSNo);
  logger.info('JourneyID: ' + JourneyID);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNo)
        .input('JourneyRefID', sql.VarChar, JourneyID)
        .input('ConsumerAPIRequest', sql.VarChar(sql.MAX), CICXMLRequest)
        .input('Operation', sql.VarChar, 'Insert')
        .output('p_OutStatusCode', sql.NVarChar)
        .execute('proc_CIBILData_InsertUpdate');

      logger.info('QueryResult: ' + JSON.stringify(result));
      logger.info('OutStatusCode: ' + result.output.p_OutStatusCode);

      if (
        result.output.p_OutStatusCode == '200' &&
        result.rowsAffected &&
        result.rowsAffected.length > 0 &&
        result.rowsAffected[0] > 0
      ) {
        resolve({
          "ErrorCode": "00",
          "ErrorMsg": "CIBIL Request Inserted Successfully."
        });
      } else {
        resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error inserting CIBIL request data"
        });
      }

    } catch (err) {
      logger.error('CIBILData_Insert Error:', err);
      reject(err);
    }
  });
}


// function PullConsumerCibilAPI(PMSNo, JourneyID, CICXMLRequest) {
  // logger.info('************************Inside PullConsumerCibilAPI Method ***************************');
  // logger.info('inside PullConsumerCibilAPI Called PMSNo: ' + PMSNo);

  // return new Promise(async (resolve, reject) => {
    // try {
      //const headers = {
        // 'SOAPAction': await GetKeyConfigurationValue('CIBIL_SoapAction_Consumer'),
        // 'Content-Type': 'text/xml',
      // }
      // logger.info("Headers " + headers);
      // const CIBIL_API_URL = await GetKeyConfigurationValue('CIBIL_API_URL')
     // // logger.info("API URL " + CIBIL_API_URL);
      // const Emptybody = "Call PULL CIBIL CONSUMER API";
      // if (CICXMLRequest != null) {
        // await axios.post(CIBIL_API_URL, CICXMLRequest, { headers, httpsAgent: ProxyAgent }).then(async CIBILAPIResp => {
          // if (JSON.stringify(CIBILAPIResp.data, null, 2) != null) {

           // // logger.info('SOAP XML START');
           // // logger.info('CIBIL SOAP XML Response: ', JSON.stringify(CIBILAPIResp.data, null, 2));
           // // logger.info('SOAP XML END');

            // //logger.info("XMLResp: "+xmlResp0);

            // const parser = new xml2js.Parser();
            // parser.parseString(CIBILAPIResp.data, (err, result) => {
              // if (err) {
                // console.error("Error parsing XML:", err);
              // } else {
               // // console.error('Yaha aaya');
                // const jsonObject = JSON.parse(JSON.stringify(result, null, 2));
                // //console.error("jsonObject:", jsonObject);
                // const executeResult1 = jsonObject['s:Envelope']['s:Body'][0]['ExecuteXMLStringResponse'][0]['ExecuteXMLStringResult'][0];
                // let executeResult = executeResult1.replace(/&gt;/g, '>').replace(/&lt;/g, '<');
                // logger.info("#########################################dcResponseXml#################################################");
                // //logger.info(`dcResponseXml:  ${executeResult} `);                  
                // if (executeResult) {
                  // // Parse the inner XML string (DCResponse)
                  // xml2js.parseString(executeResult, (err, dcResponseResult) => {
                    // if (err) {
                      // console.error("Error parsing inner XML:", err);
                    // } else {
                      // logger.info("#####################################DCResponse#####################################################");
                      // //logger.info(`Parsed DCResponse${ JSON.stringify(dcResponseResult)}`);
                      // // {"DCResponse":{"Status":["Failed"],"Authentication":[{"Status":["Ignore"]}],"ErrorInfo":[{"Message":["Ignore"]}]}}
                      // const dcResponse = dcResponseResult.DCResponse;
                                    // logger.info("Parsed DCResponse"     +JSON.stringify(dcResponse));
                      // // Accessing values
                      // logger.info(`- 2. dcResponse Status: ${dcResponse.Status}`);
                      // logger.info('- 1. Authentication:', JSON.stringify(dcResponse.Authentication));
                      // if (dcResponse.Status == "Success") {
                        // logger.info('Success DCResponse');


                       // // logger.info("DsCibilBureau Data:");
                        // logger.info(`0. ApplicationId: ${dcResponse.ResponseInfo[0].ApplicationId}`);
                        // // logger.info(`1. Request: ${dsCibilBureau.DsCibilBureauData[0].Request[0]}`);
                        // const dsCibilBureau = dcResponse.ContextData[0].Field[0].Applicants[0].Applicant[0].DsCibilBureau[0];
                        // //  logger.info(`2. Trail: ${dsCibilBureau.DsCibilBureauStatus[0].Trail[0]}`);
                        // logger.info(`3. CibilBureauResponse Is Success: ${dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0]}`);
                        // //logger.info(`4. Bureau Response Raw: ${dsCibilBureau.Response[0].CibilBureauResponse[0].BureauResponseRaw[0]}`);
                        // logger.info(`5. Bureau Response XML: ${dsCibilBureau.Response[0].CibilBureauResponse[0].BureauResponseXml[0]}`);
                        // logger.info(`6. Document ID: ${dsCibilBureau.Document[0].Id[0]}`);
                        // logger.info(`7. Document Name: ${dsCibilBureau.Document[0].Name[0]}`);
                        // // Parse the inner XML string (DCResponse)

                        // let executeResult2 = dsCibilBureau.Response[0].CibilBureauResponse[0].BureauResponseXml[0].replace(/&gt;/g, '>').replace(/&lt;/g, '<');
                   
                  

                        // //   let executeResult2='<CreditReport><Header><SegmentTag>TUEF</SegmentTag><Version>12</Version><ReferenceNumber>2351414365</ReferenceNumber><MemberCode>BN01147778_CIRC2CNPE          </MemberCode><SubjectReturnCode>1</SubjectReturnCode><EnquiryControlNumber>008205906379</EnquiryControlNumber><DateProcessed>07102024</DateProcessed><TimeProcessed>154614</TimeProcessed></Header><NameSegment><Length>03</Length><SegmentTag>N01</SegmentTag><ConsumerName1FieldLength>21</ConsumerName1FieldLength><ConsumerName1>SIMA BAPUPURI GOSWAMY</ConsumerName1><DateOfBirthFieldLength>08</DateOfBirthFieldLength><DateOfBirth>02031972</DateOfBirth><GenderFieldLength>01</GenderFieldLength><Gender>1</Gender></NameSegment><IDSegment><Length>03</Length><SegmentTag>I01</SegmentTag><IDType>01</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>DAOPG8480F</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I02</SegmentTag><IDType>03</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>ZHG6182324</IDNumber><EnrichedThroughEnquiry>Y</EnrichedThroughEnquiry></IDSegment><IDSegment><Length>03</Length><SegmentTag>I03</SegmentTag><IDType>04</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>ZHG6182323</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I04</SegmentTag><IDType>06</IDType><IDNumberFieldLength>12</IDNumberFieldLength><IDNumber>XXXXXXXXXXXX</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I05</SegmentTag><IDType>09</IDType><IDNumberFieldLength>14</IDNumberFieldLength><IDNumber>60035722828413</IDNumber></IDSegment><TelephoneSegment><Length>03</Length><SegmentTag>T01</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>9589017840</TelephoneNumber><TelephoneType>00</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T02</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7224812025</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T03</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>9770177122</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T04</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7441157883</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><EmailContactSegment><Length>03</Length><SegmentTag>C01</SegmentTag><EmailIDFieldLength>22</EmailIDFieldLength><EmailID>BABLUGODVAMI@GMAIL.COM</EmailID></EmailContactSegment><EmploymentSegment><Length>03</Length><SegmentTag>E01</SegmentTag><AccountType>39</AccountType><DateReportedCertified>31122023</DateReportedCertified><OccupationCode>01</OccupationCode></EmploymentSegment><ScoreSegment><Length>10</Length><ScoreName>CIBILTUSC3</ScoreName><ScoreCardName>08</ScoreCardName><ScoreCardVersion>10</ScoreCardVersion><ScoreDate>07102024</ScoreDate><Score>00653</Score><ReasonCode1FieldLength>02</ReasonCode1FieldLength><ReasonCode1>04</ReasonCode1><ReasonCode2FieldLength>02</ReasonCode2FieldLength><ReasonCode2>32</ReasonCode2><ReasonCode3FieldLength>02</ReasonCode3FieldLength><ReasonCode3>30</ReasonCode3><ReasonCode4FieldLength>02</ReasonCode4FieldLength><ReasonCode4>31</ReasonCode4><ReasonCode5FieldLength>02</ReasonCode5FieldLength><ReasonCode5>29</ReasonCode5><BureauCharacterstics></BureauCharacterstics></ScoreSegment><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A01</SegmentTag><AddressLine1FieldLength>23</AddressLine1FieldLength><AddressLine1>110 SHRIRAM COLONY NEAR</AddressLine1><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452001</PinCode><AddressCategory>02</AddressCategory><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A02</SegmentTag><AddressLine1FieldLength>39</AddressLine1FieldLength><AddressLine1>110 SHREE RAM NAGAR BIJASAN ROAD INDORE</AddressLine1><AddressLine2FieldLength>40</AddressLine2FieldLength><AddressLine2>INDORE INDORE INDORE INDORE (M CORP.   O</AddressLine2><AddressLine3FieldLength>02</AddressLine3FieldLength><AddressLine3>G)</AddressLine3><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452005</PinCode><AddressCategory>02</AddressCategory><ResidenceCode>01</ResidenceCode><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A03</SegmentTag><AddressLine1FieldLength>28</AddressLine1FieldLength><AddressLine1>BAPUPURI GOSVAMEE PUSP SHREE</AddressLine1><AddressLine2FieldLength>05</AddressLine2FieldLength><AddressLine2>HOTEL</AddressLine2><AddressLine3FieldLength>19</AddressLine3FieldLength><AddressLine3>AIRPORT ROAD INDORE</AddressLine3><AddressLine4FieldLength>06</AddressLine4FieldLength><AddressLine4>INDORE</AddressLine4><AddressLine5FieldLength>06</AddressLine5FieldLength><AddressLine5>INDORE</AddressLine5><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452005</PinCode><AddressCategory>01</AddressCategory><ResidenceCode>01</ResidenceCode><DateReported>13052019</DateReported><EnrichedThroughEnquiry>Y</EnrichedThroughEnquiry></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A04</SegmentTag><AddressLine1FieldLength>11</AddressLine1FieldLength><AddressLine1>HOUSE NO 73</AddressLine1><AddressLine2FieldLength>16</AddressLine2FieldLength><AddressLine2>PADMALAYA COLONY</AddressLine2><AddressLine3FieldLength>13</AddressLine3FieldLength><AddressLine3>BANGARDA ROAD</AddressLine3><AddressLine4FieldLength>06</AddressLine4FieldLength><AddressLine4>INDORE</AddressLine4><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452005</PinCode><AddressCategory>02</AddressCategory><ResidenceCode>01</ResidenceCode><DateReported>25042019</DateReported></Address><Account><Length>04</Length><SegmentTag>T001</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>17</AccountType><OwenershipIndicator>4</OwenershipIndicator><DateOpenedOrDisbursed>17092019</DateOpenedOrDisbursed><DateOfLastPayment>23072024</DateOfLastPayment><DateReportedAndCertified>31082024</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>225000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>04</CurrentBalanceFieldLength><CurrentBalance>5590</CurrentBalance><AmountOverdueFieldLength>05</AmountOverdueFieldLength><AmountOverdue>79068</AmountOverdue><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>075044074044013000074075075074075075075075074075072073</PaymentHistory1><PaymentHistory2FieldLength>54</PaymentHistory2FieldLength><PaymentHistory2>073075075074075075075075074075072073073075075074075075</PaymentHistory2><PaymentHistoryStartDate>01082024</PaymentHistoryStartDate><PaymentHistoryEndDate>01092021</PaymentHistoryEndDate><SuitFiledOrWilfulDefault>01</SuitFiledOrWilfulDefault><RepaymentTenureFieldLength>02</RepaymentTenureFieldLength><RepaymentTenure>48</RepaymentTenure><PaymentFrequency>03</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T002</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>02</AccountType><OwenershipIndicator>4</OwenershipIndicator><DateOpenedOrDisbursed>07102015</DateOpenedOrDisbursed><DateOfLastPayment>10082024</DateOfLastPayment><DateReportedAndCertified>31082024</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>07</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>1505005</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>07</CurrentBalanceFieldLength><CurrentBalance>1370696</CurrentBalance><AmountOverdueFieldLength>05</AmountOverdueFieldLength><AmountOverdue>28918</AmountOverdue><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>053052052022021022020053061052052052022083082052080050</PaymentHistory1><PaymentHistory2FieldLength>54</PaymentHistory2FieldLength><PaymentHistory2>019022022021000000000000000000000000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01082024</PaymentHistoryStartDate><PaymentHistoryEndDate>01092021</PaymentHistoryEndDate><ValueOfCollateralFieldLength>07</ValueOfCollateralFieldLength><ValueOfCollateral>1505005</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RepaymentTenureFieldLength>03</RepaymentTenureFieldLength><RepaymentTenure>318</RepaymentTenure><EmiAmountFieldLength>05</EmiAmountFieldLength><EmiAmount>13930</EmiAmount><PaymentFrequency>03</PaymentFrequency><ActualPaymentAmountFieldLength>05</ActualPaymentAmountFieldLength><ActualPaymentAmount>13930</ActualPaymentAmount></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T003</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>03</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>03</ReportingMemberShortNameFieldLength><ReportingMemberShortName>PNB</ReportingMemberShortName><AccountNumberFieldLength>16</AccountNumberFieldLength><AccountNumber>659500JZ00003840</AccountNumber><AccountType>39</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>30092023</DateOpenedOrDisbursed><DateOfLastPayment>27082024</DateOfLastPayment><DateClosed>04092024</DateClosed><DateReportedAndCertified>27092024</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>10000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>36</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000001001</PaymentHistory1><PaymentHistoryStartDate>01092024</PaymentHistoryStartDate><PaymentHistoryEndDate>01102023</PaymentHistoryEndDate><RateOfInterestFieldLength>05</RateOfInterestFieldLength><RateOfInterest>13.12</RateOfInterest><RepaymentTenureFieldLength>02</RepaymentTenureFieldLength><RepaymentTenure>12</RepaymentTenure><EmiAmountFieldLength>03</EmiAmountFieldLength><EmiAmount>833</EmiAmount><PaymentFrequency>03</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T004</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>51</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>08072021</DateOpenedOrDisbursed><DateOfLastPayment>14072023</DateOfLastPayment><DateClosed>31082023</DateClosed><DateReportedAndCertified>31102023</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>50000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>30</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01102023</PaymentHistoryStartDate><PaymentHistoryEndDate>01072021</PaymentHistoryEndDate></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T005</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>01</AccountType><OwenershipIndicator>4</OwenershipIndicator><DateOpenedOrDisbursed>27042019</DateOpenedOrDisbursed><DateOfLastPayment>01112019</DateOfLastPayment><DateClosed>31122019</DateClosed><DateReportedAndCertified>31012020</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>350000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>140354</CurrentBalance><AmountOverdueFieldLength>06</AmountOverdueFieldLength><AmountOverdue>144705</AmountOverdue><PaymentHistory1FieldLength>27</PaymentHistory1FieldLength><PaymentHistory1>000063033000000003002000000</PaymentHistory1><PaymentHistoryStartDate>01122019</PaymentHistoryStartDate><PaymentHistoryEndDate>01042019</PaymentHistoryEndDate><CreditFacility>02</CreditFacility></Account_NonSummary_Segment_Fields></Account><Enquiry><Length>04</Length><SegmentTag>I001</SegmentTag><DateOfEnquiryFields>14022024</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>300000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I002</SegmentTag><DateOfEnquiryFields>13122023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>110000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I003</SegmentTag><DateOfEnquiryFields>04112023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>100000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I004</SegmentTag><DateOfEnquiryFields>04112023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>100000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I005</SegmentTag><DateOfEnquiryFields>21102023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>700000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I006</SegmentTag><DateOfEnquiryFields>30092023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>03</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>PNB</EnquiringMemberShortName><EnquiryPurpose>06</EnquiryPurpose><EnquiryAmountFieldLength>05</EnquiryAmountFieldLength><EnquiryAmount>10000</EnquiryAmount></Enquiry><End><SegmentTag>ES07</SegmentTag><TotalLength>0002452</TotalLength></End></CreditReport>'



                        // //   let executeResult3='<CreditReport><Header><SegmentTag>TUEF</SegmentTag><Version>12</Version><ReferenceNumber>3467935901</ReferenceNumber><MemberCode>BN01149988_CIRC2CNPE</MemberCode><SubjectReturnCode>1</SubjectReturnCode><EnquiryControlNumber>010044164891</EnquiryControlNumber><DateProcessed>10122025</DateProcessed><TimeProcessed>175736</TimeProcessed></Header><NameSegment><Length>03</Length><SegmentTag>N01</SegmentTag><ConsumerName1FieldLength>11</ConsumerName1FieldLength><ConsumerName1>SURAJ SINGH</ConsumerName1><ConsumerName2FieldLength>12</ConsumerName2FieldLength><ConsumerName2>MAHRAJ SINGH</ConsumerName2><DateOfBirthFieldLength>08</DateOfBirthFieldLength><DateOfBirth>10061996</DateOfBirth><GenderFieldLength>01</GenderFieldLength><Gender>2</Gender></NameSegment><IDSegment><Length>03</Length><SegmentTag>I01</SegmentTag><IDType>01</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>JVXPS7726A</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I02</SegmentTag><IDType>06</IDType><IDNumberFieldLength>12</IDNumberFieldLength><IDNumber>XXXXXXXXXXXX</IDNumber></IDSegment><TelephoneSegment><Length>03</Length><SegmentTag>T01</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>8756668032</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T02</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7052342831</TelephoneNumber><TelephoneType>00</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T03</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7052342831</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><EmailContactSegment><Length>03</Length><SegmentTag>C01</SegmentTag><EmailIDFieldLength>20</EmailIDFieldLength><EmailID>CSCNIWAJPUR@MAIL.COM</EmailID></EmailContactSegment><EmailContactSegment><Length>03</Length><SegmentTag>C02</SegmentTag><EmailIDFieldLength>24</EmailIDFieldLength><EmailID>SURAJRAMAPUR99@GMAIL.COM</EmailID></EmailContactSegment><EmailContactSegment><Length>03</Length><SegmentTag>C03</SegmentTag><EmailIDFieldLength>14</EmailIDFieldLength><EmailID>NULL@GMAIL.COM</EmailID></EmailContactSegment><EmploymentSegment><Length>03</Length><SegmentTag>E01</SegmentTag><AccountType>53</AccountType><DateReportedCertified>31052024</DateReportedCertified><OccupationCode>03</OccupationCode><IncomeFieldLength>05</IncomeFieldLength><Income>50000</Income><NetGrossIndicator>G</NetGrossIndicator><MonthlyAnnualIndicator>A</MonthlyAnnualIndicator></EmploymentSegment><ScoreSegment><Length>10</Length><ScoreName>CIBILTUSC3</ScoreName><ScoreCardName>08</ScoreCardName><ScoreCardVersion>10</ScoreCardVersion><ScoreDate>10122025</ScoreDate><Score>00762</Score><BureauCharacterstics></BureauCharacterstics></ScoreSegment><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A01</SegmentTag><AddressLine1FieldLength>21</AddressLine1FieldLength><AddressLine1>VILL AND POST RAMAPUR</AddressLine1><AddressLine2FieldLength>22</AddressLine2FieldLength><AddressLine2>BARKATPUR SHAHJAHANPUR</AddressLine2><AddressLine5FieldLength>12</AddressLine5FieldLength><AddressLine5>SHAHJAHANPUR</AddressLine5><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242306</PinCode><AddressCategory>02</AddressCategory><DateReported>31012024</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A02</SegmentTag><AddressLine1FieldLength>38</AddressLine1FieldLength><AddressLine1>RAMAPUR BARKATPUR PO RAMAPUR BARKATPUR</AddressLine1><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242001</PinCode><AddressCategory>02</AddressCategory><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A03</SegmentTag><AddressLine1FieldLength>38</AddressLine1FieldLength><AddressLine1>RAMAPUR BARKATPUR PO RAMAPUR BARKATPUR</AddressLine1><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242001</PinCode><AddressCategory>01</AddressCategory><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A04</SegmentTag><AddressLine1FieldLength>39</AddressLine1FieldLength><AddressLine1>RAMAPUR VARKATPUR SHAHJAHANPUR NR UNANI</AddressLine1><AddressLine2FieldLength>37</AddressLine2FieldLength><AddressLine2>HOSPITAL  SHAHJAHANPUR  UTTAR PRADESH</AddressLine2><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242306</PinCode><AddressCategory>02</AddressCategory><ResidenceCode>02</ResidenceCode><DateReported>31072021</DateReported></Address><Account><Length>04</Length><SegmentTag>T001</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>53</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>27052024</DateOpenedOrDisbursed><DateOfLastPayment>08052025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>150000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>150000</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>03</PaymentHistory2FieldLength><PaymentHistory2>000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01052024</PaymentHistoryEndDate><ValueOfCollateralFieldLength>06</ValueOfCollateralFieldLength><ValueOfCollateral>200000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.25</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T002</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>37</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>05042024</DateOpenedOrDisbursed><DateOfLastPayment>12102025</DateOfLastPayment><DateClosed>15102025</DateClosed><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>50000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>06</PaymentHistory2FieldLength><PaymentHistory2>000000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01042024</PaymentHistoryEndDate></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T003</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>10</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>18112023</DateOpenedOrDisbursed><DateOfLastPayment>11112025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>77356</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>05</CurrentBalanceFieldLength><CurrentBalance>72799</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>21</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01112023</PaymentHistoryEndDate><CreditLimitFieldLength>05</CreditLimitFieldLength><CreditLimit>75000</CreditLimit></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T004</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>36</AccountType><OwenershipIndicator>3</OwenershipIndicator><DateOpenedOrDisbursed>28062023</DateOpenedOrDisbursed><DateOfLastPayment>17062025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>242000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>161353</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000STD</PaymentHistory1><PaymentHistory2FieldLength>36</PaymentHistory2FieldLength><PaymentHistory2>000000000000000STDSTDSTDSTDSTDSTDSTD</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01062023</PaymentHistoryEndDate><ValueOfCollateralFieldLength>06</ValueOfCollateralFieldLength><ValueOfCollateral>500000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.00</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T005</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>36</AccountType><OwenershipIndicator>3</OwenershipIndicator><DateOpenedOrDisbursed>28062023</DateOpenedOrDisbursed><DateOfLastPayment>17062025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>186000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>124203</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000STD</PaymentHistory1><PaymentHistory2FieldLength>36</PaymentHistory2FieldLength><PaymentHistory2>000000000000000STDSTDSTDSTDSTDSTDSTD</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01062023</PaymentHistoryEndDate><ValueOfCollateralFieldLength>06</ValueOfCollateralFieldLength><ValueOfCollateral>500000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.00</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T006</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>10</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>12042023</DateOpenedOrDisbursed><DateOfLastPayment>11082025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>74681</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>42</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000000000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01042023</PaymentHistoryEndDate><CreditLimitFieldLength>05</CreditLimitFieldLength><CreditLimit>75000</CreditLimit></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T007</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>36</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>24112022</DateOpenedOrDisbursed><DateOfLastPayment>04052025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>167200</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>113258</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>54</PaymentHistory2FieldLength><PaymentHistory2>000000000000000STDSTDSTDSTDSTDSTDSTDSTDSTDSTDSTDSTDSTD</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01122022</PaymentHistoryEndDate><ValueOfCollateralFieldLength>07</ValueOfCollateralFieldLength><ValueOfCollateral>1578000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.00</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T008</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>06</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>21072021</DateOpenedOrDisbursed><DateClosed>02022022</DateClosed><DateReportedAndCertified>30042023</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>10197</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>12</PaymentHistory2FieldLength><PaymentHistory2>000000000000</PaymentHistory2><PaymentHistoryStartDate>01042023</PaymentHistoryStartDate><PaymentHistoryEndDate>01072021</PaymentHistoryEndDate><RepaymentTenureFieldLength>01</RepaymentTenureFieldLength><RepaymentTenure>7</RepaymentTenure><EmiAmountFieldLength>04</EmiAmountFieldLength><EmiAmount>1700</EmiAmount><PaymentFrequency>03</PaymentFrequency><ActualPaymentAmountFieldLength>03</ActualPaymentAmountFieldLength><ActualPaymentAmount>500</ActualPaymentAmount></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T009</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>13</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>27012017</DateOpenedOrDisbursed><DateOfLastPayment>25122018</DateOfLastPayment><DateClosed>08012019</DateClosed><DateReportedAndCertified>06022019</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>38152</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000026000000000</PaymentHistory1><PaymentHistory2FieldLength>18</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01012019</PaymentHistoryStartDate><PaymentHistoryEndDate>01022017</PaymentHistoryEndDate><RateOfInterestFieldLength>05</RateOfInterestFieldLength><RateOfInterest>22.83</RateOfInterest><RepaymentTenureFieldLength>02</RepaymentTenureFieldLength><RepaymentTenure>18</RepaymentTenure><EmiAmountFieldLength>04</EmiAmountFieldLength><EmiAmount>2541</EmiAmount><PaymentFrequency>03</PaymentFrequency><ActualPaymentAmountFieldLength>05</ActualPaymentAmountFieldLength><ActualPaymentAmount>50088</ActualPaymentAmount></Account_NonSummary_Segment_Fields></Account><Enquiry><Length>04</Length><SegmentTag>I001</SegmentTag><DateOfEnquiryFields>17022025</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>02</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>500000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I002</SegmentTag><DateOfEnquiryFields>24052024</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>53</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>150000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I003</SegmentTag><DateOfEnquiryFields>27022024</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>36</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>100000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I004</SegmentTag><DateOfEnquiryFields>27062023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>53</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>186000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I005</SegmentTag><DateOfEnquiryFields>12042023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>10</EnquiryPurpose><EnquiryAmountFieldLength>04</EnquiryAmountFieldLength><EnquiryAmount>1000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I006</SegmentTag><DateOfEnquiryFields>23022023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>10</EnquiryPurpose><EnquiryAmountFieldLength>04</EnquiryAmountFieldLength><EnquiryAmount>1000</EnquiryAmount></Enquiry><End><SegmentTag>ES07</SegmentTag><TotalLength>0003241</TotalLength></End></CreditReport>'
                        // // //logger.info("executeResult2 " + executeResult2)
                      
                        // xml2js.parseString(executeResult2, (err, result) => {
                          // if (err) {
                            // console.error(`Error parsing inner XML: ${err}`);
                          // }
                          // else {
                            // logger.info(`BureauResponseXml result:  ${JSON.stringify(result)}`);
                            
                                               

                            // logger.info(`BureauResponseXml resultHIIIIIIIIIII:  ${dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0]}`);
                             // if (dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0] == "True") 
                          // {
                              // logger.info(`9. Yaha Chala Gaya`);
                              // let ErrorCode = '';
                              // let ErrorMessage = '';
                            // //  logger.info(`0 CIBILData_Update`);
                              // CIBILData_Update(PMSNo, JourneyID, CIBILAPIResp.data, dcResponse.ResponseInfo[0].ApplicationId, dsCibilBureau.Document[0].Id[0], dsCibilBureau.Document[0].Name[0], dcResponse.Status.toString(), dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0], JSON.stringify(result), "ConsumerRespUpdate", null, ErrorCode, ErrorMessage).then(async (CIBILReqUpdate) => {

                                // // xml2js.parseString(results, (err, result) => {
                                // //   if (err) {
                                // //     console.error("Error parsing XML:", err);
                                // //     return;
                                // //   }

                               // // logger.info(`Stage result 1${result}`);
                               // // logger.info(`Stage result.CreditReport.Account.length 1${result.CreditReport.Account.length}`);   
                               // //  logger.info(`Stage result.CreditReport 1${result.CreditReport}`);   
                                // // logger.info(`Stage result.CreditReport.Account 1${result.CreditReport.Account}`);
                                // if (result && result.CreditReport && result.CreditReport.Account && result.CreditReport.Account.length) {
                                  // logger.info(`if true hua`);
                                  // logger.info(`Stage 2 with length: ${result.CreditReport.Account.length}`);
                                  // for (var i = 0; i < result.CreditReport.Account.length; i++) {
                                    // logger.info("Stage 3");
                                    // var accFields = result.CreditReport.Account[i].Account_NonSummary_Segment_Fields[0];
                                    // logger.info("accFields: " + JSON.stringify(accFields));
                                    // logger.info("CreditFacility Value: " + accFields.CreditFacility);
                                    // logger.info("AccountType Value: " + accFields.AccountType[0]);
                                    // if (accFields.CreditFacility) {
                                      // logger.info("Inside CreditFacility Value: " + accFields.CreditFacility);
                                      // if (accFields.CreditFacility == "00") {
                                        // logger.info(`Stage 00  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Restructured Loan"
                                        // }
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "01") {
                                        // logger.info(`Stage 01  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Restructured Loan (Govt.Mandated)"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Restructured Loan (Govt.Mandated)';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "02") {
                                        // logger.info(`Stage 02  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Written-off"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Written-off';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "03") {
                                        // logger.info(`inner Stage 03  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Settled"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Settled';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "04") {
                                        // logger.info(`Stage 04  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Post (WO) Settled"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Post (WO) Settled';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "05") {
                                        // logger.info(`Stage 05  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Account Sold"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Account Sold';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "06") {
                                        // logger.info(`Stage 06  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Written Off and Account Sold"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Written Off and Account Sold';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "07") {
                                        // logger.info(`Stage 07  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Account Purchased"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Account Purchased';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "08") {
                                        // logger.info(`Stage 08  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Account Purchased and Written Off"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Account Purchased and Written Off';
                                        // resolve(respObj);                         
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "09") {
                                        // logger.info(`Stage 09  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Account Purchased and Settled"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Account Purchased and Settled';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "10") {
                                        // logger.info(`Stage 10  ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Account Purchased and Restructured"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Account Purchased and Restructured';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "11") {
                                        // logger.info(`Stage 11 ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Restructured due to Natural Calamity"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Restructured due to Natural Calamity';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "12") {
                                        // logger.info(`Stage 12 ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Restructured due to COVID-19"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Restructured due to COVID-19';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "13") {
                                        // logger.info(`Stage 13 ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Post Write Off Closed"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Post Write Off Closed';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "14") {
                                        // logger.info(`Stage 14 ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Restructured and Closed"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Restructured and Closed';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "15") {
                                        // logger.info(`Stage 15 ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Auctioned and Settled"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Auctioned and Settled';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "16") {
                                        // logger.info(`Stage 16 ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Repossessed and Settled"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Repossessed and Settled';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                      // else if (accFields.CreditFacility == "17") {
                                        // logger.info(`Stage 17 ${accFields.CreditFacility}`);
                                        // respObj = {
                                          // "ErrorCode": "02",
                                          // "ErrorMsg": "Credit Facility: Guarantee Invoked"
                                        // }
                                        // ErrorCode = '02';
                                        // ErrorMessage = 'Credit Facility: Guarantee Invoked';
                                        // resolve(respObj);
                                        // break;
                                      // }
                                    // }
                                    // else if (accFields.SuitFiledOrWilfulDefault && accFields.SuitFiledOrWilfulDefault[0] != '00') {
                                      // logger.info("Stage 5 " + accFields.SuitFiledOrWilfulDefault);
                                      // respObj = {
                                        // "ErrorCode": "02",
                                        // "ErrorMsg": "Error due to SuitFiledOrWilfulDefault : " + accFields.SuitFiledOrWilfulDefault + " " + accFields.SuitFiledOrWilfulDefault[0]
                                      // }
                                      // ErrorCode = '02';
                                      // ErrorMessage = "Error due to SuitFiledOrWilfulDefault : " + accFields.SuitFiledOrWilfulDefault + " " + accFields.SuitFiledOrWilfulDefault[0];
                                      // resolve(respObj);
                                      // break;
                                    // }
                                    // else if (accFields.PaymentHistory1) {
                                      // logger.info("PaymentHistory1 Stage 6 " + accFields.PaymentHistory1[0]);
                                      // //logger.info(i, accFields.PaymentHistory1[0]);
                                      // if (accFields.PaymentHistory1[0]) {
                                        // for (var j = 0; j < accFields.PaymentHistory1FieldLength[0]; j = j + 3) {
                                          // var temp = accFields.PaymentHistory1[0].substring(j, j + 3);
                                          // logger.info("PaymentHistory1: " + temp);
                                          // if (temp > 90 || temp == 'LSS' || temp == 'DBT' || temp == 'SUB') {
                                            // respObj = {
                                              // "ErrorCode": "02",
                                              // "ErrorMsg": "Error due to Payment history 1 for NPA account : " + temp,
                                            // }
                                            // ErrorCode = '02';
                                            // ErrorMessage = "Error due to Payment history 1 for NPA account : " + temp;
                                            // resolve(respObj);
                                            // break;
                                          // }
                                          // else {
                                            // if (result.CreditReport.Account.length > 1) {
                                              // continue;
                                            // }
                                            // else {
                                              // respObj = {
                                                // "ErrorCode": "00",
                                                // "ErrorMsg": "No issue found in customer CIBIL",
                                              // }
                                              // ErrorCode = '00';
                                              // ErrorMessage = "No issue found in customer CIBIL";
                                              // resolve(respObj);
                                            // }
                                          // }
                                        // }
                                      // }
                                    // }
                                    // else if (accFields.PaymentHistory2) {
                                      // logger.info("PaymentHistory2 Stage 7 " + accFields.PaymentHistory2[0]);
                                      // logger.info(i, accFields.PaymentHistory2[0]);
                                      // if (accFields.PaymentHistory2[0]) {
                                        // for (var j = 0; j < accFields.PaymentHistory2FieldLength[0]; j = j + 3) {
                                          // var temp = accFields.PaymentHistory2[0].substring(j, j + 3);
                                          // logger.info("PaymentHistory2" + temp);
                                          // if (temp > 90 || temp == 'LSS' || temp == 'DBT' || temp == 'SUB') {
                                            // respObj = {
                                              // "ErrorCode": "02",
                                              // "ErrorMsg": "Error due to Payment history 2 for NPA account : " + temp,
                                            // }
                                            // ErrorCode = '02';
                                            // ErrorMessage = "Error due to Payment history 2 for NPA account : " + temp;
                                            // resolve(respObj);
                                            // break;
                                          // }
                                          // else {
                                            // if (result.CreditReport.Account.length > 1) {
                                              // continue;
                                            // }
                                            // else {
                                              // respObj = {
                                                // "ErrorCode": "00",
                                                // "ErrorMsg": "No issue found in customer CIBIL",
                                              // }
                                              // ErrorCode = '00';
                                              // ErrorMessage = "No issue found in customer CIBIL";
                                              // resolve(respObj);
                                            // }
                                          // }
                                        // }
                                      // }
                                    // }
                                    // else if ((accFields.AccountType[0] == '09' && !accFields.DateClosed) || (accFields.AccountType[0] == '11' && !accFields.DateClosed) || (accFields.AccountType[0] == '12' && !accFields.DateClosed) || (accFields.AccountType[0] == '14' && !accFields.DateClosed) || (accFields.AccountType[0] == '17' && !accFields.DateClosed) || (accFields.AccountType[0] == '18' && !accFields.DateClosed) || (accFields.AccountType[0] == '19' && !accFields.DateClosed) || (accFields.AccountType[0] == '20' && !accFields.DateClosed) || (accFields.AccountType[0] == '23' && !accFields.DateClosed) || (accFields.AccountType[0] == '24' && !accFields.DateClosed) || (accFields.AccountType[0] == '33' && !accFields.DateClosed) || (accFields.AccountType[0] == '38' && !accFields.DateClosed) || (accFields.AccountType[0] == '39' && !accFields.DateClosed) || (accFields.AccountType[0] == '40' && !accFields.DateClosed) || (accFields.AccountType[0] == '43' && !accFields.DateClosed) || (accFields.AccountType[0] == '50' && !accFields.DateClosed) || (accFields.AccountType[0] == '51' && !accFields.DateClosed) || (accFields.AccountType[0] == '52' && !accFields.DateClosed) || (accFields.AccountType[0] == '53' && !accFields.DateClosed) || (accFields.AccountType[0] == '54' && !accFields.DateClosed) || (accFields.AccountType[0] == '55' && !accFields.DateClosed) || (accFields.AccountType[0] == '56' && !accFields.DateClosed) || (accFields.AccountType[0] == '57' && !accFields.DateClosed) || (accFields.AccountType[0] == '58' && !accFields.DateClosed) || (accFields.AccountType[0] == '59' && !accFields.DateClosed) || (accFields.AccountType[0] == '61' && !accFields.DateClosed) || (accFields.AccountType[0] == '00' && !accFields.DateClosed)) {
                                      // logger.info("Stage 8 Business Account");
                                      // respObj = {
                                        // "ErrorCode": "03",
                                        // "ErrorMsg": "Customer having active business loan."
                                      // }
                                      // ErrorCode = '03';
                                      // ErrorMessage = "Customer having active business loan";
                                      // resolve(respObj);
                                      // break;
                                    // }
                                    // else {
                                      // logger.info("Stage 9 Score " + result.CreditReport.ScoreSegment[0].Score);
                                      // respObj = {
                                        // "ErrorCode": "00",
                                        // "ErrorMsg": "No issue found in customer CIBIL with score " + result.CreditReport.ScoreSegment[0].Score,
                                      // }
                                      // ErrorCode = '00';
                                      // ErrorMessage = "No issue found in customer CIBIL with score " + result.CreditReport.ScoreSegment[0].Score;
                                      // resolve(respObj);
                                      // break;
                                    // }
                                  // }
                                // }
                                // else if (result && result.CreditReport && result.CreditReport.ScoreSegment && result.CreditReport.ScoreSegment[0].Score == '000-1') {
                                  // logger.info(`else if true hua`);
                                  // logger.info('2 CIBILData_Update ')
                                  // CIBILData_Update(PMSNo, JourneyID, null, null, null, null, null, null, null, "ErrorCode", null, "00", "No issue found in customer CIBIL with Score: " + result.CreditReport.ScoreSegment[0].Score).then(async (CIBILReqUpdate) => {
                                    // logger.info("Stage 10 Score " + result.CreditReport.ScoreSegment[0].Score);
                                    // respObj = {
                                      // "ErrorCode": "00",
                                      // "ErrorMsg": "No issue found in customer CIBIL",
                                    // }
                                    // resolve(respObj);
                                  // });
                                // }
                                // else {
                                  // logger.info(`else true hua`);
                                  // logger.info('3 CIBILData_Update ')
                                  // CIBILData_Update(PMSNo, JourneyID, null, null, null, null, null, null, null, "ErrorCode", null, "00", result).then(async (CIBILReqUpdate) => {
                                    // logger.info("Else part with no condition fullfil with result " + JSON.stringify(result));
                                    // respObj = {
                                      // "ErrorCode": "00",
                                      // "ErrorMsg": result
                                    // }
                                    // resolve(respObj);
                                  // });
                                // }
                              // });
                            // }
                            // else {
                              // logger.info("else dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0] is false ")
                              // logger.info('#################################Called  PullConsumerCIBILAPI End ###################################');

                              // logger.info("00. BureauResponseXml result:  " + result.Response.Status);
                              // logger.info("01. BureauResponseXml result:  " + result.Response.ErrorCode);
                              // logger.info("02. BureauResponseXml result:  " + result.Response.ErrorDescription + " " + result.Response.Segment);
                              // logger.info(`dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess else true hua`);
                              // CIBILData_Update(PMSNo, JourneyID, CIBILAPIResp.data, dcResponse.ResponseInfo[0].ApplicationId, dsCibilBureau.Document[0].Id[0], dsCibilBureau.Document[0].Name[0], dcResponse.Status.toString(), dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0], result.Response.ErrorDescription + " " + result.Response.Segment, "ConsumerRespUpdate", null, "01", result.Response.ErrorDescription + " " + result.Response.Segment).then(async (CIBILReqUpdate) => {
                                // respObj = {
                                  // "ErrorCode": "01",
                                  // "ErrorMsg": result.Response.ErrorDescription + " " + result.Response.Segment
                                // }
                                // resolve(respObj);
                              // });
                            // }
                          // }
                        // });
                      // }
                      // else {
                        // // logger.info(`2. Authentication Status: ${dcResponse.Authentication[0].Status}`);
                        // //Update CIBIL Response
                        // logger.info("Failed Here " + dcResponse.Status);
                        // logger.info("Failed Here " + CIBILAPIResp.data);
                        // logger.info("Failed Here " + dcResponse.Status);
                        // logger.info("Failed Here " + dcResponse.ErrorInfo[0].Message);
                        // // {"DCResponse":{"Status":["Failed"],"Authentication":[{"Status":["Success"],"Token":["3a7ba125-b6c9-47e3-8401-35c85de093de"]}],"ResponseInfo":[{"ApplicationId":["61378493"],"SolutionSetInstanceId":["45371860-89e6-4522-ac94-e673f2038b4e"],"CurrentQueue":[""]}],"ExceptionInfo":[{"ExceptionId":["abec8efb-97b4-42a2-83b8-ce854b800e90"]}]}}
                        // logger.info(`dcResponse.Status else true hua`);
                        // CIBILData_Update(PMSNo, JourneyID, CIBILAPIResp.data, null, null, null, dcResponse.Status, null, dcResponse.ErrorInfo[0].Message, "ConsumerRespUpdate", null, "01", dcResponse.ErrorInfo[0].Message).then(async (CIBILReqUpdate) => {
                          // logger.info("CIBIL Request update in database" + JSON.stringify(CIBILReqUpdate));
                          // if (CIBILReqUpdate.Error = "00") {
                            // logger.info(`3. Error Message: ${dcResponse.ErrorInfo[0].Message}`);
                            // logger.info('#################################Called  PullConsumerCIBILAPI End ###################################');
                            // respObj = {
                              // "ErrorCode": "01",
                              // "ErrorMsg": dcResponse.ErrorInfo[0].Message,
                            // }
                            // resolve(respObj);
                          // }
                        // });
                      // }
                    // }
                  // });
                // } else {
                  // console.error("ExecuteXMLStringResult is undefined or does not contain expected content.");
                // }
              // }
            // });
          // }
        // })
          // .catch(error => {
            // console.error('Error posting to CIBIL Pull Consumer API:', error);
            // // console.error('Error posting to CIBIL for customer document API Response:',error.response);
            // // console.error('Error posting to CIBIL for customer document API Response Status:',error.response.status);
            // // console.error('Error posting to CIBIL for customer document API Response Text:',error.response.statusText);
            // // console.error('Error posting to CIBIL for customer document API Response Text:',error.response.data);
            // logError.ErrorLogs(PMSNo, JourneyID, error.response.status, error.response.statusText, "PullConsumerCibilAPI").then(async (ErrorLogResp) => {
              // // const result = logError.ErrorLogs(PMSNo,error.response.status,error.response.statusText,"CIBIL Document Pull API");                                           
              // logger.info("**************************************************************")
              // logger.info("ErrorLogResp: " + JSON.stringify(ErrorLogResp));
              // logger.info("*************************************************************")
            // });
            // response = {
              // "ErrorCode": "01",
              // "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
            // }
            // logger.info('#################################Called  PullConsumerCIBILAPI End ###################################');
            // resolve(response);
          // });
      // }

    // } catch (err1) {
      // logger.info('Exception err1: ', err1);
      // reject(err1);
    // }
  // });
// }

function PullConsumerCibilAPI(PMSNo, JourneyID, CICXMLRequest) {
  logger.info('************************Inside PullConsumerCibilAPI Method ***************************');
  logger.info('inside PullConsumerCibilAPI Called PMSNo: ' + PMSNo);

  return new Promise(async (resolve, reject) => {
    try {
     const headers = {
        'SOAPAction': await GetKeyConfigurationValue('CIBIL_SoapAction_Consumer'),
        'Content-Type': 'text/xml',
      }
      logger.info("Headers " + headers);
      const CIBIL_API_URL = await GetKeyConfigurationValue('CIBIL_API_URL')
      // logger.info("API URL " + CIBIL_API_URL);
      const Emptybody = "Call PULL CIBIL CONSUMER API";
      if (CICXMLRequest != null) {
     
        await axios.post(CIBIL_API_URL, CICXMLRequest, { headers, httpsAgent: ProxyAgent }).then(async CIBILAPIResp => { //111000
         //  await axios.post(CIBIL_API_URL, CICXMLRequest, { headers, httpsAgent: agent}).then(async CIBILAPIResp => {
          if (JSON.stringify(CIBILAPIResp.data, null, 2) != null) {

            // logger.info('SOAP XML START');
            // logger.info('CIBIL SOAP XML Response: ', JSON.stringify(CIBILAPIResp.data, null, 2));
            // logger.info('SOAP XML END');

            //logger.info("XMLResp: "+xmlResp0);

            const parser = new xml2js.Parser();
            parser.parseString(CIBILAPIResp.data, (err, result) => {
              if (err) {
                console.error("Error parsing XML:", err);
              } else {
                // console.error('Yaha aaya');
                const jsonObject = JSON.parse(JSON.stringify(result, null, 2));
                //console.error("jsonObject:", jsonObject);
                const executeResult1 = jsonObject['s:Envelope']['s:Body'][0]['ExecuteXMLStringResponse'][0]['ExecuteXMLStringResult'][0];
                let executeResult = executeResult1.replace(/&gt;/g, '>').replace(/&lt;/g, '<');
                logger.info("#########################################dcResponseXml#################################################");
                //logger.info(`dcResponseXml:  ${executeResult} `);                  
                if (executeResult) {
                  // Parse the inner XML string (DCResponse)
                  xml2js.parseString(executeResult, (err, dcResponseResult) => {
                    if (err) {
                      console.error("Error parsing inner XML:", err);
                    } else {
                      logger.info("#####################################DCResponse#####################################################");
                      //logger.info(`Parsed DCResponse${ JSON.stringify(dcResponseResult)}`);
                      // {"DCResponse":{"Status":["Failed"],"Authentication":[{"Status":["Ignore"]}],"ErrorInfo":[{"Message":["Ignore"]}]}}
                      const dcResponse = dcResponseResult.DCResponse;
                      logger.info("Parsed DCResponse" + JSON.stringify(dcResponse));
                      // Accessing values
                      logger.info(`- 2. dcResponse Status: ${dcResponse.Status}`);
                      logger.info('- 1. Authentication:', JSON.stringify(dcResponse.Authentication));
                      if (dcResponse.Status == "Success") {
                        logger.info('Success DCResponse');


                        // logger.info("DsCibilBureau Data:");
                        logger.info(`0. ApplicationId: ${dcResponse.ResponseInfo[0].ApplicationId}`);
                        // logger.info(`1. Request: ${dsCibilBureau.DsCibilBureauData[0].Request[0]}`);
                        const dsCibilBureau = dcResponse.ContextData[0].Field[0].Applicants[0].Applicant[0].DsCibilBureau[0];
                        //  logger.info(`2. Trail: ${dsCibilBureau.DsCibilBureauStatus[0].Trail[0]}`);
                        logger.info(`3. CibilBureauResponse Is Success: ${dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0]}`);
                        //logger.info(`4. Bureau Response Raw: ${dsCibilBureau.Response[0].CibilBureauResponse[0].BureauResponseRaw[0]}`);
                        logger.info(`5. Bureau Response XML: ${dsCibilBureau.Response[0].CibilBureauResponse[0].BureauResponseXml[0]}`);
                        logger.info(`6. Document ID: ${dsCibilBureau.Document[0].Id[0]}`);
                        logger.info(`7. Document Name: ${dsCibilBureau.Document[0].Name[0]}`);
                        // Parse the inner XML string (DCResponse)

                        let executeResult2 = dsCibilBureau.Response[0].CibilBureauResponse[0].BureauResponseXml[0].replace(/&gt;/g, '>').replace(/&lt;/g, '<');



                        //   let executeResult2='<CreditReport><Header><SegmentTag>TUEF</SegmentTag><Version>12</Version><ReferenceNumber>2351414365</ReferenceNumber><MemberCode>BN01147778_CIRC2CNPE          </MemberCode><SubjectReturnCode>1</SubjectReturnCode><EnquiryControlNumber>008205906379</EnquiryControlNumber><DateProcessed>07102024</DateProcessed><TimeProcessed>154614</TimeProcessed></Header><NameSegment><Length>03</Length><SegmentTag>N01</SegmentTag><ConsumerName1FieldLength>21</ConsumerName1FieldLength><ConsumerName1>SIMA BAPUPURI GOSWAMY</ConsumerName1><DateOfBirthFieldLength>08</DateOfBirthFieldLength><DateOfBirth>02031972</DateOfBirth><GenderFieldLength>01</GenderFieldLength><Gender>1</Gender></NameSegment><IDSegment><Length>03</Length><SegmentTag>I01</SegmentTag><IDType>01</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>DAOPG8480F</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I02</SegmentTag><IDType>03</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>ZHG6182324</IDNumber><EnrichedThroughEnquiry>Y</EnrichedThroughEnquiry></IDSegment><IDSegment><Length>03</Length><SegmentTag>I03</SegmentTag><IDType>04</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>ZHG6182323</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I04</SegmentTag><IDType>06</IDType><IDNumberFieldLength>12</IDNumberFieldLength><IDNumber>XXXXXXXXXXXX</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I05</SegmentTag><IDType>09</IDType><IDNumberFieldLength>14</IDNumberFieldLength><IDNumber>60035722828413</IDNumber></IDSegment><TelephoneSegment><Length>03</Length><SegmentTag>T01</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>9589017840</TelephoneNumber><TelephoneType>00</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T02</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7224812025</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T03</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>9770177122</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T04</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7441157883</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><EmailContactSegment><Length>03</Length><SegmentTag>C01</SegmentTag><EmailIDFieldLength>22</EmailIDFieldLength><EmailID>BABLUGODVAMI@GMAIL.COM</EmailID></EmailContactSegment><EmploymentSegment><Length>03</Length><SegmentTag>E01</SegmentTag><AccountType>39</AccountType><DateReportedCertified>31122023</DateReportedCertified><OccupationCode>01</OccupationCode></EmploymentSegment><ScoreSegment><Length>10</Length><ScoreName>CIBILTUSC3</ScoreName><ScoreCardName>08</ScoreCardName><ScoreCardVersion>10</ScoreCardVersion><ScoreDate>07102024</ScoreDate><Score>00653</Score><ReasonCode1FieldLength>02</ReasonCode1FieldLength><ReasonCode1>04</ReasonCode1><ReasonCode2FieldLength>02</ReasonCode2FieldLength><ReasonCode2>32</ReasonCode2><ReasonCode3FieldLength>02</ReasonCode3FieldLength><ReasonCode3>30</ReasonCode3><ReasonCode4FieldLength>02</ReasonCode4FieldLength><ReasonCode4>31</ReasonCode4><ReasonCode5FieldLength>02</ReasonCode5FieldLength><ReasonCode5>29</ReasonCode5><BureauCharacterstics></BureauCharacterstics></ScoreSegment><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A01</SegmentTag><AddressLine1FieldLength>23</AddressLine1FieldLength><AddressLine1>110 SHRIRAM COLONY NEAR</AddressLine1><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452001</PinCode><AddressCategory>02</AddressCategory><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A02</SegmentTag><AddressLine1FieldLength>39</AddressLine1FieldLength><AddressLine1>110 SHREE RAM NAGAR BIJASAN ROAD INDORE</AddressLine1><AddressLine2FieldLength>40</AddressLine2FieldLength><AddressLine2>INDORE INDORE INDORE INDORE (M CORP.   O</AddressLine2><AddressLine3FieldLength>02</AddressLine3FieldLength><AddressLine3>G)</AddressLine3><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452005</PinCode><AddressCategory>02</AddressCategory><ResidenceCode>01</ResidenceCode><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A03</SegmentTag><AddressLine1FieldLength>28</AddressLine1FieldLength><AddressLine1>BAPUPURI GOSVAMEE PUSP SHREE</AddressLine1><AddressLine2FieldLength>05</AddressLine2FieldLength><AddressLine2>HOTEL</AddressLine2><AddressLine3FieldLength>19</AddressLine3FieldLength><AddressLine3>AIRPORT ROAD INDORE</AddressLine3><AddressLine4FieldLength>06</AddressLine4FieldLength><AddressLine4>INDORE</AddressLine4><AddressLine5FieldLength>06</AddressLine5FieldLength><AddressLine5>INDORE</AddressLine5><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452005</PinCode><AddressCategory>01</AddressCategory><ResidenceCode>01</ResidenceCode><DateReported>13052019</DateReported><EnrichedThroughEnquiry>Y</EnrichedThroughEnquiry></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A04</SegmentTag><AddressLine1FieldLength>11</AddressLine1FieldLength><AddressLine1>HOUSE NO 73</AddressLine1><AddressLine2FieldLength>16</AddressLine2FieldLength><AddressLine2>PADMALAYA COLONY</AddressLine2><AddressLine3FieldLength>13</AddressLine3FieldLength><AddressLine3>BANGARDA ROAD</AddressLine3><AddressLine4FieldLength>06</AddressLine4FieldLength><AddressLine4>INDORE</AddressLine4><StateCode>23</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>452005</PinCode><AddressCategory>02</AddressCategory><ResidenceCode>01</ResidenceCode><DateReported>25042019</DateReported></Address><Account><Length>04</Length><SegmentTag>T001</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>17</AccountType><OwenershipIndicator>4</OwenershipIndicator><DateOpenedOrDisbursed>17092019</DateOpenedOrDisbursed><DateOfLastPayment>23072024</DateOfLastPayment><DateReportedAndCertified>31082024</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>225000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>04</CurrentBalanceFieldLength><CurrentBalance>5590</CurrentBalance><AmountOverdueFieldLength>05</AmountOverdueFieldLength><AmountOverdue>79068</AmountOverdue><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>075044074044013000074075075074075075075075074075072073</PaymentHistory1><PaymentHistory2FieldLength>54</PaymentHistory2FieldLength><PaymentHistory2>073075075074075075075075074075072073073075075074075075</PaymentHistory2><PaymentHistoryStartDate>01082024</PaymentHistoryStartDate><PaymentHistoryEndDate>01092021</PaymentHistoryEndDate><SuitFiledOrWilfulDefault>01</SuitFiledOrWilfulDefault><RepaymentTenureFieldLength>02</RepaymentTenureFieldLength><RepaymentTenure>48</RepaymentTenure><PaymentFrequency>03</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T002</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>02</AccountType><OwenershipIndicator>4</OwenershipIndicator><DateOpenedOrDisbursed>07102015</DateOpenedOrDisbursed><DateOfLastPayment>10082024</DateOfLastPayment><DateReportedAndCertified>31082024</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>07</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>1505005</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>07</CurrentBalanceFieldLength><CurrentBalance>1370696</CurrentBalance><AmountOverdueFieldLength>05</AmountOverdueFieldLength><AmountOverdue>28918</AmountOverdue><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>053052052022021022020053061052052052022083082052080050</PaymentHistory1><PaymentHistory2FieldLength>54</PaymentHistory2FieldLength><PaymentHistory2>019022022021000000000000000000000000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01082024</PaymentHistoryStartDate><PaymentHistoryEndDate>01092021</PaymentHistoryEndDate><ValueOfCollateralFieldLength>07</ValueOfCollateralFieldLength><ValueOfCollateral>1505005</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RepaymentTenureFieldLength>03</RepaymentTenureFieldLength><RepaymentTenure>318</RepaymentTenure><EmiAmountFieldLength>05</EmiAmountFieldLength><EmiAmount>13930</EmiAmount><PaymentFrequency>03</PaymentFrequency><ActualPaymentAmountFieldLength>05</ActualPaymentAmountFieldLength><ActualPaymentAmount>13930</ActualPaymentAmount></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T003</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>03</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>03</ReportingMemberShortNameFieldLength><ReportingMemberShortName>PNB</ReportingMemberShortName><AccountNumberFieldLength>16</AccountNumberFieldLength><AccountNumber>659500JZ00003840</AccountNumber><AccountType>39</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>30092023</DateOpenedOrDisbursed><DateOfLastPayment>27082024</DateOfLastPayment><DateClosed>04092024</DateClosed><DateReportedAndCertified>27092024</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>10000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>36</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000001001</PaymentHistory1><PaymentHistoryStartDate>01092024</PaymentHistoryStartDate><PaymentHistoryEndDate>01102023</PaymentHistoryEndDate><RateOfInterestFieldLength>05</RateOfInterestFieldLength><RateOfInterest>13.12</RateOfInterest><RepaymentTenureFieldLength>02</RepaymentTenureFieldLength><RepaymentTenure>12</RepaymentTenure><EmiAmountFieldLength>03</EmiAmountFieldLength><EmiAmount>833</EmiAmount><PaymentFrequency>03</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T004</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>51</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>08072021</DateOpenedOrDisbursed><DateOfLastPayment>14072023</DateOfLastPayment><DateClosed>31082023</DateClosed><DateReportedAndCertified>31102023</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>50000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>30</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01102023</PaymentHistoryStartDate><PaymentHistoryEndDate>01072021</PaymentHistoryEndDate></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T005</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>01</AccountType><OwenershipIndicator>4</OwenershipIndicator><DateOpenedOrDisbursed>27042019</DateOpenedOrDisbursed><DateOfLastPayment>01112019</DateOfLastPayment><DateClosed>31122019</DateClosed><DateReportedAndCertified>31012020</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>350000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>140354</CurrentBalance><AmountOverdueFieldLength>06</AmountOverdueFieldLength><AmountOverdue>144705</AmountOverdue><PaymentHistory1FieldLength>27</PaymentHistory1FieldLength><PaymentHistory1>000063033000000003002000000</PaymentHistory1><PaymentHistoryStartDate>01122019</PaymentHistoryStartDate><PaymentHistoryEndDate>01042019</PaymentHistoryEndDate><CreditFacility>02</CreditFacility></Account_NonSummary_Segment_Fields></Account><Enquiry><Length>04</Length><SegmentTag>I001</SegmentTag><DateOfEnquiryFields>14022024</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>300000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I002</SegmentTag><DateOfEnquiryFields>13122023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>110000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I003</SegmentTag><DateOfEnquiryFields>04112023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>100000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I004</SegmentTag><DateOfEnquiryFields>04112023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>100000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I005</SegmentTag><DateOfEnquiryFields>21102023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>01</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>700000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I006</SegmentTag><DateOfEnquiryFields>30092023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>03</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>PNB</EnquiringMemberShortName><EnquiryPurpose>06</EnquiryPurpose><EnquiryAmountFieldLength>05</EnquiryAmountFieldLength><EnquiryAmount>10000</EnquiryAmount></Enquiry><End><SegmentTag>ES07</SegmentTag><TotalLength>0002452</TotalLength></End></CreditReport>'



                        //   let executeResult3='<CreditReport><Header><SegmentTag>TUEF</SegmentTag><Version>12</Version><ReferenceNumber>3467935901</ReferenceNumber><MemberCode>BN01149988_CIRC2CNPE</MemberCode><SubjectReturnCode>1</SubjectReturnCode><EnquiryControlNumber>010044164891</EnquiryControlNumber><DateProcessed>10122025</DateProcessed><TimeProcessed>175736</TimeProcessed></Header><NameSegment><Length>03</Length><SegmentTag>N01</SegmentTag><ConsumerName1FieldLength>11</ConsumerName1FieldLength><ConsumerName1>SURAJ SINGH</ConsumerName1><ConsumerName2FieldLength>12</ConsumerName2FieldLength><ConsumerName2>MAHRAJ SINGH</ConsumerName2><DateOfBirthFieldLength>08</DateOfBirthFieldLength><DateOfBirth>10061996</DateOfBirth><GenderFieldLength>01</GenderFieldLength><Gender>2</Gender></NameSegment><IDSegment><Length>03</Length><SegmentTag>I01</SegmentTag><IDType>01</IDType><IDNumberFieldLength>10</IDNumberFieldLength><IDNumber>JVXPS7726A</IDNumber></IDSegment><IDSegment><Length>03</Length><SegmentTag>I02</SegmentTag><IDType>06</IDType><IDNumberFieldLength>12</IDNumberFieldLength><IDNumber>XXXXXXXXXXXX</IDNumber></IDSegment><TelephoneSegment><Length>03</Length><SegmentTag>T01</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>8756668032</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T02</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7052342831</TelephoneNumber><TelephoneType>00</TelephoneType></TelephoneSegment><TelephoneSegment><Length>03</Length><SegmentTag>T03</SegmentTag><TelephoneNumberFieldLength>10</TelephoneNumberFieldLength><TelephoneNumber>7052342831</TelephoneNumber><TelephoneType>01</TelephoneType></TelephoneSegment><EmailContactSegment><Length>03</Length><SegmentTag>C01</SegmentTag><EmailIDFieldLength>20</EmailIDFieldLength><EmailID>CSCNIWAJPUR@MAIL.COM</EmailID></EmailContactSegment><EmailContactSegment><Length>03</Length><SegmentTag>C02</SegmentTag><EmailIDFieldLength>24</EmailIDFieldLength><EmailID>SURAJRAMAPUR99@GMAIL.COM</EmailID></EmailContactSegment><EmailContactSegment><Length>03</Length><SegmentTag>C03</SegmentTag><EmailIDFieldLength>14</EmailIDFieldLength><EmailID>NULL@GMAIL.COM</EmailID></EmailContactSegment><EmploymentSegment><Length>03</Length><SegmentTag>E01</SegmentTag><AccountType>53</AccountType><DateReportedCertified>31052024</DateReportedCertified><OccupationCode>03</OccupationCode><IncomeFieldLength>05</IncomeFieldLength><Income>50000</Income><NetGrossIndicator>G</NetGrossIndicator><MonthlyAnnualIndicator>A</MonthlyAnnualIndicator></EmploymentSegment><ScoreSegment><Length>10</Length><ScoreName>CIBILTUSC3</ScoreName><ScoreCardName>08</ScoreCardName><ScoreCardVersion>10</ScoreCardVersion><ScoreDate>10122025</ScoreDate><Score>00762</Score><BureauCharacterstics></BureauCharacterstics></ScoreSegment><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A01</SegmentTag><AddressLine1FieldLength>21</AddressLine1FieldLength><AddressLine1>VILL AND POST RAMAPUR</AddressLine1><AddressLine2FieldLength>22</AddressLine2FieldLength><AddressLine2>BARKATPUR SHAHJAHANPUR</AddressLine2><AddressLine5FieldLength>12</AddressLine5FieldLength><AddressLine5>SHAHJAHANPUR</AddressLine5><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242306</PinCode><AddressCategory>02</AddressCategory><DateReported>31012024</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A02</SegmentTag><AddressLine1FieldLength>38</AddressLine1FieldLength><AddressLine1>RAMAPUR BARKATPUR PO RAMAPUR BARKATPUR</AddressLine1><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242001</PinCode><AddressCategory>02</AddressCategory><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A03</SegmentTag><AddressLine1FieldLength>38</AddressLine1FieldLength><AddressLine1>RAMAPUR BARKATPUR PO RAMAPUR BARKATPUR</AddressLine1><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242001</PinCode><AddressCategory>01</AddressCategory><DateReported>31122023</DateReported></Address><Address><AddressSegmentTag>PA</AddressSegmentTag><Length>03</Length><SegmentTag>A04</SegmentTag><AddressLine1FieldLength>39</AddressLine1FieldLength><AddressLine1>RAMAPUR VARKATPUR SHAHJAHANPUR NR UNANI</AddressLine1><AddressLine2FieldLength>37</AddressLine2FieldLength><AddressLine2>HOSPITAL  SHAHJAHANPUR  UTTAR PRADESH</AddressLine2><StateCode>09</StateCode><PinCodeFieldLength>06</PinCodeFieldLength><PinCode>242306</PinCode><AddressCategory>02</AddressCategory><ResidenceCode>02</ResidenceCode><DateReported>31072021</DateReported></Address><Account><Length>04</Length><SegmentTag>T001</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>53</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>27052024</DateOpenedOrDisbursed><DateOfLastPayment>08052025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>150000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>150000</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>03</PaymentHistory2FieldLength><PaymentHistory2>000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01052024</PaymentHistoryEndDate><ValueOfCollateralFieldLength>06</ValueOfCollateralFieldLength><ValueOfCollateral>200000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.25</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T002</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>37</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>05042024</DateOpenedOrDisbursed><DateOfLastPayment>12102025</DateOfLastPayment><DateClosed>15102025</DateClosed><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>50000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>06</PaymentHistory2FieldLength><PaymentHistory2>000000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01042024</PaymentHistoryEndDate></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T003</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>10</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>18112023</DateOpenedOrDisbursed><DateOfLastPayment>11112025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>77356</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>05</CurrentBalanceFieldLength><CurrentBalance>72799</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>21</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01112023</PaymentHistoryEndDate><CreditLimitFieldLength>05</CreditLimitFieldLength><CreditLimit>75000</CreditLimit></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T004</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>36</AccountType><OwenershipIndicator>3</OwenershipIndicator><DateOpenedOrDisbursed>28062023</DateOpenedOrDisbursed><DateOfLastPayment>17062025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>242000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>161353</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000STD</PaymentHistory1><PaymentHistory2FieldLength>36</PaymentHistory2FieldLength><PaymentHistory2>000000000000000STDSTDSTDSTDSTDSTDSTD</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01062023</PaymentHistoryEndDate><ValueOfCollateralFieldLength>06</ValueOfCollateralFieldLength><ValueOfCollateral>500000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.00</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T005</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>36</AccountType><OwenershipIndicator>3</OwenershipIndicator><DateOpenedOrDisbursed>28062023</DateOpenedOrDisbursed><DateOfLastPayment>17062025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>186000</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>124203</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000STD</PaymentHistory1><PaymentHistory2FieldLength>36</PaymentHistory2FieldLength><PaymentHistory2>000000000000000STDSTDSTDSTDSTDSTDSTD</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01062023</PaymentHistoryEndDate><ValueOfCollateralFieldLength>06</ValueOfCollateralFieldLength><ValueOfCollateral>500000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.00</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T006</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>10</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>12042023</DateOpenedOrDisbursed><DateOfLastPayment>11082025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>74681</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>42</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000000000000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01042023</PaymentHistoryEndDate><CreditLimitFieldLength>05</CreditLimitFieldLength><CreditLimit>75000</CreditLimit></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T007</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>36</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>24112022</DateOpenedOrDisbursed><DateOfLastPayment>04052025</DateOfLastPayment><DateReportedAndCertified>30112025</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>06</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>167200</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>06</CurrentBalanceFieldLength><CurrentBalance>113258</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>54</PaymentHistory2FieldLength><PaymentHistory2>000000000000000STDSTDSTDSTDSTDSTDSTDSTDSTDSTDSTDSTDSTD</PaymentHistory2><PaymentHistoryStartDate>01112025</PaymentHistoryStartDate><PaymentHistoryEndDate>01122022</PaymentHistoryEndDate><ValueOfCollateralFieldLength>07</ValueOfCollateralFieldLength><ValueOfCollateral>1578000</ValueOfCollateral><TypeOfCollateralFieldLength>02</TypeOfCollateralFieldLength><TypeOfCollateral>01</TypeOfCollateral><RateOfInterestFieldLength>04</RateOfInterestFieldLength><RateOfInterest>7.00</RateOfInterest><PaymentFrequency>08</PaymentFrequency></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T008</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>06</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>21072021</DateOpenedOrDisbursed><DateClosed>02022022</DateClosed><DateReportedAndCertified>30042023</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>10197</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000000000000000</PaymentHistory1><PaymentHistory2FieldLength>12</PaymentHistory2FieldLength><PaymentHistory2>000000000000</PaymentHistory2><PaymentHistoryStartDate>01042023</PaymentHistoryStartDate><PaymentHistoryEndDate>01072021</PaymentHistoryEndDate><RepaymentTenureFieldLength>01</RepaymentTenureFieldLength><RepaymentTenure>7</RepaymentTenure><EmiAmountFieldLength>04</EmiAmountFieldLength><EmiAmount>1700</EmiAmount><PaymentFrequency>03</PaymentFrequency><ActualPaymentAmountFieldLength>03</ActualPaymentAmountFieldLength><ActualPaymentAmount>500</ActualPaymentAmount></Account_NonSummary_Segment_Fields></Account><Account><Length>04</Length><SegmentTag>T009</SegmentTag><Account_Summary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength></Account_Summary_Segment_Fields><Account_NonSummary_Segment_Fields><ReportingMemberShortNameFieldLength>13</ReportingMemberShortNameFieldLength><ReportingMemberShortName>NOT DISCLOSED</ReportingMemberShortName><AccountType>13</AccountType><OwenershipIndicator>1</OwenershipIndicator><DateOpenedOrDisbursed>27012017</DateOpenedOrDisbursed><DateOfLastPayment>25122018</DateOfLastPayment><DateClosed>08012019</DateClosed><DateReportedAndCertified>06022019</DateReportedAndCertified><HighCreditOrSanctionedAmountFieldLength>05</HighCreditOrSanctionedAmountFieldLength><HighCreditOrSanctionedAmount>38152</HighCreditOrSanctionedAmount><CurrentBalanceFieldLength>01</CurrentBalanceFieldLength><CurrentBalance>0</CurrentBalance><PaymentHistory1FieldLength>54</PaymentHistory1FieldLength><PaymentHistory1>000000000000000000000000000000000000000000026000000000</PaymentHistory1><PaymentHistory2FieldLength>18</PaymentHistory2FieldLength><PaymentHistory2>000000000000000000</PaymentHistory2><PaymentHistoryStartDate>01012019</PaymentHistoryStartDate><PaymentHistoryEndDate>01022017</PaymentHistoryEndDate><RateOfInterestFieldLength>05</RateOfInterestFieldLength><RateOfInterest>22.83</RateOfInterest><RepaymentTenureFieldLength>02</RepaymentTenureFieldLength><RepaymentTenure>18</RepaymentTenure><EmiAmountFieldLength>04</EmiAmountFieldLength><EmiAmount>2541</EmiAmount><PaymentFrequency>03</PaymentFrequency><ActualPaymentAmountFieldLength>05</ActualPaymentAmountFieldLength><ActualPaymentAmount>50088</ActualPaymentAmount></Account_NonSummary_Segment_Fields></Account><Enquiry><Length>04</Length><SegmentTag>I001</SegmentTag><DateOfEnquiryFields>17022025</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>02</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>500000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I002</SegmentTag><DateOfEnquiryFields>24052024</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>53</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>150000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I003</SegmentTag><DateOfEnquiryFields>27022024</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>36</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>100000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I004</SegmentTag><DateOfEnquiryFields>27062023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>53</EnquiryPurpose><EnquiryAmountFieldLength>06</EnquiryAmountFieldLength><EnquiryAmount>186000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I005</SegmentTag><DateOfEnquiryFields>12042023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>10</EnquiryPurpose><EnquiryAmountFieldLength>04</EnquiryAmountFieldLength><EnquiryAmount>1000</EnquiryAmount></Enquiry><Enquiry><Length>04</Length><SegmentTag>I006</SegmentTag><DateOfEnquiryFields>23022023</DateOfEnquiryFields><EnquiringMemberShortNameFieldLength>13</EnquiringMemberShortNameFieldLength><EnquiringMemberShortName>NOT DISCLOSED</EnquiringMemberShortName><EnquiryPurpose>10</EnquiryPurpose><EnquiryAmountFieldLength>04</EnquiryAmountFieldLength><EnquiryAmount>1000</EnquiryAmount></Enquiry><End><SegmentTag>ES07</SegmentTag><TotalLength>0003241</TotalLength></End></CreditReport>'
                        // //logger.info("executeResult2 " + executeResult2)

                        xml2js.parseString(executeResult2, (err, result) => {
                          if (err) {
                            console.error(`Error parsing inner XML: ${err}`);
                          }
                          else {
                            logger.info(`BureauResponseXml result:  ${JSON.stringify(result)}`);



                            logger.info(`BureauResponseXml resultHIIIIIIIIIII:  ${dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0]}`);
                            if (dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0] == "True") {
                              logger.info(`9. Yaha Chala Gaya`);
                              let ErrorCode = '';
                              let ErrorMessage = '';
                              //  logger.info(`0 CIBILData_Update`);
                              CIBILData_Update(PMSNo, JourneyID, CIBILAPIResp.data, dcResponse.ResponseInfo[0].ApplicationId, dsCibilBureau.Document[0].Id[0], dsCibilBureau.Document[0].Name[0], dcResponse.Status.toString(), dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0], JSON.stringify(result), "ConsumerRespUpdate", null, ErrorCode, ErrorMessage).then(async (CIBILReqUpdate) => {

                                const accounts = result?.CreditReport?.Account || [];
                                const scores = result?.CreditReport?.ScoreSegment || [];

                                logger.info(`CIBIL Shape: Accounts=${accounts.length}, Scores=${scores.length}`);

                                /* ------------------ ACCOUNT FLOW ------------------ */
                                if (accounts.length > 0) {
                                  logger.info(`Stage 2 with length: ${accounts.length}`);

                                  for (let i = 0; i < accounts.length; i++) {

                                    const accFields = accounts[i].Account_NonSummary_Segment_Fields?.[0];
                                    if (!accFields) continue;

                                    logger.info(`Processing Account #${i + 1}`);

                                    /* 1️⃣ Credit Facility Check */
                                    if (accFields.CreditFacility?.[0]) {
                                      const cf = accFields.CreditFacility[0];

                                      const cfMap = {
                                        "00": "Restructured Loan",
                                        "01": "Restructured Loan (Govt. Mandated)",
                                        "02": "Written-off",
                                        "03": "Settled",
                                        "04": "Post (WO) Settled",
                                        "05": "Account Sold",
                                        "06": "Written Off and Account Sold",
                                        "07": "Account Purchased",
                                        "08": "Account Purchased and Written Off",
                                        "09": "Account Purchased and Settled",
                                        "10": "Account Purchased and Restructured",
                                        "11": "Restructured due to Natural Calamity",
                                        "12": "Restructured due to COVID-19",
                                        "13": "Post Write Off Closed",
                                        "14": "Restructured and Closed",
                                        "15": "Auctioned and Settled",
                                        "16": "Repossessed and Settled",
                                        "17": "Guarantee Invoked"
                                      };

                                      if (cfMap[cf]) {
                                        resolve({ ErrorCode: "02", ErrorMsg: `Credit Facility: ${cfMap[cf]}` });
                                        return;
                                      }
                                    }

                                    /* 2️⃣ Suit Filed / Wilful Default */
                                    if (accFields.SuitFiledOrWilfulDefault?.[0] && accFields.SuitFiledOrWilfulDefault[0] !== "00") {
                                      resolve({ ErrorCode: "02", ErrorMsg: `SuitFiledOrWilfulDefault: ${accFields.SuitFiledOrWilfulDefault[0]}` });
                                      return;
                                    }

                                    /* 3️⃣ Payment History 1 */
                                    if (accFields.PaymentHistory1?.[0] && accFields.PaymentHistory1FieldLength?.[0]) {
                                      const hist = accFields.PaymentHistory1[0];
                                      const len = parseInt(accFields.PaymentHistory1FieldLength[0], 10);

                                      for (let j = 0; j < len; j += 3) {
                                        const temp = hist.substring(j, j + 3);
                                        if (temp > 90 || temp === 'LSS' || temp === 'DBT' || temp === 'SUB') {
                                          resolve({ ErrorCode: "02", ErrorMsg: `NPA in PaymentHistory1: ${temp}` });
                                          return;
                                        }
                                      }
                                    }

                                    /* 4️⃣ Payment History 2 */
                                    if (accFields.PaymentHistory2?.[0] && accFields.PaymentHistory2FieldLength?.[0]) {
                                      const hist = accFields.PaymentHistory2[0];
                                      const len = parseInt(accFields.PaymentHistory2FieldLength[0], 10);

                                      for (let j = 0; j < len; j += 3) {
                                        const temp = hist.substring(j, j + 3);
                                        if (temp > 90 || temp === 'LSS' || temp === 'DBT' || temp === 'SUB') {
                                          resolve({ ErrorCode: "02", ErrorMsg: `NPA in PaymentHistory2: ${temp}` });
                                          return;
                                        }
                                      }
                                    }

                                    /* 5️⃣ Active Business Loan */
                                    const businessTypes = [
                                      '09', '11', '12', '14', '17', '18', '19', '20', '23', '24',
                                      '33', '38', '39', '40', '43', '50', '51', '52', '53', '54',
                                      '55', '56', '57', '58', '59', '61', '00'
                                    ];

                                    if (businessTypes.includes(accFields.AccountType?.[0]) && !accFields.DateClosed) {
                                      resolve({ ErrorCode: "03", ErrorMsg: "Customer having active business loan." });
                                      return;
                                    }
                                  }

                                  const firstScore = scores.find(s => s.Score)?.Score?.[0] || "NA";
                                  resolve({ ErrorCode: "00", ErrorMsg: "No issue found in customer CIBIL with score " + firstScore });
                                  return;
                                }

                                /* ------------------ SCORE-ONLY / NTC FLOW ------------------ */
                                const hasNTC = scores.some(s => s.Score?.[0] === '000-1');

                                if (hasNTC) {
                                  resolve({ ErrorCode: "00", ErrorMsg: "No issue found in customer CIBIL (NTC Customer)" });
                                  return;
                                }

                                /* ------------------ FALLBACK ------------------ */
                                resolve({
                                  ErrorCode: "00",
                                  ErrorMsg: "No account data present. Proceeding as clean CIBIL."
                                });


                                
                              });
                            }
                            else {
                              logger.info("else dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0] is false ")
                              logger.info('#################################Called  PullConsumerCIBILAPI End ###################################');

                              logger.info("00. BureauResponseXml result:  " + result.Response.Status);
                              logger.info("01. BureauResponseXml result:  " + result.Response.ErrorCode);
                              logger.info("02. BureauResponseXml result:  " + result.Response.ErrorDescription + " " + result.Response.Segment);
                              logger.info(`dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess else true hua`);
                              CIBILData_Update(PMSNo, JourneyID, CIBILAPIResp.data, dcResponse.ResponseInfo[0].ApplicationId, dsCibilBureau.Document[0].Id[0], dsCibilBureau.Document[0].Name[0], dcResponse.Status.toString(), dsCibilBureau.Response[0].CibilBureauResponse[0].IsSucess[0], result.Response.ErrorDescription + " " + result.Response.Segment, "ConsumerRespUpdate", null, "01", result.Response.ErrorDescription + " " + result.Response.Segment).then(async (CIBILReqUpdate) => {
                                respObj = {
                                  "ErrorCode": "01",
                                  "ErrorMsg": result.Response.ErrorDescription + " " + result.Response.Segment
                                }
                                resolve(respObj);
                              });
                            }
                          }
                        });
                      }
                      else {
                        // logger.info(`2. Authentication Status: ${dcResponse.Authentication[0].Status}`);
                        //Update CIBIL Response
                        logger.info("Failed Here " + dcResponse.Status);
                        logger.info("Failed Here " + CIBILAPIResp.data);
                        logger.info("Failed Here " + dcResponse.Status);
                        	logger.info("Failed Here " + dcResponse?.ErrorInfo?.[0]?.Message);
                        // {"DCResponse":{"Status":["Failed"],"Authentication":[{"Status":["Success"],"Token":["3a7ba125-b6c9-47e3-8401-35c85de093de"]}],"ResponseInfo":[{"ApplicationId":["61378493"],"SolutionSetInstanceId":["45371860-89e6-4522-ac94-e673f2038b4e"],"CurrentQueue":[""]}],"ExceptionInfo":[{"ExceptionId":["abec8efb-97b4-42a2-83b8-ce854b800e90"]}]}}
                        logger.info(`dcResponse.Status else true hua`);
                        CIBILData_Update(PMSNo, JourneyID, CIBILAPIResp.data, null, null, null, dcResponse.Status, null, dcResponse?.ErrorInfo?.[0]?.Message, "ConsumerRespUpdate", null, "01", dcResponse?.ErrorInfo?.[0]?.Message).then(async (CIBILReqUpdate) => {
                          logger.info("CIBIL Request update in database" + JSON.stringify(CIBILReqUpdate));
                          if (CIBILReqUpdate.Error = "00") {
                            logger.info(`3. Error Message: ${dcResponse?.ErrorInfo?.[0]?.Message}`);
                            logger.info('#################################Called  PullConsumerCIBILAPI End ###################################');
                            respObj = {
                              "ErrorCode": "01",
                              "ErrorMsg": dcResponse?.ErrorInfo?.[0]?.Message,
                            }
                            resolve(respObj);
                          }
                        });
                      }
                    }
                  });
                } else {
                  console.error("ExecuteXMLStringResult is undefined or does not contain expected content.");
                }
              }
            });
          }
        })
          .catch(error => {
            console.error('Error posting to CIBIL Pull Consumer API:', error);
            // console.error('Error posting to CIBIL for customer document API Response:',error.response);
            // console.error('Error posting to CIBIL for customer document API Response Status:',error.response.status);
            // console.error('Error posting to CIBIL for customer document API Response Text:',error.response.statusText);
            // console.error('Error posting to CIBIL for customer document API Response Text:',error.response.data);
            logError.ErrorLogs(PMSNo, JourneyID, error.response.status, error.response.statusText, "PullConsumerCibilAPI").then(async (ErrorLogResp) => {
              // const result = logError.ErrorLogs(PMSNo,error.response.status,error.response.statusText,"CIBIL Document Pull API");                                           
              logger.info("**************************************************************")
              logger.info("ErrorLogResp: " + JSON.stringify(ErrorLogResp));
              logger.info("*************************************************************")
            });
            response = {
              "ErrorCode": "01",
              "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
            }
            logger.info('#################################Called  PullConsumerCIBILAPI End ###################################');
            resolve(response);
          });
      }

    } catch (err1) {
      logger.info('Exception err1: ', err1);
      reject(err1);
    }
  });
}

// function CIBILData_Update(PMSNumber, JourneyID, CICXMLResponse, ApplicationId, DocumentId, DocumentName, DCResponseStatus, CibilBureauStatus, Message, Operation, DocBytes, ErrorCode, ErrorMessage) {
  // logger.info(''); logger.info('');
  // logger.info('**************************Inside CIBILData_Update Method *****************************');
  // logger.info('DCResponseStatus:' + DCResponseStatus);
  // logger.info('CibilBureauStatus:' + CibilBureauStatus);
  // logger.info('Operation: ' + Operation);
  // logger.info('ApplicationId:' + ApplicationId);

  // let strDCResponseStatus = DCResponseStatus !== null && DCResponseStatus !== undefined ? DCResponseStatus.toString() : '';
  // let strMessage = Message !== null && Message !== undefined ? Message.toString() : '';
  // logger.info('After Null handle DCResponseStatus:' + strDCResponseStatus);
  // logger.info('After Null handle ErrorMessage: --' + ErrorMessage +' --Data Ends');

  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('PMSNumber', sql.NVarChar, PMSNumber)
          // .input('JourneyRefID', sql.NVarChar, JourneyID)
          // .input('ApplicationId', sql.BigInt, ApplicationId)
          // .input('DocumentId', sql.BigInt, DocumentId)
          // .input('DocumentName', sql.NVarChar, DocumentName)
          // .input('Request', sql.VarChar(sql.MAX), CICXMLResponse)
          // .input('Response', sql.VarChar(sql.MAX), CICXMLResponse)
          // .input('DCResponseStatus', sql.NVarChar, strDCResponseStatus)
          // .input('CibilBureauStatus', sql.NVarChar, CibilBureauStatus)
          // .input('ErrorCode', sql.NVarChar, ErrorCode)
         // .input('ErrorMessage', sql.NVarChar, ErrorMessage ? ErrorMessage.toString() : null)
           // // .input('ErrorMessage', sql.NVarChar, ErrorMessage != null ? 'NA1' :'NA')
          // .input('Message', sql.VarChar(sql.MAX), strMessage)
          // .input('DocumentByte', sql.VarBinary(sql.MAX), DocBytes)
          // .input('Operation', sql.NVarChar, Operation)
          // .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          // .execute('proc_CIBILData_InsertUpdate', function (err, queryResult) {
            // logger.info("queryResult: " + JSON.stringify(queryResult));
            // logger.info("err: " + err);
            // // logger.info("Rows Affacted: "+queryResult.rowsAffected[0]);                      
            // if (queryResult.output.p_OutStatusCode == 200 && queryResult.rowsAffected[0] > 0) {
              // conn.close();
              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "CIBIL Response updated Successfully.",
              // }
              // resolve(response);
            // }
            // else {
              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": err
              // }
              // logger.info("Error while insert in database :- " + err);
              // resolve(response);
            // }
          // });
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function CIBILData_Update(
  PMSNumber, JourneyID, CICXMLResponse, ApplicationId, DocumentId,
  DocumentName, DCResponseStatus, CibilBureauStatus, Message,
  Operation, DocBytes, ErrorCode, ErrorMessage
) {

  logger.info('');
  logger.info('');
  logger.info('**************************Inside CIBILData_Update Method *****************************');
  logger.info('DCResponseStatus:' + DCResponseStatus);
  logger.info('CibilBureauStatus:' + CibilBureauStatus);
  logger.info('Operation: ' + Operation);
  logger.info('ApplicationId:' + ApplicationId);

  const strDCResponseStatus =
    DCResponseStatus !== null && DCResponseStatus !== undefined
      ? DCResponseStatus.toString()
      : '';

  const strMessage =
    Message !== null && Message !== undefined
      ? Message.toString()
      : '';

  logger.info('After Null handle DCResponseStatus:' + strDCResponseStatus);
  logger.info('After Null handle ErrorMessage: --' + ErrorMessage + ' --Data Ends');

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNumber)
        .input('JourneyRefID', sql.NVarChar, JourneyID)
        .input('ApplicationId', sql.BigInt, ApplicationId)
        .input('DocumentId', sql.BigInt, DocumentId)
        .input('DocumentName', sql.NVarChar, DocumentName)
        .input('Request', sql.VarChar(sql.MAX), CICXMLResponse)
        .input('Response', sql.VarChar(sql.MAX), CICXMLResponse)
        .input('DCResponseStatus', sql.NVarChar, strDCResponseStatus)
        .input('CibilBureauStatus', sql.NVarChar, CibilBureauStatus)
        .input('ErrorCode', sql.NVarChar, ErrorCode)
        .input(
          'ErrorMessage',
          sql.NVarChar,
          ErrorMessage ? ErrorMessage.toString() : null
        )
        .input('Message', sql.VarChar(sql.MAX), strMessage)
        .input('DocumentByte', sql.VarBinary(sql.MAX), DocBytes)
        .input('Operation', sql.NVarChar, Operation)
        .output('p_OutStatusCode', sql.NVarChar)
        .execute('proc_CIBILData_InsertUpdate');

      logger.info('QueryResult: ' + JSON.stringify(result));
      logger.info('OutStatusCode: ' + result.output.p_OutStatusCode);

      if (
        result.output.p_OutStatusCode === '200' &&
        result.rowsAffected &&
        result.rowsAffected[0] > 0
      ) {
        resolve({
          "ErrorCode": "00",
          "ErrorMsg": "CIBIL Response updated Successfully."
        });
      } else {
        resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error updating CIBIL response data"
        });
      }

    } catch (err) {
      logger.error('CIBILData_Update Error:', err);
      reject(err);
    }
  });
}


function PullCIBILDocumentAPI(PMSNo, JourneyID, ApplicationID, DocumentID) {
  logger.info('#################################Called  PullCIBILDocumentAPI Start ###################################');
  logger.info('inside PullCIBILDocumentAPI ApplicationID: ' + ApplicationID);
  logger.info('inside PullCIBILDocumentAPI DocumentID: ' + DocumentID);
  logger.info('inside PullCIBILDocumentAPI  PMSNo: ' + PMSNo);


  return new Promise(async (resolve, reject) => {
    try {

      let userId = await GetKeyConfigurationValue('CIBIL_UserID');
      let password = await GetKeyConfigurationValue('CIBIL_Password');

      //Call CIBIL Document Pull AP
      const DocRequestXML = `<soapenv:Envelope
                                	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                                	xmlns:tem="http://tempuri.org/">
                                	<soapenv:Header />
                                	<soapenv:Body>
                                		<tem:DownloadDocument>
                                			<tem:request>
                                				<![CDATA[ <DCRequest
                                				xmlns="http://transunion.com/dc/extsvc"><Authentication type="Token"><UserId>${userId}</UserId><Password>${password}</Password></Authentication><DownloadDocument><ApplicationId>${ApplicationID}</ApplicationId><DocumentId>${DocumentID}</DocumentId></DownloadDocument></DCRequest>]]>
                                			</tem:request>
                                		</tem:DownloadDocument>
                                	</soapenv:Body>
                                </soapenv:Envelope>`
      logger.info("DocRequestXML " + DocRequestXML);
     const headers = {
        'SOAPAction': await GetKeyConfigurationValue('CIBIL_SoapAction_Document'),
        'Content-Type': 'text/xml; charset=utf-8',
      }
      //logger.info("Header",headers);
      const CIBIL_API_URL = await GetKeyConfigurationValue('CIBIL_API_URL');
      //logger.info("API URL "+CIBIL_API_URL);

      CIBILData_Update(PMSNo, JourneyID, DocRequestXML, null, null, null, null, null, null, "DocumentReqUpdate", null, null, null).then(async (CIBILReqUpdate) => {
        if (CIBILReqUpdate.ErrorCode == "00") {
          await axios.post(CIBIL_API_URL, DocRequestXML, { headers, httpsAgent: ProxyAgent }).then(async CIBILDocumentResp => { //111000
          //  await axios.post(CIBIL_API_URL, DocRequestXML, { headers, httpsAgent: agent}).then(async CIBILDocumentResp => {
            if (JSON.stringify(CIBILDocumentResp.data, null, 2) != null) {
              const xmlResp = JSON.stringify(CIBILDocumentResp.data, null, 2);

              // logger.info("CIBIL XMLResp : "+xmlResp);
              const parser = new xml2js.Parser();
              parser.parseString(CIBILDocumentResp.data, (err, result) => {
                if (err) {
                  console.error("Error parsing XML:", err);
                } else {
                  const jsonObject = JSON.parse(JSON.stringify(result, null, 2));
                  const fileContentBase64 = result['s:Envelope']['s:Body'][0]['DownloadDocumentResponse'][0]['DownloadDocumentResult'][0]['a:FileContent'][0];
                  //logger.info("fileContentBase64 "+fileContentBase64);

                  const responseStatusXML = result['s:Envelope']['s:Body'][0]['DownloadDocumentResponse'][0]['DownloadDocumentResult'][0]['a:Response'][0].replace(/&gt;/g, '>').replace(/&lt;/g, '<');

                  xml2js.parseString(responseStatusXML, (err, ResponseResult) => {
                    if (err) {
                      console.error("Error parsing inner responseStatus XML:", err);
                    } else {
                      const dcResponse = ResponseResult.DCResponse;
                      logger.info("ResponseResult:  " + JSON.stringify(ResponseResult));
                      logger.info("ResponseResult.Status:  " + dcResponse.Status[0]);
                      if (dcResponse.Status[0] == "Success") {
                        // Decode the Base64 content to Buffer
                        const fileContentBuffer = Buffer.from(fileContentBase64, 'base64');
                        // Write the buffer to an HTML file
                        // fs.writeFile('output.html', fileContentBuffer, (err) => {
                        // if (err) {
                        // console.error('Error writing file:', err);
                        // } else {
                        // logger.info('HTML file created successfully!');
                        // }
                        // });


                        CIBIL_DocData_Update(PMSNo, JourneyID, CIBILDocumentResp.data, dcResponse.Status[0].toString(), "Successfully retrieved CIBIL Document", "DocumentRespUpdate", fileContentBuffer).then(async (CIBILReqUpdate) => {

                          //Update Document API response in Database
                          CibilDocResponse = {
                            "ErrorCode": "00",
                            "ErrorMsg": "CIBIL Document successfully pulled."
                          }
                          logger.info('#################################Called  PullCIBILDocumentAPI End ###################################');
                          resolve(CibilDocResponse);

                        });
                      }
                      else {
                        CIBILData_Update(PMSNo, JourneyID, CIBILDocumentResp.data, null, null, null, dcResponse.Status[0].toString(), "Error to pull Customer CIBIL Document", "DocumentRespUpdate", null, null, null).then(async (CIBILReqUpdate) => {

                          CibilDocResponse = {
                            "ErrorCode": "01",
                            "ErrorMsg": "There seems to be some error in fetching your CIC.Kindly try later"
                          }
                          logger.info('#################################Called  PullCIBILDocumentAPI End ###################################');
                          resolve(CibilDocResponse);
                        });
                      }
                    }
                  });
                }
              });
            }
          })
            .catch(error => {
              console.error('Error posting to CIBIL for customer document API:', error);
              //console.error('Error posting to CIBIL for customer document API Response:',error.response);
              // console.error('Error posting to CIBIL for customer document API Response Status:',error.response.status);
              // console.error('Error posting to CIBIL for customer document API Response Text:',error.response.statusText);       
              //Save Logs in Database
              logError.ErrorLogs(PMSNo, error.response.status, error.response.statusText, "CIBILDocumentPullAPI").then(async (ErrorLogResp) => {
                response = {
                  "ErrorCode": "01",
                  "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
                }
                logger.info('#################################Called  PullCIBILDocumentAPI End ###################################');
                resolve(response);
              });

            })
        }
        else {
          //Error Update CIBIL Data
        }
      })
    } catch (err1) {
      logger.info('Exception err1: ', +err1);
      reject(err1);
    }
  });
}

// function CIBIL_DocData_Update(PMSNumber, JourneyID, XMLDocResponse, DCResponseStatus, Message, Operation, DocBytes) {
 // // logger.info(''); logger.info('');
  // logger.info('**************************Inside CIBIL_DocData_Update Method *****************************');
  // logger.info('DCResponseStatus:' + DCResponseStatus);
  // logger.info('Message:' + Message);
  // logger.info('Operation:' + Operation);

  // return new Promise((resolve, reject) => {
    // try {
      // var conn = new sql.ConnectionPool(config);
      // conn.connect().then(function (pool) {
        // var request = new sql.Request(pool);
        // request.input('PMSNumber', sql.NVarChar, PMSNumber)
          // .input('JourneyRefID', sql.NVarChar, JourneyID)

          // .input('DCResponseStatus', sql.NVarChar, DCResponseStatus)
          // .input('Response', sql.VarChar(sql.MAX), XMLDocResponse)
          // .input('Message', sql.VarChar(sql.MAX), Message)
          // .input('DocumentByte', sql.VarBinary(sql.MAX), DocBytes)
          // .input('Operation', sql.NVarChar, Operation)
          // .output('p_OutStatusCode', sql.NVarChar) // Define output parameter
          // .execute('proc_CIBILData_InsertUpdate', function (err, queryResult) {
            // logger.info("queryResult: " + JSON.stringify(queryResult));
            // logger.info("err: " + err);
            // // logger.info("Rows Affacted: "+queryResult.rowsAffected[0]);                      
            // if (queryResult.output.p_OutStatusCode == 200 && queryResult.rowsAffected[0] > 0) {
              // conn.close();
              // response = {
                // "ErrorCode": "00",
                // "ErrorMsg": "CIBIL Response updated Successfully.",
              // }
              // resolve(response);
            // }
            // else {
              // response = {
                // "ErrorCode": "01",
                // "ErrorMsg": err
              // }
              // logger.info("Error while insert in database :- " + err);
              // resolve(response);
            // }
          // });
      // });
    // } catch (err1) {
      // logger.info(err1);
      // reject(err1);
    // }
  // });
// }

function CIBIL_DocData_Update(
  PMSNumber,
  JourneyID,
  XMLDocResponse,
  DCResponseStatus,
  Message,
  Operation,
  DocBytes
) {
  logger.info('**************************Inside CIBIL_DocData_Update Method *****************************');
  logger.info('DCResponseStatus: ' + DCResponseStatus);
  logger.info('Message: ' + Message);
  logger.info('Operation: ' + Operation);

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      const result = await request
        .input('PMSNumber', sql.NVarChar, PMSNumber)
        .input('JourneyRefID', sql.NVarChar, JourneyID)
        .input('DCResponseStatus', sql.NVarChar, DCResponseStatus)
        .input('Response', sql.VarChar(sql.MAX), XMLDocResponse)
        .input('Message', sql.VarChar(sql.MAX), Message)
        .input('DocumentByte', sql.VarBinary(sql.MAX), DocBytes)
        .input('Operation', sql.NVarChar, Operation)
        .output('p_OutStatusCode', sql.NVarChar)
        .execute('proc_CIBILData_InsertUpdate');

      logger.info('QueryResult: ' + JSON.stringify(result));
      logger.info('OutStatusCode: ' + result.output.p_OutStatusCode);

      if (
        result.output.p_OutStatusCode === '200' &&
        result.rowsAffected &&
        result.rowsAffected[0] > 0
      ) {
        resolve({
          "ErrorCode": "00",
          "ErrorMsg": "CIBIL Response updated Successfully."
        });
      } else {
        resolve({
          "ErrorCode": "01",
          "ErrorMsg": "Error updating CIBIL document data"
        });
      }

    } catch (err) {
      logger.error('CIBIL_DocData_Update Error:', err);
      reject(err);
    }
  });
}


// function SplitCICMessage(TransXpedia){
//     return new Promise((resolved,rejected)=>{
//             try{
//                     logger.info('TransXpedia.RESPONSE_BUFFER',TransXpedia.RESPONSE_BUFFER);
//                     TransXpedia.SplitCICMessage={};
//                     TransXpedia.SplitCICMessage.STATUSDESC = 'Y';
//                     if(TransXpedia.RESPONSE_BUFFER.indexOf('BureauResponseXml')>0){
//                     var BureauResponseXmlData = TransXpedia.RESPONSE_BUFFER.split('BureauResponseXml')[1].slice(8,-9);
//                     var CreditReportDataXML = BureauResponseXmlData.replace(/&amp;amp;lt;/g,'<').replace(/&amp;amp;gt;/g,'>');
//                     }else{
//                             TransXpedia.SplitCICMessage.STATUS = '99';
//                             TransXpedia.SplitCICMessage.STATUSDESC = 'NA';
//                             return resolved(TransXpedia);
//                     }
//                     logger.info('CreditReportDataXML',CreditReportDataXML);
//                     var parseString = require('xml2js').parseString;
//                     parseString(CreditReportDataXML, (err,result) => {
//                             if(result && result.CreditReport && result.CreditReport.Account && result.CreditReport.Account.length){
//                                     for(var i=0; i
// <result.CreditReport.Account.length; i++){
//                                             //if(result.CreditReport.Account[i].Account_NonSummary_Segment_Fields[0].CreditFacility)
//                                             var accFields = result.CreditReport.Account[i].Account_NonSummary_Segment_Fields[0];
//                                             if(accFields.CreditFacility){
//                                                     TransXpedia.SplitCICMessage.STATUSDESC = 'N';
//                                                     break;
//                                             }
//                                             if(accFields.SuitFiledOrWilfulDefault && accFields.SuitFiledOrWilfulDefault[0] != '00'){
//                                                     TransXpedia.SplitCICMessage.STATUSDESC = 'N';
//                                                     TransXpedia.SplitCICMessage.STATUS = '99';
//                                                     break;
//                                             }
//                                             if (accFields.PaymentHistory1) {
//                                                     logger.info(i, accFields.PaymentHistory1[0]);
//                                                     if (accFields.PaymentHistory1[0]) {
//                                                             for (var j = 0; j < accFields.PaymentHistory1FieldLength[0]; j = j + 3) {
//                                                                     var temp = accFields.PaymentHistory1[0].substring(j, j + 3);
//                                                                     if (temp > 90 || temp == 'LSS' || temp == 'DBT' || temp == 'SUB') {
//                                                                             TransXpedia.SplitCICMessage.STATUSDESC = 'N';
//                                                                             TransXpedia.SplitCICMessage.STATUS = '99';
//                                                                             break;
//                                                                     }
//                                                             }
//                                                     }
//                                             }
//                                             if (accFields.PaymentHistory2) {
//                                                     logger.info(i, accFields.PaymentHistory2[0]);
//                                                     if (accFields.PaymentHistory2[0]) {
//                                                             for (var j = 0; j < accFields.PaymentHistory2FieldLength[0]; j = j + 3) {
//                                                               var temp = accFields.PaymentHistory2[0].substring(j, j + 3);
//                                                                     if (temp > 90 || temp == 'LSS' || temp == 'DBT' || temp == 'SUB') {
//                                                                             TransXpedia.SplitCICMessage.STATUSDESC = 'N';
//                                                                             TransXpedia.SplitCICMessage.STATUS = '99';
//                                                                             break;
//                                                                     }
//                                                             }
//                                                     }
//                                             }
//                                             if(accFields.CreditFacility || (accFields.AccountType[0] == '12' && !accFields.DateClosed) || (accFields.AccountType[0] == '17' && !accFields.DateClosed) || (accFields.AccountType[0] == '23' && !accFields.DateClosed) || (accFields.AccountType[0] == '24' && !accFields.DateClosed) || (accFields.AccountType[0] == '33' && !accFields.DateClosed) || (accFields.AccountType[0] == '38' && !accFields.DateClosed) || (accFields.AccountType[0] == '39' && !accFields.DateClosed) || (accFields.AccountType[0] == '40' && !accFields.DateClosed) || (accFields.AccountType[0] == '50' && !accFields.DateClosed) || (accFields.AccountType[0] == '51' && !accFields.DateClosed) || (accFields.AccountType[0] == '52' && !accFields.DateClosed) || (accFields.AccountType[0] == '53' && !accFields.DateClosed) || (accFields.AccountType[0] == '54' && !accFields.DateClosed) || (accFields.AccountType[0] == '61' && !accFields.DateClosed) || (accFields.AccountType[0] == '00' && !accFields.DateClosed))
//                                             TransXpedia.SplitCICMessage.STATUSDESC = 'N';
//                                     }
//                                     TransXpedia.SplitCICMessage.STATUS = '00';
//                             }else if(result && result.CreditReport && result.CreditReport.ScoreSegment && result.CreditReport.ScoreSegment[0].Score == '000-1'){
//                                     TransXpedia.SplitCICMessage.STATUSDESC = 'Y';
//                                     TransXpedia.SplitCICMessage.STATUS = '00';
//                             }else{
//                                     TransXpedia.SplitCICMessage.STATUS = '99';
//                                     TransXpedia.SplitCICMessage.STATUSDESC = result;
//                                     return resolved(TransXpedia);
//                             }
//                     })
//                     if(TransXpedia.SplitCICMessage.STATUSDESC == 'Y' || TransXpedia.SplitCICMessage.STATUSDESC == 'N'){
//                     TransXpedia.RESPONSE_BUFFER1 = TransXpedia.RESPONSE_BUFFER.replace(/&amp;amp;lt;/g,'<').replace(/&amp;amp;gt;/g,'>');
//                     TransXpedia.RESPONSE_BUFFER2 = TransXpedia.RESPONSE_BUFFER1.replace(/&amp;lt;/g,'<').replace(/&amp;gt;/g,'>').replace(/&amp;gt;&#xD;/g,'>');
//                     TransXpedia.RESPONSE_BUFFER3 = TransXpedia.RESPONSE_BUFFER2.replace(/&lt;/g,'<').replace(/&gt;/g,'>');
//                     parseString(TransXpedia.RESPONSE_BUFFER3, (err1,result1) => {
//                     TransXpedia.SplitCICMessage.RESPONSEDATA1 = {"applicationid":result1["s:Envelope"]["s:Body"][0].ExecuteXMLStringResponse[0].ExecuteXMLStringResult[0].DCResponse[0].ContextData[0].Field[1].ApplicationData[0].ApplicationId[0],"documentid":result1["s:Envelope"]["s:Body"][0].ExecuteXMLStringResponse[0].ExecuteXMLStringResult[0].DCResponse[0].ContextData[0].Field[0].Applicants[0].Applicant[0].DsCibilBureau[0].Document[0].Id[0]};
//                     TransXpedia.SplitCICMessage.RESPONSEDATA = JSON.stringify(TransXpedia.SplitCICMessage.RESPONSEDATA1);
//                     });
//                     }else{
//                             TransXpedia.SplitCICMessage.RESPONSEDATA = 'NA';
//                     }

//                     return resolved(TransXpedia);

//             }catch(e){
//                     TransXpedia.systemErr      = e;
//                     TransXpedia.serverError    = errModule.E_MESSAGE_SPLITTING_ERROR;
//                     TransXpedia.errDescription = `UNABLE TO SPLIT DECRYPTED MESSAGE` +
//                              `[FUNCTION : SplitMessage]`;
//                     return rejected(TransXpedia);
//             }
//             });
//             }

// async function GetKeyConfigurationValue(KeyName) {
  // logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);
  // const query = `SELECT [KeyValue] FROM [dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;

  // try {
	  // const pool = await getPool();
	// const request = pool.request();
    
	// //const pool = await sql.connect(config);
    // //logger.info('Connected to the database');

    // //const result = await pool.request()
    // const result = await request()
      // .input('KeyName', sql.VarChar, KeyName)
      // .query(query);

    // if (result.recordset.length > 0) {

      // const jsonString = JSON.stringify(result.recordset, null, 2);
      // formattedString = jsonString.slice(1, -1);
      // //  logger.info('Result: ',formattedString);               
      // //  logger.info('Parse Result: ',JSON.parse(formattedString));
      // const OutValue = JSON.parse(formattedString).KeyValue;
      // //  logger.info('OutValue', OutValue.toString());
      // return JSON.parse(formattedString).KeyValue; // Return the formatted string
    // } else {
      // logger.info('No results found for the provided KeyName.');
      // return null;
    // }
  // } catch (err) {
    // console.error('Error:', err);
    // return null;
  // } finally {
    // await sql.close(); // Ensure the connection is closed
  // }
// }

async function GetKeyConfigurationValue(KeyName) {
  logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  const query = `
    SELECT [KeyValue]
    FROM [dbo].[SVND_CONFIGURATION_DATA]
    WHERE KeyName = @KeyName
  `;

  try {
    const pool = await getPool();
    const request = pool.request();

    const result = await request
      .input('KeyName', sql.VarChar, KeyName)
      .query(query);

    if (result.recordset && result.recordset.length > 0) {
      const value = result.recordset[0].KeyValue;
      logger.info('KeyValue fetched: ' + value);
      return value;
    } else {
      logger.info('No results found for the provided KeyName.');
      return null;
    }

  } catch (err) {
    logger.error('GetKeyConfigurationValue Error:', err);
    return null;
  }
}

async function getUidByRefKeyOnce(refKeyInput) {


  // ✅ Check cache FIRST
  // if (uidCache.has(refKeyInput)) {
    // logger.info(`refKey fetched from cache for Aadhaar: ${refKeyInput}`);
    // return uidCache.get(refKeyInput);
  // }

  // ❗ Call UID API ONLY ONCE
  logger.info(`Calling UID API for Aadhaar: ${refKeyInput}`);
  const resp = await objAadhaarDataLayer.GetDataByRefKeyAPI(refKeyInput);

  const refKey = resp?.Data?.vaultData?.uid;
  if (!refKey) {
    throw new Error("refKey not received from UID API");
  }

  // ✅ Store in cache
  //uidCache.set(refKeyInput, refKey);
  logger.info(`refKey cached for Aadhaar: ${refKeyInput}`);

  return refKey;
}



module.exports = { funCIBILRequestXML, CIBILData_Insert, PullConsumerCibilAPI, CIBILData_Update, PullCIBILDocumentAPI, GetStateCode };