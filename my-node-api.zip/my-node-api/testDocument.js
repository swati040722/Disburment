testEncrypt.jsconst { PDFDocument } = require('pdf-lib/dist/pdf-lib');

(async () => {
  const pdfDoc = await PDFDocument.create();

  // This must exist
  if (typeof pdfDoc.encrypt !== 'function') {
    console.error('ERROR: encrypt() is not available!');
    return;
  }

  pdfDoc.encrypt({
    userPassword: 'userpass123',
    ownerPassword: 'ownerpass123',
    permissions: { printing: 'highResolution', copying: false, modifying: false }
  });

  const pdfBytes = await pdfDoc.save();
  console.log('PDF encryption works! Bytes length:', pdfBytes.length);
})();