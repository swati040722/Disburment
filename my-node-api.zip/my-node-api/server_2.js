
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // Disable SSL check due to bank's proxy server
const express = require('express');
const cors = require('cors');
const sql = require('mssql');
const userDataLayer = require('./UserManagementDataLayer');
const app = express();
// Increase limit for JSON payloads
app.use(express.json({ limit: '50mb' })); // or a larger value like '50mb'
app.use(express.urlencoded({ limit: '50mb', extended: true }));
const jwt = require('jsonwebtoken');
const crypto = require('crypto-js');
const secretKey = '8fdfdb7245c044279078ea1966a096fa';
const jwtSecret = '8fdfdb7245c042379878ea1966a096fa';
const moment = require('moment');
const activeSessions = {};
const ip = require('ip');
// const { HttpsProxyAgent } = require('https-proxy-agent');//for System Proxy
// const https = require('https');
// const http = require('http');
// // const ActiveDirectory = require('activedirectory');
// const ldap = require('ldapjs');
// const {config}= require('./config');
// const { proxyUrl } = require('./config');
// const ProxyAgent = require('https-proxy-agent');
//const agent = new HttpsProxyAgent(proxyUrl);
const { HttpsProxyAgent } = require('https-proxy-agent');//for System Proxy
const https = require('https');
const http = require('http');
// const ActiveDirectory = require('activedirectory');
const ldap = require('ldapjs');
const { config } = require('./config').default;
const { proxyUrl } = require('./config').default;
const ProxyAgent = require('https-proxy-agent');
const agent = new HttpsProxyAgent(proxyUrl);
const axios = require('axios');
//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('ServerLogs');
const logError = require('./ErrorLog');

const objSIDBILayer = require('./SIDBIDataLayer');
const objCIBILDataLayer = require('./CIBILDataLayer');
const objGeneralOperation = require('./GeneralDataLayer');
const objCBSLayer = require('./CBSDataLayer');
const objNeSLLayer = require('./NeSLDataLayer.js');
const objValueFirstDataLayer = require('./ValueFirstDataLayer');
const objCommonFunction = require('./CommonFunctions');
const objAadhaarDataLayer = require('./AadhaarDataLayer');
const e = require('express');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Console } = require('console');
const pem = require("pem");
const { emitKeypressEvents } = require('readline');
const { Logger } = require('winston');
const { ref } = require('process');
//let refKey = '';
const refKeyCache = new Map();
const uidCache = new Map();


// // Enable CORS
app.use(cors({
  origin: 'http://localhost:4200', // Allow only this origin
}));


app.options('*', cors());


app.use(express.json()); // For parsing application/json

// const config = {
//   user: 'nodejsuser',
//   password: 'Pnb@12345',
//   server: '10.192.236.6',
//   port: 1434,
//   database: 'PMSvanidhiDB',
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000,
//   },
//   options: {
//     encrypt: true,
//     trustServerCertificate: true,
//   },
// };




//logger.info("CONFIG DATA",config);








// // Define your proxy URL (you can get this from environment variables or hardcode it)
// const proxyUrl = process.env.HTTPS_PROXY || 'http://10.192.34.167:3128';   //http://corpoffice.pnb.net:3128
// // Create a new agent instance
// const ProxyAgent = new HttpsProxyAgent(proxyUrl);


// // // const agent = new https.Agent({
// // //    rejectUnauthorized: false, // Set to false to bypass certificate verification 
// // //    HttpsProxyAgent:proxyUrl 
// // // });
// const httpAgent = new https.Agent({
//   rejectUnauthorized: true, // Set to false to bypass certificate verification 

// });


//Start the server on port 3000
//  var port = 3000;
            //     app.listen(port, async () => {
            //     logger.info('Node.js server is running on http://10.192.235.7:3000');
            // });

    // app.listen(port, async () => {
    //             logger.info('Node.js server is running on http://10.192.205.179:3000');
    //          });

            app.listen(3000, 'localhost', () => {
             console.log('Server is running on http://localhost:3000');
            });
// Additional initialization logic (e.g., database connection) with error handling
setTimeout(() => {
  logger.info('Initialization completed');
}, 1000); // Simulate some initialization delay if necessary



async function getRefKeyOnce(encAadhaarPayload) {
  // Decrypt Aadhaar
  const aadhaar = await objCommonFunction.Decrypt(encAadhaarPayload);

  // ✅ Check cache FIRST
  if (refKeyCache.has(aadhaar)) {
    logger.info(`refKey fetched from cache for Aadhaar: ${aadhaar}`);
    return refKeyCache.get(aadhaar);
  }

  // ❗ Call UID API ONLY ONCE
  logger.info(`Calling UID API for Aadhaar: ${aadhaar}`);
  const resp = await objAadhaarDataLayer.GetDataByUIDAPI(aadhaar);

  const refKey = resp?.Data?.vaultData?.refKey;
  if (!refKey) {
    throw new Error("refKey not received from UID API");
  }

  // ✅ Store in cache
  refKeyCache.set(aadhaar, refKey);
  logger.info(`refKey cached for Aadhaar: ${aadhaar}`);

  return refKey;
}


async function getRefKeyOncebyUID(aadhaar1) {

  logger.info('Before calling getRefKeyOncebyUID', aadhaar1);

  // 🔒 1. Mandatory validation
  if (!aadhaar1 || typeof aadhaar1 !== 'string' || aadhaar1.trim() === '') {
    logger.error('Aadhaar UID is blank or invalid');
    throw new Error('Aadhaar UID is mandatory and cannot be blank');
  }

  const cleanAadhaar = aadhaar1.trim();

  // 🔒 2. Optional format validation (strongly recommended)
  if (!/^\d{12}$/.test(cleanAadhaar)) {
    logger.error(`Invalid Aadhaar format: ${cleanAadhaar}`);
    throw new Error('Invalid Aadhaar UID format');
  }

  // ✅ 3. Cache check
  if (refKeyCache.has(cleanAadhaar)) {
    logger.info(`refKey fetched from cache for Aadhaar: ${cleanAadhaar}`);
    return refKeyCache.get(cleanAadhaar);
  }

  // ❗ 4. Call API ONLY when valid
  logger.info(`Calling UID API for Aadhaar: ${cleanAadhaar}`);
  const resp = await objAadhaarDataLayer.GetDataByUIDAPI(cleanAadhaar);

  const refKey = resp?.Data?.vaultData?.refKey;
  if (!refKey) {
    logger.error('refKey missing in UID API response');
    throw new Error('refKey not received from UID API');
  }

  // ✅ 5. Cache safely
  refKeyCache.set(cleanAadhaar, refKey);
  logger.info(`refKey cached for Aadhaar: ${cleanAadhaar}`);

  return refKey;
}


async function getUidByRefKeyOnce(refKeyInput) {
  

  // ✅ Check cache FIRST
  if (uidCache.has(refKeyInput)) {
    logger.info(`refKey fetched from cache for Aadhaar: ${refKeyInput}`);
    return uidCache.get(refKeyInput);
  }

  // ❗ Call UID API ONLY ONCE
  logger.info(`Calling UID API for Aadhaar: ${refKeyInput}`);
  const resp = await objAadhaarDataLayer.GetDataByRefKeyAPI(refKeyInput);

  const refKey = resp?.Data?.vaultData?.uid;
  if (!refKey) {
    throw new Error("refKey not received from UID API");
  }

  // ✅ Store in cache
  uidCache.set(refKeyInput, refKey);
  logger.info(`refKey cached for Aadhaar: ${refKeyInput}`);

  return refKey;
}



app.post('/api/SendMobileOTP', async (req, res) => {


   
  logger.info("***********************Inside LoginDetails (START)*************************");
  const { userid, password } = req.body;
  logger.info("Login UserID: " + userid)
  logger.info("Login Password: " + password)
  const userPrincipalName = `${userid}@pnb.net`;
  logger.info("userPrincipalName: " + userPrincipalName)
  // Create an LDAP client
  const client = ldap.createClient({
    url: 'LDAPS://vdc-cisdad01.pnb.net:636'  // Use secure LDAPS connection
  });
  // Bind to the server with the provided bindDN and credentials
  client.bind(userPrincipalName, password, (err, auth) => {//5187736@pnb.net Newdelhi@1223
    if (err) {
      console.error('Bind failed:', JSON.stringify(err));
      if (err.lde_message == 'Invalid Credentials') {
        resJSON = {
          "ErrorCode": "01",
          "ErrorMessage": err.lde_message,
          "EncString": null
        }
      }
      else {
        resJSON = {
          "ErrorCode": "01",
          "ErrorMessage": "Error while Active Directory Authentication",
          "EncString": null
        }
      }

      return res.json(JSON.stringify(resJSON));
    } else {
      logger.info('Bind successful with Response');
      // Search for the user with the sAMAccountName (e.g., "5187736")
      const searchOptions = {
        filter: `(sAMAccountName=${userid})`, // Searching by sAMAccountName
        scope: 'sub', // Search the whole subtree
        attributes: ['distinguishedName', 'ou', 'cn'] // We want to retrieve these attributes
      };

      client.search('dc=pnb,dc=net', searchOptions, (err, resp) => {
        if (err) {
          console.error('Search failed:', err);
          return;
        }

        resp.on('searchEntry', (entry) => {
          logger.info('User DN:', JSON.stringify(entry.dn));
          logger.info('User attributes:', JSON.stringify(entry.attributes));
          const ADResponse = entry.attributes;
          // Extract the values for "cn" and "distinguishedName"
          const cnValue = ADResponse.find(item => item.type === 'cn')?.values[0];
          const distinguishedNameValue = ADResponse.find(item => item.type === 'distinguishedName')?.values[0];
          logger.info("Name: " + cnValue)
          // logger.info("ouParts: "+ouParts)
          logger.info("distinguishedNameValue: " + distinguishedNameValue)

          // Extract PostingLocation and PostingSOL from the Distinguished Name
          const { postingLocation, postingSOLPart, LoginUserType } = extractOUDetails(distinguishedNameValue);
          logger.info("out postingLocation: " + postingLocation);
          logger.info("out postingSOLPart: " + postingSOLPart);
          logger.info("out LoginUserType: " + LoginUserType);
          if (LoginUserType === "CO" || LoginUserType === "ZO") {
            returnResp = {
              "ErrorCode": "01",
              "ErrorMessage": "You are not authorised to access this portal"
            }
            logger.info('');
            logger.info('############################### You are not authorised ao access this portal ###############################');
            logger.info(JSON.stringify(returnResp));
            return res.json(JSON.stringify(returnResp));
          }
          else {
            userDataLayer.getEmployeeDetails(userid, postingSOLPart).then(async (response) => {
              if (response != null) {
                logger.info("Output getEmployeeDetails " + JSON.stringify(response))
                ParseUserData = JSON.parse(response);
                logger.info("Output EMPLOYEE_ID " + ParseUserData.EMPLOYEE_ID)
                let token = generateToken(userid);
                logger.info("Token " + token);
                if (!response) {
                  console.error("Error while fecting user data given by hrms team.");
                  resJSON = {
                    ErrorCode: "01",
                    ErrorMessage: "Error while fecting user data given by hrms team.",
                    EncString: null
                  }
                  return res.json(JSON.stringify(resJSON));
                }
                logger.info("AD SOL " + postingSOLPart);

                // Only call CreateEncLoginObject once if the logic has been validated.

                //Call vFirst SMS API 

                logger.info('###############################  Call ValueFirstToken API ((START)) ###############################');
                //logger.info('############################### 7. Call ValueFirstToken API ((START)) ###############################');
                objGeneralOperation.getVFirstToken(userid, 'Dashboard').then(async (VFirstTokenDetails) => {
                  logger.info('Output getVFirstToken: ' + JSON.stringify(VFirstTokenDetails));
                  //logger.info('get VFirstToken Response saved in local database: '+JSON.stringify(VFirstTokenDetails));                            
                  if (VFirstTokenDetails.ErrorCode == "00") {
                    logger.info('');
                    logger.info('###############################  SUCCESS CallValueFirstToken API ((END)) ###############################')
                    logger.info('');
                    let VfisrtOTPReq = {
                      "MobileNo":ParseUserData.MOBILE_NUMBER ,
                      "Token": VFirstTokenDetails.VFirstToken
                    }
                    logger.info('');
                    logger.info('############################### Call SendVFirstOTP API ((START)) ###############################');
                    logger.info('');
                    objValueFirstDataLayer.SendVFirstOTP(userid, 'Dashboard', JSON.stringify(VfisrtOTPReq)).then(async (VFirstOTPDetails) => {
                      logger.info('Output SendVFirstOTP: ' + JSON.stringify(VFirstOTPDetails));
                      if (VFirstOTPDetails.ErrorCode == "00") {
                        CreateEncLoginObject(userid, ParseUserData, token, LoginUserType).then((JsonObj) => {
                          logger.info("Output CreateEncLoginObject Encrypted String: " + JsonObj);
                          logger.info("Output CreateEncLoginObject EncString: " + JSON.parse(JsonObj).EncString);
                          logger.info("Output CreateEncLoginObject Role: " + JSON.parse(JsonObj).Role);
                          resJSON = {
                            "ErrorCode": "00",
                            "ErrorMessage": "User successfully logged in.",
                            "EncString": JSON.parse(JsonObj).EncString,
                            "Role": JSON.parse(JsonObj).Role,
                            "AccessToken": JSON.parse(JsonObj).AccessToken
                          }
                          logger.info("Return Object " + JSON.stringify(resJSON));
                          return res.json(JSON.stringify(resJSON));
                        })
                          .catch((error) => {
                            console.error("Error: ", error);
                          });
                      }
                      else {
                        SIDBIResp = {
                          "ErrorCode": "01",
                          "ErrorMessage": "Error while sending mobile OTP.",
                          "EncString": ""
                        }
                        logger.info('');
                        logger.info('############################### FAILURE CallSendVFirstOTP API ((END)) ###############################');
                        logger.info('');
                        return res.json(JSON.stringify(SIDBIResp));
                      }
                    });
                  }
                  else {
                    SIDBIResp = {
                      "ErrorCode": "01",
                      "ErrorMessage": "Error while generating vFirst Token"
                    }
                    logger.info('');
                    logger.info('############################### FAILURE CallValueFirstToken API ((END)) ###############################');
                    logger.info('');
                    return res.json(SIDBIResp);
                  }
                });
              }
              else {
                returnResp = {
                  "ErrorCode": "01",
                  "ErrorMessage": "You are not authorised to access this portal"
                }
                logger.info('');
                logger.info('############################### You are not authorised ao access this portal ###############################');
                logger.info(JSON.stringify(returnResp));
                return res.json(JSON.stringify(returnResp));
              }
            });
          }
        });
      });
      res.on('end', (result) => {
        logger.info('Search finished:', result.status);
        client.unbind();
      });
    }
  });
  // You should always unbind when you're done to close the connection
  client.unbind();
});

function extractOUDetails(distinguishedNameValue) {
  const ouParts = distinguishedNameValue.split(',').map(part => part.trim()); // Split the DN into parts
  let postingLocation = '';
  let postingSOLPart = '';
  let LoginUserType = ''; // Array to store the first part (e.g., BR, CO, ZO)

  // Loop through the parts to find the OU with the expected pattern
  ouParts.forEach(part => {
    if (part.startsWith('OU=')) {
      const ouSegment = part.replace('OU=', ''); // Remove 'OU=' to work with the remaining value
      const ouSegmentParts = ouSegment.split('-'); // Split the value using '-'

      // Extract the first part (e.g., BR, CO, ZO, BO)
      // if (ouSegmentParts.length > 0) {
      //   ouPrefixValues.push(ouSegmentParts[0]);
      // }

      // Check if the part contains 'BO' and return its value if it exists
      if (ouSegmentParts[0] === 'BR') {
        postingLocation = ouSegmentParts.slice(0, ouSegmentParts.length - 1).join('-'); // Join the first parts to form the division   
        postingSOLPart = ouSegmentParts[2]; // The next part after 'BO' will be the PostingSOL
        LoginUserType = ouSegmentParts[0];
        return; // Stop further processing as we've found the 'BO' part
      }
    }
  });

  // If BO is not found, process the last `OU` as usual
  if (!postingLocation) {
    logger.info('BR nahi mila');
    postingLocation = '';
    postingSOLPart = '';
    ouParts.forEach(part => {
      if (part.startsWith('OU=')) {
        const ouSegment = part.replace('OU=', '');
        const ouSegmentParts = ouSegment.split('-');

        // Extract the first part (e.g., BR, CO, ZO, BO)
        // if (ouSegmentParts.length > 0) {
        //   ouPrefixValues.push(ouSegmentParts[0]);
        // }
        // Check if the part contains 'BO' and return its value if it exists
        if (ouSegmentParts[0] === 'CO') {
          postingLocation = ouSegmentParts.slice(0, ouSegmentParts.length - 1).join('-');
          postingSOLPart = ouSegmentParts[2];
          LoginUserType = ouSegmentParts[0];
          return;
        }
      }
    });
    if (!postingLocation) {
      logger.info('CO nahi mila');
      postingLocation = '';
      postingSOLPart = '';
      ouParts.forEach(part => {
        if (part.startsWith('OU=')) {
          const ouSegment = part.replace('OU=', '');
          const ouSegmentParts = ouSegment.split('-');
          // Extract the first part (e.g., BR, CO, ZO, BO)
          //  if (ouSegmentParts.length > 0) {
          //    ouPrefixValues.push(ouSegmentParts[0]);
          //  }

          // Check if the part contains 'BO' and return its value if it exists
          if (ouSegmentParts[0] === 'ZO' || ouSegmentParts[0] === 'HO') {
            postingLocation = ouSegmentParts.slice(0, ouSegmentParts.length - 1).join('-'); // Join the first parts to form the division   
            postingSOLPart = ouSegmentParts[2]; // The next part after 'BO' will be the PostingSOL
            LoginUserType = ouSegmentParts[0];
            return; // Stop further processing as we've found the 'BO' part
          }
        }
      });
    }
  }
  return {
    postingLocation,
    postingSOLPart,
    LoginUserType // Return the array with the prefixes (e.g., BR, CO, ZO)
  };
}

async function CreateEncLoginObject(userid, ParseUserData, token, LoginUserType) {
  logger.info("Inside CreateEncLoginObject");

  logger.info('EMPLOYEE_ID: ' + ParseUserData.EMPLOYEE_ID);

  logger.info('EMPLOYEE_NAME: ' + ParseUserData.EMPLOYEE_NAME);
  logger.info('GRADE: ' + ParseUserData.GRADE);
  logger.info('MaxGrade: ' + ParseUserData.MaxGrade);
  logger.info('MOBILE_NUMBER: ' + ParseUserData.MOBILE_NUMBER);
  logger.info('BRANCH_CODE: ' + ParseUserData.BRANCH_CODE);
  logger.info('DESIGNATION: ' + ParseUserData.DESIGNATION);
  let UserGradeValue = "";
  let SOLMaxGrade = "";

  if (ParseUserData.GRADE.substring(0, 1) === "S") {
    UserGradeValue = parseInt(ParseUserData.GRADE.substring(1));  // Extract number after 'S'
    SOLMaxGrade = parseInt(ParseUserData.MaxGrade.substring(1));  // Extract number after 'S'
  }
  else {
    logger.info("else Yaha AAYA");
    UserGradeValue = ParseUserData.GRADE;
    SOLMaxGrade = parseInt(ParseUserData.MaxGrade.substring(1));  // Extract number after 'S'
  }


  logger.info('UserGradeValue: ' + UserGradeValue);
  logger.info('SOLMaxGrade: ' + SOLMaxGrade);
  let UserRole = '';


  if (LoginUserType == 'BR') {
    if (UserGradeValue < SOLMaxGrade && (ParseUserData.GRADE == "S1" || ParseUserData.GRADE == "S2" || ParseUserData.GRADE == "S3" || ParseUserData.GRADE == "S4" || ParseUserData.GRADE == "S5" || ParseUserData.GRADE == "S6"
      || ParseUserData.GRADE == "S7" || ParseUserData.GRADE == "S8")) {
      UserRole = 'BOMaker';
      logger.info(`${ParseUserData.GRADE} is less than ${ParseUserData.MaxGrade}. and User in officer grade only`);
    }
    else if (UserGradeValue === SOLMaxGrade &&
      (ParseUserData.DESIGNATION.toUpperCase() === 'BRANCH HEAD-AGM' || ParseUserData.DESIGNATION.toUpperCase() === 'BRANCH HEAD-CM' || ParseUserData.DESIGNATION.toUpperCase() === 'BRANCH MANAGER SCALE-II' ||
        ParseUserData.DESIGNATION.toUpperCase() === 'OFFICER INCHARGE' || ParseUserData.DESIGNATION.toUpperCase() === 'OFR INCHARGE - DY MANAGER' ||
        ParseUserData.DESIGNATION.toUpperCase() === 'SR. BRANCH MANAGER') && ParseUserData.OfficerCount > 1) {
      UserRole = 'BOChecker';//BOChecker
      logger.info(`${ParseUserData.GRADE} is equal ${ParseUserData.MaxGrade}. and User in officer grade only`);//same grade person in sol have  bizz-words as incumbent
    }
    else if (UserGradeValue === SOLMaxGrade && (ParseUserData.DESIGNATION !== 'Branch Head-AGM' || ParseUserData.DESIGNATION !== 'Branch Head-CM' || ParseUserData.DESIGNATION !== 'Branch Manager Scale-II'
      || ParseUserData.DESIGNATION !== 'OFFICER INCHARGE' || ParseUserData.DESIGNATION !== 'OFR INCHARGE - DY MANAGER' || ParseUserData.DESIGNATION !== 'SR. BRANCH MANAGER') && ParseUserData.OfficerCount > 1) {
      UserRole = 'BOMaker';
      logger.info(`${ParseUserData.GRADE} is equal ${ParseUserData.MaxGrade}. and User in officer grade only not buzz words`);//same grade person in sol have no bizz-words as incumbent
    }
    else if (UserGradeValue === SOLMaxGrade && ParseUserData.OfficerCount == 1) {
      UserRole = 'BOChecker';
      logger.info(`${ParseUserData.GRADE} is less than ${ParseUserData.MaxGrade}.`);//only one officer as checker
    }
    else if (UserGradeValue == "CLK" && ParseUserData.OfficerCount == 1) {
      UserRole = 'BOMaker';
      logger.info(`${ParseUserData.GRADE} is less than ${ParseUserData.MaxGrade}.`);//Clerk
    }
    else {
      UserRole = ''
      logger.info('No Employee data found ');
    }
  }
  else if (LoginUserType == 'CO') {
    UserRole = 'COAdmin'
  }
  else if (LoginUserType == 'ZO') {
    UserRole = 'ZOAdmin'
  }
  else if (LoginUserType == 'HO') {
    UserRole = 'HOAdmin'
  }
  else {

  }
  logger.info('UserRole: ' + UserRole);

  const respJON = {
    "UserID": userid,
    "UserName": ParseUserData.EMPLOYEE_NAME,
    "UserRole": UserRole,
    "UserSOL": ParseUserData.BRANCH_CODE,
    "MobileNo": ParseUserData.MOBILE_NUMBER,     
  };

  try {
    // Wait for the encryption to complete
    const EncString = await objCommonFunction.Encrypt(JSON.stringify(respJON));

    // After encryption, insert login trail
    const respLoginTrail = await LoginUserTrailInsert(userid);

    JSONObj = {
      "EncString": EncString,
      "Role": UserRole,
      "AccessToken": token
    }

    if (respLoginTrail.ErrorCode === "00") {
      //logger.info("Inside CreateEncLoginObject EncString: " + EncString);
      return JSON.stringify(JSONObj); // return the encrypted string after login trail
    } else {
      throw new Error("Login trail failed.");
    }
  } catch (error) {
    console.error("Error in CreateEncLoginObject: " + error.message);
    return undefined; // return undefined in case of error
  }
}

app.post('/api/OTPValidate', async (req, res) => {



    logger.info("***********************RESPONSE FROM UID  (START)*************************"+respfromuid);
  logger.info("*************Inside OTPValidate****************");
  const { EncPMPayload, encOValue, encData } = req.body;
  logger.info('EncPMPayload: ' + EncPMPayload + ' EncOTP: ' + encOValue);
  try {
    objCommonFunction.Decrypt(EncPMPayload).then(async (PFNumber) => {
      logger.info(PFNumber);
      objCommonFunction.Decrypt(encData).then(async (jsonString) => {
        logger.info(jsonString);
        // Parse the string into an object
        const userData = JSON.parse(jsonString);
        // Accessing values   
        logger.info('MobileNo:', userData.MobileNo);

        objCommonFunction.Decrypt(encOValue).then(async (OTP) => {
          objCommonFunction.OTPsha256Hash(OTP.toString()).then(async (OTPHash) => {
            let OTPReq = {
              "UserID": userData.MobileNo,
              "PFNumber": PFNumber,
              "OTPHash": OTPHash,
              "OTPMsg": "OTP Verified successfully.",
            }
            logger.info('OTPReq ' + JSON.stringify(OTPReq))
            //Verify otp data in database
            logger.info("************* 9. Call VerifyVFirstOTP ((START)) ****************");
            objGeneralOperation.VerifyVFirstOTP(OTPReq).then(async (VFirstOTPInsert) => {
              logger.info('Out VerifyVFirstOTP Result: ' + VFirstOTPInsert.ErrorCode);
              logger.info('Out VerifyVFirstOTP Result: ' + VFirstOTPInsert.ErrorMsg);
              if (VFirstOTPInsert.ErrorCode == "00") {
                outResp = {
                  "ErrorCode": "00",
                  "ErrorMessage": "OTP successfully validated."
                }
                logger.info("************* 9. SUCCESS VerifyVFirstOTP ((END)) ****************");
                logger.info("If outResp: " + JSON.stringify(outResp));
                return res.json(outResp);
              }
              else if (VFirstOTPInsert.ErrorCode == "01" && VFirstOTPInsert.ErrorMsg.toUpperCase() == 'ENTERED OTP GOT EXPIRED') {
                outResp = {
                  "ErrorCode": "02",
                  "ErrorMessage": VFirstOTPInsert.ErrorMsg
                }
                logger.info("************* 9. FAILURE VerifyVFirstOTP ((END)) ****************");
                logger.info("Else outResp: " + JSON.stringify(outResp));
                return res.json(outResp);
              }
              else {
                outResp = {
                  "ErrorCode": VFirstOTPInsert.ErrorCode,
                  "ErrorMessage": VFirstOTPInsert.ErrorMsg
                }
                logger.info("************* 9. FAILURE VerifyVFirstOTP ((END)) ****************");
                logger.info("Else outResp: " + JSON.stringify(outResp));
                return res.json(outResp);
              }
            });
          });
        });
      });
    });
  } catch (error) {

    logError.ErrorLogs(PMSNumber, error.response.status, error.response.statusText, "PMSOTPValidate").then(async (ErrorLogResp) => {
      ExceptionResp = {
        "ErrorCode": "01",
        "ErrorMsg": error.response.status + " - " + error.response.statusText,
      }
      resolve(ExceptionResp);
    });

    if (error.response) {
      switch (error.response.status) {
        case 400:
          console.error('Bad Request:', error.response.data);
          break;
        case 401:
          console.error('Unauthorized:', error.response.data);
          break;
        case 404:
          console.error('Not Found:', error.response.data);
          break;
        case 500:
          console.error('Internal Server Error:', error.response.data);
          break;
        default:
          console.error('HTTP Error:', error.response.status, error.response.data);
      }
    } else if (error.request) {
      console.error('No response received:', error.request);
    } else {
      console.error('Error:', error.message);
    }
  }
  finally {
    // Close the connection pool
    // await conn.close();
  }

  // Define a dashboard route
  app.get('/dashboard', (req, res) => {
    logger.info('hi in dashboard');
    logger.info('hi in dashboard' + req.cookies.AadhaarNumber);
    const AadhaarNumber = req.cookies.AadhaarNumber;
    if (AadhaarNumber) {
      res.send(`Welcome, ${AadhaarNumber}!`);
    }
    else {
      res.status(401).send('You are not logged in');
    }
  });
  // Define a logout route
  app.get('/logout', (req, res) => {
    res.clearCookie('username');
    res.redirect('/login');
  });

});


app.post('/api/PMSOTPValidate', async (req, res) => {

   
  logger.info("*************Inside PMSOTPValidate****************");
  const { EncPMPayload, encOValue } = req.body;
  logger.info('EncPMPayload: ' + EncPMPayload + ' EncOTP: ' + encOValue);
  try {
    objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {
      objCommonFunction.Decrypt(encOValue).then(async (OTP) => {
        objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => {
          // logger.info('RespCustomerJourneyData '+JSON.stringify(RespCustomerJourneyData));
          let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
          objCommonFunction.OTPsha256Hash(OTP.toString()).then(async (OTPHash) => {
            let OTPReq = {
              "UserID": CustomerJourneyDataParsed.MobileNo,
              "OTPHash": OTPHash,
              "OTPMsg": "OTP Verified successfully.",
            }
            logger.info('OTPReq ' + JSON.stringify(OTPReq))
            //Verify otp data in database
            logger.info("************* 9. Call VerifyVFirstOTP ((START)) ****************");
            objGeneralOperation.VerifyVFirstOTP(OTPReq).then(async (VFirstOTPInsert) => {
              logger.info('Out VerifyVFirstOTP Result: ', VFirstOTPInsert.ErrorCode);
              logger.info('Out VerifyVFirstOTP Result: ', VFirstOTPInsert.ErrorMsg);
              if (VFirstOTPInsert.ErrorCode == "00") {
                outResp = {
                  "ErrorCode": "00",
                  "ErrorMessage": "Your PMS number has been successfully validated. Please generate otp to validate Aadhaar Number"
                }
                logger.info("************* 9. SUCCESS VerifyVFirstOTP ((END)) ****************");
                logger.info("If outResp: ", outResp);
                return res.json(outResp);
              }
              else {
                outResp = {
                  "ErrorCode": VFirstOTPInsert.ErrorCode,
                  "ErrorMessage": VFirstOTPInsert.ErrorMsg
                }
                logger.info("************* 9. FAILURE VerifyVFirstOTP ((END)) ****************");
                logger.info("Else outResp: ", outResp);
                return res.json(outResp);
              }
            });
          });
        });
      });

    });
  } catch (error) {

    logError.ErrorLogs(PMSNumber, error.response.status, error.response.statusText, "PMSOTPValidate").then(async (ErrorLogResp) => {
      ExceptionResp = {
        "ErrorCode": "01",
        "ErrorMsg": error.response.status + " - " + error.response.statusText,
      }
      resolve(ExceptionResp);
    });

    if (error.response) {
      switch (error.response.status) {
        case 400:
          console.error('Bad Request:', error.response.data);
          break;
        case 401:
          console.error('Unauthorized:', error.response.data);
          break;
        case 404:
          console.error('Not Found:', error.response.data);
          break;
        case 500:
          console.error('Internal Server Error:', error.response.data);
          break;
        default:
          console.error('HTTP Error:', error.response.status, error.response.data);
      }
    } else if (error.request) {
      console.error('No response received:', error.request);
    } else {
      console.error('Error:', error.message);
    }
  }
  finally {
    // Close the connection pool
    // await conn.close();
  }

  // Define a dashboard route
  app.get('/dashboard', (req, res) => {
    logger.info('hi in dashboard');
    logger.info('hi in dashboard' + req.cookies.AadhaarNumber);
    const AadhaarNumber = req.cookies.AadhaarNumber;
    if (AadhaarNumber) {
      res.send(`Welcome, ${AadhaarNumber}!`);
    }
    else {
      res.status(401).send('You are not logged in');
    }
  });
  // Define a logout route
  app.get('/logout', (req, res) => {
    res.clearCookie('username');
    res.redirect('/login');
  });

});


app.post('/api/AadhaarOTPGenerate', async (req, res) => {

  logger.info('req body' + req.body);
  const { EncADPayload, EncPMPayload } = req.body;
  logger.info('AadhaarNumber:' + EncADPayload + '\nPMSNumber:' + EncPMPayload);
 
  logger.info('');
  logger.info('############################### Inside AadhaarOTPGenerate API ((START)) ###############################');
  logger.info('');
  try {
    objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNo) => {
      objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {
        logger.info('');
        logger.info('############################### 10. Call SendAadhaarOTP API ((START)) ###############################');
        logger.info('');
        objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => {
          // logger.info('RespCustomerJourneyData '+JSON.stringify(RespCustomerJourneyData));
          let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
          objAadhaarDataLayer.SendAadhaarOTPAPI(PMSNumber, AadhaarNo, CustomerJourneyDataParsed.JourneyID).then(async (objRespSendAadhaarOTP) => {

            logger.info('Out SendAadhaarOTP Result: ' + JSON.stringify(objRespSendAadhaarOTP));
            if (objRespSendAadhaarOTP.ErrorCode == "00") {
              outResp = {
                "ErrorCode": objRespSendAadhaarOTP.ErrorCode,
                "ErrorMessage": objRespSendAadhaarOTP.ErrorMsg
              }
              logger.info("************* 10. SUCCESS SendAadhaarOTP ((END)) ****************");
              logger.info("If outResp: " + outResp);
              return res.json(outResp);
            }
            else {
              outResp = {
                "ErrorCode": objRespSendAadhaarOTP.ErrorCode,
                "ErrorMessage": objRespSendAadhaarOTP.ErrorMsg
              }
              logger.info("************* 10. FAILURE SendAadhaarOTP ((END)) ****************");
              logger.info("Else outResp: " + outResp);
              return res.json(outResp);
            }

          });
        });

      });
    });
  } catch (error) {
    if (error.response) {
      switch (error.response.status) {
        case 400:
          console.error('Bad Request:', error.response.data);
          break;
        case 401:
          console.error('Unauthorized:', error.response.data);
          break;
        case 404:
          console.error('Not Found:', error.response.data);
          break;
        case 500:
          console.error('Internal Server Error:', error.response.data);
          break;
        default:
          console.error('HTTP Error:', error.response.status, error.response.data);
      }
    } else if (error.request) {
      console.error('No response received:', error.request);
    } else {
      console.error('Error:', error.message);
    }
  }
  finally {
    // Close the connection pool
    // await conn.close();
  }
});



app.post('/api/AadhaarOTPValidate', async (req, res) => {

  const { EncADPayload, EncPMPayload, encOValue } = req.body;
  logger.info('EncADPayload: ' + EncADPayload + ' Encotp: ' + encOValue);
  logger.info('');
  logger.info('');
  logger.info('############################### Inside AadhaarOTPValidate API ((START)) ###############################');
  logger.info('');
  try {
    objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {
      objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNo) => {
        objCommonFunction.Decrypt(encOValue).then(async (OTP) => {

          logger.info('');
          logger.info('############################### 11. Call SendAadhaarOTP API ((START)) ###############################');
          logger.info('');
          objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => {
            let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
            let PlainString = {
              "AadhaarNumber": CustomerJourneyDataParsed.AadhaarNo,
              "PMSNumber": CustomerJourneyDataParsed.PMSNumber,
              "JourneyID": CustomerJourneyDataParsed.JourneyID,
              "CustomerID": CustomerJourneyDataParsed.CustomerID
            }

            logger.info("PlainString ", JSON.stringify(PlainString));
            objCommonFunction.Encrypt(JSON.stringify(PlainString)).then(async (EncString) => {
              logger.info("EncString ", EncString);
              objGeneralOperation.getAadhaarOTPData(PMSNumber, AadhaarNo, CustomerJourneyDataParsed.JourneyID).then(async (RespCustomerJourneyData) => {
                if (RespCustomerJourneyData != null) {
                  objGeneralOperation.getCustomerDetails(CustomerJourneyDataParsed.CustomerID).then(async (RespCustomerData) => {
                    if (RespCustomerData != null) {

                      let ParseRespCustomerJourneyData = JSON.parse(RespCustomerJourneyData);
                      objGeneralOperation.getCustomerDetails(CustomerJourneyDataParsed.CustomerID).then(async (CustomerIDDetails) => {
                        logger.info('Output getCustomerDetails Data ' + JSON.stringify(CustomerIDDetails));

                
                         objAadhaarDataLayer.ValidateAadhaarOTPAPI(PMSNumber, AadhaarNo, OTP, ParseRespCustomerJourneyData.ReqTxn, CustomerJourneyDataParsed.JourneyID,
                           JSON.parse(RespCustomerData),JSON.parse(CustomerIDDetails)).then(async (objRespSendAadhaarOTP) => {
                         
                            
                   
                            logger.info('Out SendAadhaarOTP Result: ', JSON.stringify(objRespSendAadhaarOTP));
                              //objRespSendAadhaarOTP.ErrorCode == "00"

                            if (objRespSendAadhaarOTP.ErrorCode == "00") {
                              outResp = {
                                "ErrorCode": objRespSendAadhaarOTP.ErrorCode,
                                "ErrorMessage": objRespSendAadhaarOTP.ErrorMsg,
                                "EncString": EncString
                              }
                              logger.info("************* 11. SUCCESS AadhaarOTPValidate ((END)) ****************");
                              logger.info("If outResp: ", outResp);
                              return res.json(outResp);
                            }
                            else {
                              outResp = {
                                "ErrorCode": objRespSendAadhaarOTP.ErrorCode,
                                "ErrorMessage": objRespSendAadhaarOTP.ErrorMsg
                              }
                              logger.info("************* 11. FAILURE AadhaarOTPValidate ((END)) ****************");
                              logger.info("Else outResp: ", outResp);
                              return res.json(outResp);
                            }

                          });
                      });
                    }
                  });

                }
              });

            });
          });

          //PlainString  {"AadhaarNumber":"735012589970","PMSNumber":"PMS07200014375","JourneyID":"PNB_SVND_000010004","CustomerID":"AGK057632"}
          //EncString  cPj6I40Y+y1XDXFe0Bo9o6hhf9Dsk7SsP2jczww0nAh4yIRFbS9NLojRVS4rkJ9ieWm9uZjPi7SOivnIeg7dQd7pglm3bkdFpBTI4V5eNRtDZK6vVS/gcbGN1wKqojVy2ifHefS5vejqLTbJmwZPew2MgFEgZpeG3iCYbxZE9nE=
          //objPlainString  "{\"AadhaarNumber\":\"735012589970\",\"PMSNumber\":\"PMS07200014375\",\"JourneyID\":\"PNB_SVND_000010004\",\"CustomerID\":\"AGK057632\"}"

        });
      });
    });


  } catch (error) {
    if (error.response) {
      switch (error.response.status) {
        case 400:
          console.error('Bad Request:', error.response.data);
          break;
        case 401:
          console.error('Unauthorized:', error.response.data);
          break;
        case 404:
          console.error('Not Found:', error.response.data);
          break;
        case 500:
          console.error('Internal Server Error:', error.response.data);
          break;
        default:
          console.error('HTTP Error:', error.response.status, error.response.data);
      }
    } else if (error.request) {
      console.error('No response received:', error.request);
      return res.json(error);
    } else {
      console.error('Error:', error.message);
      return res.json(error);
    }
  }
  finally {
    // Close the connection pool
    // await conn.close();
  }
});



app.post('/api/ExtractUserData', async (req, res) => {
  logger.info("***********************Inside ExtractUserData(START)*************************");
  // logger.info("Encrpt Data from ExtractDAata Function"+JSON.stringify(req.body));

  try {
    let EncString = (req.body).Encyptdata
    logger.info("EncString " + EncString);
    objCommonFunction.Decrypt(EncString).then(async (DecptString) => {
      logger.info("Output Decrypt " + JSON.stringify(DecptString))
      if (DecptString != null) {
        return res.json(JSON.stringify(DecptString));
      }
    });

  } catch (error) {
    console.error("Exception: ", error);
    return res.status(500).json({ message: 'An error occurred during login', error: error.message });
  }
});


function generateToken(userid) {
  return jwt.sign({ userid }, jwtSecret, { expiresIn: '1h' });
};


app.post('/api/LoginUserTrailInsert', async (req, res) => {
  const { RespAadhaarNo, RespPMSNo } = req.body;
  logger.info('RespAadhaarNo: ' + RespAadhaarNo + ' RespPMSNo: ' + RespPMSNo);
  logger.info("Hi Vishram, You are inside LoginUserTrailInsert");
  try {
    LoginUserTrailInsert(RespAadhaarNo, RespPMSNo).then(async (respLoginUserTrailInsert) => {
      logger.info('Out LoginUserTrailInsert Result: ', JSON.stringify(respLoginUserTrailInsert));
      if (respLoginUserTrailInsert.ErrorCode == "00") {
        Trailresp = {
          "ErrorCode": respLoginUserTrailInsert.ErrorCode,
          "ErrorMessage": respLoginUserTrailInsert.ErrorMsg
        }
        res.json(Trailresp);
      }
    });
  }
  catch (error) {

  }
  finally {
    // Close the connection pool
    // await conn.close();
  }

});

function LoginUserTrailInsert(userid) {

  logger.info('Inside LoginUserTrailInsert userid: ' + userid);
  return new Promise((resolve, reject) => {
    try {
      const ipAddress = ip.address();
      //logger.info("IP Address "+ipAddress);
      const oRandomID = Math.random();
      const Alphabet = 'abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      let strUniqueID = '';

      const date = new Date();
      //logger.info('date '+date)
      const year = date.getFullYear();

      const month = (`0${date.getMonth() + 1}`).slice(-2);
      const day = (`0${date.getDate()}`).slice(-2);
      const dateString = `${day}${month}${year}`;
      //logger.info(dateString);
      strUniqueID = Math.random().toString(12).slice(2)
      //logger.info('Before '+strUniqueID);
      strUniqueID = strUniqueID + '_' + dateString + '_' + userid;
      // do something with strUniqueID

      const date1 = DatePart();
      //logger.info('date1 '+date1);
      const query = `INSERT INTO SVND_USER_LOGIN_TRACE ([UNIQUEID],[LOGINID],[USERIP],[LOGINTIME]) VALUES(@UNIQUEID,@LOGINID,@USERIP,@LOGINTIME)`;
      var conn = new sql.ConnectionPool(config);
      conn.connect().then(async function (pool) {
        //logger.info('Query: ' + query);                           
        const result = await pool.request()
          .input('UNIQUEID', sql.VarChar, strUniqueID)
          .input('LOGINID', sql.VarChar, userid)
          .input('USERIP', sql.VarChar, ipAddress)
          .input('LOGINTIME', sql.VarChar, date1)
          .query(query);
        //logger.info('Result Length: '+JSON.stringify(result));
        //logger.info('Rows Affacted: '+result.rowsAffected[0]);
        if (result.recordsets && result.rowsAffected[0] == 1) {
          formattedString = {
            "ErrorCode": "00",
            "ErrorMsg": "User login trail saved in database",
          }
          resolve(formattedString);
        }
        else {
          logger.info('else:');
          formattedString = {
            "ErrorCode": "01",
            "ErrorMsg": "Error User login trail saved in database."
          }
          resolve(formattedString);
        }
      });

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
};

function DatePart() {
  const date = new Date();
  const day = (`0${date.getDate()}`).slice(-2);
  const month = (`0${date.getMonth() + 1}`).slice(-2);
  const year = date.getFullYear().toString().slice(-4);
  const hours = (`0${date.getHours()}`).slice(-2);
  const minutes = (`0${date.getMinutes()}`).slice(-2);
  const seconds = (`0${date.getSeconds()}`).slice(-2);
  return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
};



app.post('/api/logoutTrail', async (req, res) => {
  logger.info("***********************Inside  logoutTrail*************************");
  let EncString = (req.body).Encyptdata
  logger.info("EncString " + EncString);
  objCommonFunction.Decrypt(EncString).then(async (DecptString) => {
    logger.info("Logout page per output after decryption" + DecptString);
    logger.info("UserID " + JSON.parse(DecptString).UserID);
    if (DecptString != null) {
      userDataLayer.logoutTrailUpdate(JSON.parse(DecptString).UserID, "logout by user").then(async (objlogoutTrailUpdate) => {
        logger.info('Output logoutTrailUpdate ' + objlogoutTrailUpdate);
        if (objlogoutTrailUpdate != null) {
          return res.json(objlogoutTrailUpdate);
        }
        else {
          return res.json(null);
        }
      });
    }
  });
});


app.post('/api/BindDashboardData', async (req, res) => {
  logger.info("***********************Inside  BindDashboardData Dashboard Summery Screen(START)*************************");
  const { encLognData, JourneyType } = req.body;
  objCommonFunction.Decrypt(encLognData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
    userDataLayer.BindDashboardData(deLoginResponse, JourneyType).then(async (objLoanData) => {
      logger.info('Output BindDashboardData: ' + JSON.stringify(objLoanData));
      if (objLoanData != null) {
        return res.json(JSON.stringify(objLoanData));
      }
      else {
        return res.json(JSON.stringify(null));
      }
    });
  });
});

app.post('/api/DashboardExcelDownload', async (req, res) => {
  logger.info("***********************Inside  DashboardExcelDownload Home Screen(START)*************************");
  const { encLognData, Action, JourneyType } = req.body;
  objCommonFunction.Decrypt(encLognData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
    userDataLayer.DashboardExcelDownload(deLoginResponse, Action, JourneyType).then(async (objLoanData) => {
      logger.info('Output DashboardExcelDownload: ' + JSON.stringify(objLoanData));
      if (objLoanData != null) {
        return res.json(JSON.stringify(objLoanData));
      }
      else {
        return res.json(null);
      }
    });
  });
});

app.post('/api/showCustomerEsignData', async (req, res) => {
  logger.info("***********************Inside  E-sign DATA(START)*************************");

  const { encLognData, JourneyType, fromDate, toDate } = req.body;
  objCommonFunction.Decrypt(encLognData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
    userDataLayer.EsignData(deLoginResponse, JourneyType, fromDate, toDate).then(async (objEsignData) => {
      logger.info('Output GetCuCstomerEsignData: ' + JSON.stringify(objEsignData));

      if (objEsignData != null) {
        return res.json(JSON.stringify(objEsignData));
      }
      else {
        return res.json(null);
      }
    });
  });

});

app.post('/api/showCustomerTranchwise', async (req, res) => {
  logger.info("***********************Inside showCustomerTranchwise(START)*************************");

  const { fromDate, toDate } = req.body;
  userDataLayer.GetCustomerTranchData(fromDate, toDate).then(async (objGetCustomerTrenchData) => {
    logger.info('Output GetCustomerTrenchData: ', JSON.stringify(objGetCustomerTrenchData));

    if (objGetCustomerTrenchData != null) {
      return res.json(JSON.stringify(objGetCustomerTrenchData));
    }
    else {
      return res.json(null);
    }
  });
});

app.post('/api/getJourneyLogs', async (req, res) => {
  logger.info("***********************Inside ErrorLogs(START)*************************");
  logger.info(JSON.stringify(req.body));
  //const { fromDate, toDate } = req.body;
  const fromDate = new Date(req.body.fromDate);
  const toDate = new Date(req.body.toDate);
  // Log in UTC format using toISOString to avoid timezone issues
  logger.info("From Date (UTC):" + fromDate.toISOString());
  logger.info("To Date (UTC):" + toDate.toISOString());
  userDataLayer.getJourneyLogs(fromDate.toISOString(), toDate.toISOString()).then(async (objGetErrorLogsData) => {
    logger.info('Output GetErrorLogsData:' + JSON.stringify(objGetErrorLogsData));

    if (objGetErrorLogsData != null) {
      return res.json(JSON.stringify(objGetErrorLogsData));
    }
    else {
      return res.json(null);
    }
  });
});

app.post('/api/getJourneyWiseAPILogs', async (req, res) => {
  logger.info("***********************Inside getJourneyWiseAPILogs(START)*************************");

  const { PMSNumber, JourneyID, LogType } = req.body;
  userDataLayer.getJourneyWiseAPILogs(PMSNumber, JourneyID, LogType).then(async (objGetErrorLogsData) => {
    //logger.info('Output getJourneyWiseAPILogs:',JSON.stringify(objGetErrorLogsData));

    if (objGetErrorLogsData != null) {
      return res.json(JSON.stringify(objGetErrorLogsData));
    }
    else {
      return res.json(null);
    }
  });
});


app.post('/api/errorLogs', async (req, res) => {
  logger.info("***********************Inside ErrorLogs(START)*************************");

  const { fromDate, toDate } = req.body;
  userDataLayer.showErrorLogs(fromDate, toDate).then(async (objGetErrorLogsData) => {
    logger.info('Output GetErrorLogsData:', JSON.stringify(objGetErrorLogsData));

    if (objGetErrorLogsData != null) {
      return res.json(JSON.stringify(objGetErrorLogsData));
    }
  });
});


app.post('/api/AadhaarErrorLogs', async (req, res) => {
  logger.info("***********************Inside AadhaarErrorLogs(START)*************************");

  const { fromDate, toDate } = req.body;
  userDataLayer.AadhaarErrorLogs(fromDate, toDate).then(async (objGetErrorLogsData) => {
    logger.info('Output GetErrorLogsData:', JSON.stringify(objGetErrorLogsData));

    if (objGetErrorLogsData != null) {
      return res.json(JSON.stringify(objGetErrorLogsData));
    }
  });
});


app.post('/api/cibilErrorLogs', async (req, res) => {
  logger.info("***********************Inside CibilErrorLogs(START)*************************");

  const { fromDate, toDate } = req.body;
  userDataLayer.CibilErrorLogs(fromDate, toDate).then(async (objGetErrorLogsData) => {
    logger.info('Output GetErrorLogsData:', JSON.stringify(objGetErrorLogsData));

    if (objGetErrorLogsData != null) {
      return res.json(JSON.stringify(objGetErrorLogsData));
    }
  });
});

app.post('/api/userLoginTraceLogs', async (req, res) => {
  logger.info("***********************Inside userLoginTraceLogs(START)*************************");

  const { fromDate, toDate } = req.body;
  userDataLayer.UserLoginTraceLogs(fromDate, toDate).then(async (objGetErrorLogsData) => {
    logger.info('Output GetErrorLogsData:', JSON.stringify(objGetErrorLogsData));

    if (objGetErrorLogsData != null) {
      return res.json(JSON.stringify(objGetErrorLogsData));
    }
  });
})


app.post('/api/UserDataInsertUpdate', async (req, res) => {
  logger.info('*******************Inside UserDataInsertUpdate (START) **************************');
  const { strFormData } = req.body;

  try {


    logger.info('Data to be insert ', JSON.stringify(strFormData));
    userDataLayer.InsertUpdate(JSON.parse(strFormData)).then(async (objInsertUpdate) => {
      if (objInsertUpdate.ErrorCode == "00") {
        formattedString = {
          "ErrorCode": "00",
          "ErrorMessage": "Detail saved successfully"
        }
        return res.json(formattedString);
      }
      else {
        formattedString = {
          "ErrorCode": "01",
          "ErrorMsg": "error saved "
        }
        return res.json(formattedString);
      }


    });
  } catch (exception) {

  }

});

app.post('/api/getUserDetails', async (req, res) => {
  logger.info("***********************Inside getUserDetails (START)*************************");
  const { EmployeeID, OptionValue } = req.body;

  userDataLayer.GetEmployeeData(EmployeeID, OptionValue).then(async (objGetEmployeeData) => {
    logger.info('Output GetEmployeeData: ', JSON.stringify(objGetEmployeeData));

    if (objGetEmployeeData != null) {
      //   CustResp={
      //     "ErrorCode":"00",
      //     "ErrorMessage":"Data Successfully retrieved.",
      //     "EmployeeID":objGetEmployeeData.EmployeeID,
      //     "Name":objGetEmployeeData.Name,
      //     "MobileNumber":objGetEmployeeData.MobileNumber,
      //     "Designation":objGetEmployeeData.Designation,
      //     "CurrentSOLID":objGetEmployeeData.CurrentSOLID,
      //     "Address":objGetEmployeeData.Address,
      //     "Status":objGetEmployeeData.Status,
      //     "UserRole":objGetEmployeeData.UserRole,
      // }
      return res.json(JSON.stringify(objGetEmployeeData));
    }
  });
});


app.post('/api/getUserSOL', async (req, res) => {
  logger.info("***********************Inside getSolID (START)*************************");
  userDataLayer.getUserSOL().then(async (objgetUserSOL) => {
    // logger.info('Output getUserSOL: ',JSON.stringify(objgetUserSOL));


    return res.json(JSON.stringify(objgetUserSOL));

  });
});

app.post('/api/getUserDesignation', async (req, res) => {
  logger.info("***********************Inside getSolID (START)*************************");
  userDataLayer.getUserDesignation().then(async (objgetUserDesignation) => {
    // logger.info('Output getUserSOL: ',JSON.stringify(objgetUserSOL));


    return res.json(JSON.stringify(objgetUserDesignation));

  });
});



app.post('/api/getLoanJourneyData', async (req, res) => {
  logger.info("***********************Inside  getLoanJourneyData (START)*************************");
  const { encLognData, JourneyType, fromDate, toDate } = req.body;
  objCommonFunction.Decrypt(encLognData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));

    userDataLayer.getLoanJourneyData(deLoginResponse, JourneyType, fromDate, toDate).then(async (objgetLoanJourneyData) => {
      logger.info('Output GetCustomerData: ', JSON.stringify(objgetLoanJourneyData));

      if (objgetLoanJourneyData != null) {
        return res.json(JSON.stringify(objgetLoanJourneyData));
      }
      else {
        return res.json(null);
      }
    });
  });
});

app.post('/api/getSIDBISyncData', async (req, res) => {
  logger.info("***********************Inside  getSIDBISyncData (START)*************************");
  const { encLognData, fromDate, toDate } = req.body;
  objCommonFunction.Decrypt(encLognData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));

    userDataLayer.getSIDBISyncData(deLoginResponse, fromDate, toDate).then(async (objgetSIDBISyncData) => {
      //logger.info('Output GetCustomerData: ',JSON.stringify(objgetSIDBISyncData));

      if (objgetSIDBISyncData != null) {
        return res.json(JSON.stringify(objgetSIDBISyncData));
      }
      else {
        return res.json(null);
      }
    });
  });
});

app.post('/api/GetCAMReportData', async (req, res) => {
  logger.info("***********************Inside  showcbsCustomerData (START)*************************");

  const { ApplicationNumber, JourneyID } = req.body;
  logger.info('ApplicationNumber ', ApplicationNumber);
  logger.info('JourneyID ', JourneyID);
  userDataLayer.GetCAMReportData(ApplicationNumber, JourneyID).then(async (objGetCBSCustomerData) => {
    logger.info('Output GetCAMReportData: ' + JSON.stringify(objGetCBSCustomerData));
    if (objGetCBSCustomerData != null) {
      return res.json(JSON.stringify(objGetCBSCustomerData));
    }
    else {
      return res.json(null);
    }
  });
});

app.post('/api/GetCIBILReportData', async (req, res) => {
  logger.info("***********************Inside  showPMSCustomerData (START)*************************");
  const { ApplicationNumber, JourneyID } = req.body;
  logger.info('ApplicationNumber', ApplicationNumber);
  logger.info('JourneyID', JourneyID);
  userDataLayer.GetCIBILReportData(ApplicationNumber, JourneyID).then(async (objGetPMSCustomerData) => {
    //logger.info('Output GetPMSCustomerData: ',JSON.stringify(objGetPMSCustomerData));
    if (objGetPMSCustomerData != null) {
      JsonResp = {
        "ErrorCode": "00",
        "ErrorMessage": "CIBIL Download success",
        "CibilData": objGetPMSCustomerData
      }

      return res.json(JSON.stringify(objGetPMSCustomerData));
    }
  });
});

app.post('/api/GetLoanDocument', async (req, res) => {
  logger.info("***********************Inside CompleteLoanDocument (START)*************************");

  const { PMSNumber, JourneyID } = req.body;
  logger.info('ApplicationNumber', PMSNumber);
  userDataLayer.GetLoanDocument(PMSNumber, JourneyID).then(async (objGetLoanDoc) => {
    //logger.info('Output GetPMSCustomerData: ',JSON.stringify(objGetLoanDoc));
    if (objGetLoanDoc != null) {
      return res.json(JSON.stringify(objGetLoanDoc));
    }
    else {
      return res.json(null);
    }
  });
});

app.post('/api/getReconcilationData', async (req, res) => {
  logger.info("***********************getReconcilationData (START)*************************");

  const { encLognData, JourneyType, fromDate, toDate } = req.body;
  objCommonFunction.Decrypt(encLognData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
    userDataLayer.getReconcilationData(deLoginResponse, JourneyType, fromDate, toDate).then(async (objGetCustomerCICData) => {
      logger.info('Output getReconcilationData: ', JSON.stringify(objGetCustomerCICData));
      if (objGetCustomerCICData != null) {
        return res.json(JSON.stringify(objGetCustomerCICData));
      }
      else {
        return res.json(null);
      }
    });
  });
});

// async function getRefKeyOnce(encPayload) {
//   const aadhaar = await objCommonFunction.Decrypt(encPayload);

//   const resp = await objAadhaarDataLayer.GetDataByUIDAPI(aadhaar);

//   const refKey = resp?.Data?.vaultData?.refKey;
//   if (!refKey) {
//     throw new Error("refKey not received from UID API");
//   }

//   return refKey;
// }


// async function getRefKeyOncebyUID(aadhaar) {
  

//   const resp = await objAadhaarDataLayer.GetDataByUIDAPI(aadhaar);

//   const refKey = resp?.Data?.vaultData?.refKey;
//   if (!refKey) {
//     throw new Error("refKey not received from UID API");
//   }

//   return refKey;
// }

// app.post('/api/NewOrResumeJourney', async (req, res) => {



//  const { EncADPayload, EncPMPayload, EncLoginPayload, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent } = req.body;

// //  objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNumber) => {

// //     logger.info('uid', AadhaarNumber);
// //     logger.info(`######### ADV Calling for Aadhaar Number ######## ${AadhaarNumber}`);

// //     // ✅ WAIT for API response
// //     let respfromuid = await objAadhaarDataLayer.GetDataByUIDAPI(AadhaarNumber);

// //     logger.info('Response get from UID ' + JSON.stringify(respfromuid));

// //     // ✅ Now vaultData will exist
// //     let vaultData = respfromuid?.Data?.vaultData;

// //     logger.info('vaultData:', vaultData);

// //     refKey = vaultData?.refKey;

// //     logger.info(`refKey: ${refKey}`);
// // });

//  refKey = await getRefKeyOnce(EncADPayload);

//   logger.info(`Journey Initiation By: ` + Operation);
//   let deLoginResponse = ''
//   if (Operation == "BranchJourney") {
//     objCommonFunction.Decrypt(EncLoginPayload).then(async (decLoginPayload) => {
//       deLoginResponse = JSON.parse(decLoginPayload);
//       logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
//       logger.info('UserID ' + deLoginResponse.UserID);
//       logger.info(`HigherTranchPassConsent flag` + isHigherTranchPassConsent);
//       logger.info(`MakerCBSAadharDataConsent flag` + MakerCBSAadharDataConsent);
//     });
//   }
//   objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNumber) => {
//     logger.info(``);
//     let ROI = await GetKeyConfigurationValue('ROI');
//     let ROIAddsTwentyFiveBasis = await GetKeyConfigurationValue('ROIAddsTwentyFiveBasis');
//     let RLLR = await GetKeyConfigurationValue('ROI_RLLR');
//     let Spread = await GetKeyConfigurationValue('ROI_SPREAD'); 
//     let ServiceCharge = await GetKeyConfigurationValue('ROI_ServiceCharge');

//     objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {
//       logger.info(`######### 1. Call NewOrResumeJourney ((START)) for PMS Number ######## ${PMSNumber}`);
//       objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (objRespCustomerJourney) => {
//         logger.info('Output  getCustomerJourneyData: ' + JSON.stringify(objRespCustomerJourney));
//         let ParseobjRespCustomerJourney = JSON.parse(objRespCustomerJourney);

//      console.log("HIIIIIIIIIIII"+ ParseobjRespCustomerJourney);
//         if (objRespCustomerJourney != null) {
//           let objCICCalllDays;
//           let CICCalledDate;
//           let LoanSanctionedDays;
//           let LoanSanctionDate;
//          let isLoanAccountOpenedValue=ParseobjRespCustomerJourney.isLoanAccountOpened;

//    logger.info('Output  isLoanAccountOpenedValue ' + isLoanAccountOpenedValue);



// // Now pass the `isLoanAccountOpenedValue` (1 or 0) when calling `getConsumerCIBIL`
// objGeneralOperation.getConsumerCIBIL(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, isLoanAccountOpenedValue).then(async (objRespConsumerCIBIL) => {
//    // logger.info('Output getConsumerCIBIL: ' + JSON.stringify(objRespConsumerCIBIL));
  

//           // objGeneralOperation.getConsumerCIBIL(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID).then(async (objRespConsumerCIBIL) => {
//            // logger.info('Output  getConsumerCIBIL: ' + JSON.stringify(objRespConsumerCIBIL));


//                 if (!objRespConsumerCIBIL) {
//         logger.error('getConsumerCIBIL returned null');
//         return res.json({
//             "ErrorCode": "01",
//             "ErrorMessage": "Error fetching CIBIL information. Please try again later.",
            
//         });
//     }

//     //logger.info('Output getConsumerCIBIL: ' + JSON.stringify(objRespConsumerCIBIL));

//     // Extract the ConsumerAPIResponseTime safely
//     CICCalledDate = JSON.parse(objRespConsumerCIBIL).ConsumerAPIResponseTime;
//     logger.info('CIC Pull Date ' + CICCalledDate);

//     // Calculate the days if the date is not null
//     if (CICCalledDate != null) {
//         objCICCalllDays = CalculateDateDifferenceInDays(CICCalledDate);
//         logger.info('Inside CIC Called days ' + objCICCalllDays);
//     }
//             // CICCalledDate = JSON.parse(objRespConsumerCIBIL).ConsumerAPIResponseTime;
//             // logger.info('CIC Pull Date ' + CICCalledDate);
//             // if (CICCalledDate != null) {
//             //   objCICCalllDays = CalculateDateDifferenceInDays(CICCalledDate);
//             //   logger.info('Inside CIC Called days ' + objCICCalllDays);
//             // }

//             if (Operation == "BranchJourney") {
//               logger.info('Branch Journey');
//               if (ParseobjRespCustomerJourney.isCustomerJourneyCompleted == 1 && ParseobjRespCustomerJourney.isSchedularJourneyCompleted == 1) {
//                 Journeyresp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "Customer has completed the journey and account disbursement also completed.",
//                   "Tranche": ""
//                 }
//                 logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                 return res.json(Journeyresp);
//               }
//               else if (ParseobjRespCustomerJourney.isCustomerJourneyCompleted == 1 && ParseobjRespCustomerJourney.isSchedularJourneyCompleted == 0) {
//                 Journeyresp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "Customer has completed the journey. But Account Disbursement is pending.",
//                   "Tranche": ""
//                 }
//                 logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                 return res.json(Journeyresp);
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 1 && ParseobjRespCustomerJourney.JourneyInitiationChannel == "CustomerJourney") {
//                 logger.info('Customer Journey Rejected and Branch user immediately create journey ');
             

//                 await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, deLoginResponse.UserID, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread,BSP,RLLR_BSP, ServiceCharge, true, 'Recreate fresh journey after expired earlier rejected customer journey').then(async (objCreateLoanJourney) => {
//                   logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));

//                   CreateJourneyResp = {
//                     "ErrorCode": objCreateLoanJourney.ErrorCode,
//                     "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                     "Tranche": ""
//                   }
//                   logger.info('New Journey Create Response JSON: ' + JSON.stringify(CreateJourneyResp));
//                   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                   res.json(CreateJourneyResp);
//                 });
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 1 && ParseobjRespCustomerJourney.JourneyInitiationChannel == "BranchJourney") {
//                 logger.info('Branch Journey rejected and never revive');

//                 CreateJourneyResp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "Journey can not be process as same has been rejected at SIDBI portal",
//                   "Tranche": ""
//                 }
//                 logger.info('New Journey Create Response JSON: ' + JSON.stringify(CreateJourneyResp));
//                 logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                 res.json(CreateJourneyResp);
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate == null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "CustomerJourney") {
//                 logger.info('Customer initiate this journey and branch cant process it');
//                 CreateJourneyResp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "The customer has already started a digital journey. Please contact customer to completed the journey.",
//                   "Tranche": ""
//                 }
//                 logger.info(`JourneyRejection Response: ${JSON.stringify(CreateJourneyResp)}`);
//                 return res.json(CreateJourneyResp);

//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate == null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "BranchJourney") {
//                 logger.info('Branch Journey Resume every time by branch user before CIC pull');
//                 CreateJourneyResp = {
//                   "ErrorCode": "00",
//                   "ErrorMessage": "Customer successfully resume journey.",
//                   "Tranche": ""
//                 }
//                 logger.info(`JourneyRejection Response: ${JSON.stringify(CreateJourneyResp)}`);
//                 return res.json(CreateJourneyResp);

//                 // let JourneyStartDate = ParseobjRespCustomerJourney.EntryDate;
//                 // // Parse the given date and get the current date and time
//                 // const startTime = moment(JourneyStartDate, 'YYYY-MM-DD HH:mm:ss.SSS');
//                 // const currentTime = moment();

//                 // // Calculate the difference in hours
//                 // const differenceInHours = currentTime.diff(startTime, 'hours');

//                 // console.log(`Time difference in hours: ${differenceInHours}`);

//                 // if (differenceInHours >= 24) {
//                 //   logger.info('Journey expire as journey time more than 24 hours');
//                 //   await objGeneralOperation.CreateLoanJourney(AadhaarNumber, PMSNumber, Operation, isHigherTranchPassConsent, deLoginResponse.UserID, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, true, 'Branch Journey not complete within 24 hours so journey automatically expired').then(async (objCreateLoanJourney) => {
//                 //     logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));

//                 //     CreateJourneyResp = {
//                 //       "ErrorCode": objCreateLoanJourney.ErrorCode,
//                 //       "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                 //       "Tranche": ""
//                 //     }
//                 //     logger.info('New Journey Create Response JSON: ' + JSON.stringify(CreateJourneyResp));
//                 //     logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                 //     res.json(CreateJourneyResp);
//                 //   });
//                 // }
//                 // else {
//                 //   logger.info('Journey Resume as journey time less than 24 hour');
//                 //   CreateJourneyResp = {
//                 //     "ErrorCode": "00",
//                 //     "ErrorMessage": "Customer successfully resume journey.",
//                 //     "Tranche": ""
//                 //   }
//                 //   logger.info(`JourneyRejection Response: ${JSON.stringify(CreateJourneyResp)}`);
//                 //   return res.json(CreateJourneyResp);
//                 // }
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate != null && JSON.parse(objRespCustomerJourney).JourneySanctionedDate == null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "BranchJourney") {
//                 logger.info('Journey initiated by branch and rejected and even CIC also pulled');
//                 logger.info(`obj CIC Calll Days:  ${objCICCalllDays}`);

//                 if (objCICCalllDays >= 15) {
//                   //Create Fresh Journey Due to Rejection
                  
//                   await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, deLoginResponse.UserID, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, true, 'Recreate fresh journey after expired earlier branch journey due to CIC expiery').then(async (objCreateLoanJourney) => {
//                     logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));
//                     CreateJourneyResp = {
//                       "ErrorCode": objCreateLoanJourney.ErrorCode,
//                       "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                       "Tranche": ""
//                     }
//                     logger.info(`New Journey Create  Response: ${JSON.stringify(CreateJourneyResp)}`);
//                     res.json(CreateJourneyResp);
//                   });
//                 }
//                 else if (ParseobjRespCustomerJourney.JourneyMilestone >= 105) {
//                   logger.info('Branch Journey: Maker User already mark for checker verification');
//                   Journeyresp = {
//                     "ErrorCode": "01",
//                     "ErrorMessage": "Application is forward to the branch head for verification",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                   res.json(Journeyresp);
//                 }
//                 else {
//                   CreateJourneyResp = {
//                     "ErrorCode": "00",
//                     "ErrorMessage": "Customer successfully resume journey.",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journey Resume Response: ${JSON.stringify(CreateJourneyResp)}`);
//                   return res.json(CreateJourneyResp);
//                 }
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate != null && JSON.parse(objRespCustomerJourney).JourneySanctionedDate == null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "CustomerJourney") {
//                 logger.info('Journey initiated by customer and rejected and even CIC also pulled');
//                 logger.info(`obj CIC Calll Days:  ${objCICCalllDays}`);

//                 if (objCICCalllDays >= 15) {
//                   //Create Fresh Journey Due to Rejection
//                   await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, deLoginResponse.UserID, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, true, 'Recreate fresh journey after expired earlier customer journey due to CIC expiery').then(async (objCreateLoanJourney) => {
//                     logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));
//                     CreateJourneyResp = {
//                       "ErrorCode": objCreateLoanJourney.ErrorCode,
//                       "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                       "Tranche": ""
//                     }
//                     logger.info(`New Journey Create  Response: ${JSON.stringify(CreateJourneyResp)}`);
//                     res.json(CreateJourneyResp);
//                   });
//                 }
//                 else {
//                   CreateJourneyResp = {
//                     "ErrorCode": "01",
//                     "ErrorMessage": "The customer has already started a digital journey. Please contact customer to completed the journey.",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journey Resume Response: ${JSON.stringify(CreateJourneyResp)}`);
//                   return res.json(CreateJourneyResp);
//                 }
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate != null && JSON.parse(objRespCustomerJourney).JourneySanctionedDate != null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "BranchJourney") {
//                 logger.info('Branch Journey: CIC Date not null and Sanctioned date also not null');
//                 LoanSanctionedDays = CalculateDateDifferenceInDays(JSON.parse(objRespCustomerJourney).JourneySanctionedDate);
//                 logger.info('Loan Sanctioned Days ' + LoanSanctionedDays);

//                 logger.info('Journey not rejected and Sanctioned days not null');

//                 if (LoanSanctionedDays >= 15) {
//                   //Create Fresh Journey Due to Rejection
//                   await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, deLoginResponse.UserID, deLoginResponse.UserSOL, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, true, 'Recreate fresh journey after expired earlier branch journey due to Loan offer expiry').then(async (objCreateLoanJourney) => {
//                     logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));
//                     CreateJourneyResp = {
//                       "ErrorCode": objCreateLoanJourney.ErrorCode,
//                       "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                       "Tranche": ""
//                     }
//                     logger.info(`New Journey Create  Response: ${JSON.stringify(CreateJourneyResp)}`);
//                     res.json(CreateJourneyResp);
//                   });
//                 }
//                 else if (ParseobjRespCustomerJourney.JourneyMilestone >= 105) {
//                   logger.info('Branch Journey: Maker User already mark for checker verification');
//                   Journeyresp = {
//                     "ErrorCode": "01",
//                     "ErrorMessage": "Application is forward to the branch head for verification",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                   res.json(Journeyresp);
//                 }
//                 else {
//                   CreateJourneyResp = {
//                     "ErrorCode": "00",
//                     "ErrorMessage": "Customer successfully resume journey.",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journey Resume Response: ${JSON.stringify(CreateJourneyResp)}`);
//                   return res.json(CreateJourneyResp);
//                 }
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate != null && JSON.parse(objRespCustomerJourney).JourneySanctionedDate != null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "CustomerJourney") {
//                 logger.info('Customer Journey: CIC Date not null and Sanctioned date also not null');
//                 LoanSanctionedDays = CalculateDateDifferenceInDays(JSON.parse(objRespCustomerJourney).JourneySanctionedDate);
//                 logger.info('Loan Sanctioned Days ' + LoanSanctionedDays);

//                 logger.info('Journey not rejected and Sanctioned days not null');

//                 if (LoanSanctionedDays >= 15) {
//                   //Create Fresh Journey Due to Rejection
//                   await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, deLoginResponse.UserID, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, true, 'Recreate fresh journey after expired earlier branch journey due to Loan offer expiry').then(async (objCreateLoanJourney) => {
//                     logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));
//                     CreateJourneyResp = {
//                       "ErrorCode": objCreateLoanJourney.ErrorCode,
//                       "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                       "Tranche": ""
//                     }
//                     logger.info(`New Journey Create  Response: ${JSON.stringify(CreateJourneyResp)}`);
//                     res.json(CreateJourneyResp);
//                   });
//                 }
//                 else if (ParseobjRespCustomerJourney.JourneyMilestone >= 105) {
//                   logger.info('Branch Journey: Maker User already mark for checker verification');
//                   Journeyresp = {
//                     "ErrorCode": "01",
//                     "ErrorMessage": "Application is forward to the branch head for verification",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                   res.json(Journeyresp);
//                 }
//                 else {
//                   CreateJourneyResp = {
//                     "ErrorCode": "00",
//                     "ErrorMessage": "Customer successfully resume journey.",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journey Resume Response: ${JSON.stringify(CreateJourneyResp)}`);
//                   return res.json(CreateJourneyResp);
//                 }
//               }

//               else if (ParseobjRespCustomerJourney.EntryBy !== deLoginResponse.UserID && ParseobjRespCustomerJourney.JourneyInitiationChannel == "BranchJourney") {
//                 logger.info('Branch Journey: ENtry user and modify user are different');
//                 Journeyresp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "This application has initiated by user:" + ParseobjRespCustomerJourney.EntryBy + ". So you are not authorised to resume this application.",
//                   "Tranche": ""
//                 }
//                 logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                 logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                 res.json(Journeyresp);
//               }
//               // else if (ParseobjRespCustomerJourney.JourneyMilestone >= 105 && ParseobjRespCustomerJourney.JourneyInitiationChannel == "BranchJourney") {
//               //   logger.info('Branch Journey: Maker User already mark for checker verification');
//               //   Journeyresp = {
//               //     "ErrorCode": "01",
//               //     "ErrorMessage": "Branch journey already marked for verification. And send to checker.",
//               //     "Tranche": ""
//               //   }
//               //   logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//               //   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//               //   res.json(Journeyresp);
//               // }
//               else {
//                 CreateJourneyResp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "Unhandelled response",
//                   "Tranche": ""
//                 }
//                 logger.info('Unhandelled Response JSON: ' + JSON.stringify(CreateJourneyResp));
//                 logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                 res.json(CreateJourneyResp);
//               }
//             }
//             else if (Operation == "CustomerJourney") {
//               if (ParseobjRespCustomerJourney.isCustomerJourneyCompleted == 1 && ParseobjRespCustomerJourney.isSchedularJourneyCompleted == 0) {
//                 Journeyresp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "Customer has completed the journey. But Account Disbursement is pending.",
//                   "Tranche": ""
//                 }
//                 logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                 return res.json(Journeyresp);
//               }
//               else if (ParseobjRespCustomerJourney.isCustomerJourneyCompleted == 1 && ParseobjRespCustomerJourney.isSchedularJourneyCompleted == 1) {
//                 Journeyresp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "Customer has completed the journey and account disbursement also completed.",
//                   "Tranche": ""
//                 }
//                 logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                 return res.json(Journeyresp);
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 1) {
//                 logger.info('Only single journey in database with rejected status');
//                 CreateJourneyResp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": ParseobjRespCustomerJourney.JourneyRejectionReason,
//                   "Tranche": ""
//                 }
//                 logger.info(`JourneyRejection Response: ${JSON.stringify(CreateJourneyResp)}`);
//                 return res.json(CreateJourneyResp);
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate == null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "CustomerJourney") {
//                 logger.info('DIY journey which is not rejected and also CIC pull is pending');
//                 CreateJourneyResp = {
//                   "ErrorCode": "00",
//                   "ErrorMessage": "Customer successfully resume journey.",
//                   "Tranche": ""
//                 }
//                 logger.info(`JourneyRejection Response: ${JSON.stringify(CreateJourneyResp)}`);
//                 return res.json(CreateJourneyResp);
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate != null && JSON.parse(objRespCustomerJourney).JourneySanctionedDate == null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "CustomerJourney") {
//                 logger.info('Journey not rejected and CIC days not null');
//                 logger.info(`obj CIC Calll Days:  ${objCICCalllDays}`);

//                 if (objCICCalllDays >= 15) {
//                   //Create Fresh Journey Due to Rejection
//                   await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, isHigherTranchPassConsent, deLoginResponse.UserID, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, true, 'New journey created due to 15teen days expiry period of CIC for DIY').then(async (objCreateLoanJourney) => {
//                     logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));
//                     CreateJourneyResp = {
//                       "ErrorCode": objCreateLoanJourney.ErrorCode,
//                       "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                       "Tranche": ""
//                     }
//                     logger.info(`New Journey Create  Response: ${JSON.stringify(CreateJourneyResp)}`);
//                     res.json(CreateJourneyResp);
//                   });
//                 }
//                 else {
//                   CreateJourneyResp = {
//                     "ErrorCode": "00",
//                     "ErrorMessage": "Customer successfully resume journey.",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journey Resume Response: ${JSON.stringify(CreateJourneyResp)}`);
//                   return res.json(CreateJourneyResp);
//                 }
//               }
//               else if (ParseobjRespCustomerJourney.isJourneyRejected == 0 && CICCalledDate != null && JSON.parse(objRespCustomerJourney).JourneySanctionedDate != null && ParseobjRespCustomerJourney.JourneyInitiationChannel == "CustomerJourney") {
//                 logger.info('Branch Journey: CIC Date not null and Sanctioned date also not null');
//                 LoanSanctionedDays = CalculateDateDifferenceInDays(JSON.parse(objRespCustomerJourney).JourneySanctionedDate);
//                 logger.info('Loan Sanctioned Days ' + LoanSanctionedDays);

//                 logger.info('Journey not rejected and Sanctioned days not null');

//                 if (LoanSanctionedDays >= 15) {
//                   //Create Fresh Journey Due to Rejection
//                   await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, deLoginResponse.UserID, deLoginResponse.UserSOL, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, true, 'Recreate fresh journey after expired earlier branch journey due to Loan offer expiry').then(async (objCreateLoanJourney) => {
//                     logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));
//                     CreateJourneyResp = {
//                       "ErrorCode": objCreateLoanJourney.ErrorCode,
//                       "ErrorMessage": objCreateLoanJourney.ErrorMsg,
//                       "Tranche": ""
//                     }
//                     logger.info(`New Journey Create  Response: ${JSON.stringify(CreateJourneyResp)}`);
//                     res.json(CreateJourneyResp);
//                   });
//                 }
//                 else {
//                   CreateJourneyResp = {
//                     "ErrorCode": "00",
//                     "ErrorMessage": "Customer successfully resume journey.",
//                     "Tranche": ""
//                   }
//                   logger.info(`Journey Resume Response: ${JSON.stringify(CreateJourneyResp)}`);
//                   return res.json(CreateJourneyResp);
//                 }
//               }
//               else {
//                 CreateJourneyResp = {
//                   "ErrorCode": "01",
//                   "ErrorMessage": "Error while ",
//                   "Tranche": ""
//                 }
//               }
//             }
//           });
//         }
//         else {
//           logger.info(`No Customer journey found for the customer, check whether PMS no exists or not`);
//           objGeneralOperation.isPMSNumberExist(PMSNumber).then(async (PMSDetails) => {
//             logger.info(`Outpot isPMSNumberExist ${JSON.stringify(PMSDetails)}`);
//             if (PMSDetails != null) {
//               PMSDataParse = JSON.parse(PMSDetails);
//               logger.info('isHigherTranchPassConsent: ' + isHigherTranchPassConsent)
//               if (Operation == "BranchJourney" && (PMSDataParse.TRENCH == "2" || PMSDataParse.TRENCH == "3") && isHigherTranchPassConsent == false)//TRENCH
//               {
//                 Journeyresp = {
//                   "ErrorCode": "02",
//                   "ErrorMessage": "Application pertains to second/third tranche. Please provide consent to proceed further",
//                   "Tranche": PMSDataParse.TRENCH
//                 }
//                 logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                 res.json(Journeyresp);
//               }
//               // else if(Operation=="CustomerJourney" && (PMSDataParse.TRENCH=="2" || PMSDataParse.TRENCH=="3"))//TRENCH
//               // {
//               //   Journeyresp={
//               //     "ErrorCode":"01",
//               //     "ErrorMessage":"Error:Application is of "+PMSDataParse.TRENCH +" tranche.Can not proceed digitally. Kindly contact branch.",
//               //     "Tranche": PMSDataParse.TRENCH
//               //   }
//               //   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//               //   res.json(Journeyresp);
//               // }
//               else {
//                 //Insert Customer Journey

//              //  let uid='492359588326'
//                // let respfromuid =  objAadhaarDataLayer.GetDataByUIDAPI(uid);




               

          
//                 await objGeneralOperation.CreateLoanJourney(refKey, PMSNumber, Operation, MakerCBSAadharDataConsent, isHigherTranchPassConsent, deLoginResponse.UserID, deLoginResponse.UserSOL, ROI, ROIAddsTwentyFiveBasis, RLLR, Spread, ServiceCharge, false, 'FreshJourney').then(async (objCreateLoanJourney) => {
//                   logger.info('Output CreateLoanJourney' + JSON.stringify(objCreateLoanJourney));
//                   if (objCreateLoanJourney.ErrorCode == "00") {
//                     Journeyresp = {
//                       "ErrorCode": "00",
//                       "ErrorMessage": "Customer journey Resume Successful.",
//                       "Tranche": PMSDataParse.TRENCH
//                     }
//                     logger.info(`Journeyresp: ${JSON.stringify(Journeyresp)}`);
//                     logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                     res.json(Journeyresp);
//                   }
//                   else {
//                     Journeyresp = {
//                       "ErrorCode": "01",
//                       "ErrorMessage": "System Error, Please contact system admin or try again later.",
//                       "Tranche": ""
//                     }
//                     logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                     res.json(Journeyresp);
//                   }
//                 });
//               }
//             }
//             else {
//               Journeyresp = {
//                 "ErrorCode": "01",
//                 "ErrorMessage": "Entered wrong PMS number/PMS number is not updated in server. Please start the journey after 24 hours.",
//                 "Tranche": ""
//               }
//               logger.info(JSON.stringify(Journeyresp));
//               logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//               res.json(Journeyresp);
//             }
//           });
//         }
//       });
//     });
//   });
// });

app.post('/api/NewOrResumeJourney', async (req, res) => {
  try {
    const {
      EncADPayload,
      EncPMPayload,
      EncLoginPayload,
      Operation,
      MakerCBSAadharDataConsent,
      isHigherTranchPassConsent
    } = req.body;

    logger.info(`######### NewOrResumeJourney START #########`);
    logger.info(`Operation: ${Operation}`);

    /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    // ------------------------------------------------- */
   // const refKey = await getRefKeyOnce(EncADPayload);  //TESTING
     const refKey ='PNB131574606407'
    if (!refKey) {
      logger.error('refKey not generated');
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate Aadhaar details",
        Tranche: ""
      });
    }
   logger.info(`refKey resolved: ${refKey}`);

    /* -------------------------------------------------
       2️⃣ DECRYPT LOGIN (Branch only)
    ------------------------------------------------- */
    let loginUser = null;
    if (Operation === "BranchJourney") {
      const loginPayload = await objCommonFunction.Decrypt(EncLoginPayload);
      loginUser = JSON.parse(loginPayload);
      logger.info(`Branch UserID: ${loginUser.UserID}`);
    }

    /* -------------------------------------------------
       3️⃣ DECRYPT Aadhaar & PMS
    ------------------------------------------------- */
    const AadhaarNumber = await objCommonFunction.Decrypt(EncADPayload);
    const PMSNumber = await objCommonFunction.Decrypt(EncPMPayload);

    logger.info(`Aadhaar: ${AadhaarNumber}`);
    logger.info(`PMS: ${PMSNumber}`);

    /* -------------------------------------------------
       4️⃣ LOAD CONFIG VALUES
    ------------------------------------------------- */
    const ROI = await GetKeyConfigurationValue('ROI');
    const ROIAddsTwentyFiveBasis = await GetKeyConfigurationValue('ROIAddsTwentyFiveBasis');
    const RLLR = await GetKeyConfigurationValue('ROI_RLLR');
    const Spread = await GetKeyConfigurationValue('ROI_SPREAD');
    const ServiceCharge = await GetKeyConfigurationValue('ROI_ServiceCharge');

    /* -------------------------------------------------
       5️⃣ FETCH JOURNEY DATA
    ------------------------------------------------- */
    const journeyRaw = await objGeneralOperation.getCustomerJourneyData(PMSNumber);

    if (!journeyRaw) {
      logger.info(`No journey found → Fresh flow`);

      const PMSDetailsRaw = await objGeneralOperation.isPMSNumberExist(PMSNumber);
      if (!PMSDetailsRaw) {
        return res.json({
          ErrorCode: "01",
          ErrorMessage: "Invalid PMS number",
          Tranche: ""
        });
      }

      const PMSData = JSON.parse(PMSDetailsRaw);

      if (
        Operation === "BranchJourney" &&
        (PMSData.TRENCH === "2" || PMSData.TRENCH === "3") &&
        !isHigherTranchPassConsent
      ) {
        return res.json({
          ErrorCode: "02",
          ErrorMessage: "Second/Third tranche consent required",
          Tranche: PMSData.TRENCH
        });
      }

      const createResp = await objGeneralOperation.CreateLoanJourney(
        refKey,
        PMSNumber,
        Operation,
        MakerCBSAadharDataConsent,
        isHigherTranchPassConsent,
        loginUser?.UserID,
        loginUser?.UserSOL,
        ROI,
        ROIAddsTwentyFiveBasis,
        RLLR,
        Spread,
        ServiceCharge,
        false,
        'FreshJourney'
      );

      return res.json({
        ErrorCode: createResp.ErrorCode,
        ErrorMessage: createResp.ErrorMsg,
        Tranche: PMSData.TRENCH
      });
    }

    /* -------------------------------------------------
       6️⃣ PARSE EXISTING JOURNEY
    ------------------------------------------------- */
    const journey = JSON.parse(journeyRaw);
    logger.info(`JourneyID: ${journey.JourneyID}`);

    /* -------------------------------------------------
       7️⃣ ENTRY USER VALIDATION (RESTORED)
    ------------------------------------------------- */
    if (
      Operation === "BranchJourney" &&
      journey.JourneyInitiationChannel === "BranchJourney" &&
      journey.EntryBy !== loginUser.UserID
    ) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: `Application initiated by ${journey.EntryBy}. You are not authorised.`,
        Tranche: ""
      });
    }

    /* -------------------------------------------------
       8️⃣ CIBIL CHECK
    ------------------------------------------------- */
    const cibilRaw = await objGeneralOperation.getConsumerCIBIL(
      PMSNumber,
      journey.JourneyID,
      journey.isLoanAccountOpened
    );

    let CICCalledDate = null;
    let CICDays = null;

    if (cibilRaw) {
      CICCalledDate = JSON.parse(cibilRaw).ConsumerAPIResponseTime;
      if (CICCalledDate) {
        CICDays = CalculateDateDifferenceInDays(CICCalledDate);
        logger.info(`CIC Days: ${CICDays}`);
      }
    }

    /* -------------------------------------------------
       9️⃣ CHECKER VERIFICATION (RESTORED)
    ------------------------------------------------- */
    if (journey.JourneyMilestone >= 105 && Operation === "BranchJourney") {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Application forwarded to Branch Head for verification",
        Tranche: ""
      });
    }

    /* -------------------------------------------------
       🔟 LOAN SANCTION EXPIRY (RESTORED)
    ------------------------------------------------- */
    if (journey.JourneySanctionedDate) {
      const sanctionedDays = CalculateDateDifferenceInDays(journey.JourneySanctionedDate);
      logger.info(`LoanSanctionedDays: ${sanctionedDays}`);

 if (sanctionedDays >= 15)  {
    //  if (sanctionedDays <= 15) {
        const recreateResp = await objGeneralOperation.CreateLoanJourney(
          refKey,
          PMSNumber,
          Operation,
          MakerCBSAadharDataConsent,
          isHigherTranchPassConsent,
          loginUser?.UserID,
          loginUser?.UserSOL,
          ROI,
          ROIAddsTwentyFiveBasis,
          RLLR,
          Spread,
          ServiceCharge,
          true,
          'Loan offer expired – recreated'
        );

        return res.json({
          ErrorCode: recreateResp.ErrorCode,
          ErrorMessage: recreateResp.ErrorMsg,
          Tranche: ""
        });
      }
    }

    /* -------------------------------------------------
       🔟 CIC EXPIRY (RESTORED)
    ------------------------------------------------- */
    if (CICDays !== null && CICDays >= 15) { 
   // if (CICDays !== null && CICDays <= 15) {
      const recreateResp = await objGeneralOperation.CreateLoanJourney(
        refKey,
        PMSNumber,
        Operation,
        MakerCBSAadharDataConsent,
        isHigherTranchPassConsent,
        loginUser?.UserID,
        loginUser?.UserSOL,
        ROI,
        ROIAddsTwentyFiveBasis,
        RLLR,
        Spread,
        ServiceCharge,
        true,
        'CIC expired – recreated'
      );

      return res.json({
        ErrorCode: recreateResp.ErrorCode,
        ErrorMessage: recreateResp.ErrorMsg,
        Tranche: ""
      });
    }

    /* -------------------------------------------------
       🔚 DEFAULT RESUME
    ------------------------------------------------- */
    return res.json({
      ErrorCode: "00",
      ErrorMessage: "Customer successfully resumed journey",
      Tranche: ""
    });

  } catch (err) {
    logger.error('Unhandled error in NewOrResumeJourney', err);
    return res.json({
      ErrorCode: "01",
      ErrorMessage: "System error occurred. Please try again later.",
      Tranche: ""
    });
  }
});


function CalculateDateDifferenceInDays(inputDate) {

  const [day, month, year] = inputDate.split('-');
  const DateFormated = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  const ObjDateFormated = new Date(DateFormated);

  const currentDate = new Date();//Today Date Time
  const differenceInTime = currentDate.getTime() - ObjDateFormated.getTime();
  const TotalDays = Math.floor(differenceInTime / (1000 * 3600 * 24));
  return `${TotalDays}`;
};


app.post('/api/updateLoginMilestone', async (req, res) => {
  const { EncPMPayload, JourneyMileStone } = req.body;
  logger.info(``);
  logger.info(``);
  logger.info('############################### update login Journey Milestone START for ' + JourneyMileStone + ' ###############################');
  logger.info('@@@@@@ Enc Payload: ' + EncPMPayload + " JourneyMileStone: " + JourneyMileStone + ' @@@@@@');

  let JourneyMileStoneDesc = "";

  objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {

    objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (respCustomerJourney) => {
      let CurrentMileStone = JSON.parse(respCustomerJourney).JourneyMilestone;
      logger.info('CurrentMileStone' + CurrentMileStone);
      //Check in local database for customer record exist, if exists then get data to return response
      //Note: CurrentMileStone -1 would check here, that confirm journey next milestone would be JourneyMileStone (variable)
      if (JourneyMileStone == "CityKYCInfo" && CurrentMileStone == 101) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "CustomerInfo" && CurrentMileStone == 102) {
        JourneyMileStoneDesc = CurrentMileStone;
      }

      else {
        JourneyMileStoneDesc = null;
        logger.info('*******************************ELSE PART Customer Journey Milestone********************************');
        logger.info('This segment works only when, milestone crossed current stage');
      }
      if (JourneyMileStoneDesc != null) {
        objGeneralOperation.getMilestoneFromMilestoneMaster(JourneyMileStone).then(async (objRespMilestone) => {
          if (objRespMilestone != null) {
            const MilestoneParse = JSON.parse(objRespMilestone);
            logger.info('JourneyMileStoneDesc not null');
            objGeneralOperation.CustomerJourneyUpdate(PMSNumber, JSON.parse(respCustomerJourney).JourneyID, MilestoneParse.MilestoneCode, MilestoneParse.MilestoneDesc, null, null, null, null, null, null, "Update").then(async (objRespCustomerJourney) => {
              logger.info('Output Journey Milestone Update: ', JSON.stringify(objRespCustomerJourney));
              if (objRespCustomerJourney.ErrorCode == "00") {
                Journeyresp = {
                  "ErrorCode": objRespCustomerJourney.ErrorCode,
                  "ErrorMessage": objRespCustomerJourney.ErrorMsg
                }
                logger.info('############################### Update Customer Journey Milestone START ###############################');
                res.json(Journeyresp);
              }
            });
          }
        });
      }
      else {
        Journeyresp = {
          "ErrorCode": "00",
          "ErrorMessage": "Customer Journey already passed " + JourneyMileStone + " milestone"
        }
        logger.info(JSON.stringify(Journeyresp));
        logger.info('############################### Update Customer Journey Milestone END ###############################');
        res.json(Journeyresp);
      }
    });
  })
});

app.post('/api/CallCityKYCInfoAPIForSOLValidate', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### 2. Call CallCityKYCInfoAPIForSOLValidate ((START)) ###############################');
  const { EncADPayload, EncPMPayload, EncLoginPayload } = req.body;

     /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    ------------------------------------------------- */
    const refKey = await getRefKeyOnce(EncADPayload);
    if (!refKey) {
      logger.error('refKey not generated');
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate Aadhaar details",
        Tranche: ""
      });
    }
    logger.info(`refKey resolved: ${refKey}`);

  objCommonFunction.Decrypt(EncLoginPayload).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
    logger.info('UserID ' + deLoginResponse.UserID);
    logger.info('UserSOL ' + deLoginResponse.UserSOL);
    objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNumber) => {
      objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {
        objGeneralOperation.CBSToken(PMSNumber, null).then(async (TokenDetails) => {
          objCBSLayer.CallCityKYCInfoAPIForSOLValidate(AadhaarNumber, PMSNumber, TokenDetails.AccessToken, deLoginResponse.UserSOL).then(async (objRespCityKYCInfoAPI) => {
            if (objRespCityKYCInfoAPI.StatusCode == "Success" || objRespCityKYCInfoAPI.ErrorCode == "00") {
              Journeyresp = {
                "ErrorCode": objRespCityKYCInfoAPI.ErrorCode,
                "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
              }
              logger.info('Success Journeyresp ' + JSON.stringify(Journeyresp));
              logger.info('############################### 1. SUCCESS CallCityKYCInfoAPIForSOLValidate ((END)) ###############################');
              res.json(Journeyresp);
            }
            else if (objRespCityKYCInfoAPI.StatusCode == "Failure" || objRespCityKYCInfoAPI.ErrorCode == "01") {
              Journeyresp = {
                "ErrorCode": "01",//objRespCityKYCInfoAPI.ErrorCode
                "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
              }
              logger.info('else if Failure Journeyresp ' + JSON.stringify(Journeyresp));
              logger.info('############################### 2. FAILURE CallCityKYCInfoAPIForSOLValidate ((END)) ###############################');
              res.json(Journeyresp);
            }
            else {
              Journeyresp = {
                "ErrorCode": objRespCityKYCInfoAPI.ErrorCode,
                "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
              }
              logger.info('else Journeyresp ' + JSON.stringify(Journeyresp));
              logger.info('############################### 3. else CallCityKYCInfoAPIForSOLValidate ((END)) ###############################');
              res.json(Journeyresp);
            }
          });
        });
      });
    });
  });
});

app.post('/api/CallCityKYCInfoAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### 2. Call CityKYCInfoAPI ((START)) ###############################');
  const { EncADPayload, EncPMPayload } = req.body;

     /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    ------------------------------------------------- */
    
      const refKey ='PNB131574606407'
   // const refKey = await getRefKeyOnce(EncADPayload);  //TESTING
    if (!refKey) {
      logger.error('refKey not generated');
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate Aadhaar details",
        Tranche: ""
      });
    }
    logger.info(`refKey resolved: ${refKey}`);

  objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNumber) => {
    objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {
      objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (objRespCustomerJourney) => {
        CurrentMileStone = JSON.parse(objRespCustomerJourney).JourneyMilestone;
        logger.info('CurrentMileStone is ' + CurrentMileStone);
        if (CurrentMileStone == 101) {
          objGeneralOperation.CBSToken(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID).then(async (TokenDetails) => {
            objCBSLayer.CityKYCInfoAPI(refKey, PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, TokenDetails.AccessToken).then(async (objRespCityKYCInfoAPI) => {
              if (objRespCityKYCInfoAPI.StatusCode == "Success" || objRespCityKYCInfoAPI.ErrorCode == "00") {
                Journeyresp = {
                  "ErrorCode": objRespCityKYCInfoAPI.ErrorCode,
                  "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
                }
                logger.info('Success Journeyresp ' + JSON.stringify(Journeyresp));
                logger.info('############################### 2. SUCCESS CityKYCInfoAPI ((END)) ###############################');
                res.json(Journeyresp);
              }
              else if (objRespCityKYCInfoAPI.StatusCode == "Failure" || objRespCityKYCInfoAPI.ErrorCode == "01") {
                Journeyresp = {
                  "ErrorCode": "01",//objRespCityKYCInfoAPI.ErrorCode
                  "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
                }
                logger.info('Failure Journeyresp ' + JSON.stringify(Journeyresp));
                logger.info('############################### 2. FAILURE CityKYCInfoAPI ((END)) ###############################');
                res.json(Journeyresp);
              }
              else {
                Journeyresp = {
                  "ErrorCode": objRespCityKYCInfoAPI.ErrorCode,
                  "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
                }
                logger.info('Failure Journeyresp ' + JSON.stringify(Journeyresp));
                logger.info('############################### 2. FAILURE CityKYCInfoAPI ((END)) ###############################');
                res.json(Journeyresp);
              }
            });
          });
        }
        else {
          Journeyresp = {
            "ErrorCode": "00",
            "ErrorMessage": "Customer journey already passed this milstone"
          }
          logger.info('Journeyresp ' + JSON.stringify(Journeyresp));
          logger.info('############################### 2. SUCCESS CityKYCInfoAPI END ###############################');
          res.json(Journeyresp);
        }
      });
    });
  });
});


//APIM calling CallCityKYCInfoAPIAPIM
app.post('/api/CallCityKYCInfoAPIAPIM', async (req, res) => {

  logger.info('############################### 2. Call CallCityKYCInfoAPIAPIM ((START)) ###############################');
  const { EncADPayload, EncPMPayload } = req.body;

     /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    ------------------------------------------------- */
    const refKey = await getRefKeyOnce(EncADPayload);
    if (!refKey) {
      logger.error('refKey not generated');
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate Aadhaar details",
        Tranche: ""
      });
    }
    logger.info(`refKey resolved: ${refKey}`);

  objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNumber) => {
    objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {
      objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (objRespCustomerJourney) => {
        CurrentMileStone = JSON.parse(objRespCustomerJourney).JourneyMilestone;
        logger.info('CurrentMileStone is ' + CurrentMileStone);
        if (CurrentMileStone == 101) {
          objGeneralOperation.APIMToken(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID).then(async (TokenDetails) => {
            objCBSLayer.CityKYCInfoAPIMAPI(refKey, PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, TokenDetails.AccessToken).then(async (objRespCityKYCInfoAPI) => {
              if (objRespCityKYCInfoAPI.StatusCode == "Success" || objRespCityKYCInfoAPI.ErrorCode == "00") {
                Journeyresp = {
                  "ErrorCode": objRespCityKYCInfoAPI.ErrorCode,
                  "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
                }
                logger.info('Success Journeyresp ' + JSON.stringify(Journeyresp));
                logger.info('############################### 2. SUCCESS CityKYCInfoAPI ((END)) ###############################');
                res.json(Journeyresp);
              }
              else if (objRespCityKYCInfoAPI.StatusCode == "Failure" || objRespCityKYCInfoAPI.ErrorCode == "01") {
                Journeyresp = {
                  "ErrorCode": "01",//objRespCityKYCInfoAPI.ErrorCode
                  "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
                }
                logger.info('Failure Journeyresp ' + JSON.stringify(Journeyresp));
                logger.info('############################### 2. FAILURE CityKYCInfoAPI ((END)) ###############################');
                res.json(Journeyresp);
              }
              else {
                Journeyresp = {
                  "ErrorCode": objRespCityKYCInfoAPI.ErrorCode,
                  "ErrorMessage": objRespCityKYCInfoAPI.ErrorMsg
                }
                logger.info('Failure Journeyresp ' + JSON.stringify(Journeyresp));
                logger.info('############################### 2. FAILURE CityKYCInfoAPI ((END)) ###############################');
                res.json(Journeyresp);
              }
            });
          });
        }
        else {
          Journeyresp = {
            "ErrorCode": "00",
            "ErrorMessage": "Customer journey already passed this milstone"
          }
          logger.info('Journeyresp ' + JSON.stringify(Journeyresp));
          logger.info('############################### 2. SUCCESS CityKYCInfoAPI END ###############################');
          res.json(Journeyresp);
        }
      });
    });
  });
});



app.post('/api/CallCustomerDetailsAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### 3. Call CustomerDetailsAPI START ###############################');

  const { EncADPayload, EncPMPayload } = req.body;
   /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    ------------------------------------------------- */
   //  const refKey = 'PNB817548663747'
     const refKey ='PNB131574606407'
   // const refKey = await getRefKeyOnce(EncADPayload); 
    if (!refKey) {
      logger.error('refKey not generated');
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate Aadhaar details",
        Tranche: ""
      });
    }
    logger.info(`refKey resolved1: ${refKey}`);
  objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNo) => {
    objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {

      objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (objRespCustomerJourney) => {
        let CurrentMileStone = JSON.parse(objRespCustomerJourney).JourneyMilestone;
        logger.info('CurrentMileStone ' + CurrentMileStone);
        if (CurrentMileStone == 102) {
          objGeneralOperation.getPMSData(PMSNumber, "ResumeJourney").then(async (PMSDetails) => {
            logger.info('Out PMSDetails: ', JSON.stringify(PMSDetails));
            if (PMSDetails != null) {
              PMSDataParse = JSON.parse(PMSDetails);
              objGeneralOperation.CBSToken(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID).then(async (TokenDetails) => {


             //  objGeneralOperation.getCityKYCInfoData(AadhaarNo).then(async (objRespCityKYCStatusExists) =>
                objGeneralOperation.getCityKYCInfoData(refKey).then(async (objRespCityKYCStatusExists) => {
                   logger.info('objRespCityKYCStatusExists', objRespCityKYCStatusExists);
                  let CityKYCStatusParse = JSON.parse(objRespCityKYCStatusExists);
                  objGeneralOperation.getEligibleDataFromMISD(CityKYCStatusParse.CustomerID).then(async (objgetEligibleDataFromMISD) => {
                    logger.info('Output getEligibleDataFromMISD ' + objgetEligibleDataFromMISD);

                    objGeneralOperation.getBranchInformation(CityKYCStatusParse.solid).then(async (RespBranchInformation) => {
                      logger.info('Out RespBranchInformation: ' + JSON.stringify(RespBranchInformation));
                      let ParseRespBranchInformation = JSON.parse(RespBranchInformation);

                      logger.info('Branch STATE: ' + ParseRespBranchInformation.STATE);
                      logger.info('PMS STATE: ' + PMSDataParse.CommAddr_Current_State);
                      logger.info('Branch DISTRICT: ' + ParseRespBranchInformation.DISTRICT);
                      logger.info('PMS DISTRICT: ' + PMSDataParse.CommAddr_Current_TownDist);
                  
                      logger.info('BRANCH PIN: ' + ParseRespBranchInformation.PINCODE);
                          logger.info('PMS PIN: ' + PMSDataParse.CommAddr_Current_PIN);

                          //AS per URS Dated 24-12-2025 Changes
                      // if (ParseRespBranchInformation.PINCODE.substring(0, 3) != PMSDataParse.CommAddr_Current_PIN.substring(0, 3)) {
                      //   Journeyresp = {
                      //     "ErrorCode": "01",
                      //     "ErrorMessage": "Your Application cannot be processed digitally due to city mismatch. Please visit your PNB Branch for further assistance."
                      //   }
                      //   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
                      //   objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: First 3 digit of PinCode mismatch for BranchMaster and SIDBI Data").then(async (respUpdateJourneyStatus) => {
                      //     res.json(Journeyresp);
                      //   });
                      // }
                      // else if (ParseRespBranchInformation.PINCODE != PMSDataParse.CommAddr_Current_PIN) {
                      //   Journeyresp = {
                      //     "ErrorCode": "01",
                      //     "ErrorMessage": "Your Application cannot be processed digitally due to city mismatch. Please visit your PNB Branch for further assistance."
                      //   }
                      //   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
                      //   objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: PINCode mismatch for BranchMaster and SIDBI Data").then(async (respUpdateJourneyStatus) => {
                      //     res.json(Journeyresp);
                      //   });
                      // }
                    //  if (ParseRespBranchInformation.STATE != PMSDataParse.CommAddr_Current_State || ParseRespBranchInformation.DISTRICT != PMSDataParse.CommAddr_Current_TownDist) {
                    //     Journeyresp = {
                    //       "ErrorCode": "01",
                    //       "ErrorMessage": "Your Application cannot be processed digitally due to city mismatch. Please visit your PNB Branch for further assistance."
                    //     }
                    //     logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
                    //     objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: State & Distict mismatch for BranchMaster and SIDBI Data").then(async (respUpdateJourneyStatus) => {
                    //       res.json(Journeyresp);
                    //     });
                    //   }
                       if (objgetEligibleDataFromMISD.ErrorCode == "01" && PMSDataParse.TRENCH == "2" || PMSDataParse.TRENCH == "3") {
                        logger.info('objgetEligibleDataFromMISDParse is null 01');
                        Journeyresp = {
                          "ErrorCode": "01",
                          "ErrorMessage": "You are not eligible for 2nd or 3rd Tranche.Please contact branch for further details."
                        }
                        logger.info('Journeyresp', Journeyresp);
                        objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: You are not not eligible 2nd Tranche").then(async (respUpdateJourneyStatus) => {
                          res.json(Journeyresp);
                        });
                      }
                      else if (PMSDataParse.TRENCH == "2" && (JSON.parse(objgetEligibleDataFromMISD).IP_CODE != CityKYCStatusParse.CustomerID && JSON.parse(objgetEligibleDataFromMISD).ELIGIBLE_FOR_2ND_TRANCHNE != "Y" && JSON.parse(objgetEligibleDataFromMISD).DEL_FLG != "N")) {
                        logger.info('objgetEligibleDataFromMISD is not null 2');
                        Journeyresp = {
                          "ErrorCode": "01",
                          "ErrorMessage": "You are not eligible for 2nd Tranche.Please contact branch for further details."
                        }
                        logger.info('Journeyresp', Journeyresp);
                        objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: You are not not eligible 2nd Tranche").then(async (respUpdateJourneyStatus) => {
                          res.json(Journeyresp);
                        });
                      }
                      else if (PMSDataParse.TRENCH == "3" && (JSON.parse(objgetEligibleDataFromMISD).IP_CODE != CityKYCStatusParse.CustomerID && JSON.parse(objgetEligibleDataFromMISD).ELIGIBLE_FOR_2ND_TRANCHNE != "Y" && JSON.parse(objgetEligibleDataFromMISD).DEL_FLG != "N")) {
                        logger.info('');
                        logger.info('');
                        logger.info('IP_CODE' + objgetEligibleDataFromMISD.IP_CODE);
                        logger.info('CustomerID' + CityKYCStatusParse.CustomerID);
                        logger.info('ELIGIBLE_FOR_2ND_TRANCHNE' + ELIGIBLE_FOR_2ND_TRANCHNE);
                        logger.info('DEL_FLG' + DEL_FLG);


                        logger.info('objgetEligibleDataFromMISD is null 3');
                        Journeyresp = {
                          "ErrorCode": "01",
                          "ErrorMessage": "You are not eligible for 3rd Tranche.Please contact branch for further details."
                        }
                        logger.info('Journeyresp', Journeyresp);
                        objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: You are not not eligible 3rd Tranche").then(async (respUpdateJourneyStatus) => {
                          res.json(Journeyresp);
                        });
                      }
                      else {
                        logger.info('Else : Means no condition success');
                        objCBSLayer.CustomerDetailsAPI(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, CityKYCStatusParse, TokenDetails.AccessToken, PMSDataParse).then(async (objRespCustomerDetails) => {
                          if (objRespCustomerDetails.ErrorCode == "00") {
                            Journeyresp = {
                              "ErrorCode": objRespCustomerDetails.ErrorCode,
                              "ErrorMessage": objRespCustomerDetails.ErrorMsg
                            }
                            res.json(Journeyresp);
                          }
                          else {
                            Journeyresp = {
                              "ErrorCode": "01",
                              "ErrorMessage": objRespCustomerDetails.ErrorMsg
                            }
                            res.json(Journeyresp);
                          }
                        });
                      }
                    });
                  });
                });
              });
            }
          });

        }
        else {
          Journeyresp = {
            "ErrorCode": "00",
            "ErrorMessage": "Customer journey already passed this milstone"
          }
          logger.info('Journeyresp' + JSON.stringify(Journeyresp));
          logger.info('############################### Call CustomerDetailsAPI END ###############################');
          res.json(Journeyresp);
        }
      });
    });
  });
});

//APIM CAlling 


// app.post('/api/CallCustomerDetailsAPIAPIM', async (req, res) => {
//   logger.info('');
//   logger.info('');
//   logger.info('############################### 3. Call CallCustomerDetailsAPIAPIM START ###############################');

//   const { EncADPayload, EncPMPayload } = req.body;
//    /* -------------------------------------------------
//        1️⃣ GET refKey (SYNC & SAFE)
//     ------------------------------------------------- */
//     const refKey = await getRefKeyOnce(EncADPayload);
//     if (!refKey) {
//       logger.error('refKey not generated');
//       return res.json({
//         ErrorCode: "01",
//         ErrorMessage: "Unable to validate Aadhaar details",
//         Tranche: ""
//       });
//     }
//     logger.info(`refKey resolved1: ${refKey}`);
//   objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNo) => {
//     objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {

//       objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (objRespCustomerJourney) => {
//         let CurrentMileStone = JSON.parse(objRespCustomerJourney).JourneyMilestone;
//         logger.info('CurrentMileStone ' + CurrentMileStone);
//         if (CurrentMileStone == 102) {
//           objGeneralOperation.getPMSData(PMSNumber, "ResumeJourney").then(async (PMSDetails) => {
//             logger.info('Out PMSDetails: ', JSON.stringify(PMSDetails));
//             if (PMSDetails != null) {
//               PMSDataParse = JSON.parse(PMSDetails);
//               objGeneralOperation.APIMToken(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID).then(async (TokenDetails) => {


//              //  objGeneralOperation.getCityKYCInfoData(AadhaarNo).then(async (objRespCityKYCStatusExists) =>
//                 objGeneralOperation.getCityKYCInfoData(refKey).then(async (objRespCityKYCStatusExists) => {
//                    logger.info('objRespCityKYCStatusExists', objRespCityKYCStatusExists);
//                   let CityKYCStatusParse = JSON.parse(objRespCityKYCStatusExists);                              
//                     objGeneralOperation.getBranchInformation(CityKYCStatusParse.solid).then(async (RespBranchInformation) => {
//                       logger.info('Out RespBranchInformation: ' + JSON.stringify(RespBranchInformation));
//                       let ParseRespBranchInformation = JSON.parse(RespBranchInformation);

//                       logger.info('Branch STATE: ' + ParseRespBranchInformation.STATE);
//                       logger.info('PMS STATE: ' + PMSDataParse.CommAddr_Current_State);
//                       logger.info('Branch DISTRICT: ' + ParseRespBranchInformation.DISTRICT);
//                       logger.info('PMS DISTRICT: ' + PMSDataParse.CommAddr_Current_TownDist);
                  
//                       logger.info('BRANCH PIN: ' + ParseRespBranchInformation.PINCODE);
//                           logger.info('PMS PIN: ' + PMSDataParse.CommAddr_Current_PIN);

//                           //AS per URS Dated 24-12-2025 Changes
//                       // if (ParseRespBranchInformation.PINCODE.substring(0, 3) != PMSDataParse.CommAddr_Current_PIN.substring(0, 3)) {
//                       //   Journeyresp = {
//                       //     "ErrorCode": "01",
//                       //     "ErrorMessage": "Your Application cannot be processed digitally due to city mismatch. Please visit your PNB Branch for further assistance."
//                       //   }
//                       //   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                       //   objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: First 3 digit of PinCode mismatch for BranchMaster and SIDBI Data").then(async (respUpdateJourneyStatus) => {
//                       //     res.json(Journeyresp);
//                       //   });
//                       // }
//                       // else if (ParseRespBranchInformation.PINCODE != PMSDataParse.CommAddr_Current_PIN) {
//                       //   Journeyresp = {
//                       //     "ErrorCode": "01",
//                       //     "ErrorMessage": "Your Application cannot be processed digitally due to city mismatch. Please visit your PNB Branch for further assistance."
//                       //   }
//                       //   logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                       //   objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: PINCode mismatch for BranchMaster and SIDBI Data").then(async (respUpdateJourneyStatus) => {
//                       //     res.json(Journeyresp);
//                       //   });
//                       // }
//                     //  if (ParseRespBranchInformation.STATE != PMSDataParse.CommAddr_Current_State || ParseRespBranchInformation.DISTRICT != PMSDataParse.CommAddr_Current_TownDist) {
//                     //     Journeyresp = {
//                     //       "ErrorCode": "01",
//                     //       "ErrorMessage": "Your Application cannot be processed digitally due to city mismatch. Please visit your PNB Branch for further assistance."
//                     //     }
//                     //     logger.info(`######### 1. Call NewOrResumeJourney ((END)) ########`);
//                     //     objGeneralOperation.UpdateCustomerJourneyErrorUpdate(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, "Error: State & Distict mismatch for BranchMaster and SIDBI Data").then(async (respUpdateJourneyStatus) => {
//                     //       res.json(Journeyresp);
//                     //     });
//                     //   }
                    
                     
//                       else {
//                         logger.info('Else : Means no condition success');
//                         objCBSLayer.CustomerDetailsAPI(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, CityKYCStatusParse, TokenDetails.AccessToken, PMSDataParse).then(async (objRespCustomerDetails) => {
//                           if (objRespCustomerDetails.ErrorCode == "00") {
//                             Journeyresp = {
//                               "ErrorCode": objRespCustomerDetails.ErrorCode,
//                               "ErrorMessage": objRespCustomerDetails.ErrorMsg
//                             }
//                             res.json(Journeyresp);
//                           }
//                           else {
//                             Journeyresp = {
//                               "ErrorCode": "01",
//                               "ErrorMessage": objRespCustomerDetails.ErrorMsg
//                             }
//                             res.json(Journeyresp);
//                           }
//                         });
//                       }
//                     });
                  
//                 });
//               });
//             }
//           });

//         }
//         else {
//           Journeyresp = {
//             "ErrorCode": "00",
//             "ErrorMessage": "Customer journey already passed this milstone"
//           }
//           logger.info('Journeyresp' + JSON.stringify(Journeyresp));
//           logger.info('############################### Call CustomerDetailsAPI END ###############################');
//           res.json(Journeyresp);
//         }
//       });
//     });
//   });
// });


app.post('/api/CallCustomerDetailsAPIAPIM', async (req, res) => {

  logger.info('CallCustomerDetailsAPIAPIM START');

  try {

    const { EncADPayload, EncPMPayload } = req.body;

    if (!EncADPayload || !EncPMPayload) {
      return res.status(400).json({
        ErrorCode: "01",
        ErrorMessage: "Invalid payload"
      });
    }

    // 1️⃣ refKey
    const refKey = await getRefKeyOnce(EncADPayload);
    if (!refKey) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate Aadhaar"
      });
    }

    // 2️⃣ Decrypt
    const AadhaarNo = await objCommonFunction.Decrypt(EncADPayload);
    const PMSNumber = await objCommonFunction.Decrypt(EncPMPayload);

    if (!PMSNumber) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Invalid PMS Number"
      });
    }

    // 3️⃣ Journey
    const journeyRaw = await objGeneralOperation.getCustomerJourneyData(PMSNumber);

    if (!journeyRaw) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Journey not found"
      });
    }

    const journeyData = JSON.parse(journeyRaw);

    if (journeyData.JourneyMilestone !== 102) {
      return res.json({
        ErrorCode: "00",
        ErrorMessage: "Customer already passed this milestone"
      });
    }

    // 4️⃣ PMS Data
    const pmsRaw = await objGeneralOperation.getPMSData(PMSNumber, "ResumeJourney");

    if (!pmsRaw) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "PMS data not found"
      });
    }

    const PMSDataParse = JSON.parse(pmsRaw); // ✅ LOCAL VARIABLE

    // 5️⃣ Token
    const token = await objGeneralOperation.APIMToken(
      PMSNumber,
      journeyData.JourneyID
    );

    if (!token?.AccessToken) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Token generation failed"
      });
    }

    // 6️⃣ City KYC
    const cityRaw = await objGeneralOperation.getCityKYCInfoData(refKey);

    if (!cityRaw) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "City KYC not found"
      });
    }

    const CityKYCStatusParse = JSON.parse(cityRaw);

    // 7️⃣ Branch
    const branchRaw = await objGeneralOperation.getBranchInformation(
      CityKYCStatusParse.solid
    );

    if (!branchRaw) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "BranchINFO not found"
      });
    }

    const BranchInfo = JSON.parse(branchRaw);

    // 8️⃣ Validation
    if (
      BranchInfo.STATE !== PMSDataParse.CommAddr_Current_State ||
      BranchInfo.DISTRICT !== PMSDataParse.CommAddr_Current_TownDist
    ) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "City mismatch. Visit branch."
      });
    }

    // 9️⃣ Final API
    const apiResponse = await objCBSLayer.CustomerDetailsAPIAPIM(
      PMSNumber,
      journeyData.JourneyID,
      CityKYCStatusParse,
      token.AccessToken,
      PMSDataParse
    );

    if (!apiResponse) {
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "No response from CBS"
      });
    }

    return res.json({
      ErrorCode: apiResponse.ErrorCode === "00" ? "00" : "01",
      ErrorMessage: apiResponse.ErrorMsg || "Failed"
    });

  } catch (error) {

    logger.error("Unhandled error:", error);

    return res.status(500).json({
      ErrorCode: "01",
      ErrorMessage: "Internal server error"
    });
  }
});


app.post('/api/CallBGCustomerDetailsAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### 3. Call CallBGCustomerDetailsAPI START ###############################');

  const { EncADPayload, EncPMPayload, EncLoginPayload, custDataCheck } = req.body;
   /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    ------------------------------------------------- */
    const refKey = await getRefKeyOnce(EncADPayload);
    if (!refKey) {
      logger.error('refKey not generated');
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate Aadhaar details",
        Tranche: ""
      });
    }
    logger.info(`refKey resolved: ${refKey}`);
  logger.info('custDataCheck ' + custDataCheck)
  objCommonFunction.Decrypt(EncLoginPayload).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
    logger.info('UserID ' + deLoginResponse.UserID);
    objCommonFunction.Decrypt(EncADPayload).then(async (AadhaarNo) => {
      objCommonFunction.Decrypt(EncPMPayload).then(async (PMSNumber) => {

        objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (objRespCustomerJourney) => {
          let CurrentMileStone = JSON.parse(objRespCustomerJourney).JourneyMilestone;
          logger.info('CurrentMileStone ' + CurrentMileStone);
          if (CurrentMileStone == 102) {
            objGeneralOperation.getPMSData(PMSNumber, "ResumeJourney").then(async (PMSDetails) => {
              logger.info('Out PMSDetails: ', JSON.stringify(PMSDetails));
              if (PMSDetails != null) {
                PMSDataParse = JSON.parse(PMSDetails);
                objGeneralOperation.CBSToken(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID).then(async (TokenDetails) => {
                  objGeneralOperation.getCityKYCInfoData(refKey).then(async (objRespCityKYCStatusExists) => {
                    //  logger.info('objRespCityKYCStatusExists', objRespCityKYCStatusExists);
                    let CityKYCStatusParse = JSON.parse(objRespCityKYCStatusExists);
                    logger.info('Else : Means no condition success');
                    objCBSLayer.BGCustomerDetailsAPI(PMSNumber, JSON.parse(objRespCustomerJourney).JourneyID, CityKYCStatusParse, TokenDetails.AccessToken, PMSDataParse, custDataCheck).then(async (objRespCustomerDetails) => {
                      if (objRespCustomerDetails.ErrorCode == "00") {
                        if (custDataCheck == true) {
                          objGeneralOperation.LogMakerConsent(PMSNumber, null, deLoginResponse.UserID, "CBS_NAME_MOBILE", custDataCheck, "null").then(async (objRespLogMakerConsent) => {
                            if (objRespLogMakerConsent.ErrorCode == "00") {
                              Journeyresp = {
                                "ErrorCode": objRespCustomerDetails.ErrorCode,
                                "ErrorMessage": objRespCustomerDetails.ErrorMsg
                              }
                              res.json(Journeyresp);
                            }
                          });
                        }
                        else {
                          Journeyresp = {
                            "ErrorCode": objRespCustomerDetails.ErrorCode,
                            "ErrorMessage": objRespCustomerDetails.ErrorMsg
                          }
                          res.json(Journeyresp);
                        }
                      }
                      else {
                        Journeyresp = {
                          "ErrorCode": objRespCustomerDetails.ErrorCode,
                          "ErrorMessage": objRespCustomerDetails.ErrorMsg
                        }
                        res.json(Journeyresp);
                      }
                    });
                  });
                });
              }
            });

          }
          else {
            Journeyresp = {
              "ErrorCode": "00",
              "ErrorMessage": "Customer journey already passed this milstone"
            }
            logger.info('Journeyresp' + JSON.stringify(Journeyresp));
            logger.info('############################### Call CustomerDetailsAPI END ###############################');
            res.json(Journeyresp);
          }
        });
      });
    });
  });
});

app.post('/api/CallCBSLoanAndCBSNPAAndSIDBICurrentStausAPI', async (req, res) => {//Call at Login Page after CustDetail API and before VFirst API Call
  const { EncPMSPayload, Channel } = req.body;
  logger.info('');
  logger.info('Enc PMS Number' + EncPMSPayload);
  logger.info('API Calling Channel ' + Channel);
  logger.info('############################### 4. Call CBSLoanAndCBSNPAAndSIDBICurrentStausAPI ((START)) ###############################');
  logger.info('');
  objCommonFunction.Decrypt(EncPMSPayload).then(async (PMSNumber) => {
    objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => { //get active journey Data
      logger.info('RespCustomerJourneyData ' + JSON.stringify(RespCustomerJourneyData));

      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
      

const trancheSchemeMap = {
    1: "TLSVF",
    2: "TLSVS",
    3: "TLSVT"
};

let schemeCode = trancheSchemeMap[CustomerJourneyDataParsed.LoanTranche];


console.log(schemeCode);

      objGeneralOperation.CBSToken(PMSNumber, CustomerJourneyDataParsed.JourneyID).then(async (TokenDetails) => {
        let objloanStatusInquiry = {
          "CustomerID": CustomerJourneyDataParsed.CustomerID,
          "Access_Token": TokenDetails.AccessToken,
          "LoanAmount": CustomerJourneyDataParsed.LoanAmount,
          "SchmCode":schemeCode
         
        }

        let PlainString = {
          "AadhaarNumber": CustomerJourneyDataParsed.AadhaarNo,
          "PMSNumber": CustomerJourneyDataParsed.PMSNumber,
          "JourneyID": CustomerJourneyDataParsed.JourneyID,
          "CustomerID": CustomerJourneyDataParsed.CustomerID
        }

	  


        logger.info("PlainString ", JSON.stringify(PlainString));
        objCommonFunction.Encrypt(JSON.stringify(PlainString)).then(async (EncString) => {
          logger.info("EncString ", EncString);

          logger.info('objloanStatusInquiry ' + JSON.stringify(objloanStatusInquiry));
          logger.info('');
          logger.info('############################### 4. Call LoanStatusInquiryAPI ((START)) ###############################');
          objCBSLayer.LoanStatusInquiryAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, JSON.stringify(objloanStatusInquiry)).then(async (respLoanStatusInquiry) => {
            logger.info('LoanStatusAPIAPI saved in local database ErrorCode: ' + JSON.stringify(respLoanStatusInquiry));
            //logger.info('LoanStatusAPIAPI saved in local database ErrorCode: '+JSON.stringify(respLoanStatusInquiry));            
            if (respLoanStatusInquiry.ErrorStatus == "Success" && respLoanStatusInquiry.ErrorCode == "00") { //Success          
              let objNPAStatusInquiry = {
                "CustomerID": CustomerJourneyDataParsed.CustomerID,
                "Access_Token": TokenDetails.AccessToken,
              }
              logger.info('############################### 4. SUCCESS Call LoanStatusInquiryAPI ((END)) ###############################');
              logger.info('');
              logger.info('');
              logger.info('############################### 5. Call CallCBSNPAStatusAPIAPI ((START)) ###############################');
              objCBSLayer.NPAStatusInquiryAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, objNPAStatusInquiry).then(async (respNPAStatusInquiry) => {
                logger.info('NPAStatusInquiryAPI saved in local database ErrorCode: ' + JSON.stringify(respNPAStatusInquiry));
                if (respNPAStatusInquiry.StatusCode == "Success" && respNPAStatusInquiry.ErrorCode == "00") {
                  logger.info('');
                  logger.info('');
                  logger.info('############################### 6. Call CallSIDBICurrentStatusAPI ((START)) ###############################');
                 
                  objSIDBILayer.CallSIDBICurrentStatusAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed).then(async (objRespSIDBIResponse) => {
                    logger.info('get CallSIDBIStatusAPI Response saved in local database: ' + JSON.stringify(objRespSIDBIResponse));
                    if (objRespSIDBIResponse.ErrorCode == "00")//Success-"00", Failure-"01" 111111000000
                 
                    {

                      
                      Journeyresp = {
                        "ErrorCode": objRespSIDBIResponse.ErrorCode,
                        "ErrorMessage": objRespSIDBIResponse.ErrorMsg,
                        "EncString": EncString
                      }
                      logger.info('if JourneyResp: ' + JSON.stringify(Journeyresp));
                      logger.info('############################### 6. SUCCESS CallSIDBICurrentStatusAPI ((END)) ###############################');
                      res.json(Journeyresp);
                    }
                    else if (objRespSIDBIResponse.ErrorCode == "01" || objRespSIDBIResponse.ErrorCode == "02") {
                      Journeyresp = {
                        "ErrorCode": objRespSIDBIResponse.ErrorCode,
                        "ErrorMessage": objRespSIDBIResponse.ErrorMsg,
                        "EncString": EncString
                      }
                      logger.info('else if JourneyResp: ' + JSON.stringify(Journeyresp));
                      logger.info('############################### 6. FAILURE CallSIDBICurrentStatusAPI ((END)) ###############################');
                      res.json(Journeyresp);
                    }
                  });
                }
                else if (respNPAStatusInquiry.StatusCode == "Failure" && respNPAStatusInquiry.ErrorCode == "01") {
                  objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", "Error02", respNPAStatusInquiry.ErrorMsg).then(async (respUpdateJourneyStatus) => {
                    if (respUpdateJourneyStatus.ErrorCode == "00") {
                      //RJ000013:Already NPA in said bank               
                      // const APIURL =await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
                      // logger.info(`CustomerJourneyDataParsed AadhaarNo: ${CustomerJourneyDataParsed.AadhaarNo}`);
                      // objGeneralOperation.getCityKYCInfoData(CustomerJourneyDataParsed.AadhaarNo).then(async (CityKYCStatusDetails) => { 
                      //   logger.info(`Output getCityKYCInfoData: ${JSON.stringify(CityKYCStatusDetails)}`);
                      //   if(CityKYCStatusDetails!=null)
                      //   {
                      //     objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(PMSNumber,CustomerJourneyDataParsed.JourneyID,"RJ000013",APIURL,CityKYCStatusDetails).then(async (respUpdateJourneyStatus) => {
                      //       logger.info("Return from  updated response in Database: "+ JSON.stringify(respUpdateJourneyStatus));
                      //       if(respUpdateJourneyStatus.ErrorCode=="00")
                      //       {
                      //         objNPAStatusInquiry={
                      //           "ErrorCode":"01",
                      //           "ErrorMessage":"Customer Journey has been rejected due to Already NPA in said bank"
                      //           }
                      //           logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');                           
                      //           return res.json(objNPAStatusInquiry); 
                      //       }
                      //       else
                      //       {
                      //         objNPAStatusInquiry={
                      //           "ErrorCode":"01",
                      //           "ErrorMessage":"Unable to update rejected status at SIDBI"
                      //           }
                      //           logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');                           
                      //           return res.json(objNPAStatusInquiry); 
                      //       }
                      //     });  
                      //   }
                      //   });
                      objNPAStatusInquiry = {
                        "ErrorCode": "01",
                        "ErrorMessage": "NPA Account Found. Please contact your PNB branch for further assistance",
                        "EncString": EncString
                      }
                      logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                      return res.json(objNPAStatusInquiry);
                    }
                  });
                }
                else if (respNPAStatusInquiry.ErrorStatus == "Failure" && respNPAStatusInquiry.ErrorCode == "02") { //Loan Status Inquiry          
                  objNPAStatusInquiry = {
                    "ErrorCode": "01",
                    "ErrorMessage": respNPAStatusInquiry.ErrorMsg,
                    "EncString": EncString
                  }
                  logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                  return res.json(objNPAStatusInquiry);
                }
                else if (respNPAStatusInquiry.ErrorStatus == "Failure" && respNPAStatusInquiry.ErrorCode == "03") { //Loan Status Inquiry          
                  objNPAStatusInquiry = {
                    "ErrorCode": "01",
                    "ErrorMessage": respNPAStatusInquiry.ErrorMsg,
                    "EncString": EncString
                  }
                  logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                  return res.json(objNPAStatusInquiry);
                }
                else {
                  //Update in database
                  objNPAStatusInquiry = {
                    "ErrorCode": "01",
                    "ErrorMessage": respNPAStatusInquiry.ErrorMsg,
                    "EncString": EncString
                  }
                  logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                  return res.json(objNPAStatusInquiry);
                }
              });
            }
            else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "02") {
              //This error handel any failure received from middleware with System error occurred. Please retry after sometime or contact your branch for further assistance        
              respLoanStatusInquiry = {
                "ErrorCode": respLoanStatusInquiry.ErrorCode,
                "ErrorMessage": respLoanStatusInquiry.ErrorMsg,
                "EncString": EncString
              }
              logger.info('############################### FAILURE LoanStatusInquiryAPI API ((END)) ###############################');
              return res.json(respLoanStatusInquiry);
            }
            else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "03") {
              //Loan Status Inquiry failure for Business or NPA
              if (Channel == "BranchJourney") {
                respLoanStatusInquiry = {
                  "ErrorCode": "03",
                  "ErrorMessage": "A business loan or NPA has been identified. If you want to proceed, please confirm that there is no active NPA or any business loan restricted under the scheme.",
                  "EncString": EncString
                }
                logger.info("Loan Status Failure gives options to branch user for further action : " + JSON.stringify(respLoanStatusInquiry));
                return res.json(respLoanStatusInquiry);
              }
              else {
                //Exception: System error occurred. Please retry after sometime or contact your branch for further assistance
                objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", "Error01", respLoanStatusInquiry.ErrorMsg).then(async (respUpdateJourneyStatus) => {
                  respLoanStatusInquiry = {
                    "ErrorCode": "03",
                    "ErrorMessage": "You have already availed a Business Loan/NPA with PNB. Please contact your PNB branch for further assistance",
                    "EncString": EncString
                  }
                  logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
                  logger.info("Loan Status Failure Directly rejected Customer Journey : " + JSON.stringify(respLoanStatusInquiry));
                  return res.json(respLoanStatusInquiry);
                });
              }
            }
            else {
              respLoanStatusInquiry = {
                "ErrorCode": respLoanStatusInquiry.ErrorCode,
                "ErrorMessage": respLoanStatusInquiry.ErrorMsg,
                "EncString": EncString
              }
              logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
              return res.json(respLoanStatusInquiry);
            }
          });
        });
      });
    });
  });
});


app.post('/api/CallAPIMCBSLoanSIDBICurrentStausAPI', async (req, res) => {//Call at Login Page after CustDetail API and before VFirst API Call using APIM
  const { EncPMSPayload, Channel } = req.body;
  logger.info('');
  logger.info('Enc PMS Number' + EncPMSPayload);
  logger.info('API Calling Channel ' + Channel);
  logger.info('############################### 4.A  CallAPIMCBSLoanSIDBICurrentStausAPI ((START)) ###############################');
  logger.info('');
  objCommonFunction.Decrypt(EncPMSPayload).then(async (PMSNumber) => {
    objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => { //get active journey Data
      logger.info('RespCustomerJourneyData ' + JSON.stringify(RespCustomerJourneyData));

      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
      

const trancheSchemeMap = {
    1: "TLSVF",
    2: "TLSVS",
    3: "TLSVT"
};

let schemeCode = trancheSchemeMap[CustomerJourneyDataParsed.LoanTranche];


console.log(schemeCode);

      objGeneralOperation.APIMToken(PMSNumber, CustomerJourneyDataParsed.JourneyID).then(async (TokenDetails) => {
        let objloanStatusInquiry = {
          "CustomerID": CustomerJourneyDataParsed.CustomerID,
          "Access_Token": TokenDetails.AccessToken,
          "LoanAmount": CustomerJourneyDataParsed.LoanAmount,
          "SchmCode":schemeCode
         
        }

        let PlainString = {
          "AadhaarNumber": CustomerJourneyDataParsed.AadhaarNo,
          "PMSNumber": CustomerJourneyDataParsed.PMSNumber,
          "JourneyID": CustomerJourneyDataParsed.JourneyID,
          "CustomerID": CustomerJourneyDataParsed.CustomerID
        }

	
        logger.info("PlainString ", +JSON.stringify(PlainString));
        objCommonFunction.APIMEncrypt(PlainString).then(async (EncString) => {
          logger.info("EncString ", EncString);

          logger.info('objloanStatusInquiry ' + JSON.stringify(objloanStatusInquiry));
          logger.info('');
          logger.info('############################### 4. Call LoanStatusInquiryAPI ((START)) ###############################');
          objCBSLayer.APIMLoanStatusInquiryAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, JSON.stringify(objloanStatusInquiry)).then(async (respLoanStatusInquiry) => {
            logger.info('LoanStatusAPIAPI saved in local database ErrorCode: ' + JSON.stringify(respLoanStatusInquiry));
            //logger.info('LoanStatusAPIAPI saved in local database ErrorCode: '+JSON.stringify(respLoanStatusInquiry));            
            if (respLoanStatusInquiry.ErrorStatus == "Success" && respLoanStatusInquiry.ErrorCode == "00") { //Success          
              let objNPAStatusInquiry = {
                "CustomerID": CustomerJourneyDataParsed.CustomerID,
                "Access_Token": TokenDetails.AccessToken,
              }
              logger.info('############################### 4. SUCCESS Call LoanStatusInquiryAPI ((END)) ###############################');
              logger.info('');
              logger.info('');
              // logger.info('############################### 5. Call CallCBSNPAStatusAPIAPI ((START)) ###############################');
              // objCBSLayer.NPAStatusInquiryAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, objNPAStatusInquiry).then(async (respNPAStatusInquiry) => {
              //   logger.info('NPAStatusInquiryAPI saved in local database ErrorCode: ' + JSON.stringify(respNPAStatusInquiry));
              //   if (respNPAStatusInquiry.StatusCode == "Success" && respNPAStatusInquiry.ErrorCode == "00") {
              //     logger.info('');
              //     logger.info('');
                  logger.info('############################### 6. Call CallSIDBICurrentStatusAPI ((START)) ###############################');
                 
                  objSIDBILayer.CallSIDBICurrentStatusAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed).then(async (objRespSIDBIResponse) => {
                    logger.info('get CallSIDBIStatusAPI Response saved in local database: ' + JSON.stringify(objRespSIDBIResponse));
                    if (objRespSIDBIResponse.ErrorCode == "00")//Success-"00", Failure-"01" 111111000000
                 
                    {
                      Journeyresp = {
                        "ErrorCode": objRespSIDBIResponse.ErrorCode,
                        "ErrorMessage": objRespSIDBIResponse.ErrorMsg,
                        "EncString": EncString
                      }
                      logger.info('if JourneyResp: ' + JSON.stringify(Journeyresp));
                      logger.info('############################### 6. SUCCESS CallSIDBICurrentStatusAPI ((END)) ###############################');
                      res.json(Journeyresp);
                    }
                    else if (objRespSIDBIResponse.ErrorCode == "01" || objRespSIDBIResponse.ErrorCode == "02") {
                      Journeyresp = {
                        "ErrorCode": objRespSIDBIResponse.ErrorCode,
                        "ErrorMessage": objRespSIDBIResponse.ErrorMsg,
                        "EncString": EncString
                      }
                      logger.info('else if JourneyResp: ' + JSON.stringify(Journeyresp));
                      logger.info('############################### 6. FAILURE CallSIDBICurrentStatusAPI ((END)) ###############################');
                      res.json(Journeyresp);
                    }
                  });
                }
                // else if (respNPAStatusInquiry.StatusCode == "Failure" && respNPAStatusInquiry.ErrorCode == "01") {
                //   objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", "Error02", respNPAStatusInquiry.ErrorMsg).then(async (respUpdateJourneyStatus) => {
                //     if (respUpdateJourneyStatus.ErrorCode == "00") {
                //       //RJ000013:Already NPA in said bank               
                //       // const APIURL =await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
                //       // logger.info(`CustomerJourneyDataParsed AadhaarNo: ${CustomerJourneyDataParsed.AadhaarNo}`);
                //       // objGeneralOperation.getCityKYCInfoData(CustomerJourneyDataParsed.AadhaarNo).then(async (CityKYCStatusDetails) => { 
                //       //   logger.info(`Output getCityKYCInfoData: ${JSON.stringify(CityKYCStatusDetails)}`);
                //       //   if(CityKYCStatusDetails!=null)
                //       //   {
                //       //     objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(PMSNumber,CustomerJourneyDataParsed.JourneyID,"RJ000013",APIURL,CityKYCStatusDetails).then(async (respUpdateJourneyStatus) => {
                //       //       logger.info("Return from  updated response in Database: "+ JSON.stringify(respUpdateJourneyStatus));
                //       //       if(respUpdateJourneyStatus.ErrorCode=="00")
                //       //       {
                //       //         objNPAStatusInquiry={
                //       //           "ErrorCode":"01",
                //       //           "ErrorMessage":"Customer Journey has been rejected due to Already NPA in said bank"
                //       //           }
                //       //           logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');                           
                //       //           return res.json(objNPAStatusInquiry); 
                //       //       }
                //       //       else
                //       //       {
                //       //         objNPAStatusInquiry={
                //       //           "ErrorCode":"01",
                //       //           "ErrorMessage":"Unable to update rejected status at SIDBI"
                //       //           }
                //       //           logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');                           
                //       //           return res.json(objNPAStatusInquiry); 
                //       //       }
                //       //     });  
                //       //   }
                //       //   });
                //       objNPAStatusInquiry = {
                //         "ErrorCode": "01",
                //         "ErrorMessage": "NPA Account Found. Please contact your PNB branch for further assistance",
                //         "EncString": EncString
                //       }
                //       logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                //       return res.json(objNPAStatusInquiry);
                //     }
                //   });
                // }
                // else if (respNPAStatusInquiry.ErrorStatus == "Failure" && respNPAStatusInquiry.ErrorCode == "02") { //Loan Status Inquiry          
                //   objNPAStatusInquiry = {
                //     "ErrorCode": "01",
                //     "ErrorMessage": respNPAStatusInquiry.ErrorMsg,
                //     "EncString": EncString
                //   }
                //   logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                //   return res.json(objNPAStatusInquiry);
                // }
                // else if (respNPAStatusInquiry.ErrorStatus == "Failure" && respNPAStatusInquiry.ErrorCode == "03") { //Loan Status Inquiry          
                //   objNPAStatusInquiry = {
                //     "ErrorCode": "01",
                //     "ErrorMessage": respNPAStatusInquiry.ErrorMsg,
                //     "EncString": EncString
                //   }
                //   logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                //   return res.json(objNPAStatusInquiry);
                // }
                // else {
                //   //Update in database
                //   objNPAStatusInquiry = {
                //     "ErrorCode": "01",
                //     "ErrorMessage": respNPAStatusInquiry.ErrorMsg,
                //     "EncString": EncString
                //   }
                //   logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                //   return res.json(objNPAStatusInquiry);
                // }
            //   });
            // }
            else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "02") {
              //This error handel any failure received from middleware with System error occurred. Please retry after sometime or contact your branch for further assistance        
              respLoanStatusInquiry = {
                "ErrorCode": respLoanStatusInquiry.ErrorCode,
                "ErrorMessage": respLoanStatusInquiry.ErrorMsg,
                "EncString": EncString
              }
              logger.info('############################### FAILURE LoanStatusInquiryAPI API ((END)) ###############################');
              return res.json(respLoanStatusInquiry);
            }
            else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "03") {
              //Loan Status Inquiry failure for Business or NPA
              if (Channel == "BranchJourney") {
                respLoanStatusInquiry = {
                  "ErrorCode": "03",
                  "ErrorMessage": "A business loan or NPA has been identified. If you want to proceed, please confirm that there is no active NPA or any business loan restricted under the scheme.",
                  "EncString": EncString
                }
                logger.info("Loan Status Failure gives options to branch user for further action : " + JSON.stringify(respLoanStatusInquiry));
                return res.json(respLoanStatusInquiry);
              }
              else {
                //Exception: System error occurred. Please retry after sometime or contact your branch for further assistance
                objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", "Error01", respLoanStatusInquiry.ErrorMsg).then(async (respUpdateJourneyStatus) => {
                  respLoanStatusInquiry = {
                    "ErrorCode": "03",
                    "ErrorMessage": "You have already availed a Business Loan/NPA with PNB. Please contact your PNB branch for further assistance",
                    "EncString": EncString
                  }
                  logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
                  logger.info("Loan Status Failure Directly rejected Customer Journey : " + JSON.stringify(respLoanStatusInquiry));
                  return res.json(respLoanStatusInquiry);
                });
              }
            }
            else {
              respLoanStatusInquiry = {
                "ErrorCode": respLoanStatusInquiry.ErrorCode,
                "ErrorMessage": respLoanStatusInquiry.ErrorMsg,
                "EncString": EncString
              }
              logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
              return res.json(respLoanStatusInquiry);
            }
          });
        });
      });
    });
  });
});
















app.post('/api/CallCBSLoanAndSIDBICurrentStausAPI', async (req, res) => {//Call at Login Page after CustDetail API and before VFirst API Call
  const { EncPMSPayload } = req.body;
  logger.info('');
  logger.info('Enc PMS Number', EncPMSPayload);
  logger.info('############################### 4. Call CallCBSLoanAndSIDBICurrentStausAPI ((START)) ###############################');
  logger.info('');
  objCommonFunction.Decrypt(EncPMSPayload).then(async (PMSNumber) => {
    objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => { //get active journey Data
      logger.info('RespCustomerJourneyData ' + JSON.stringify(RespCustomerJourneyData));
      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
      objGeneralOperation.CBSToken(PMSNumber, CustomerJourneyDataParsed.JourneyID).then(async (TokenDetails) => {
        let objloanStatusInquiry = {
          "CustomerID": CustomerJourneyDataParsed.CustomerID,
          "Access_Token": TokenDetails.AccessToken,
          "LoanAmount": CustomerJourneyDataParsed.LoanAmount
        }

        logger.info('objloanStatusInquiry ' + JSON.stringify(objloanStatusInquiry));
        logger.info('');
        logger.info('############################### 4. Call LoanStatusInquiryAPI ((START)) ###############################');
        objCBSLayer.LoanStatusInquiryAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, JSON.stringify(objloanStatusInquiry)).then(async (respLoanStatusInquiry) => {
          logger.info('Output LoanStatusAPIAPI: ' + JSON.stringify(respLoanStatusInquiry));
          // logger.info('LoanStatusAPIAPI saved in local database ErrorCode: '+JSON.stringify(respLoanStatusInquiry));            
          if (respLoanStatusInquiry.ErrorStatus == "Success" && respLoanStatusInquiry.ErrorCode == "00") { //Success          
            // let objNPAStatusInquiry={
            //   "CustomerID":CustomerJourneyDataParsed.CustomerID,
            //   "Access_Token":TokenDetails.AccessToken,
            // }
            logger.info('############################### 4. SUCCESS Call LoanStatusInquiryAPI ((END)) ###############################');
            logger.info('');
            logger.info('');
            logger.info('############################### 6. Call CallSIDBICurrentStatusAPI ((START)) ###############################');
            objSIDBILayer.CallSIDBICurrentStatusAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed).then(async (objRespSIDBIResponse) => {
              logger.info('get CallSIDBIStatusAPI Response saved in local database: ' + JSON.stringify(objRespSIDBIResponse));
              if (objRespSIDBIResponse.ErrorCode == "00")//Success-"00", Failure-"01"
              {
                let PlainString = {
                  "AadhaarNumber": CustomerJourneyDataParsed.AadhaarNo,
                  "PMSNumber": CustomerJourneyDataParsed.PMSNumber,
                  "JourneyID": CustomerJourneyDataParsed.JourneyID,
                  "CustomerID": CustomerJourneyDataParsed.CustomerID
                }
                logger.info("PlainString ", JSON.stringify(PlainString));
                objCommonFunction.Encrypt(JSON.stringify(PlainString)).then(async (EncString) => {
                  logger.info("EncString ", EncString);


                  Journeyresp = {
                    "ErrorCode": objRespSIDBIResponse.ErrorCode,
                    "ErrorMessage": objRespSIDBIResponse.ErrorMsg,
                    "EncString": EncString
                  }
                  logger.info('if JourneyResp: ' + JSON.stringify(Journeyresp));
                  logger.info('############################### 6. SUCCESS CallSIDBICurrentStatusAPI ((END)) ###############################');
                  res.json(Journeyresp);
                });
              }
              else if (objRespSIDBIResponse.ErrorCode == "01" || objRespSIDBIResponse.ErrorCode == "02") {
                Journeyresp = {
                  "ErrorCode": objRespSIDBIResponse.ErrorCode,
                  "ErrorMessage": objRespSIDBIResponse.ErrorMsg
                }
                logger.info('else if JourneyResp: ' + JSON.stringify(Journeyresp));
                logger.info('############################### 6. FAILURE CallSIDBICurrentStatusAPI ((END)) ###############################');
                res.json(Journeyresp);
              }
            });
          } else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "03") { //Loan Status Inquiry
            //RJ000013:Already NPA in said bank
            const APIURL = await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
            logger.info(`CustomerJourneyDataParsed AadhaarNo: ${CustomerJourneyDataParsed.AadhaarNo}`);
            objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
              logger.info(`Output getCityKYCInfoData: ${JSON.stringify(CityKYCStatusDetails)}`);
              if (CityKYCStatusDetails != null) {
                objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(PMSNumber, CustomerJourneyDataParsed.JourneyID, "RJ000013", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
                  logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI1: " + JSON.stringify(respObjUpdateSIDBI));
                  logger.info("Output ErrorCode: " + respObjUpdateSIDBI.ErrorCode);
                  logger.info("Output ErrorMsg: " + respObjUpdateSIDBI.ErrorMsg);
                  if (respObjUpdateSIDBI.ErrorCode == "00") {
                    objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber, CustomerJourneyDataParsed.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", 'Error01', respLoanStatusInquiry.ErrorMsg, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                      if (respObjUpdateSIDBI.StatusCode == "Y") {
                        objRejectedJourney = {
                          "ErrorCode": "01",
                          "ErrorMessage": "You have already availed a Business Loan/NPA with PNB. Please contact your PNB branch for further assistance"
                        }
                      } else {
                        objRejectedJourney = {
                          "ErrorCode": "01",
                          "ErrorMessage": respObjUpdateSIDBI.ErrorMsg
                        }
                      }
                      logger.info('############################### FAILURE CallLoanStatusAPIAPI API ((END)) ###############################');
                      logger.info("Response: " + JSON.stringify(objRejectedJourney));
                      return res.json(objRejectedJourney);
                    });
                  }
                  else {
                    objRejectedJourney = {
                      "ErrorCode": "01",
                      "ErrorMessage": "Unable to update rejected status at SIDBI"
                    }
                    logger.info('############################### FAILURE CallLoanStatusAPIAPI API ((END)) ###############################');
                    return res.json(objRejectedJourney);
                  }
                });
              }
            });
          }
          else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "02") { //Loan Status Inquiry          
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### FAILURE LoanStatusInquiryAPI API ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
          else {
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
        });
      });
    });
  });
});

app.post('/api/getMileStoneData', async (req, res) => {
  logger.info(``);
  logger.info(``);

  // logger.info('');logger.info('');
  // logger.info('*************************** getMilestoneData ***************************');
  logger.info(`*************************** getMilestoneData ***************************`);
  logger.info(``);
  const { EncPayload } = req.body;
 // logger.info(`EncReq: ${EncPayload}`);
 // logger.info('EncReq: ',EncPayload);


  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
   // const decResponse = JSON.parse(decPayload); //TESTING
 



 decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';

if (decPayload && typeof decPayload === 'string' && decPayload.trim() !== '') {
  try {
    const parsedResponse = JSON.parse(decPayload);
    
    logger.info(`Parsed Payload: ${JSON.stringify(parsedResponse)}`);
    logger.info(`decPayload AadhaarNo: ${parsedResponse.AadhaarNumber}`);
    logger.info(`decPayload PMSNumber: ${parsedResponse.PMSNumber}`);
    logger.info(`decPayload JourneyID: ${parsedResponse.JourneyID}`);
    logger.info(`decPayload CustomerID: ${parsedResponse.CustomerID}`);
      objGeneralOperation.getCustomerJourneyData(parsedResponse.PMSNumber).then(async (respCustomerJourney) => {
      logger.info(`respCustomerJourney ${respCustomerJourney}`);
      objResp = {
        "ErrorCode": "00",
        "ErrorMsg": "Journey milstone successfully retrieved.",
        "JourneyMileStone": JSON.parse(respCustomerJourney).JourneyMilestone,
        "JourneyID": parsedResponse.JourneyID
      }
      logger.info(`objResp: ${JSON.stringify(objResp)}`)
      return res.json(objResp);
    });
  } catch (error) {
    logger.error(`Failed to parse decPayload: ${error.message}`);
  }
} else {
  logger.error('Invalid or empty decPayload:', decPayload);
}

  
  });
});

app.post('/api/getPMSDetails', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('*****************Inside getPMSDetails *********************');
  const { EncPayload } = req.body;
  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
    decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';

    if (decPayload && typeof decPayload === 'string' && decPayload.trim() !== '') {
  try {
 

     const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);
    logger.info('***************** getPMSDetails ((START))*********************');

    objGeneralOperation.getPMSData(decResponse.PMSNumber, "ResumeJourney").then(async (PMSDetails) => {
      logger.info('PMS Details get data from local database: ' + JSON.stringify(PMSDetails));
      //logger.info('PMS Details get data from local database: '+JSON.parse(PMSDetails).APPLICANTNAME);
      if (JSON.parse(PMSDetails).APPLICANTNAME != null) {
        CustomResp = {
          "PMSNumber": decResponse.PMSNumber,
          "CustomerID": decResponse.CustomerID,
          "APPLICANTNAME": JSON.parse(PMSDetails).APPLICANTNAME,
          "MOBILENO": JSON.parse(PMSDetails).MOBILENO,
          "APPLICATIONNO": JSON.parse(PMSDetails).APPLICATIONNO,
          "APPLICATIONDATE": JSON.parse(PMSDetails).APPLICATIONDATE,
          "ACCOUNTNO": JSON.parse(PMSDetails).ACCOUNTNO,
          "STATENAME": JSON.parse(PMSDetails).STATENAME,
          "DISTRICTNAME": JSON.parse(PMSDetails).DISTRICTNAME,
          "ULBNAME": JSON.parse(PMSDetails).ULBNAME,
          "ULBLOCALBODYCODE": JSON.parse(PMSDetails).ULBLOCALBODYCODE,
          "TOTALLOAN": JSON.parse(PMSDetails).TOTALLOAN,
          "PICKEDUPDATE": JSON.parse(PMSDetails).PICKEDUPDATE,
          "PICKEDUPBANK": JSON.parse(PMSDetails).PICKEDUPBANK,
          "PICKEDUPBRANCH": JSON.parse(PMSDetails).PICKEDUPBRANCH,
          "PICKEDUPIFSC": JSON.parse(PMSDetails).PICKEDUPIFSC,
          "ACTIVITYNAME": JSON.parse(PMSDetails).ACTIVITYNAME,
          "LOANTERM": JSON.parse(PMSDetails).TRENCH,
        }
        //logger.info(JSON.stringify(CustomResp));
        logger.info('');
        logger.info('***************** getPMSDetails ((END))*********************');
        return res.json(JSON.stringify(CustomResp));
      }
    });
  } catch (error) {
    logger.error(`Failed to parse decPayload: ${error.message}`);
  }
} else {
  logger.error('Invalid or empty decPayload:', decPayload);
}
   
  });


});


app.post('/api/CustomerJourney', async (req, res) => {
  const { RespAadhaarNo, RespPMSNo, RespCustID } = req.body;
  logger.info('RespAadhaarNo: ' + RespAadhaarNo + ' RespPMSNo: ' + RespPMSNo + ' RespCustID: ' + RespCustID);
  logger.info("Hi Vishram, You are inside CustomerJourney");
  try {
    CustomerJourney(RespAadhaarNo, RespPMSNo, RespCustID, null, "Insert").then(async (respCustomerJourney) => {
      logger.info('Out CustomerJourney Result: ', JSON.stringify(respCustomerJourney));
      if (respCustomerJourney.ErrorCode == "00") {
        Journeyresp = {
          "ErrorCode": respCustomerJourney.ErrorCode,
          "ErrorMessage": respCustomerJourney.ErrorMsg
        }
        res.json(Journeyresp);
      }
    });
  }
  catch (error) {

  }
  finally {
    // Close the connection pool
    // await conn.close();
  }

});

app.post('/api/CallValueFirstSendSMSAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### Inside ValueFirstSendSMSAPI ((START)) ###############################');

  // logger.info(''); 
  // logger.info('');   
  // logger.info('############################### Inside ValueFirstSendSMSAPI ((START)) ###############################');
  const { EncPMSPayload, JourneyType } = req.body;
  objCommonFunction.Decrypt(EncPMSPayload).then(async (PMSNumber) => {
    objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => {
      //  logger.info('RespCustomerJourneyData '+JSON.stringify(RespCustomerJourneyData));
      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
      logger.info('############################### 7. Call ValueFirstToken API ((START)) ###############################');
    
      objGeneralOperation.getVFirstToken(PMSNumber, CustomerJourneyDataParsed.JourneyID).then(async (VFirstTokenDetails) => {
        logger.info('get VFirstToken Response saved in local database: ' + JSON.stringify(VFirstTokenDetails));
        //logger.info('get VFirstToken Response saved in local database: '+JSON.stringify(VFirstTokenDetails));                            
        if (VFirstTokenDetails.ErrorCode == "00") {
          logger.info('');
          logger.info('############################### 7. SUCCESS CallValueFirstToken API ((END)) ###############################')
          logger.info('');
          let VfisrtOTPReq = {
            "MobileNo": CustomerJourneyDataParsed.MobileNo,
            "Token": VFirstTokenDetails.VFirstToken
          }
          logger.info('');
          logger.info('############################### 8. Call SendVFirstOTP API ((START)) ###############################');
          logger.info('');
          objValueFirstDataLayer.SendVFirstOTP(PMSNumber, CustomerJourneyDataParsed.JourneyID, JSON.stringify(VfisrtOTPReq), JourneyType).then(async (VFirstOTPDetails) => {
            logger.info('Value First OTP send and save in local database: ' + JSON.stringify(VFirstOTPDetails));
           
            if (VFirstOTPDetails.ErrorCode == "00") { 
              let OTPresp = {
                "ErrorCode": VFirstOTPDetails.ErrorCode,
                "ErrorMessage": VFirstOTPDetails.ErrorMsg
              }
              logger.info('');
              logger.info('############################### 8. SUCCESS CallSendVFirstOTP API ((END)) ###############################');
              logger.info('');
              return res.json(OTPresp);
            }
            else {
              SIDBIResp = {
                "ErrorCode": "01",
                "ErrorMessage": "Currently we are not able to send SMS. Kindly try after sometime."
              }
              logger.info('');
              logger.info('############################### 8. FAILURE CallSendVFirstOTP API ((END)) ###############################');
              logger.info('');
              return res.json(SIDBIResp);
            }
          });
        }
        else {
          SIDBIResp = {
            "ErrorCode": "01",
            "ErrorMessage": "Error while VFirst Token Generation process."
          }
          logger.info('');
          logger.info('############################### 7. FAILURE CallValueFirstToken API ((END)) ###############################')
          logger.info('');
          return res.json(SIDBIResp);
        }
      });
    });
  });
});

app.post('/api/getCustomerDetails', async (req, res) => {
  logger.info(''); logger.info('');
  logger.info('*************************** getCustomerDetails ***************************');
  logger.info('');
  const { EncPayload } = req.body;
  logger.info('EncReq: ', EncPayload);


  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
  //const decResponse = JSON.parse(decPayload);  //TESTING
    // logger.info('EncPayLoad: ' + decResponse);
    // logger.info("decPayload AadhaarNo getCustomerDetails: ", decResponse.AadhaarNumber);
    // logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    // logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    // logger.info("decPayload CustomerID: ", decResponse.CustomerID);


  //  refKey=decResponse.AadhaarNumber;  //TESTING

  refKey='PNB131574606407';
 const decResponseCustomerID='O38612550'; //TESTING
	  /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    ------------------------------------------------- */
//     const aadhaar = decResponse?.AadhaarNumber;
//     logger.info("decPayload AadhaarNo getCustomerDetails:", { AadhaarNumber: decResponse.AadhaarNumber });
// logger.info("decPayload AadhaarNo getCustomerDetails:", { AadhaarNumber: aadhaar });

//     console.log('aadhaar: '+aadhaar);
//     logger.info("aadhar here : ", aadhaar);

// // 🔒 1. Block invalid input BEFORE calling UID API
// if (!aadhaar || typeof aadhaar !== 'string' || aadhaar.trim() === '') {
//   logger.error('AadhaarNumber is blank or missing');

//   return res.json({
//     ErrorCode: "01",
//     ErrorMessage: "Aadhaar number is mandatory",
//     Tranche: ""
//   });
// }

// // 🔒 2. Optional but STRONGLY recommended: format check
// if (!/^\d{12}$/.test(aadhaar.trim())) {
//   logger.error(`Invalid Aadhaar format: ${aadhaar}`);

//   return res.json({
//     ErrorCode: "01",
//     ErrorMessage: "Invalid Aadhaar number format",
//     Tranche: ""
//   });
// }

// // ✅ 3. Call UID API ONLY when valid
// const refKey = await getRefKeyOncebyUID(aadhaar.trim());

// if (!refKey) {
//   logger.error('refKey not generated');

//   return res.json({
//     ErrorCode: "01",
//     ErrorMessage: "Unable to validate Aadhaar details",
//     Tranche: ""
//   });
// }

    logger.info(`refKey resolved: ${refKey}`);

    objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
      logger.info('Return getCityKYCInfoData obj ' + JSON.stringify(CityKYCStatusDetails));
      // logger.info('Return getCityKYCInfoData CustomerID '+JSON.parse(CityKYCStatusDetails).CustomerID);

      objGeneralOperation.getCustomerDetails(decResponseCustomerID).then(async (CustomerIDDetails) => {
        logger.info('Return getCustomerDetails obj ' + JSON.stringify(CustomerIDDetails));
        // logger.info('Return getCustomerDetails CustomerID '+JSON.parse(CustomerIDDetails).CustomerID);
        // logger.info('Return getCustomerDetails CustomerID '+JSON.parse(CustomerIDDetails).PINCode);

        CustResp = {
          "CustomerID": JSON.parse(CustomerIDDetails).CustomerID,
          "CustomerName": JSON.parse(CustomerIDDetails).CustomerName,
          "MobileNo": JSON.parse(CustomerIDDetails).MobileNo,
          "DateOfBirth": JSON.parse(CustomerIDDetails).Cust_DOB,
          "Gender": JSON.parse(CustomerIDDetails).Gender,
          "Address": JSON.parse(CustomerIDDetails).CommAddr1 + JSON.parse(CustomerIDDetails).CommAddr2,
          "State": JSON.parse(CustomerIDDetails).CommState,
          "City": JSON.parse(CustomerIDDetails).CommCity,
          "PINCode": JSON.parse(CustomerIDDetails).CommPINCode,
          "AccountNo": JSON.parse(CityKYCStatusDetails).AccountNo,
          "BranchCode": JSON.parse(CityKYCStatusDetails).solid,
          "BranchName": JSON.parse(CustomerIDDetails).BRANCH,
        }
        logger.info('response for data exists and bind:' + JSON.stringify(CustResp));
        return res.json(CustResp);
      });

    });
  });
});

app.post('/api/updateCustomerJourney', async (req, res) => {
  const { EncPayload, JourneyMileStone } = req.body;
  logger.info('');
  logger.info('');
  logger.info('############################### Update Customer Journey Milestone START for ' + JourneyMileStone + ' ###############################');
  logger.info('@@@@@@ Enc Payload: ' + EncPayload + " JourneyMileStone: " + JourneyMileStone + ' @@@@@@');
  let JourneyMileStoneDesc = "";

  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
    //TESTING
   // const decResponse = JSON.parse(decPayload);
    // logger.info('EncPayLoad: ' + JSON.stringify(decResponse));
    // logger.info("decPayload AadhaarNo: " + decResponse.AadhaarNumber);
    // logger.info("decPayload PMSNumber: " + decResponse.PMSNumber);
    // logger.info("decPayload JourneyID: " + decResponse.JourneyID);
    // logger.info("decPayload CustomerID: " + decResponse.CustomerID);

const decResponsePMSNumber='PMS07200026209'

    objGeneralOperation.getCustomerJourneyData(decResponsePMSNumber).then(async (respCustomerJourney) => {
      let CurrentMileStone = JSON.parse(respCustomerJourney).JourneyMilestone;
      logger.info("CurrentMileStone " + CurrentMileStone);
      //Check in local database for customer record exist, if exists then get data to return response
      //Note: CurrentMileStone -1 would check here, that confirm journey next milestone would be JourneyMileStone (variable)
      if (JourneyMileStone == "CityKYCInfo" && CurrentMileStone == 101) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "CustomerInfo" && CurrentMileStone == 102) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "CustomerDataConsent" && CurrentMileStone == 103) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "PMSDataConsent" && CurrentMileStone == 104) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "KFSConsent" && CurrentMileStone == 105) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "SanctionLetterConsent" && CurrentMileStone == 106) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "LoanAccountOpeningConsent" && CurrentMileStone == 107) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else if (JourneyMileStone == "QRCodeConsent" && CurrentMileStone == 108) {
        JourneyMileStoneDesc = CurrentMileStone;
      }
      else {
        JourneyMileStoneDesc = null;
        logger.info('*******************************ELSE PART Customer Journey Milestone********************************');
        logger.info('This segment works only when, milestone crossed current stage');
      }
      if (JourneyMileStoneDesc != null) {
        objGeneralOperation.getMilestoneFromMilestoneMaster(JourneyMileStone).then(async (objRespMilestone) => {
          if (objRespMilestone != null) {
            const MilestoneParse = JSON.parse(objRespMilestone);
            logger.info('JourneyMileStoneDesc not null' + JSON.stringify(MilestoneParse));
            //TESTING
           
           const decResponseJourneyID='PNB_SVND_000020210';
            objGeneralOperation.CustomerJourneyUpdate(decResponsePMSNumber, decResponseJourneyID, MilestoneParse.MilestoneCode, MilestoneParse.MilestoneDesc, null, null, null, null, null, null, "Update").then(async (objRespCustomerJourney) => {
              logger.info('Output CustomerJourneyUpdate: ' + JSON.stringify(objRespCustomerJourney));
              if (objRespCustomerJourney.ErrorCode == "00") {
                Journeyresp = {
                  "ErrorCode": objRespCustomerJourney.ErrorCode,
                  "ErrorMessage": objRespCustomerJourney.ErrorMsg
                }
                logger.info('############################### Update Customer Journey Milestone START ###############################');
                res.json(Journeyresp);
              }
            });
          }
        });
      }
      else {
        Journeyresp = {
          "ErrorCode": "00",
          "ErrorMessage": "Customer Journey already passed " + JourneyMileStone + " milestone"
        }
        logger.info(JSON.stringify(Journeyresp));
        logger.info('############################### Update Customer Journey Milestone END ###############################');
        res.json(Journeyresp);
      }
    });
  });
});

app.post('/api/CBSBalanceEnquiryAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('****************************Call CBSBalanceEnquiryAPI (Start)****************************');
 const { EncPayLoad } = req.body;
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
    decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';

    if (decPayload && typeof decPayload === 'string' && decPayload.trim() !== '') {
  try {
     const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);
    logger.info('***************** getPMSDetails ((START))*********************');
 objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (RespCustomerJourneyData) => {
      logger.info('RespCustomerJourneyData ' + JSON.stringify(RespCustomerJourneyData));
      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
      objGeneralOperation.getPMSData(decResponse.PMSNumber, "ResumeJourney").then(async (PMSDetails) => {
        // logger.info('Out PMSDetails: ',PMSDetails);
        let parsePMSDetails = JSON.parse(PMSDetails);
        if (PMSDetails.ErrorCode != "01") {
          logger.info('Trench' + parsePMSDetails.TRENCH);
          logger.info('isStampChargeCollected' + CustomerJourneyDataParsed.isStampChargeCollected);
          logger.info('JourneyMileStone' + CustomerJourneyDataParsed.JourneyMilestone);
          if ((parsePMSDetails.TRENCH == 1 || parsePMSDetails.TRENCH == 2) && CustomerJourneyDataParsed.isStampChargeCollected == false && CustomerJourneyDataParsed.JourneyMilestone >= 106) {
            logger.info('############################this is Tranche 1 or 2 with non collected Stamp charge #####################################');
            logger.info('****************************Call getCityKYCInfoData (START)****************************');
            objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityInfoKYCStatusDetails) => {
              logger.info('Output CityKYCInfo ' + JSON.stringify(CityInfoKYCStatusDetails));
              // logger.info('isCityKYCStatusExists get data from local database: '+JSON.parse(CityInfoKYCStatusDetails).AccountNo);
              if (JSON.parse(CityInfoKYCStatusDetails).AccountNo != null) {
                logger.info('****************************Call getCityKYCInfoData (END)****************************');
                logger.info('');
                logger.info('');
                logger.info('****************************Call CBSToken (START)****************************');
                objGeneralOperation.CBSToken(decResponse.PMSNumber, decResponse.JourneyID).then(async (TokenDetails) => {
                  if (TokenDetails.ErrorCode == "00") {
                    logger.info('****************************Call CBSToken (END)****************************');
                    let BalanceInquiryAPIReq = {
                      "AccountNo": JSON.parse(CityInfoKYCStatusDetails).AccountNo,
                      "Access_Token": TokenDetails.AccessToken
                    }
                    logger.info('****************************Call getPMSData (END)****************************');
                    logger.info('');
                    logger.info('');
                    logger.info('****************************Call BalanceInquiryAPI (START)****************************');

                    objCBSLayer.BalanceInquiryAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.stringify(BalanceInquiryAPIReq), parsePMSDetails).then(async (BalanceInquiryResp) => {
                      logger.info('Output Balance Inquiry: ' + JSON.stringify(BalanceInquiryResp));
                    
                     // if (BalanceInquiryResp.ErrorCode == "00") { //TESTING
                        if (BalanceInquiryResp.ErrorCode != "00") {
                        if (BalanceInquiryResp.EffectiveAvlAmt < 10) {
                          Journeyresp = {
                            "ErrorCode": "01",
                            "ErrorMessage": "Please maintain minimum Rs. 50 balance in your account to proceed further."
                          }
                          return res.json(Journeyresp);
                        }
                        else {
                          logger.info('############################### CallCBSChargeCollection API (START) ###############################');
                          objCBSLayer.CBSChargeCollectionAPI(decResponse.PMSNumber, decResponse.JourneyID, "StampCharge", TokenDetails.AccessToken, CityInfoKYCStatusDetails).then(async (respChargeCollection) => {
                            logger.info('City CBSChargeCollectionAPI saved in local database ErrorCode: ' + JSON.stringify(respChargeCollection));
                            // if (BalanceInquiryResp.ErrorCode == "00") { //TESTING
                            if (respChargeCollection.ErrorCode != "00") {
                              Journeyresp = {
                                "ErrorCode": respChargeCollection.ErrorCode,
                                "ErrorMessage": respChargeCollection.ErrorMsg
                              }
                              logger.info(JSON.stringify(Journeyresp));
                              logger.info('############################### SUCCESS CBSChargeCollection API END###############################');
                              return res.json(Journeyresp);
                            }
                            else {
                              Journeyresp = {
                                "ErrorCode": respChargeCollection.ErrorCode,
                                "ErrorMessage": respChargeCollection.ErrorMsg
                              }
                              logger.info(JSON.stringify(Journeyresp));
                              logger.info('############################### FAILURE CBSChargeCollection API (END) ###############################');
                              return res.json(Journeyresp);
                            }
                          });
                        }
                      }
                      else {
                        Journeyresp = {
                          "ErrorCode": "01",
                          "ErrorMessage": BalanceInquiryResp.ErrorMsg
                        }
                      }
                    });

                  }
                });
              }
            });
          }
          else if (parsePMSDetails.TRENCH == 3 && CustomerJourneyDataParsed.isCIBILChargeCollected == false && CustomerJourneyDataParsed.JourneyMilestone < 106) {
            logger.info('****************************Call getCityKYCInfoData (START)****************************');
            objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityInfoKYCStatusDetails) => {
              // logger.info('isCityKYCStatusExists get data from local database: '+CityInfoKYCStatusDetails);
              // logger.info('isCityKYCStatusExists get data from local database: '+JSON.parse(CityInfoKYCStatusDetails).AccountNo);
              if (JSON.parse(CityInfoKYCStatusDetails).AccountNo != null) {
                logger.info('****************************Call getCityKYCInfoData (END)****************************');
                logger.info('');
                logger.info('');
                logger.info('****************************Call CBSToken (START)****************************');
                objGeneralOperation.CBSToken(decResponse.PMSNumber, decResponse.JourneyID).then(async (TokenDetails) => {
                  if (TokenDetails.ErrorCode == "00") {
                    logger.info('****************************Call CBSToken (END)****************************');
                    let BalanceInquiryAPIReq = {
                      "AccountNo": JSON.parse(CityInfoKYCStatusDetails).AccountNo,
                      "Access_Token": TokenDetails.AccessToken
                    }
                    logger.info('****************************Call getPMSData (END)****************************');
                    logger.info('');
                    logger.info('');
                    logger.info('****************************Call BalanceInquiryAPI (START)****************************');

                    objCBSLayer.BalanceInquiryAPI(decResponse.PMSNumber, JSON.stringify(BalanceInquiryAPIReq), parsePMSDetails).then(async (BalanceInquiryResp) => {
                      logger.info('Output BalanceInquiryAPI : ' + JSON.stringify(BalanceInquiryResp));
                      if (BalanceInquiryResp.ErrorCode == "00") {
                        if (BalanceInquiryResp.EffectiveAvlAmt < 10) {
                          Journeyresp = {
                            "ErrorCode": "01",
                            "ErrorMessage": "Please maintain min Rs. 150 balance in your account to proceed further."
                          }
                          return res.json(Journeyresp);
                        }
                        else {
                          logger.info('############################### CallCBSChargeCollection API (START) ###############################');
                          objCBSLayer.CBSChargeCollectionAPI(PMSNumber, "CIBILCharge", TokenDetails.AccessToken, CityInfoKYCStatusDetails).then(async (respChargeCollection) => {
                            logger.info('Output CBSChargeCollectionAPI ' + JSON.stringify(respChargeCollection));
                            if (respChargeCollection.ErrorCode == "00") {
                              Journeyresp = {
                                "ErrorCode": respChargeCollection.ErrorCode,
                                "ErrorMessage": respChargeCollection.ErrorMsg
                              }
                              logger.info(JSON.stringify(Journeyresp));
                              logger.info('############################### SUCCESS CBSChargeCollection API END###############################');
                              return res.json(Journeyresp);
                            }
                            else {
                              Journeyresp = {
                                "ErrorCode": respChargeCollection.ErrorCode,
                                "ErrorMessage": respChargeCollection.ErrorMsg
                              }
                              logger.info(JSON.stringify(Journeyresp));
                              logger.info('############################### FAILURE CBSChargeCollection API (END) ###############################');
                              return res.json(Journeyresp);
                            }
                          });
                        }
                      }
                      else {
                        Journeyresp = {
                          "ErrorCode": "01",
                          "ErrorMessage": BalanceInquiryResp.ErrorMsg
                        }
                      }
                    });
                  }
                });
              }
            });
          }
          else {
            logger.info('yah aa gaya')
            Journeyresp = {
              "ErrorCode": "00",
              // "ErrorMessage": "Charge already debited for Tranche " + parsePMSDetails.TRENCH
            }
            logger.info("else JourneyResp: " + JSON.stringify(Journeyresp));
            logger.info('############################### Call CBSBalanceEnquiryAPI (End) ###############################');
            res.json(Journeyresp);
          }
        }
      });
    });
   
  } catch (error) {
    logger.error(`Failed to parse decPayload: ${error.message}`);
  }
} else {
  logger.error('Invalid or empty decPayload:', decPayload);
}
   
  });
 
});


app.post('/api/CallConsumerCIBILAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  Call ConsumerCIBILAPI ((START))**************************');
  const { EncPayload, JourneyType } = req.body;

  logger.info("JourneyType: " + JourneyType)
  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
   decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);


    refKey=decResponse.AadhaarNumber;
      /* -------------------------------------------------
       1️⃣ GET refKey (SYNC & SAFE)
    ------------------------------------------------- */
    // const refKey = await getRefKeyOncebyUID(decResponse.AadhaarNumber);
    // if (!refKey) {
    //   logger.error('refKey not generated');
    //   return res.json({
    //     ErrorCode: "01",
    //     ErrorMessage: "Unable to validate Aadhaar details",
    //     Tranche: ""
    //   });
    // }
    logger.info(`refKey resolved: ${refKey}`);
    
    logger.info("################# Call getConsumerCIBIL (START) ###################")
    objGeneralOperation.getConsumerCIBIL(decResponse.PMSNumber, decResponse.JourneyID).then(async (ConsumerCIBILDetails) => {
      // logger.info('get data if cibil already in databse: '+JSON.stringify(ConsumerCIBILDetails));
      objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (objCustomerJourneyData) => {
        logger.info('isCICCheckPassed ' + JSON.parse(objCustomerJourneyData).isCICCheckPassed);
        logger.info('CIC JourneyMileStone ' + JSON.parse(objCustomerJourneyData).JourneyMilestone);

        if (ConsumerCIBILDetails == null || (JSON.parse(objCustomerJourneyData).isCICCheckPassed == null))//True
        {
          logger.info('CIBIL is null');

          logger.info("#################Call getConsumerCIBIL (END) ###################");
          logger.info("################# Call getCustomerDetails (START) ###################");
          objGeneralOperation.getCustomerDetails(decResponse.CustomerID).then(async (CustomerDetails) => {
            // logger.info('Customer Details get data from local database: '+CustomerDetails);
            // logger.info('Customer Details get data from local database: '+JSON.parse(CustomerDetails).CustomerName);
            if (JSON.parse(CustomerDetails).CustomerName != null) {
              logger.info("#################Call getCustomerDetails (END) ###################")
              logger.info("################# Call getPMSData (START) ###################")
              objGeneralOperation.getPMSData(decResponse.PMSNumber, "ResumeJourney").then(async (PMSDetails) => {
                // logger.info('Out PMSDetails: ', PMSDetails);         
                if (PMSDetails.ErrorCode != "01") {
                  logger.info("#################Call getPMSData (END) ###################")
                  logger.info(''); logger.info('');
                  logger.info('##########Generate CICApplicantJSON Object###########');
                  objCIBILDataLayer.funCIBILRequestXML(JSON.parse(CustomerDetails), JSON.parse(PMSDetails), JSON.parse(objCustomerJourneyData)).then(async (CICXMLRequest) => {
                    logger.info('Output funCIBILRequestXML ', CICXMLRequest);
                    //Insert CIBIL Request to Database
                    logger.info("#################Call CIBILData_Insert (START) ###################")
                    if (CICXMLRequest != null) {
                      objCIBILDataLayer.CIBILData_Insert(CICXMLRequest, decResponse.PMSNumber, decResponse.JourneyID).then(async (CIBILReqInsert) => {
                        logger.info("CIBIL Request insert in database" + JSON.stringify(CIBILReqInsert));
                        if (CIBILReqInsert.ErrorCode == "00") {
                          logger.info("Success CIBIL request in database");
                          //Call CIBIL
                          logger.info(''); logger.info('');
                          logger.info("#################Call PullConsumerCibilAPI (START) ###################")
                          objCIBILDataLayer.PullConsumerCibilAPI(decResponse.PMSNumber, decResponse.JourneyID, CICXMLRequest,).then(async (PullConsumerCibilResponse) => {
                            logger.info("Output PullConsumerCibilAPI: " + JSON.stringify(PullConsumerCibilResponse));
                            //  logger.info("Return from CIBIL API ErrorCode: "+ PullConsumerCibilResponse.ErrorCode);
                            if (PullConsumerCibilResponse.ErrorCode == "00") {
                              objGeneralOperation.getConsumerCIBIL(decResponse.PMSNumber, decResponse.JourneyID).then(async (ConsumerCIBILDetails) => {
                                logger.info("ConsumerCIBILDetails: " + JSON.stringify(ConsumerCIBILDetails));
                                objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                                  logger.info("Output PullCIBILDocumentAPI: " + JSON.stringify(PullCibilDocResponse));
                                  logger.info("Output PullCIBILDocumentAPI ErrorCode: " + PullCibilDocResponse.ErrorCode);
                                  if (PullCibilDocResponse.ErrorCode == "00") {
                                    //update CIC Check status in 
                                    logger.info('PullConsumerCibilResponse.ErrorMsg: '+PullConsumerCibilResponse.ErrorMsg);
                                    objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, true, 'PullConsumerCibilResponse.ErrorMsg').then(async (UpdateCICPassFlag) => {
                                      logger.info("00 Output UpdateCICPassFlag: " + JSON.stringify(PullCibilDocResponse));
                                      logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                                      CIBILResp = {
                                        "ErrorCode": PullCibilDocResponse.ErrorCode,
                                        "ErrorMessage": "Consumer CIBIL report successfully picked."
                                      }

                                      return res.json(CIBILResp);
                                    });
                                  }
                                  else {
                                    logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                                    CIBILResp = {
                                      "ErrorCode": "01",
                                      "ErrorMessage": PullCibilDocResponse.ErrorMsg
                                    }

                                    return res.json(CIBILResp);
                                  }
                                });
                              });


                              // CIBILResp={
                              //   "ErrorCode":PullConsumerCibilResponse.ErrorCode,
                              //   "ErrorMessage":"CIBIL Successfully pulled"                                
                              //   }
                              //   return res.json(CIBILResp); 
                            }
                            else if (PullConsumerCibilResponse.ErrorCode == "01") {
                              CIBILResp = {
                                "ErrorCode": PullConsumerCibilResponse.ErrorCode,
                                "ErrorMessage": "Error while getting CIBIL report"
                              }
                              return res.json(CIBILResp);
                            }
                            else if (PullConsumerCibilResponse.ErrorCode == "02") {//Adverse parameter in CIBIL like NPA,any Fault
                              
                              //Update Rejected status in local Database and SIDBI portal
                              objCIBILDataLayer.CIBILData_Update(decResponse.PMSNumber, decResponse.JourneyID, null, null, null, null, null, null, null, "ErrorCode", null, PullConsumerCibilResponse.ErrorCode, PullConsumerCibilResponse.ErrorMsg).then(async (CIBILReqUpdate) => {
                                if (CIBILReqUpdate != null) {
                                  logger.info('Update CIBIL Table with ErrorCode and Error Message for error code 2');
                                  objGeneralOperation.getConsumerCIBIL(decResponse.PMSNumber, decResponse.JourneyID).then(async (ConsumerCIBILDetails) => {
                                    logger.info("ConsumerCIBILDetails: " + JSON.stringify(ConsumerCIBILDetails));
                                    objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                                      logger.info("Return from CIBIL API Call: " + JSON.stringify(PullCibilDocResponse));
                                      if (PullCibilDocResponse.ErrorCode == "00") {
                                        const APIURL = await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
                                        logger.info("SIDBI Rejection API URL: " + APIURL);
                                        objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
                                          logger.info("Output getCityKYCInfoData: " + JSON.stringify(CityKYCStatusDetails));
                                          if (CityKYCStatusDetails != null) {
                                            //RJ000012:Credit rating is adverse
                                            logger.info("Swati 7777777777777777777777777777777");
                                            objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000012", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
                                              logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI2: " + JSON.stringify(respObjUpdateSIDBI));
                                              if (respObjUpdateSIDBI.ErrorCode == "00") {
                                                objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objCustomerJourneyData).LoanTranche, "Rejected", 'Error03', PullConsumerCibilResponse.ErrorMsg, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                                                  logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney:  " + JSON.stringify(respUpdateJourneyStatus));
                                                  objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false, PullConsumerCibilResponse.ErrorMsg).then(async (UpdateCICPassFlag) => {
                                                    logger.info("02 Output UpdateCICPassFlag: " + JSON.stringify(UpdateCICPassFlag));
                                                    if (respObjUpdateSIDBI.StatusCode == "N") {
                                                      objRejectedJourney = {
                                                        "ErrorCode": "01",
                                                        "ErrorMessage": "Sorry! Your loan application has been rejected due to Presence of Delinquent accounts in Credit Information Report."
                                                      }
                                                    } else {
                                                      objRejectedJourney = {
                                                        "ErrorCode": "01",
                                                        "ErrorMessage": respObjUpdateSIDBI.ErrorMsg
                                                      }
                                                    }
                                                    logger.info('Response control to UI ' + JSON.stringify(objRejectedJourney));
                                                    return res.json(objRejectedJourney);
                                               
                                                  });
                                                });
                                              }
                                              else {
                                                CIBILResp = {
                                                  "ErrorCode": "01",
                                                  "ErrorMessage": "Error to update rejected status at SIDBI"
                                                }
                                                return res.json(CIBILResp);
                                              }
                                            });
                                          }
                                        });



                                      }
                                      else {
                                        logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                                        CIBILResp = {
                                          "ErrorCode": "01",
                                          "ErrorMessage": PullCibilDocResponse.ErrorMsg
                                        }
                                        return res.json(CIBILResp);
                                      }
                                    });
                                  });
                                }
                              });
                            }
                            else if (PullConsumerCibilResponse.ErrorCode == "03")//Only Business loan
                            {
                              objCIBILDataLayer.CIBILData_Update(decResponse.PMSNumber, decResponse.JourneyID, null, null, null, null, null, null, null, "ErrorCode", null, PullConsumerCibilResponse.ErrorCode, PullConsumerCibilResponse.ErrorMsg).then(async (CIBILReqUpdate) => {
                                if (CIBILReqUpdate != null) {
                                  logger.info('Update CIBIL Table with ErrorCode and Error Message for error code 3');
                                  objGeneralOperation.getConsumerCIBIL(decResponse.PMSNumber, decResponse.JourneyID).then(async (ConsumerCIBILDetails) => {
                                    logger.info("ConsumerCIBILDetails: " + JSON.stringify(ConsumerCIBILDetails));

                                    objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                                      logger.info("Return from CIBIL API Call: " + JSON.stringify(PullCibilDocResponse));
                                      logger.info("Return from CIBIL API ErrorCode: " + PullCibilDocResponse.ErrorCode);
                                      if (PullCibilDocResponse.ErrorCode == "00") {
                                        if (JourneyType == "BranchJourney") {
                                          objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false, PullConsumerCibilResponse.ErrorMsg).then(async (UpdateCICPassFlag) => {
                                            logger.info("03 Output UpdateCICPassFlag: " + JSON.stringify(PullCibilDocResponse));
                                            CIBILResp = {
                                              "ErrorCode": "03",
                                              "ErrorMessage": "Customer having active Business loan as per CIC. Please download the CIC report and verify it as per the bank’s extant guidelines."
                                            }
                                            logger.info("Cibil Error Code 03 with : " + JSON.stringify(CIBILResp));
                                            return res.json(CIBILResp);
                                          });
                                        }
                                        else {
                                          //Update Rejected status in local Database
                                          objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objCustomerJourneyData).LoanTranche, "Rejected", 'Error04', PullConsumerCibilResponse.ErrorMsg).then(async (respUpdateJourneyStatus) => {
                                            logger.info("Return from  updated response in Database: " + JSON.stringify(respUpdateJourneyStatus));

                                            objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false).then(async (UpdateCICPassFlag) => {
                                              logger.info("Output UpdateCICPassFlag: " + JSON.stringify(PullCibilDocResponse));
                                              CIBILResp = {
                                                "ErrorCode": PullConsumerCibilResponse.ErrorCode,
                                                "ErrorMessage": "Sorry, unable to proceed due to existing business loan. Please contact your branch for further assistance."
                                              }
                                              return res.json(CIBILResp);
                                            });
                                          });
                                        }
                                        //  logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                                        //  CIBILResp={
                                        //    "ErrorCode":PullCibilDocResponse.ErrorCode,
                                        //    "ErrorMessage":PullCibilDocResponse.ErrorMsg                               
                                        //    }

                                        //    return res.json(CIBILResp); 
                                      }
                                      else {
                                        logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                                        CIBILResp = {
                                          "ErrorCode": PullCibilDocResponse.ErrorCode,
                                          "ErrorMessage": PullCibilDocResponse.ErrorMsg
                                        }
                                        return res.json(CIBILResp);
                                      }
                                    });
                                  });
                                }
                              });
                            }
                          });

                        }
                        else {
                          //Error to insert CIBIL Request in Database
                        }
                      });
                    }
                    else {
                      logger.info("Error While creating cibil XML request");
                      CIBILResp = {
                        "ErrorCode": "01",
                        "ErrorMessage": "Error while fecthing CIC report "
                      }
                      return res.json(CIBILResp);
                    }

                  });
                }
                else {
                  //PMS Else Part
                }
              });
            }
            else {
              //Customer Details Else Part
            }
          });
        }
        else if (ConsumerCIBILDetails !== null && JSON.parse(objCustomerJourneyData).JourneyMilestone == 104)//True
        {
          logger.info('CIBIL not null and milestone ' + JSON.parse(objCustomerJourneyData).JourneyMilestone);
          if (JourneyType == "BranchJourney") {
            logger.info('BranchJourney CIBIL not null but Doc is null');
            logger.info('ErrorCode ' + JSON.parse(ConsumerCIBILDetails).ErrorCode);
            if (JSON.parse(ConsumerCIBILDetails).ErrorCode == "01") {
              objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                logger.info("Outp PullCIBILDocumentAPI: " + JSON.stringify(PullCibilDocResponse));
                if (PullCibilDocResponse.ErrorCode == "00") {
                  CIBILResp = {
                    "ErrorCode": "00",
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }
                  logger.info('BranchJourney CIBIL not null but Doc is null ' + JSON.stringify(CIBILResp));
                  return res.json(CIBILResp);
                }
                else {
                  logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                  CIBILResp = {
                    "ErrorCode": "01",
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }

                  return res.json(CIBILResp);
                }
              });
            }
            else if (JSON.parse(ConsumerCIBILDetails).ErrorCode == "02") {
              logger.info('Any Error in CIC with error code 02');
              objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                logger.info("Output PullCIBILDocumentAPI: " + JSON.stringify(PullCibilDocResponse));
                if (PullCibilDocResponse.ErrorCode == "00") {
                  const APIURL = await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
                  objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
                    if (CityKYCStatusDetails != null) {
                      //RJ000012:Credit rating is adverse
                      objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000012", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
                        logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI3: " + JSON.stringify(respObjUpdateSIDBI));
                        if (respObjUpdateSIDBI.ErrorCode == "00") {
                          objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objCustomerJourneyData).LoanTranche, "Rejected", 'Error03', JSON.parse(ConsumerCIBILDetails).ErrorMessage, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                            logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney:  " + JSON.stringify(respUpdateJourneyStatus));
                            objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false, JSON.parse(ConsumerCIBILDetails).ErrorMessage).then(async (UpdateCICPassFlag) => {
                              logger.info("02 Output UpdateCICPassFlag: " + JSON.stringify(UpdateCICPassFlag));
                              if (respObjUpdateSIDBI.StatusCode == "N") {
                                objRejectedJourney = {
                                  "ErrorCode": "01",
                                  "ErrorMessage": "Sorry! Your loan application has been rejected due to presence of delinquent accounts in Credit Information Report."
                                }
                              } else {
                                objRejectedJourney = {
                                  "ErrorCode": "01",
                                  "ErrorMessage": respObjUpdateSIDBI.ErrorMsg
                                }
                              }
                              logger.info('Response control to UI ' + JSON.stringify(objRejectedJourney));
                              return res.json(objRejectedJourney);
                            });
                          });
                        }
                        else {
                          CIBILResp = {
                            "ErrorCode": "01",
                            "ErrorMessage": "Error to update rejected status at SIDBI"
                          }
                          logger.info('Response control to UI ' + JSON.stringify(CIBILResp));
                          return res.json(CIBILResp);
                        }
                      });
                    }
                  });

                }
                else {
                  logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                  CIBILResp = {
                    "ErrorCode": "01",
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }

                  return res.json(CIBILResp);
                }
              });
            }
            else if (JSON.parse(ConsumerCIBILDetails).ErrorCode == "03") {
              logger.info('Any Error in CIC with error code 03');
              logger.info('BranchJourney with error msg ' + JSON.parse(ConsumerCIBILDetails).ErrorMessage);
              objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                logger.info("Output PullCIBILDocumentAPI: " + JSON.stringify(PullCibilDocResponse));
                if (PullCibilDocResponse.ErrorCode == "00") {
                  objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false, JSON.parse(ConsumerCIBILDetails).ErrorMessage).then(async (UpdateCICPassFlag) => {
                    logger.info("03 Output UpdateCICPassFlag: " + JSON.stringify(UpdateCICPassFlag));
                    CIBILResp = {
                      "ErrorCode": "03",
                      "ErrorMessage": "Customer having active Business loan as per CIC. Please download the CIC report and verify it as per the bank’s extant guidelines."
                    }
                    logger.info("Cibil Error Code 03 with : " + JSON.stringify(CIBILResp));
                    return res.json(CIBILResp);
                  });
                }
                else {
                  logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                  CIBILResp = {
                    "ErrorCode": PullCibilDocResponse.ErrorCode,
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }
                  return res.json(CIBILResp);
                }
              });
            }
            else {
              logger.info("Consumer success response already received from CIBIL");
              CIBILResp = {
                "ErrorCode": "00",
                "ErrorMessage": "Consumer success response already received from CIBIL"
              }
              return res.json(CIBILResp);
            }
          }
          else {
            logger.info('Here for Customer Journey');
            if (JSON.parse(ConsumerCIBILDetails).ErrorCode == "01") {
              objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                logger.info("Return from CIBIL API Call: " + JSON.stringify(PullCibilDocResponse));
                logger.info("Return from CIBIL API ErrorCode: " + PullCibilDocResponse.ErrorCode);
                if (PullCibilDocResponse.ErrorCode == "00") {
                  CIBILResp = {
                    "ErrorCode": "00",
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }
                  return res.json(CIBILResp);
                }
                else {
                  logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                  CIBILResp = {
                    "ErrorCode": "01",
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }

                  return res.json(CIBILResp);
                }
              });
            }
            else if (JSON.parse(ConsumerCIBILDetails).ErrorCode == "02") {
              objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                logger.info("Output PullCIBILDocumentAPI: " + JSON.stringify(PullCibilDocResponse));
                if (PullCibilDocResponse.ErrorCode == "00") {
                  const APIURL = await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
                  objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
                    if (CityKYCStatusDetails != null) {
                      //RJ000012:Credit rating is adverse                    
                      objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000012", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
                        logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI4: " + JSON.stringify(respObjUpdateSIDBI));
                        if (respObjUpdateSIDBI.ErrorCode == "00") {
                          objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objCustomerJourneyData).LoanTranche, "Rejected", 'Error03', PullConsumerCibilResponse.ErrorMsg, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                            logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney:  " + JSON.stringify(respUpdateJourneyStatus));
                            objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false, PullConsumerCibilResponse.ErrorMsg).then(async (UpdateCICPassFlag) => {
                              logger.info("02 Output UpdateCICPassFlag: " + JSON.stringify(UpdateCICPassFlag));
                              if (respObjUpdateSIDBI.StatusCode == "N") {
                                objRejectedJourney = {
                                  "ErrorCode": "01",
                                  "ErrorMessage": "Sorry! Your loan application has been rejected due to Presence of Delinquent accounts in Credit Information Report."
                                }
                              } else {
                                objRejectedJourney = {
                                  "ErrorCode": "01",
                                  "ErrorMessage": respObjUpdateSIDBI.ErrorMsg
                                }
                              }
                              logger.info('Response control to UI ' + JSON.stringify(CIBILResp));
                              return res.json(CIBILResp);
                            });
                          });
                        }
                        else {
                          CIBILResp = {
                            "ErrorCode": "01",
                            "ErrorMessage": "Error to update rejected status at SIDBI"
                          }
                          logger.info('Response control to UI ' + JSON.stringify(CIBILResp));
                          return res.json(CIBILResp);
                        }
                      });
                    }
                  });


                }
                else {
                  logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                  CIBILResp = {
                    "ErrorCode": "01",
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }

                  return res.json(CIBILResp);
                }
              });
            }
            else if (JSON.parse(ConsumerCIBILDetails).ErrorCode == "03") {
              objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
                logger.info("Return from CIBIL API Call: " + JSON.stringify(PullCibilDocResponse));
                logger.info("Return from CIBIL API ErrorCode: " + PullCibilDocResponse.ErrorCode);
                if (PullCibilDocResponse.ErrorCode == "00") {
                  //Update Rejected status in local Database
                  objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, "Rejected", "Customer Journey rejected due to any active business loan as per CIC").then(async (respUpdateJourneyStatus) => {
                    logger.info("Return from  updated response in Database: " + JSON.stringify(respUpdateJourneyStatus));

                    objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false, JSON.parse(ConsumerCIBILDetails).ErrorMessage).then(async (UpdateCICPassFlag) => {
                      logger.info("Output UpdateCICPassFlag: " + JSON.stringify(PullCibilDocResponse));
                      CIBILResp = {
                        "ErrorCode": PullConsumerCibilResponse.ErrorCode,
                        "ErrorMessage": "Sorry, unable to proceed due to existing business loan. Please contact your branch for further assistance."
                      }
                      return res.json(CIBILResp);
                    });
                  });
                }
                else {
                  logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
                  CIBILResp = {
                    "ErrorCode": PullCibilDocResponse.ErrorCode,
                    "ErrorMessage": PullCibilDocResponse.ErrorMsg
                  }
                  return res.json(CIBILResp);
                }
              });
            }
            else {
              logger.info("Consumer success response already received from CIBIL");
              CIBILResp = {
                "ErrorCode": "00",
                "ErrorMessage": "Consumer success response already received from CIBIL"
              }
              return res.json(CIBILResp);
            }
          }
        }
        else {
          logger.info("Consumer success response already received from CIBIL");
          CIBILResp = {
            "ErrorCode": "00",
            "ErrorMessage": "Consumer success response already received from CIBIL"
          }
          return res.json(CIBILResp);
        }
      });
    });
  });
});

app.post('/api/CallCIBILDocumentPullAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  CallCIBILDocumentPullAPI ((START))**************************');
  const { EncPayload } = req.body;

  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
     decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);

    objGeneralOperation.getConsumerCIBIL(decResponse.PMSNumber, decResponse.JourneyID).then(async (ConsumerCIBILDetails) => {
      logger.info("ConsumerCIBILDetails: " + JSON.stringify(ConsumerCIBILDetails));
      logger.info(JSON.stringify(ConsumerCIBILDetails));
      logger.info(JSON.parse(ConsumerCIBILDetails).ApplicationId);
      if (ConsumerCIBILDetails == null || (JSON.parse(ConsumerCIBILDetails).DocumentAPIRespStatus != "Success")) {
        logger.info("Failed CIBIL request in database");
        objCIBILDataLayer.PullCIBILDocumentAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(ConsumerCIBILDetails).ApplicationId, JSON.parse(ConsumerCIBILDetails).DocumentId).then(async (PullCibilDocResponse) => {
          logger.info("Return from CIBIL API Call: " + JSON.stringify(PullCibilDocResponse));
          logger.info("Return from CIBIL API ErrorCode: " + PullCibilDocResponse.ErrorCode);
          if (PullCibilDocResponse.ErrorCode == "00") {
            logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
            CIBILResp = {
              "ErrorCode": PullCibilDocResponse.ErrorCode,
              "ErrorMessage": "CIBIL Successfully Picked"
            }

            return res.json(CIBILResp);
          }
          else {
            logger.info('###############################Called getCIBILDocumentPullAPI (END) ###############################');
            CIBILResp = {
              "ErrorCode": "01",
              "ErrorMessage": PullCibilDocResponse.ErrorMsg
            }

            return res.json(CIBILResp);
          }
        });
      }
      else {
        logger.info("ELSE: CIBIL document already available in database with success response");
        CIBILResp = {
          "ErrorCode": "00",
          "ErrorMessage": "CIBIL document already available in database with success response"
        }
        return res.json(CIBILResp);
      }
    });
  });

});

//Cheker Segment
app.post('/api/getPendingCheckerVerification', async (req, res) => {
  logger.info("***********************Inside  getPendingCheckerVerification (START)*************************");

  const { fromDate, toDate } = req.body;
  userDataLayer.getPendingCheckerVerification(fromDate, toDate).then(async (objGetCustomerCICData) => {
    logger.info('Output getPendingCheckerVerification: ' + JSON.stringify(objGetCustomerCICData));
    if (objGetCustomerCICData != null) {
      respJSON = {
        "ErrorCode": "00",
        "ErrorMessage": "Record retrieved succssfully",
        "Data": objGetCustomerCICData,

      }
      logger.info('Response JSON Data: ' + JSON.stringify(respJSON));
      return res.json(JSON.stringify(respJSON));
    }
    else {
      return res.json(null);
    }
  });
});

app.post('/api/getMakerChekerBypassFlags', async (req, res) => {
  logger.info("***********************Inside  getMakerChekerBypassFlags (START)*************************");

  const { PMSNumber, JourneyID, encLognData } = req.body;
  logger.info('PMSNumber ' + PMSNumber);
  logger.info('JourneyID ' + JourneyID);

  objCommonFunction.Decrypt(encLognData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));
    let objCICCalllDays;
    let CICCalledDate;
    let JourneySanctionedDate;
    let objJourneySanctionedDays;
    objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (objCustomerJourneyData) => {
      logger.info('Output getCustomerJourneyData: ' + JSON.stringify(objCustomerJourneyData));
      let parseobjCustomerJourneyData = JSON.parse(objCustomerJourneyData);
      logger.info('Journey Milestone: ' + parseobjCustomerJourneyData.JourneyMilestone);
      if (parseobjCustomerJourneyData.JourneyMilestone == 107) {
        JourneySanctionedDate = parseobjCustomerJourneyData.JourneySanctionedDate;
        logger.info('Loan Sanctioned Date ' + JourneySanctionedDate);
        if (JourneySanctionedDate != null) {
          objJourneySanctionedDays = CalculateDateDifferenceInDays(JourneySanctionedDate);
          logger.info('Loan Sanctioned days ' + objJourneySanctionedDays);
          if (objJourneySanctionedDays >= 15) {
            //Downngrade journey to maker
            objGeneralOperation.CustomerJourneyUpdate(PMSNumber, JourneyID, deLoginResponse.UserID, deLoginResponse.UserSOL, null, null, null, null, null, null, "DowngradeJourney").then(async (objRespCustomerJourney) => {
              logger.info('Output CustomerJourneyUpdate: ', JSON.stringify(objRespCustomerJourney));
              if (objRespCustomerJourney.ErrorCode == "00") {
                respJSON = {
                  "ErrorCode": "01",
                  "ErrorMessage": "Journey expired due to expiery of loan offer by 15 days from sanctioned date. Kindly create fresh journey.",
                  "Data": null
                }
                logger.info('Loan Offer expire at cheker level for this journey ' + JSON.stringify(respJSON));
                return res.json(JSON.stringify(respJSON));
              }
            });
          }
          else {
            userDataLayer.getMakerChekerBypassFlags(PMSNumber, JourneyID).then(async (objGetJourneyByPassFlag) => {
              logger.info('Output getMakerChekerBypassFlags: ', JSON.stringify(objGetJourneyByPassFlag));
              logger.info('Output getMakerChekerBypassFlags: ', JSON.stringify(objGetJourneyByPassFlag[0]));
              logger.info('Output PMSNumber: ', JSON.stringify(objGetJourneyByPassFlag[0].PMSNumber));
              if (objGetJourneyByPassFlag != null) {
                respJSON = {
                  "ErrorCode": "00",
                  "ErrorMessage": "Record retrieved succssfully",
                  "Data": objGetJourneyByPassFlag
                }
                logger.info('Response Maker Cheker Bypass Flags JSON Data: ' + JSON.stringify(respJSON));
                return res.json(JSON.stringify(respJSON));
              }
            });
          }
        }
      }
      else {
        objGeneralOperation.getConsumerCIBIL(PMSNumber, JourneyID).then(async (objRespConsumerCIBIL) => {
          //logger.info('Output  getConsumerCIBIL: ' + JSON.stringify(objRespConsumerCIBIL));
          if (objRespConsumerCIBIL != null) {

            CICCalledDate = JSON.parse(objRespConsumerCIBIL).ConsumerAPIResponseTime;
            logger.info('CIC Pull Date ' + CICCalledDate);
            if (CICCalledDate != null) {
              objCICCalllDays = CalculateDateDifferenceInDays(CICCalledDate);
              logger.info('Inside CIC Called days ' + objCICCalllDays);
              if (objCICCalllDays >= 15) {
                //Downngrade journey to maker
                objGeneralOperation.CustomerJourneyUpdate(PMSNumber, JourneyID, deLoginResponse.UserID, deLoginResponse.UserSOL, null, null, null, null, null, null, "DowngradeJourney").then(async (objRespCustomerJourney) => {
                  logger.info('Output CustomerJourneyUpdate: ', JSON.stringify(objRespCustomerJourney));
                  if (objRespCustomerJourney.ErrorCode == "00") {
                    respJSON = {
                      "ErrorCode": "01",
                      "ErrorMessage": "CIC expired by 15 days for this journey. Kindly create fresh journey.",
                      "Data": null
                    }
                    logger.info('CIC Expired at cheker level for this journey ' + JSON.stringify(respJSON));
                    return res.json(JSON.stringify(respJSON));
                  }
                });
              }
              else {
                userDataLayer.getMakerChekerBypassFlags(PMSNumber, JourneyID).then(async (objGetJourneyByPassFlag) => {
                  logger.info('Output getMakerChekerBypassFlags: ', JSON.stringify(objGetJourneyByPassFlag));
                  logger.info('Output getMakerChekerBypassFlags: ', JSON.stringify(objGetJourneyByPassFlag[0]));
                  logger.info('Output PMSNumber: ', JSON.stringify(objGetJourneyByPassFlag[0].PMSNumber));
                  if (objGetJourneyByPassFlag != null) {
                    respJSON = {
                      "ErrorCode": "00",
                      "ErrorMessage": "Record retrieved succssfully",
                      "Data": objGetJourneyByPassFlag
                    }
                    logger.info('Response Maker Cheker Bypass Flags JSON Data: ' + JSON.stringify(respJSON));
                    return res.json(JSON.stringify(respJSON));
                  }
                });
              }
            }
          }
        });
      }
    });
  });
});

app.post('/api/ProceedOrRejectJourney', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  ProceedOrRejectJourney ((START))**************************');
  const { EncPayload, EncLoginData, ActionEvent, Action, message } = req.body;

  logger.info('Encrypted User Login Object: ' + EncLoginData);
  objCommonFunction.Decrypt(EncLoginData).then(async (decLoginPayload) => {
    const deLoginResponse = JSON.parse(decLoginPayload);
    logger.info('Decrypt User Login Object: ' + JSON.stringify(deLoginResponse));

    logger.info('Encrypted PMS Object: ' + EncPayload);
    objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
      const decResponse = JSON.parse(decPayload);
      logger.info('Decrypt PMS Object: ' + JSON.stringify(decResponse));
      logger.info('decPayload: ' + decResponse);
      logger.info("decPayload AadhaarNo: " + decResponse.AadhaarNumber);
      logger.info("decPayload PMSNumber: " + decResponse.PMSNumber);
      logger.info("decPayload JourneyID: " + decResponse.JourneyID);
      logger.info("decPayload CustomerID: " + decResponse.CustomerID);


      logger.info('Action' + Action);

      if (Action == "No") {
        objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
          if (CityKYCStatusDetails != null) {
            //RJ000014:Other
            objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (objCustomerJourneyData) => {
              const APIURL = await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
              objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000012", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
                logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI5: " + JSON.stringify(respObjUpdateSIDBI));
                if (respObjUpdateSIDBI.ErrorCode == "00") {
                  objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objCustomerJourneyData).LoanTranche, "Rejected", 'Error04', "Maker user rejected journey due to existing business loan as per Credit Information Report.", respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                    logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney:  " + JSON.stringify(respUpdateJourneyStatus));
                    objGeneralOperation.UpdateCICPassFlag(decResponse.PMSNumber, decResponse.JourneyID, false, "Maker user rejected journey due to existing business loan as per Credit Information Report.").then(async (UpdateCICPassFlag) => {
                      logger.info("Output UpdateCICPassFlag: " + JSON.stringify(UpdateCICPassFlag));
                      if (respObjUpdateSIDBI.StatusCode == "N") {
                        objRejectedJourney = {
                          "ErrorCode": "00",
                          "ErrorMessage": "Maker user rejected journey due to existing business loan as per Credit Information Report."
                        }
                      } else {
                        objRejectedJourney = {
                          "ErrorCode": "01",
                          "ErrorMessage": respObjUpdateSIDBI.ErrorMsg
                        }
                      }
                      logger.info('Response control to UI ' + JSON.stringify(objRejectedJourney));
                      return res.json(objRejectedJourney);
                    });
                  });
                }
                else {
                  objRejectedJourney = {
                    "ErrorCode": "01",
                    "ErrorMessage": "Error to update rejected status at SIDBI"
                  }
                  logger.info('Response control to UI ' + JSON.stringify(objRejectedJourney));
                  return res.json(objRejectedJourney);
                }
              });
            });
          }
        });
      }
      else if (Action == "Yes") {
        //Log Maker Consent
        objGeneralOperation.LogMakerConsent(decResponse.PMSNumber, decResponse.JourneyID, deLoginResponse.UserID, ActionEvent, Action, message).then(async (objRespLogMakerConsent) => {
          if (objRespLogMakerConsent.ErrorCode == "00") {
            CIBILResp = {
              "ErrorCode": "00",
              "ErrorMessage": "Branch maker user consent save successfully."
            }
            logger.info(JSON.stringify(CIBILResp));
            return res.json(CIBILResp);
          }
          else {
            CIBILResp = {
              "ErrorCode": "01",
              "ErrorMessage": "Rejected due to negative parameter in CIC"
            }
            return res.json(CIBILResp);
          }
        });
      }
      else if (Action == "Approve") {
        logger.info('Approve me aa gaya');
        objGeneralOperation.LogMakerConsent(decResponse.PMSNumber, decResponse.JourneyID, deLoginResponse.UserID, ActionEvent, Action, message).then(async (objRespLogMakerConsent) => {
          if (objRespLogMakerConsent.ErrorCode == "00") {
            CIBILResp = {
              "ErrorCode": "00",
              "ErrorMessage": "Branch user consent save successfully."
            }
            logger.info(JSON.stringify(CIBILResp));
            return res.json(CIBILResp);
          }
          else {
            CIBILResp = {
              "ErrorCode": "01",
              "ErrorMessage": ""
            }
            return res.json(CIBILResp);
          }
        });
      }
      else if (Action == "Reject") {
        logger.info('########## Journey rejection start by checker user ##########');
        const APIURL = await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');

        objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
          if (CityKYCStatusDetails != null) {
            //RJ000013:Credit rating is adverse
            objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000012", APIURL, CityKYCStatusDetails).then(async (respUpdateJourneyStatus) => {
              logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI6: " + JSON.stringify(respUpdateJourneyStatus));
              if (respUpdateJourneyStatus.ErrorCode == "00") {
                objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, "Rejected", message).then(async (objRespCustomerJourney) => {
                  //objGeneralOperation.UpdateJourneyStatus(decResponse.PMSNumber,decResponse.JourneyID,"Sanctioned","Journey successfully Sanctioned").then(async (objDataUpdateResponse) => {
                  logger.info(`OUTPUT Sanctioned_Rejected_Suspended_CustomerJourney: ${JSON.stringify(objRespCustomerJourney)}`);
                  logger.info('');
                  //Log Maker Consent
                  if (objRespCustomerJourney.ErrorCode == "00") {
                    objGeneralOperation.LogMakerConsent(decResponse.PMSNumber, decResponse.JourneyID, deLoginResponse.UserID, ActionEvent, Action, message).then(async (objRespLogMakerConsent) => {
                      if (objRespLogMakerConsent.ErrorCode == "00") {
                        CIBILResp = {
                          "ErrorCode": "00",
                          "ErrorMessage": "Branch user rejected journey"
                        }
                        return res.json(CIBILResp);
                      }
                      else {
                        CIBILResp = {
                          "ErrorCode": "01",
                          "ErrorMessage": "Error to update Checker consent"
                        }
                        return res.json(CIBILResp);
                      }
                    });
                  }
                });
              }
              else {
                CIBILResp = {
                  "ErrorCode": "01",
                  "ErrorMessage": "Error to update rejected status at SIDBI"
                }
                return res.json(CIBILResp);
              }

            });
          }
        });
      }
    });
  });
});

//Cheker Segment
app.post('/api/getNeslFailedApplications', async (req, res) => {
  logger.info("***********************Inside  getNeslFailedApplications (START)*************************");

  const { fromDate, toDate } = req.body;
  userDataLayer.getNeslFailedApplications(fromDate, toDate).then(async (objGetCustomerCICData) => {
    logger.info('Output getNeslFailedApplications: ' + JSON.stringify(objGetCustomerCICData));
    if (objGetCustomerCICData != null) {
      respJSON = {
        "ErrorCode": "00",
        "ErrorMessage": "Record retrieved succssfully",
        "Data": objGetCustomerCICData
      }
      logger.info('Response JSON Data: ' + JSON.stringify(respJSON));
      return res.json(JSON.stringify(respJSON));
    }
    else {
      return res.json(null);
    }
  });
});

app.post('/api/UploadCustomerSignedLoanDocument', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  UploadCustomerSignedLoanDocument ((START))**************************');
  const { EncPayload, EncLoginData, FileName, base64String, chkConsent, Action } = req.body;
  logger.info('Action: ' + Action);
  //logger.info('base64String: ' + base64String.split(',')[1]);
  let strBase64String = base64String.split(',')[1];
  objCommonFunction.Decrypt(EncLoginData).then(async (decLoginPayload) => {
    objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
      const decResponse = JSON.parse(decPayload);
      logger.info("PMSNumber: " + decResponse.PMSNumber);
      logger.info("JourneyID: " + decResponse.JourneyID);

      objGeneralOperation.UploadCustomerSignedLoanDocument(decResponse.PMSNumber, decResponse.JourneyID, FileName, strBase64String, chkConsent, Action).then(async (objUploadCustomerSignedLoanDocument) => {
        logger.info(`OUTPUT UploadCustomerSignedLoanDocument: ${JSON.stringify(objUploadCustomerSignedLoanDocument)}`);
        logger.info('');
        docUploadResponse = {
          "ErrorCode": objUploadCustomerSignedLoanDocument.ErrorCode,
          "ErrorMessage": objUploadCustomerSignedLoanDocument.ErrorMsg
        }
        logger.info('Response after loan document upload ' + JSON.stringify(docUploadResponse));
        return res.json(JSON.stringify(docUploadResponse));
      });
    });
  });
});


// app.post('/api/ChekerRejectJourney',async (req,res)=>{
//   logger.info('');
//   logger.info('');
//   logger.info('********************Inside  ChekerRejectJourney ((START))**************************');
//   const {PMSNumber,JourneyID}=req.body;
//     objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber,JourneyID,"Rejected","Checker user rejected customer journey").then(async (objRespCustomerJourney) => {       
//       //objGeneralOperation.UpdateJourneyStatus(decResponse.PMSNumber,decResponse.JourneyID,"Sanctioned","Journey successfully Sanctioned").then(async (objDataUpdateResponse) => {
//       logger.info(`OUTPUT Sanctioned_Rejected_Suspended_CustomerJourney: ${JSON.stringify(objRespCustomerJourney)}`);
//       logger.info('');      
//       if (objRespCustomerJourney.ErrorCode=="00")
//         JsonResp={
//         "ErrorCode":objRespCustomerJourney.ErrorCode,
//         "ErrorMessage":"Customer journey rejected by checker user."
//       }
//       logger.info('Response for checker rejected customer journey: '+JsonResp);
//       return res.json(JSON.stringify(JsonResp));  
//     });
// });


app.post('/api/getKFSAndSanctionLetterData', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  getKFSAndSanctionLetterData ((START)) **************************');
  const { EncPayload } = req.body;

  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
      decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);

    const NodalOfficerName = await GetKeyConfigurationValue('NodalOfficerName');

    const NodalOfficerDesignation = await GetKeyConfigurationValue('NodalOfficerDesignation');
    const NodalOfficerContactNo = await GetKeyConfigurationValue('NodalOfficerContactNo');
    const NodalOfficerEmailID = await GetKeyConfigurationValue('NodalOfficerEmailID');

    const ROI = await GetKeyConfigurationValue('ROI');
    const ROIAddsTwentyFiveBasis = await GetKeyConfigurationValue('ROIAddsTwentyFiveBasis');

    ConfigurationData = {
      "NodalOfficerName": NodalOfficerName,
      "NodalOfficerDesignation": NodalOfficerDesignation,
      "NodalOfficerContactNo": NodalOfficerContactNo,
      "NodalOfficerEmailID": NodalOfficerEmailID,
      "ROI": ROI,
      "ROIAddsTwentyFiveBasis": ROIAddsTwentyFiveBasis
    };
    logger.info('ConfigurationData: ', ConfigurationData)
    objGeneralOperation.getKFSAndSanctionLetterData(decResponse.PMSNumber, decResponse.CustomerID, decResponse.JourneyID).then(async (respKFSAndSanctionLetterData) => {
      logger.info('Output getKFSAndSanctionLetterData', JSON.stringify(respKFSAndSanctionLetterData));

      if (respKFSAndSanctionLetterData != null) {
        PDFDataResp = {
          "ErrorCode": "00",
          "JourneyData": JSON.stringify(respKFSAndSanctionLetterData),
          "ConfigurationData": JSON.stringify(ConfigurationData)
        }
        logger.info('********************Inside  getKFSAndSanctionLetterData ((END))**************************');
        return res.json(JSON.stringify(PDFDataResp));
      }
    });
  });
});

app.post('/api/CalculateLoanEMI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  CalculateLoanEMI ((START))**************************');
  const { EncPayload } = req.body;

  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
     decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);

    let ROI = await GetKeyConfigurationValue('ROI');
    logger.info('out ROI ' + ROI);  // Now this should log the actual value
    if (ROI != null) {
      const ROIAddsTwentyFiveBasis = await GetKeyConfigurationValue('ROIAddsTwentyFiveBasis');
       const BSP = await GetKeyConfigurationValue('BSP');
      logger.info('out 25Basis ' + ROIAddsTwentyFiveBasis);  // Now this should log the actual value
      // const ROITwentyFiveBasisPoint=objGeneralOperation.GetKeyConfigurationValue('ROIAddsTwentyFiveBasis');
      objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (objCustomerJourneyData) => {
        const result = calculateAmortizationSchedule(JSON.parse(objCustomerJourneyData).LoanAmount, ROI, ROIAddsTwentyFiveBasis, JSON.parse(objCustomerJourneyData).LoanTenure);
        //logger.info('Result ',result);
        // logger.info('Result ',JSON.stringify(result.AmortSchedule));
        objGeneralOperation.SaveRepaymentSchedule(decResponse.PMSNumber, decResponse.JourneyID, decResponse.CustomerID, JSON.stringify(result.AmortSchedule)).then(async (objCustomerJourneyData) => {

          objGeneralOperation.UpdateRepaymentData(decResponse.PMSNumber, decResponse.JourneyID, result.TotalInstallment, result.TotalInterest, result.EMI1, result.EMI2).then(async (objCustomerJourneyData) => {



            repaymentResp = {
              "ErrorCode": "00",
              "ErrorMessage": "Repayment schedule saved successfully.",
              "Amortisation": JSON.stringify(result.AmortSchedule)
            }
            return res.json(JSON.stringify(repaymentResp));
          });

        });
      });
    }
    else {
      repaymentResp = {
        "ErrorCode": "01",
        "ErrorMessage": "Error while accessing ROI",
        "Amortisation": null
      }
      return res.json(JSON.stringify(repaymentResp));
    }

  });
});

async function GetKeyConfigurationValue(KeyName) {
  logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);
  const query = `SELECT [KeyValue] FROM [dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;

  try {
    const pool = await sql.connect(config);
    logger.info('Connected to the database');

    const result = await pool.request()
      .input('KeyName', sql.VarChar, KeyName)
      .query(query);

    if (result.recordset.length > 0) {

      const jsonString = JSON.stringify(result.recordset, null, 2);
      formattedString = jsonString.slice(1, -1);
      //  logger.info('Result: ',formattedString);               
      //  logger.info('Parse Result: ',JSON.parse(formattedString));
      const OutValue = JSON.parse(formattedString).KeyValue;
      //  logger.info('OutValue', OutValue.toString());
      return JSON.parse(formattedString).KeyValue; // Return the formatted string
    } else {
      logger.info('No results found for the provided KeyName.');
      return null;
    }
  } catch (err) {
    console.error('Error:', err);
    return null;
  } finally {
    await sql.close(); // Ensure the connection is closed
  }
}



app.post('/api/CheckNeSLStatusForJourneyMilestone1', async (req, res) => {
  logger.info(``);
  logger.info(`********************Inside  CheckNeSLStatusForJourneyMilestone ((START))**************************`);
  //logger.info('req.body '+JSON.stringify(req.body));
  const { EncData, Operation } = req.body;
  logger.info(`Operation: ${Operation}`);
  logger.info(`EncData: ${EncData}`);

  objCommonFunction.Decrypt(EncData).then(async (decPayload) => {
     decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info(`EncPayLoad: ${JSON.stringify(decResponse)}`);

    logger.info(`decPayload PMSNumber: ${decResponse.PMSNumber}`);
    logger.info(`decPayload JourneyID: ${decResponse.JourneyID}`);
    logger.info(`decPayload NeSLTranID: ${decResponse.NeSLTranID}`);
    logger.info(`decPayload AadhaarNumber: ${decResponse.AadhaarNumber}`);
    logger.info(`decPayload CustomerID: ${decResponse.CustomerID}`);

    if (Operation == "BranchJourney") {
      logger.info(`This part call for Branch Journey`);
      objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID).then(async (objNeSLDocumentData) => {
        if (JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign == "N") {
          objGeneralOperation.BankSignAffix(decResponse.PMSNumber, decResponse.JourneyID, objNeSLDocumentData).then(async (objBankSignAffix) => {
            if (objBankSignAffix != null) {
              objGeneralOperation.getJourneyNeSLStatus(decResponse.PMSNumber, decResponse.JourneyID, decResponse.NeSLTranID).then(async (objRespJourneyNeSLStatus) => {
                logger.info(`Output getJourneyNeSLStatus ${objRespJourneyNeSLStatus}`);
                res.json(objRespJourneyNeSLStatus);
              });
            }
            else {
              res.json(null);
            }
          });
        }
        else {
          objGeneralOperation.getJourneyNeSLStatus(decResponse.PMSNumber, decResponse.JourneyID, decResponse.NeSLTranID).then(async (objRespJourneyNeSLStatus) => {
            logger.info(`Output getJourneyNeSLStatus ${objRespJourneyNeSLStatus}`);
            res.json(objRespJourneyNeSLStatus);
          });
        }
      });
      //Call 
      // objNeSLLayer.CallStatusData(decResponse.PMSNumber, decResponse.JourneyID, decResponse.NeSLTranID).then(async (objStatusAPIResp) => {
      //   logger.info(`Output CallStatusData ${objStatusAPIResp}`);   

      //   if (objStatusAPIResp !== null) {          
      //       const statusResponse = StatusDataPlainResponse.fromJSON(objStatusAPIResp);
      //       logger.info(`@@@@@@@@@transId: ${JSON.stringify(statusResponse)}`);

      //     const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSLResponseFiles');    
      //       const filePath = path.join(outputDir, 'NeslStatusDataResponse' + statusResponse.transId + '.txt');
      //       fs.writeFileSync(filePath,  objStatusAPIResp);// Write the PDF
      //       if (statusResponse.statusCode == "1" && statusResponse.statusMsg == "Success") {
      //         logger.info('&&&&&&&&&&&&&&& Condition 1 &&&&&&&&&&&&&&&');
      //       objGeneralOperation.getCityKYCInfoData(decResponse.AadhaarNumber).then(async (objCityKYCInfoData) => {
      //         objGeneralOperation.getBranchInformation(JSON.parse(objCityKYCInfoData).solid).then(async (objBranchInformation) => {
      //           objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (objCustomerJourneyData) => {
      //             objGeneralOperation.getCustomerDetails(JSON.parse(objCustomerJourneyData).CustomerID).then(async (objCustomerDetails) => {
      //               objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID).then(async (objNeSLDocumentData) => {
      //                 NeSLLink_UpdateNeSLData_BankSignAffix_NonCallBackAPI(decResponse.PMSNumber, decResponse.JourneyID, decResponse.NeSLTranID, statusResponse, JSON.parse(objCityKYCInfoData), JSON.parse(objBranchInformation), JSON.parse(objCustomerJourneyData), JSON.parse(objNeSLDocumentData), JSON.parse(objCustomerDetails)).then(async (respNeSLDocUpdateDatabase) => {
      //                   logger.info(`Output NeSLLink_UpdateNeSLData_BankSignAffix API ${JSON.stringify(respNeSLDocUpdateDatabase)}`);                       
      //                   //return res.json(JSON.stringify(respNeSLDocUpdateDatabase));
      //                   objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID).then(async (objNeSLDocumentData) => {
      //                     if(JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign=="N")
      //                       {
      //                         objGeneralOperation.BankSignAffix(decResponse.PMSNumber, decResponse.JourneyID,objNeSLDocumentData).then(async (objBankSignAffix) => {
      //                           if(objBankSignAffix!=null)
      //                           {
      //                             objGeneralOperation.getJourneyNeSLStatus(decResponse.PMSNumber,decResponse.JourneyID,decResponse.NeSLTranID).then(async (objRespJourneyNeSLStatus) => { 
      //                               logger.info(`Output getJourneyNeSLStatus ${objRespJourneyNeSLStatus}`);
      //                               res.json(objRespJourneyNeSLStatus);
      //                             });
      //                           }
      //                           else{
      //                             res.json(null);
      //                           }
      //                         }); 
      //                       }
      //                       else{
      //                         objGeneralOperation.getJourneyNeSLStatus(decResponse.PMSNumber,decResponse.JourneyID,decResponse.NeSLTranID).then(async (objRespJourneyNeSLStatus) => { 
      //                           logger.info(`Output getJourneyNeSLStatus ${objRespJourneyNeSLStatus}`);
      //                           res.json(objRespJourneyNeSLStatus);
      //                         });
      //                       }

      //                 });                        
      //                });
      //               });
      //             });                      
      //           });
      //         });
      //       });
      //     }
      //   }
      // });      
    }
    else {
      logger.info(`This part call for DIY Journey`);
      objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID).then(async (objNeSLDocumentData) => {
        if (JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign == "N") {
          objGeneralOperation.BankSignAffix(decResponse.PMSNumber, decResponse.JourneyID, objNeSLDocumentData).then(async (objBankSignAffix) => {
            if (objBankSignAffix != null) {
              objGeneralOperation.getJourneyNeSLStatus(decResponse.PMSNumber, decResponse.JourneyID, decResponse.NeSLTranID).then(async (objRespJourneyNeSLStatus) => {
                logger.info(`Output getJourneyNeSLStatus ${objRespJourneyNeSLStatus}`);
                res.json(objRespJourneyNeSLStatus);
              });
            }
            else {
              res.json(null);
            }
          });
        }
        else {
          objGeneralOperation.getJourneyNeSLStatus(decResponse.PMSNumber, decResponse.JourneyID, decResponse.NeSLTranID).then(async (objRespJourneyNeSLStatus) => {
            logger.info(`Output getJourneyNeSLStatus ${objRespJourneyNeSLStatus}`);
            res.json(objRespJourneyNeSLStatus);
          });
        }
      });
    }
  });
});

app.post('/api/CheckNeSLStatusForJourneyMilestone', async (req, res) => {
  logger.info(``);
  logger.info(`********************Inside CheckNeSLStatusForJourneyMilestone ((START))**************************`);

  try {
    const { EncData, Operation } = req.body;
    logger.info(`Operation: ${Operation}`);
    logger.info(`EncData: ${EncData}`);

    // ✅ Decrypt EncData safely
    const decPayload = await objCommonFunction.Decrypt(EncData);
     decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);

    logger.info(`EncPayLoad: ${JSON.stringify(decResponse)}`);
    logger.info(`decPayload PMSNumber: ${decResponse.PMSNumber}`);
    logger.info(`decPayload JourneyID: ${decResponse.JourneyID}`);
    logger.info(`decPayload NeSLTranID: ${decResponse.NeSLTranID}`);
    logger.info(`decPayload AadhaarNumber: ${decResponse.AadhaarNumber}`);
    logger.info(`decPayload CustomerID: ${decResponse.CustomerID}`);

    if (Operation === "BranchJourney") {
      logger.info(`This part call for Branch Journey`);
      try {
        const objNeSLDocumentData = await objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID);

        if (JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign === "N") {
          logger.info(`Document not pending for NeSL eSign — affixing bank sign`);
          const objBankSignAffix = await objGeneralOperation.BankSignAffix(decResponse.PMSNumber, decResponse.JourneyID, objNeSLDocumentData);

          if (objBankSignAffix != null) {
            const objRespJourneyNeSLStatus = await objGeneralOperation.getJourneyNeSLStatus(
              decResponse.PMSNumber,
              decResponse.JourneyID,
              decResponse.NeSLTranID
            );
            logger.info(`Output getJourneyNeSLStatus: ${objRespJourneyNeSLStatus}`);
            return res.json(objRespJourneyNeSLStatus);
          } else {
            logger.warn(`BankSignAffix returned null`);
            return res.json(null);
          }
        } else {
          logger.info(`Document is still pending for NeSL eSign`);
          const objRespJourneyNeSLStatus = await objGeneralOperation.getJourneyNeSLStatus(
            decResponse.PMSNumber,
            decResponse.JourneyID,
            decResponse.NeSLTranID
          );
          logger.info(`Output getJourneyNeSLStatus: ${objRespJourneyNeSLStatus}`);
          return res.json(objRespJourneyNeSLStatus);
        }
      } catch (innerErr) {
        logger.error(`BranchJourney flow failed: ${innerErr.stack || innerErr}`);
        return res.status(500).json({ Status: "Error", Message: "Error in BranchJourney flow", Details: innerErr.message });
      }
    }

    // 🧩 DIY Journey block
    else {
      logger.info(`This part call for DIY Journey`);
      try {
        const objNeSLDocumentData = await objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID);

        if (JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign === "N") {
          logger.info(`Document not pending for NeSL eSign — affixing bank sign`);
          const objBankSignAffix = await objGeneralOperation.BankSignAffix(decResponse.PMSNumber, decResponse.JourneyID, objNeSLDocumentData);

          if (objBankSignAffix != null) {
            const objRespJourneyNeSLStatus = await objGeneralOperation.getJourneyNeSLStatus(
              decResponse.PMSNumber,
              decResponse.JourneyID,
              decResponse.NeSLTranID
            );
            logger.info(`Output getJourneyNeSLStatus: ${objRespJourneyNeSLStatus}`);
            return res.json(objRespJourneyNeSLStatus);
          } else {
            logger.warn(`BankSignAffix returned null`);
            return res.json(null);
          }
        } else {
          logger.info(`Document is still pending for NeSL eSign`);
          const objRespJourneyNeSLStatus = await objGeneralOperation.getJourneyNeSLStatus(
            decResponse.PMSNumber,
            decResponse.JourneyID,
            decResponse.NeSLTranID
          );
          logger.info(`Output getJourneyNeSLStatus: ${objRespJourneyNeSLStatus}`);
          return res.json(objRespJourneyNeSLStatus);
        }
      } catch (innerErr) {
        logger.error(`DIY Journey flow failed: ${innerErr.stack || innerErr}`);
        return res.status(500).json({ Status: "Error", Message: "Error in DIY Journey flow", Details: innerErr.message });
      }
    }
  } catch (outerErr) {
    logger.error(`Global error in CheckNeSLStatusForJourneyMilestone: ${outerErr.stack || outerErr}`);
    return res.status(500).json({
      Status: "Error",
      Message: "Unhandled exception in CheckNeSLStatusForJourneyMilestone",
      Details: outerErr.message
    });
  } finally {
    logger.info(`********************Inside CheckNeSLStatusForJourneyMilestone ((END))**************************`);
  }
});



app.post('/api/GetNeSLErrorCode', async (req, res) => {
  logger.info(``);
  logger.info(`ErrorCode Body ${JSON.stringify(req.body)}`);
  logger.info(`********************Inside  GetNeSLErrorCode ((START))**************************`);


  const ErrorCode = req.body;
  logger.info(`ErrorCode ${ErrorCode}`);
  objGeneralOperation.GetNeSLErrorCode(ErrorCode).then(async (objNeSLErrorCode) => {
    logger.info(`Output GetNeSLErrorCode ${JSON.stringify(objNeSLErrorCode)}`);

    res.json(objNeSLErrorCode);

    logger.info(`********************Inside  GetNeSLErrorCode ((END))**************************`);
  });
});

app.post('/api/GetLoanSchedule', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### GetLoanSchedule ###############################');
  logger.info('');
  const { EncPayLoad } = req.body;
 
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
      decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);

    objGeneralOperation.GetAmortizationSchedule(decResponse.PMSNumber).then(async (AmortizationSchedule) => {
      logger.info('Out 1' + AmortizationSchedule);
      logger.info('Out GetAmortizationSchedule' + JSON.stringify(AmortizationSchedule));

      objeResp = {
        "ErrorCode": "00",
        "ErrorMsg": "Success",
        "AmortizationData": JSON.stringify(AmortizationSchedule)
      }
      return res.json(JSON.stringify(objeResp));
    });
  });
});

app.post('/api/UpdateJourneyStatusSIDBIAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  UpdateJourneyStatusSIDBIAPI ((START))**************************');
  const { EncPayload } = req.body;

  objCommonFunction.Decrypt(EncPayload).then(async (decPayload) => {
      decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info(`EncPayLoad: ${decResponse}`);
    logger.info(`decPayload AadhaarNo: ${decResponse.AadhaarNumber}`);
    logger.info(`decPayload PMSNumber: ${decResponse.PMSNumber}`);
    logger.info(`decPayload JourneyID: ${decResponse.JourneyID}`);
    logger.info(`decPayload CustomerID: ${decResponse.CustomerID}`);
    let SanctionedStatusResponse;
    refKey=decResponse.AadhaarNumber;
    objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
      if (CityKYCStatusDetails != null) {
        objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (respCustomerJourney) => {
          CurrentMileStone = JSON.parse(respCustomerJourney).JourneyMilestone;

          if (JSON.parse(respCustomerJourney).CurrentStatus == "Sanctioned") {
            logger.info('SIDBI sync already sanctioned data.')
            objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(respCustomerJourney).LoanTranche, "Sanctioned", null, null, null).then(async (objRespCustomerJourney) => {
              logger.info(`OUTPUT Sanctioned_Rejected_Suspended_CustomerJourney: ${JSON.stringify(objRespCustomerJourney)}`);
              SanctionedStatusResponse = {
                "ErrorCode": objRespCustomerJourney.ErrorCode,
                "ErrorMessage": objRespCustomerJourney.ErrorMsg
              }
              logger.info(`${JSON.stringify(SanctionedStatusResponse)}`);
              logger.info('###############################Call Journey Current Status update at SIDBI API START ###############################');
              return res.json(SanctionedStatusResponse);
            });
          }
          else {
            if (CurrentMileStone == 106)//KFS consent already given
            {
              logger.info('SIDBI sync already picked up data.')
              if (!JSON.parse(respCustomerJourney).isJourneySanctioned) {
                const APIURL = await GetKeyConfigurationValue('SIDBI_Sanctioned_Disbursement_API_URL');
                logger.info(`APIURL: ${APIURL}`);
                objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "Sanctioned", APIURL, CityKYCStatusDetails).then(async (respSIDBIStatus) => {
                  logger.info("Return");
                  logger.info(JSON.stringify(respSIDBIStatus));
                  if (respSIDBIStatus.ErrorCode == "00") {
                    objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(respCustomerJourney).LoanTranche, "Sanctioned", null, respSIDBIStatus.ErrorMsg, respSIDBIStatus.StatusCode).then(async (objRespCustomerJourney) => {
                      logger.info(`OUTPUT Sanctioned_Rejected_Suspended_CustomerJourney: ${JSON.stringify(objRespCustomerJourney)}`);
                      SanctionedStatusResponse = {
                        "ErrorCode": respSIDBIStatus.ErrorCode,
                        "ErrorMessage": respSIDBIStatus.ErrorMsg
                      }
                      logger.info(`${JSON.stringify(SanctionedStatusResponse)}`);
                      logger.info('###############################Call Journey Current Status update at SIDBI API START ###############################');
                      return res.json(SanctionedStatusResponse);
                    });
                  }
                  else {
                    SanctionedStatusResponse = {
                      "ErrorCode": "01",
                      "ErrroMessage": respSIDBIStatus.ErrorMsg
                    }
                    logger.info(`${JSON.stringify(SanctionedStatusResponse)}`);
                    logger.info('###############################Call Journey Current Status update at SIDBI API END ###############################');
                    return res.json(SanctionedStatusResponse);
                  }
                });
              }
              else {
                SanctionedStatusResponse = {
                  "ErrorCode": "00",
                  "ErrorMessage": "Status already updated at SIDBI"
                }
                logger.info(`${JSON.stringify(SanctionedStatusResponse)}`);
                logger.info('###############################Call Journey Current Status update at SIDBI API START ###############################');
                return res.json(SanctionedStatusResponse);
              }


            }
            else {
              SIDBIStatusResp = {
                "ErrorCode": "00",
                "ErrorMessage": "Customer Journey already pass SIDBI Sanctioned Status API"
              }
              logger.info(`${JSON.stringify(SIDBIStatusResp)}`);
              logger.info('###############################Call Journey Current Status update at SIDBI API END ###############################');
              return res.json(SIDBIStatusResp);
            }
          }

        });
      }
    });
  });
});

app.post('/api/CallNeSLforStampAndESigningAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### Call CallNeSLforStampAndESigning API ((START)) ###############################');
  logger.info('');
  const { EncPayLoad, JourneyInitiation } = req.body;
  logger.info(`JourneyInitiation: ${JourneyInitiation}`);
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
      decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';  
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: " + decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: " + decResponse.PMSNumber);
    logger.info("decPayload JourneyID: " + decResponse.JourneyID);
    logger.info("decPayload CustomerID: " + decResponse.CustomerID);

        let aadhar;

    const aadhaarNo = decResponse.AadhaarNumber?.trim();

    if (aadhaarNo && aadhaarNo.length === 12) {
      aadhar = aadhaarNo;
    } else {
      //aadhar = await getUidByRefKeyOnce(aadhaarNo);
      aadhar = '492359588326'
    }
    if (!aadhar) {
      logger.error('aadhar not generated');
      return res.json({
        ErrorCode: "01",
        ErrorMessage: "Unable to validate refkey details",
        Tranche: ""
      });
    }
    logger.info(`aadhar resolved: ${aadhar}`);

    // Load the existing PDF template
    // Create the path to the PDF template
    objGeneralOperation.getCityKYCInfoData(refKey).then(async (objCityKYCInfoData) => {
      objGeneralOperation.getBranchInformation(JSON.parse(objCityKYCInfoData).solid).then(async (objBranchInformation) => {
        objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (objCustomerJourneyData) => {
          objGeneralOperation.GetAmortizationSchedule(decResponse.PMSNumber, decResponse.JourneyID).then(async (AmortizationSchedule) => {
            objNeSLLayer.BindTrancheWisePDFDocument(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objBranchInformation), JSON.parse(objCustomerJourneyData), JSON.parse(objCityKYCInfoData), JSON.parse(AmortizationSchedule)).then(async (objBindTrancheWisePDFDocument) => {
              logger.info('objBindTrancheWisePDFDocument' + JSON.stringify(objBindTrancheWisePDFDocument));
              if (objBindTrancheWisePDFDocument.ErrorCode == "00") {
                objGeneralOperation.getCustomerDetails(decResponse.CustomerID).then(async (objCustomerDetails) => {
                  logger.info('Output getCustomerDetails: ' + JSON.stringify(objCustomerDetails));
                  objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID).then(async (objNeSLDocumentData) => {
                    //logger.info('Output getNeSLDocumentData: '+JSON.stringify(objNeSLDocumentData));
                    logger.info(`isPendingForNeSLeSign ${JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign}`);
                    logger.info(`isPendingForNeSLeSign ${JSON.parse(objNeSLDocumentData).NeSL_Tran_ID}`);
                    if (JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign == "Y") {
                      let NeSLPlainData = {
                        "AadhaarNumber": aadhar,//decResponse.AadhaarNumber,
                        "PMSNumber": decResponse.PMSNumber,
                        "JourneyID": decResponse.JourneyID,
                        "NeSLTranID": JSON.parse(objNeSLDocumentData).NeSL_Tran_ID
                      }
                      logger.info(`NeSLPlainData for resp-url: ${JSON.stringify(NeSLPlainData)}`);
                      objCommonFunction.Encrypt(JSON.stringify(NeSLPlainData)).then(async (EncResponse) => {
                        if (EncResponse != null) {
                          logger.info(`NeSLEncData for resp-url: ${EncResponse}`);
                          let NeslRetURL = "";
                          if (JourneyInitiation == "BranchJourney") {
                            NeslRetURL = 'https://uat.pnbsvanidhidashboard.mypnb.in:1553/epmsservice?Data=' + EncResponse;
                          }
                          else {
                             NeslRetURL = 'https://svanidhi.pnbuat.bank.in/epmsservice?Data=' + EncResponse;
                          //  NeslRetURL = 'https://uat.pnbsvanidhi.mypnb.in/epmsservice?Data=' + EncResponse;
                          }

                          logger.info(`NeslRetURL: ${NeslRetURL}`);
                          objGeneralOperation.UpdateRespURL(JSON.parse(objNeSLDocumentData).NeSL_Tran_ID, decResponse.PMSNumber, decResponse.JourneyID, NeslRetURL).then(async (ResponseURLObj) => {
                            logger.info(`OuptutResponseURLObj: ${JSON.stringify(ResponseURLObj)}`);
                            if (ResponseURLObj != null) {
                              objNeSLLayer.CallStatusData(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objNeSLDocumentData).NeSL_Tran_ID).then(async (objStatusAPIResp) => {
                                logger.info(`Output CallStatusData ${objStatusAPIResp} and ${objStatusAPIResp.length}`);
                                if (objStatusAPIResp !== null) {
                                  const statusResponse = StatusDataPlainResponse.fromJSON(objStatusAPIResp);
                                  logger.info(`@@@@@@@@@transId: ${statusResponse}`);


                                  const outputDir = path.resolve(__dirname, '..', 'Logs', 'NeSLResponseFiles');
                                  const filePath = path.join(outputDir, 'NeslStatusDataResponse' + statusResponse.transId + '.txt');
                                  fs.writeFileSync(filePath, objStatusAPIResp);// Write the PDF

                                  //fs.writeFileSync('../Logs/NeSLResponseFiles/NeslStatusDataResponse_' + statusResponse.transId + '.txt', objStatusAPIResp);

                                  logger.info('');
                                  logger.info('');
                                  logger.info('API Logs for NeSL status data Response');
                                  logger.info('Transaction ID:', statusResponse.transId); // Nel_10014500
                                  // logger.info('Status Code:', statusResponse.statusCode);              // 1
                                  // logger.info('Status Message:', statusResponse.statusMsg);            // Success
                                  // logger.info('Estamp Certificate:', statusResponse.estampCertificate); // ["IN-K41142Q"]
                                  // // Accessing the nested "docStatus" array and its first element
                                  let docStatus = statusResponse.docStatus[0]; // The first item in the docStatus array
                                  if (docStatus != null) {
                                    // //logger.info('docstatus:'+JSON.stringify(docStatus));
                                    // logger.info(`yobPercent ${docStatus.yobPercent}`);
                                    // logger.info(`genderPercent ${docStatus.genderPercent}`);     
                                    // logger.info(`aadharPercent ${docStatus.aadharPercent}`);  
                                    // logger.info(`Signer Name: ${docStatus.signtryName}`);         // Vish Ram Meena
                                    // logger.info(`PAN: ${docStatus.pan}`);                         // 1170
                                    // logger.info(`Relationship: ${docStatus.rltnshp}`);            // DEBTOR
                                    // logger.info(`Esign Status: ${docStatus.esignStatus}`);        // Success
                                    // logger.info(`Estamp Status: ${docStatus.estampStatus}`);      // Success
                                    // logger.info(`Sequence Number: ${docStatus.seqNo}`);
                                    logger.info(``);
                                    logger.info(``);
                                  }
                                  if (statusResponse.statusCode == "1" && statusResponse.statusMsg == "Success") {
                                    logger.info('&&&&&&&&&&&&&&& Condition 1 &&&&&&&&&&&&&&&');
                                    // NeSLLink_UpdateNeSLData_BankSignAffix(decResponse.PMSNumber,decResponse.JourneyID,JSON.parse(objNeSLDocumentData).NeSL_Tran_ID,statusResponse,JSON.parse(objCityKYCInfoData),JSON.parse(objBranchInformation),JSON.parse(objCustomerJourneyData),JSON.parse(objNeSLDocumentData),JSON.parse(objCustomerDetails));
                                    NeSLLink_UpdateNeSLData_BankSignAffix_NonCallBackAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objNeSLDocumentData).NeSL_Tran_ID, statusResponse, JSON.parse(objCityKYCInfoData), JSON.parse(objBranchInformation), JSON.parse(objCustomerJourneyData), JSON.parse(objNeSLDocumentData), JSON.parse(objCustomerDetails)).then(async (respNeSLDocUpdateDatabase) => {
                                      logger.info(`Output NeSLLink_UpdateNeSLData_BankSignAffix API ${JSON.stringify(respNeSLDocUpdateDatabase)}`);
                                      //statusResponse.docStatus[0].docData
                                      objGeneralOperation.getNeSLDocumentData(decResponse.PMSNumber, decResponse.JourneyID).then(async (objNeSLDocumentData) => {
                                        if (JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign == "N") {
                                          objGeneralOperation.BankSignAffix(decResponse.PMSNumber, decResponse.JourneyID, objNeSLDocumentData).then(async (objBankSignAffix) => {
                                            logger.info(`Output BankSignAffix ${JSON.stringify(objBankSignAffix)}`);
                                            return res.json(JSON.stringify(respNeSLDocUpdateDatabase));
                                          });
                                        }
                                        else {
                                          return res.json(JSON.stringify(respNeSLDocUpdateDatabase));
                                        }
                                      });
                                    });
                                  } else if (statusResponse.statusCode != "ER005" && docStatus.esignStatus == "Pending") {
                                    logger.info('&&&&&&&&&&&&&&& Condition 2 &&&&&&&&&&&&&&&');
                                    // NeSLLink_UpdateNeSLData_BankSignAffix(decResponse.PMSNumber,decResponse.JourneyID,JSON.parse(objNeSLDocumentData).NeSL_Tran_ID,statusResponse,JSON.parse(objCityKYCInfoData),JSON.parse(objBranchInformation),JSON.parse(objCustomerJourneyData),JSON.parse(objNeSLDocumentData),JSON.parse(objCustomerDetails));
                                    NeSLLink_UpdateNeSLData_BankSignAffix_NonCallBackAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objNeSLDocumentData).NeSL_Tran_ID, statusResponse, JSON.parse(objCityKYCInfoData), JSON.parse(objBranchInformation), JSON.parse(objCustomerJourneyData), JSON.parse(objNeSLDocumentData), JSON.parse(objCustomerDetails)).then(async (respNeSLDocUpdateDatabase) => {
                                      logger.info('Output NeSLLink_UpdateNeSLData_BankSignAffix API', respNeSLDocUpdateDatabase);
                                      if (respNeSLDocUpdateDatabase.ErrorCode == "00") {
                                        return res.json(JSON.stringify(respNeSLDocUpdateDatabase));
                                      } else {
                                        return res.json(JSON.stringify(respNeSLDocUpdateDatabase));
                                      }
                                    });
                                  } else if (docStatus != null && docStatus.esignStatus == "Success") {
                                    logger.info('&&&&&&&&&&&&&&& Condition 3 &&&&&&&&&&&&&&&');
                                    logger.Info("");
                                    logger.Info("match per:" + docStatus.matchPercentage);
                                    logger.info('NESL_txnID before caliing updateReturnObj ', NeslTranID);
                                    objNeSLLayer.updateNeSLResponse(NeslTranID, PMSNumber, JourneyID, statusResponse).then(async (respNeSLDocUpdateDatabase) => {
                                      logger.info('Output updateNeSLResponse ', JSOn.stringify(respNeSLDocUpdateDatabase));
                                      if (respNeSLDocUpdateDatabase.ErrorCode == "00") {
                                        if (docStatus.matchPercentage == 100) {
                                          if (JSON.parse(objNeSLDocumentData).isPendingForNeSLeSign == "N") {
                                            objGeneralOperation.BankSignAffix(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objNeSLDocumentData).NeSL_Tran_ID, statusResponse.docStatus[0].docData).then(async (objBankSignAffix) => {
                                              logger.info(`Output BankSignAffix ${JSON.stringify(objBankSignAffix)}`);
                                              NeslResp = {
                                                "ErrorCode": "00",
                                                "ErrorMessage": "Document data saved in databse and bank sign successfully affixed on document",
                                                "htmlBody": null
                                              }
                                              return res.json(JSON.stringify(NeslResp));
                                            });
                                          }
                                        } else {
                                          //Reject Journey
                                          logger.info('Failure in E-Signing due to name mismatch');
                                          NeslResp = {
                                            "ErrorCode": "01",
                                            "ErrorMessage": "Failure in E-Signing due to name mismatch",
                                            "htmlBody": null
                                          }
                                          return res.json(JSON.stringify(NeslResp));
                                        }
                                      } else {
                                        NeslResp = {
                                          "ErrorCode": respNeSLDocUpdateDatabase.ErrorCode,
                                          "ErrorMessage": respNeSLDocUpdateDatabase.ErrorMsg,
                                          "htmlBody": null
                                        }
                                        return res.json(JSON.stringify(NeslResp));
                                      }
                                    });
                                  } else {
                                    logger.info('Yaha Aaaya');
                                    objNeSLLayer.PostNeslData(decResponse.PMSNumber, decResponse.JourneyID, JSON.parse(objCityKYCInfoData), JSON.parse(objBranchInformation), JSON.parse(objCustomerJourneyData), JSON.parse(objNeSLDocumentData), JSON.parse(objCustomerDetails)).then(async (respPostNeslData) => {
                                      if (respPostNeslData != null) {
                                        try {
                                          // logger.info('Output PostNeslData ', respPostNeslData);                              
                                          NeslResp = {
                                            "ErrorCode": "02",
                                            "ErrorMessage": "Success",
                                            "htmlBody": respPostNeslData
                                          }
                                          return res.json(JSON.stringify(NeslResp));
                                        } catch (Exception) {
                                          logger.info(Exception)
                                        }
                                        logger.info('No error');
                                      }
                                    });
                                  }
                                } else {
                                  NeSLStatusResp = {
                                    "ErrorCode": objStatusAPIResp.ErrorCode,
                                    "ErrorMessage": "Error during Status check in  Nesl. Please try after sometime"
                                  }
                                  return res.json(JSON.stringify(NeSLStatusResp));
                                }
                              });
                            }
                          });
                        }
                      });
                    } else {
                      logger.info(`Nesl Already Signed`);
                      NeSLStatusResp = {
                        "ErrorCode": "00",
                        "ErrorMessage": "NeSL e-Sign already successfully done."
                      }
                      logger.info(`NeSLStatusResp ${JSON.stringify(NeSLStatusResp)}`)
                      return res.json(JSON.stringify(NeSLStatusResp));
                    }
                  });
                });
              }
            });
          });
        });
      });
    });
  });
});

class docStatus {
  constructor(data) {
    this.signtryName = data.signtryName || '';
    this.signedName = data.signedName || '';
    this.matchPercentage = data.matchPercentage || '';
    this.pan = data.pan || '';
    this.rltnshp = data.rltnshp || '';
    this.esignStatus = data.esignStatus || '';
    this.esignDate = data.esignDate || '';
    this.estampStatus = data.estampStatus || '';
    this.estampDate = data.estampDate || '';
    this.seqNo = data.seqNo || '';
    this.docData = data.docData || '';
    this.signatoryYob = data.signatoryYob || '';
    this.signedYob = data.signedYob || '';
    this.yobPercent = data.yobPercent || '';
    this.signatoryAadhar = data.signatoryAadhar || '';
    this.signedAadhar = data.signedAadhar || '';
    this.aadharPercent = data.aadharPercent || '';
    this.signatoryGender = data.signatoryGender || '';
    this.signedGender = data.signedGender || '';
    this.genderPercent = data.genderPercent || '';
  }
}

class StatusDataPlainResponse {
  constructor(data) {
    this.transId = data.transId || '';
    this.statusCode = data.statusCode || '';
    this.statusMsg = data.statusMsg || '';
    this.signtryName = data.signtryName || '';
    this.statusMessage = data.statusMessage || '';
    this.estampCertificate = data.estampCertificate || []; // Array of strings
    this.docStatus = (data.docStatus || []).map(doc => new docStatus(doc)); // Deserialize Docstatu
  }
  static fromJSON(json) {
    const data = JSON.parse(json);
    // logger.info('Data inside fromJSON ',json);
    return new StatusDataPlainResponse(data);
  }
}


function NeSLLink_UpdateNeSLData_BankSignAffix_NonCallBackAPI(PMSNumber, JourneyID, NeslTranID, statusResponse, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objNeSLDocumentData, objCustomerDetails) {
  logger.info('###################### Inside NeSLLink_UpdateNeSLData_BankSignAffix_NonCallBackAPI Method######################');

  //logger.info('Serilizied Object', JSON.stringify(objNeSLReturnObj));
  logger.info('');
  logger.info('');
  logger.info(`NeslTranID ${NeslTranID}`);
  logger.info(`PMSNumber  ${PMSNumber}`);
  logger.info(`JourneyID  ${JourneyID}`);
  return new Promise((resolve, reject) => {
    try {

      objNeSLLayer.GetNeslLink(PMSNumber, JourneyID, NeslTranID).then(async (objNeslinkAPIResp) => {
        logger.info(`Output GetNeslLink API ${objNeslinkAPIResp}`);
        if (objNeslinkAPIResp != null) {
          const LinkResponseObj = new LinkResponse(objNeslinkAPIResp);
          if (LinkResponseObj != null) {
            logger.info(`LinkResponseObj.esignLink ${LinkResponseObj.esignLink}`);
            logger.info(`LinkResponseObj.statusCode ${LinkResponseObj.statusCode}`);

            if (LinkResponseObj.esignLink != null) {
              NeslResp = {
                "ErrorCode": "03",
                "ErrorMessage": "Success",
                "htmlBody": LinkResponseObj.esignLink
              }
              resolve(NeslResp);
            }
            else {
              if (LinkResponseObj.statusCode == "ER003") {
                logger.info("Data Not posted. Reposting the transaction.");
                objNeSLLayer.PostNeslData(PMSNumber, JourneyID, objCityKYCInfoData, objBranchInformation, objCustomerJourneyData, objNeSLDocumentData, objCustomerDetails).then(async (respPostNeslData) => {
                  if (respPostNeslData != null) {
                    NeslResp = {
                      "ErrorCode": "02",
                      "ErrorMsg": "Success",
                      "htmlBody": respPostNeslData
                    }
                    resolve(NeslResp);
                  }
                  else {
                    NeslResp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "Success",
                      "htmlBody": respPostNeslData
                    }
                    resolve(NeslResp);
                  }

                });
              }
              else if (LinkResponseObj.statusCode == 'ER005') {
                logger.info('Nesl Signed Successful done. Bank signing initated');

                const docStatus = statusResponse.docStatus[0];  // The first item in the docStatus array

                // logger.info('Signer Name:', docStatus.signtryName);         // Vish Ram Meena
                // logger.info('PAN:', docStatus.pan);                         // 1170
                // logger.info('Relationship:', docStatus.rltnshp);            // DEBTOR
                // logger.info('Esign Status:', docStatus.esignStatus);        // Success
                // logger.info('Estamp Status:', docStatus.estampStatus);      // Success
                // logger.info('Sequence Number:', docStatus.seqNo);     
                // logger.info('');
                // logger.info('');                    

                // logger.info("match per:" + docStatus.matchPercentage);
                logger.info('');


                logger.info('NESL_txnID before caliing updateReturnObj ', NeslTranID);
                objNeSLLayer.updateNeSLResponse(NeslTranID, PMSNumber, JourneyID, statusResponse, "NonCallBackAPIUpdate").then(async (respNeSLDocUpdateDatabase) => {
                  logger.info(`Output updateNeSLResponse: ${JSON.stringify(respNeSLDocUpdateDatabase)}`);
                  if (respNeSLDocUpdateDatabase.ErrorCode == "00") {
                    if (docStatus.matchPercentage == 100) {
                      NeslResp = {
                        "ErrorCode": "00",
                        "ErrorMsg": "Document data saved in databse and bank sign successfully affixed on document",
                        "htmlBody": null
                      }
                      resolve(NeslResp);
                    }
                    else {
                      logger.info('Failure in E-Signing due to name mismatch');
                      NeslResp = {
                        "ErrorCode": "04",
                        "ErrorMsg": "Failure in E-Signing due to name mismatch",
                        "htmlBody": null
                      }
                      resolve(NeslResp);
                    }
                  }
                  else {
                    NeslResp = {
                      "ErrorCode": respNeSLDocUpdateDatabase.ErrorCode,
                      "ErrorMsg": respNeSLDocUpdateDatabase.ErrorMsg,
                      "htmlBody": null
                    }
                    logger.info(`Response: ${JSON.stringify(NeslResp)}`);
                    resolve(NeslResp);
                  }
                });
              }
            }
          }
        }
        else {
          NeslResp = {
            "ErrorCode": "01",
            "ErrorMsg": "Error during link generation in  Nesl. Please try after sometime",
            "htmlBody": null
          }
          resolve(NeslResp);
        }
      });

    } catch (err1) {
      reject(err1);
    }
  });
}


class LinkResponse {
  constructor(data) {
    this.transid = data.transid;
    this.statusCode = data.statusCode;
    this.statusMsg = data.statusMsg;
    this.seqNo = data.seqNo;
    this.relationShip = data.relationShip;
    this.esignLink = data.esignLink;
  }
}

app.post('/api/eSignCallBack', async (req, res) => {
  logger.info('');
  logger.info('############################### 1. Receive eSignCallBack via Call Back API START ###############################');
  logger.info('On Server page for NeSL CallBack API Logs');

  try {
    logger.info(`NeSL Complete Response:  ${JSON.stringify(req.body)}`);

    const NesleSignCallBackAPIResponseObj = new NesleSignCallBackAPIResponse(req.body[0]);
    logger.info(`NeSL NesleSignCallBackAPIResponseObj:  ${JSON.stringify(NesleSignCallBackAPIResponseObj)}`);
    const parseJSON = JSON.parse(JSON.stringify(NesleSignCallBackAPIResponseObj));
    const headers = req.headers;
    logger.info(`Response Headers in CallBack API: ${JSON.stringify(headers)}`);
    // Access the 'txnid' header
    let NeSL_TxnID = headers['txnid'];  // Headers are case-insensitive, so use lowercase
    logger.info(`NeSL Response in CallBack API for Txn No: ${NeSL_TxnID}`);
    if (NeSL_TxnID == null) {
      NeSLresp = {
        "txnID": NeSL_TxnID,
        "status": "txnID filed is missing",
        "statusCode": "002"
      }
      logger.info('CallBack Failed Response: ' + JSON.stringify(NeSLresp)); // Empty string or value
      return res.json(NeSLresp);
    }

    logger.info(`NeSL Response in CallBack API: ${JSON.stringify(parseJSON, null, 2)}`);



    logger.info('');
    logger.info('');
    logger.info('Log All the Data in NeSL Doc Data API');
    logger.info(`signatoryName: ${parseJSON.signatoryName}`); // Nel_10014500
    logger.info(`matchPercentage: ${parseJSON.matchPercentage}`); // 1
    logger.info(`eSignAffixed: ${parseJSON.eSignAffixed}`); // Success
    logger.info(`eStampAffixed: ${parseJSON.eStampAffixed}`); // Empty string or value

    NeSLLink_UpdateNeSLData_BankSignAffix_CallBackAPI(NeSL_TxnID, parseJSON).then(async (respNeSLDocUpdateDatabase) => {
      logger.info(`Output NeSLLink_UpdateNeSLData_BankSignAffix API ${JSON.stringify(respNeSLDocUpdateDatabase)}`);

      if (respNeSLDocUpdateDatabase.ErrorCode == "00") {
        NeSLresp = {
          "txnID": NeSL_TxnID,
          "status": "Received successfully",
          "statusCode": "001"
        }
        return res.json(JSON.stringify(NeSLresp));
      }
      else {
        NeSLresp = {
          "txnID": NeSL_TxnID,
          "status": "Error",
          "statusCode": "000"
        }
        return res.json(JSON.stringify(NeSLresp));
      }
    });
  }
  catch (exception) {
    logger.info('Exception in eSignCallBack API' + exception);
  }


});


class NesleSignCallBackAPIResponse {
  constructor(data) {
    this.docId = data.docId || '',
      this.uin = data.uin || '',
      this.reltocntrct = data.reltocntrct || '',
      this.signedDocData = data.signedDocData || '',
      this.signatoryName = data.signatoryName || '',
      this.signedName = data.signedName || '',
      this.matchPercentage = data.matchPercentage || '',
      this.signatoryAadhar = data.signatoryAadhar || '',
      this.signedAadhar = data.signedAadhar || '',
      this.signatoryYob = data.signatoryYob || '',
      this.signedYob = data.signedYob || '',
      this.signatoryGender = data.signatoryGender || '',
      this.signedGender = data.signedGender || '',
      this.eSignAffixed = data.eSignAffixed || '',
      this.eStampAffixed = data.eStampAffixed || '',
      this.genderPercent = data.genderPercent || '',
      this.yobPercent = data.yobPercent || '',
      this.aadharPercent = data.aadharPercent || ''
  }
}

function NeSLLink_UpdateNeSLData_BankSignAffix_CallBackAPI(NeSL_TxnID, NesleSignCallBackAPIResponseObj) {
  logger.info('###################### Inside NeSLLink_UpdateNeSLData_BankSignAffix_CallBackAPI Method######################');
  logger.info('Serilizied Object', JSON.stringify(NesleSignCallBackAPIResponseObj));
  logger.info('');
  logger.info('');
  logger.info(`NeslTranID, ${NeSL_TxnID}`);

  return new Promise((resolve, reject) => {

    objGeneralOperation.GetDataBasedOnNeslTxnID(NeSL_TxnID).then(async (GetDataBasedOnNeslTxnIDResp) => {
      logger.info(`Output GetDataBasedOnNeslTxnIDResp , ${GetDataBasedOnNeslTxnIDResp}`);
      if (GetDataBasedOnNeslTxnIDResp != null) {
        objNeSLLayer.updateNeSLResponse(NeSL_TxnID, JSON.parse(GetDataBasedOnNeslTxnIDResp).PMSNumber, JSON.parse(GetDataBasedOnNeslTxnIDResp).JourneyID, NesleSignCallBackAPIResponseObj, "CallBackAPIUpdate").then(async (respNeSLDocUpdateDatabase) => {
          logger.info('Output updateNeSLResponse: ' + JSON.stringify(respNeSLDocUpdateDatabase));
          if (respNeSLDocUpdateDatabase != "00") {
            NeslResp = {
              "ErrorCode": respNeSLDocUpdateDatabase.ErrorCode,
              "ErrorMessage": respNeSLDocUpdateDatabase.ErrorMsg,
              "htmlBody": null
            }
            logger.info(`Output response from updateNeSLResponse method: ${JSON.stringify(NeslResp)}`);
            resolve(NeslResp);
          }
          else {
            NeslResp = {
              "ErrorCode": respNeSLDocUpdateDatabase.ErrorCode,
              "ErrorMessage": respNeSLDocUpdateDatabase.ErrorMsg,
              "htmlBody": null
            }
            logger.info(`Response: ${JSON.stringify(NeslResp)}`);
            resolve(NeslResp);
          }
        });
      }
    });
  });
}
class NeSLReturnObj {
  constructor(txnID, status, doc_data, matchPercentage, nesl_api_signer) {
    this.txnID = txnID;
    this.status = status;
    this.doc_data = doc_data;
    this.matchPercentage = matchPercentage;
    this.nesl_api_signer = nesl_api_signer;
  }

  // Method to update the document (assumes NeSLDBO.updateDocumentNeslRsp exists)
  async updateReturnObj(NeSLTranID, PMSNumber, JourneyID) {
    // Call a function from another module (e.g., NeSLDBO)
    logger.info('Inside updateReturnObj Method ');
    return await objNeSLLayer.updateNeSLResponse(this, NeSLTranID, PMSNumber, JourneyID);
  }
}

function GetKeyConfigurationValue(KeyName) {
  logger.info('**************** Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  const query = `SELECT [KeyValue] FROM [PMSvanidhiDB].[dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;

  return new Promise((resolve, reject) => {
    const conn = new sql.ConnectionPool(config);
    conn.connect()
      .then(async (pool) => {
        logger.info('Query: ' + query);
        try {
          const result = await pool.request()
            .input('KeyName', sql.VarChar, KeyName)
            .query(query);

          logger.info('Result Length: ' + JSON.stringify(result));
          logger.info('Rows Affected: ' + result.rowsAffected[0]);

          if (result.recordsets && result.rowsAffected[0] > 0) {
            const ourValue = result.recordset[0].KeyValue;
            logger.info('ourValue: ' + ourValue);
            resolve(ourValue);  // Resolve the promise with the value
          } else {
            logger.info('No matching record found');
            resolve(null);  // No result, return null
          }
        } catch (err) {
          logger.error('Error during query execution: ' + err);
          reject(err);  // Reject if error occurs during query execution
        } finally {
          conn.close();  // Ensure connection is closed
        }
      })
      .catch((err) => {
        logger.error('Error connecting to the database: ' + err);
        reject(err);  // Reject if error occurs during connection
      });
  });
}

// function GetKeyConfigurationValue(KeyName) {
//   logger.info('**************** Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

//   try {
//     const query = `SELECT KeyValue FROM [PMSvanidhiDB].[dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`; 
//     var conn = new sql.ConnectionPool(config);
//      conn.connect().then(async function (pool) 
//     {      
//       logger.info('Query: ' + query);                           
//       const result = await pool.request()
//       .input('KeyName', sql.VarChar, KeyName)          
//       .query(query);

//        logger.info('Data Result: '+JSON.stringify(result));
//        logger.info('Record set Value: '+result.recordset[0].KeyValue);
//        logger.info('Rows Affacted: '+result.rowsAffected[0]);

//       if(result.recordsets && result.rowsAffected[0]>0)
//       {
//         conn.close();
//         let ourValue=result.recordset[0].KeyValue;  // Resolve the Promise with OutValue
//         logger.info('outValue '+ourValue);
//         return ourValue;
//       }

//       else{
//         logger.info('else part');
//         conn.close();
//        return null;
//       }
//     });                     
//   } catch (err1) {
//   logger.info('GetKeyConfigurationValue Exception: '+err1);
//   }  
// }

function calculateAmortizationSchedule1(principal, annualInterestRate, ROIAddsTwentyFiveBasis, LoanTenure) {
  logger.info('Inside calculateAmortizationSchedule method');
  logger.info('principal ' + principal);
  logger.info('annualInterestRate ' + annualInterestRate,);
  logger.info('ROIAddsTwentyFiveBasis ' + ROIAddsTwentyFiveBasis);
  logger.info('LoanTenure ' + LoanTenure);


  const monthlyInterestRate = annualInterestRate / 100 / 12;
  const AmortizationSchedule = [];
  let TotalInterest = 0;
  let TotalInstallment = 0;
  let TotalPrincipal = 0;

  // Calculate monthly payment
  const installmentAmount = (principal * monthlyInterestRate) / (1 - Math.pow(1 + monthlyInterestRate, -LoanTenure));
  const EMI1 = installmentAmount;

  // Calculate EMI for after increase of 25 basis points in ROI
  const monthlyInterestRateTwentyFiveBasis = (ROIAddsTwentyFiveBasis / 100) / 12;
  const EMI2 = (principal * monthlyInterestRateTwentyFiveBasis) / (1 - Math.pow(1 + monthlyInterestRateTwentyFiveBasis, -LoanTenure));

  let remainingBalance = principal;

  for (let month = 1; month <= LoanTenure + 1; month++) {
    if (month <= LoanTenure) {
      let interestPayment = remainingBalance * monthlyInterestRate;
      let principalPayment = installmentAmount - interestPayment;

      // Ensure that the principal payment does not exceed the remaining balance
      if (principalPayment > remainingBalance) {
        principalPayment = remainingBalance; // Adjust to not exceed remaining balance
      }

      remainingBalance -= principalPayment;
      TotalPrincipal += principalPayment;
      TotalInterest += interestPayment;
      TotalInstallment += installmentAmount;

      AmortizationSchedule.push({
        InstallmentNo: month.toString(),
        InstallmentAmount: EMI1.toFixed(2),
        PrincipalPart: principalPayment.toFixed(2),
        InterestPart: interestPayment.toFixed(2),
        OutstandingAmount: remainingBalance < 0 ? 0 : remainingBalance.toFixed(2) // Ensure no negative balance
      });
    } else {
      AmortizationSchedule.push({
        InstallmentNo: "Total",
        InstallmentAmount: TotalInstallment.toFixed(2),
        PrincipalPart: TotalPrincipal.toFixed(2),
        InterestPart: TotalInterest.toFixed(2),
        OutstandingAmount: null
      });
    }
  }

  return {
    "EMI1": EMI1.toFixed(2),
    "EMI2": EMI2.toFixed(2),
    "AmortSchedule": AmortizationSchedule,
    "TotalPrincipal": TotalPrincipal.toFixed(2),
    "TotalInterest": TotalInterest.toFixed(2),
    "TotalInstallment": TotalInstallment.toFixed(2)
  };
}


function calculateAmortizationSchedule(principal, annualInterestRate, ROIAddsTwentyFiveBasis, LoanTenure) {
  logger.info('Inside calculateAmortizationSchedule method');
  logger.info('principal ' + principal);
  logger.info('annualInterestRate ' + annualInterestRate);
  logger.info('ROIAddsTwentyFiveBasis ' + ROIAddsTwentyFiveBasis);
  logger.info('LoanTenure ' + LoanTenure);

  const monthlyInterestRate = annualInterestRate / 100 / 12;
  const monthlyInterestRateTwentyFiveBasis = ROIAddsTwentyFiveBasis / 100 / 12;

  const AmortizationSchedule = [];
  let TotalInterest = 0;
  let TotalInstallment = 0;
  let TotalPrincipal = 0;

  const fixedPrincipal = principal / LoanTenure;
  let remainingBalance = principal;

  for (let month = 1; month <= LoanTenure + 1; month++) {
    if (month <= LoanTenure) {
      let interestPayment = remainingBalance * monthlyInterestRate;
      let installmentAmount = fixedPrincipal + interestPayment;

      remainingBalance -= fixedPrincipal;
      TotalPrincipal += fixedPrincipal;
      TotalInterest += interestPayment;
      TotalInstallment += installmentAmount;

      AmortizationSchedule.push({
        InstallmentNo: month.toString(),
        InstallmentAmount: installmentAmount.toFixed(2),
        PrincipalPart: fixedPrincipal.toFixed(2),
        InterestPart: interestPayment.toFixed(2),
        OutstandingAmount: remainingBalance < 0 ? "0.00" : remainingBalance.toFixed(2)
      });
    } else {
      AmortizationSchedule.push({
        InstallmentNo: "Total",
        InstallmentAmount: TotalInstallment.toFixed(2),
        PrincipalPart: TotalPrincipal.toFixed(2),
        InterestPart: TotalInterest.toFixed(2),
        OutstandingAmount: null
      });
    }
  }

  // EMI1 and EMI2 are not applicable in fixed principal method, but you can still show first-month EMI
  const EMI1 = (fixedPrincipal + (principal * monthlyInterestRate)).toFixed(2);
  const EMI2 = (fixedPrincipal + (principal * monthlyInterestRateTwentyFiveBasis)).toFixed(2);
 // ***********************DATA TO BIND IN PDF DOCUMENT******************
logger.info("EMI1"+EMI1)
logger.info("EMI2"+EMI2)
logger.info("AmortizationSchedule"+AmortizationSchedule)
logger.info("TotalPrincipal"+TotalPrincipal.toFixed(2))
logger.info("TotalInterest"+TotalInterest.toFixed(2))
logger.info("TotalInstallment"+TotalInstallment.toFixed(2))



  return {
    EMI1,
    EMI2,
    AmortSchedule: AmortizationSchedule,
    TotalPrincipal: TotalPrincipal.toFixed(2),
    TotalInterest: TotalInterest.toFixed(2),
    TotalInstallment: TotalInstallment.toFixed(2)
  };
}




app.post('/api/CallCBSLoanAndCBSNPAStatusAPI', async (req, res) => {// HIII Call before Loan Account Opening at LoanAccountOpening.ts
  logger.info('');
  logger.info('');
  logger.info('############################### 4. Call CBS Loan And NPA Status API ((START)) ###############################');
  logger.info('');
  const { EncPayLoad } = req.body;
     
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
 decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';
if (decPayload && typeof decPayload === 'string' && decPayload.trim() !== '') {
  try {
     const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);
    logger.info('***************** getPMSDetails ((START))*********************');
 objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (RespCustomerJourneyData) => {
      logger.info('RespCustomerJourneyData ' + JSON.stringify(RespCustomerJourneyData));
      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
      objGeneralOperation.CBSToken(decResponse.PMSNumber, decResponse.JourneyID).then(async (TokenDetails) => {
        let objloanStatusInquiry = {
          "CustomerID": CustomerJourneyDataParsed.CustomerID,
          "Access_Token": TokenDetails.AccessToken,
          "LoanAmount": CustomerJourneyDataParsed.LoanAmount
        }

        logger.info("objloanStatusInquiry " + JSON.stringify(objloanStatusInquiry));
        logger.info('############################### 4. Call LoanStatusInquiryAPI ((START)) ###############################');
        objCBSLayer.LoanStatusInquiryAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.stringify(objloanStatusInquiry)).then(async (respLoanStatusInquiry) => {
          logger.info('Output LoanStatusInquiryAPI: ' + JSON.stringify(respLoanStatusInquiry));
          if (respLoanStatusInquiry.ErrorStatus == "Success" && respLoanStatusInquiry.ErrorCode == "00") { //Success          
            let objNPAStatusInquiry = {
              "CustomerID": CustomerJourneyDataParsed.CustomerID,
              "Access_Token": TokenDetails.AccessToken,
            }
            logger.info('############################### 4. SUCCESS Call LoanStatusInquiryAPI ((END)) ###############################');
            logger.info(''); logger.info('');

            logger.info('############################### 5. Call CallCBSNPAStatusAPIAPI ((START)) ###############################');
            objCBSLayer.NPAStatusInquiryAPI(decResponse.PMSNumber, decResponse.JourneyID, objNPAStatusInquiry).then(async (respNPAStatusInquiry) => {
              logger.info('Output NPAStatusInquiryAPI: ' + JSON.stringify(respNPAStatusInquiry));
              if (respNPAStatusInquiry.StatusCode == "Success" && respNPAStatusInquiry.ErrorCode == "00") {
                logger.info('############################### 5. SUCCESS CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                logger.info(''); logger.info('');
                Journeyresp = {
                  "ErrorCode": "00",
                  "ErrorMessage": respNPAStatusInquiry.ErrorMsg
                }
                logger.info("if JourneyResp: " + JSON.stringify(Journeyresp));
                logger.info('############################### 6. SUCCESS  CallCBSNPAStatusAPIAPI ((END)) ###############################');
                res.json(Journeyresp);

              }
              else if (respNPAStatusInquiry.ErrorStatus == "Failure" && respNPAStatusInquiry.ErrorCode == "02") { //Loan Status Inquiry          
                objNPAStatusInquiry = {
                  "ErrorCode": "01",
                  "ErrorMessage": respNPAStatusInquiry.ErrorMsg
                }
                logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                return res.json(objNPAStatusInquiry);
              }
              else if (respNPAStatusInquiry.ErrorCode == "03") {
                objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", 'Error02', respNPAStatusInquiry.ErrorMsg, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                  if (respUpdateJourneyStatus.ErrorCode == "00") {
                    objNPAStatusInquiry = {
                      "ErrorCode": "01",
                      "ErrorMessage": respNPAStatusInquiry.ErrorMsg
                    }
                    logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                    return res.json(objNPAStatusInquiry);
                  }
                });
              }
              else {
                //Update in database
                objNPAStatusInquiry = {
                  "ErrorCode": "01",
                  "ErrorMessage": respNPAStatusInquiry.ErrorMsg
                }
                logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
                logger.info(`objNPAStatusInquiry ${JSON.stringify(objNPAStatusInquiry)}`)

                return res.json(objNPAStatusInquiry);
              }
              // else{                
              //   //Update Rejected journey in Database, along with inactive journey due to NPA ,
              //   objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber,CustomerJourneyDataParsed.JourneyID,"Rejected",respNPAStatusInquiry.ErrorMsg).then(async (respUpdateJourneyStatus) => 
              //     {
              //     objNPAStatusInquiry={
              //       "ErrorCode":"01",
              //       "ErrorMessage":respNPAStatusInquiry.ErrorMsg                         
              //     }
              //     logger.info('############################### FAILURE CallCBSNPAStatusAPIAPI API ((END)) ###############################');
              //     return res.json(objNPAStatusInquiry);
              //   });               
              // }
            });
          }
          else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "02") { //Loan Status Inquiry        
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### FAILURE LoanStatusInquiryAPI API ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
          else if (respLoanStatusInquiry.ErrorCode == "03") { //Loan Status Inquiry Business/NPA exists  
            //RJ000012:Credit rating is adverse
            objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000012", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
              logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI7: " + JSON.stringify(respObjUpdateSIDBI));
              if (respObjUpdateSIDBI.ErrorCode == "00") {
                objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", 'Error01', respLoanStatusInquiry.ErrorMsg, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                  logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney:  " + JSON.stringify(respUpdateJourneyStatus));

                  objRejectedJourney = {
                    "ErrorCode": "01",
                    "ErrorMessage": respLoanStatusInquiry.ErrorMsg
                  }
                  logger.info('Response control to UI ' + JSON.stringify(objRejectedJourney));
                  return res.json(objRejectedJourney);

                });
              }
              else {
                CIBILResp = {
                  "ErrorCode": "01",
                  "ErrorMessage": "Error to update rejected status at SIDBI"
                }
                return res.json(CIBILResp);
              }
            });
          }
          else {
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
          // else{
          //   //Update in database
          //   //Update Rejected journey in Database, along with inactive journey,
          //   objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber,CustomerJourneyDataParsed.JourneyID,"Rejected",respLoanStatusInquiry.ErrorMsg).then(async (respUpdateJourneyStatus) => 
          //     {
          //       respLoanStatusInquiry={
          //         "ErrorCode":"01",
          //         "ErrorMessage":respLoanStatusInquiry.ErrorMsg
          //        }
          //       logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');  
          //       return res.json(respLoanStatusInquiry);
          //   });           
          // }
        });
      });
    });
   
  } catch (error) {
    logger.error(`Failed to parse decPayload: ${error.message}`);
  }
} else {
  logger.error('Invalid or empty decPayload:', decPayload);
}  
  });
});

app.post('/api/CallCBSLoanStatusAPI', async (req, res) => {// Call before Loan Account Opening at LoanAccountOpening.ts
  logger.info('');
  logger.info('');
  logger.info('############################### 4. Call CallCBSLoanStatusAPI ((START)) ###############################');
  logger.info('');
  const { EncPayLoad } = req.body;
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);

    objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (RespCustomerJourneyData) => {
      logger.info('RespCustomerJourneyData ' + JSON.stringify(RespCustomerJourneyData));
      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
      objGeneralOperation.CBSToken(decResponse.PMSNumber, decResponse.JourneyID).then(async (TokenDetails) => {
        let objloanStatusInquiry = {
          "CustomerID": CustomerJourneyDataParsed.CustomerID,
          "Access_Token": TokenDetails.AccessToken,
          "LoanAmount": CustomerJourneyDataParsed.LoanAmount
        }

        logger.info("objloanStatusInquiry " + JSON.stringify(objloanStatusInquiry));
        logger.info('############################### 4. Call LoanStatusInquiryAPI ((START)) ###############################');
        objCBSLayer.LoanStatusInquiryAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.stringify(objloanStatusInquiry)).then(async (respLoanStatusInquiry) => {
          logger.info('Output LoanStatusInquiryAPI: ' + JSON.stringify(respLoanStatusInquiry));
          if (respLoanStatusInquiry.ErrorStatus == "Success" && respLoanStatusInquiry.ErrorCode == "00") { //Success          
            let LoanStatusInquiry = {
              "ErrorCode": respLoanStatusInquiry.ErrorCode,
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg,
            }
            logger.info("Response for UI: " + JSON.stringify(LoanStatusInquiry));
            return res.json(LoanStatusInquiry);
          }
          else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "03") { //Loan Status Inquiry 
            //RJ000013:Already NPA in said bank
            const APIURL = await GetKeyConfigurationValue('SIDBI_Rejected_API_URL');
            logger.info(`CustomerJourneyDataParsed AadhaarNo: ${CustomerJourneyDataParsed.AadhaarNo}`);
            objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
              logger.info(`Output getCityKYCInfoData: ${JSON.stringify(CityKYCStatusDetails)}`);
              if (CityKYCStatusDetails != null) {
                objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000013", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
                  logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI8: " + JSON.stringify(respObjUpdateSIDBI));
                  logger.info("Output ErrorCode: " + respObjUpdateSIDBI.ErrorCode);
                  logger.info("Output ErrorMsg: " + respObjUpdateSIDBI.ErrorMsg);
                  if (respObjUpdateSIDBI.ErrorCode == "00") {
                    objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", 'Error01', respLoanStatusInquiry.ErrorMsg, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                      if (respObjUpdateSIDBI.StatusCode == "N") {
                        objRejectedJourney = {
                          "ErrorCode": "03",
                          "ErrorMessage": "You have already availed a Business Loan/NPA with PNB. Please contact your PNB branch for further assistance"
                        }
                      } else {
                        objRejectedJourney = {
                          "ErrorCode": "01",
                          "ErrorMessage": respObjUpdateSIDBI.ErrorMsg
                        }
                      }
                      logger.info('############################### FAILURE CallLoanStatusAPIAPI API ((END)) ###############################');
                      logger.info("Response: " + JSON.stringify(objRejectedJourney));
                      return res.json(objRejectedJourney);
                    });
                  }
                  else {
                    objRejectedJourney = {
                      "ErrorCode": "01",
                      "ErrorMessage": "Unable to update rejected status at SIDBI"
                    }
                    logger.info('############################### FAILURE CallLoanStatusAPIAPI API ((END)) ###############################');
                    return res.json(objRejectedJourney);
                  }
                });
              }
            });
          }
          else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "02") { //Loan Status Inquiry          
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### FAILURE LoanStatusInquiryAPI API ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
          else {
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
        });
      });
    });
  });
});




app.post('/api/CallCBSLoanStatusAPIM', async (req, res) => {// Call before Loan Account Opening at LoanAccountOpening.ts using APIM
  logger.info('');
  logger.info('');
  logger.info('############################### 4. Call CBS Loan  APIM ((START)) ###############################');
  logger.info('');
  const { EncPayLoad } = req.body;
     
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
 decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';
if (decPayload && typeof decPayload === 'string' && decPayload.trim() !== '') {
  try {
     const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);
    logger.info('***************** getPMSDetails ((START))*********************');
 objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (RespCustomerJourneyData) => {
      logger.info('RespCustomerJourneyData ' + JSON.stringify(RespCustomerJourneyData));
      let CustomerJourneyDataParsed = JSON.parse(RespCustomerJourneyData);
	  
	

const trancheSchemeMap = {
    1: "TLSVF",
    2: "TLSVS",
    3: "TLSVT"
};

let schemeCode = trancheSchemeMap[CustomerJourneyDataParsed.LoanTranche];
console.log(schemeCode);

      objGeneralOperation.APIMToken(decResponse.PMSNumber, decResponse.JourneyID).then(async (TokenDetails) => {
      
         let objloanStatusInquiry = {
          "CustomerID": CustomerJourneyDataParsed.CustomerID,
          "Access_Token": TokenDetails.AccessToken,
          "LoanAmount": CustomerJourneyDataParsed.LoanAmount,
          "SchmCode":schemeCode
         
        }


        logger.info("objloanStatusInquiry " + JSON.stringify(objloanStatusInquiry));
        logger.info('############################### 4. Call LoanStatusInquiryAPI ((START)) ###############################');
        objCBSLayer.APIMLoanStatusInquiryAPI(decResponse.PMSNumber, decResponse.JourneyID, JSON.stringify(objloanStatusInquiry)).then(async (respLoanStatusInquiry) => {
          logger.info('Output LoanStatusInquiryAPI: ' + JSON.stringify(respLoanStatusInquiry));
          if (respLoanStatusInquiry.ErrorStatus == "Success" && respLoanStatusInquiry.ErrorCode == "00") { //Success          
             respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### 4. SUCCESS Call LoanStatusInquiryAPI ((END)) ###############################');
            logger.info(''); logger.info('');

             return res.json(respLoanStatusInquiry);
          }
          else if (respLoanStatusInquiry.ErrorStatus == "Failure" && respLoanStatusInquiry.ErrorCode == "02") { //Loan Status Inquiry        
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### FAILURE LoanStatusInquiryAPI API ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
          else if (respLoanStatusInquiry.ErrorCode == "03") { //Loan Status Inquiry Business/NPA exists  
            //RJ000012:Credit rating is adverse
            objSIDBILayer.CallSIDBI_SanctionedOrDisbursedStatusAPI(decResponse.PMSNumber, decResponse.JourneyID, "RJ000012", APIURL, CityKYCStatusDetails).then(async (respObjUpdateSIDBI) => {
              logger.info("Output CallSIDBI_SanctionedOrDisbursedStatusAPI7: " + JSON.stringify(respObjUpdateSIDBI));
              if (respObjUpdateSIDBI.ErrorCode == "00") {
                objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(decResponse.PMSNumber, decResponse.JourneyID, CustomerJourneyDataParsed.LoanTranche, "Rejected", 'Error01', respLoanStatusInquiry.ErrorMsg, respObjUpdateSIDBI.StatusCode).then(async (respUpdateJourneyStatus) => {
                  logger.info("Output Sanctioned_Rejected_Suspended_CustomerJourney:  " + JSON.stringify(respUpdateJourneyStatus));

                  objRejectedJourney = {
                    "ErrorCode": "01",
                    "ErrorMessage": respLoanStatusInquiry.ErrorMsg
                  }
                  logger.info('Response control to UI ' + JSON.stringify(objRejectedJourney));
                  return res.json(objRejectedJourney);

                });
              }
              else {
                CIBILResp = {
                  "ErrorCode": "01",
                  "ErrorMessage": "Error to update rejected status at SIDBI"
                }
                return res.json(CIBILResp);
              }
            });
          }
          else {
            respLoanStatusInquiry = {
              "ErrorCode": "01",
              "ErrorMessage": respLoanStatusInquiry.ErrorMsg
            }
            logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');
            return res.json(respLoanStatusInquiry);
          }
          // else{
          //   //Update in database
          //   //Update Rejected journey in Database, along with inactive journey,
          //   objGeneralOperation.Sanctioned_Rejected_Suspended_CustomerJourney(PMSNumber,CustomerJourneyDataParsed.JourneyID,"Rejected",respLoanStatusInquiry.ErrorMsg).then(async (respUpdateJourneyStatus) => 
          //     {
          //       respLoanStatusInquiry={
          //         "ErrorCode":"01",
          //         "ErrorMessage":respLoanStatusInquiry.ErrorMsg
          //        }
          //       logger.info('############################### 4. FAILURE LoanStatusInquiryAPI ((END)) ###############################');  
          //       return res.json(respLoanStatusInquiry);
          //   });           
          // }
        });
      });
    });
   
  } catch (error) {
    logger.error(`Failed to parse decPayload: ${error.message}`);
  }
} else {
  logger.error('Invalid or empty decPayload:', decPayload);
}  
  });
});





app.post('/api/CallCBSLoanAccountOpeningAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### Call CBSLoanAccountOpening API ((START)) ###############################');
  logger.info('');
  const { EncPayLoad } = req.body;
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);
    objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (RespCustomerJourneyData) => {
      if (RespCustomerJourneyData != null) {
        logger.info(JSON.parse(RespCustomerJourneyData).JourneyMilestone);
        if (JSON.parse(RespCustomerJourneyData).JourneyMilestone == 107) {
          objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
            if (CityKYCStatusDetails != null) {
              objGeneralOperation.CBSToken(decResponse.PMSNumber, decResponse.JourneyID).then(async (TokenDetails) => {
                objGeneralOperation.getBranchInformation(JSON.parse(CityKYCStatusDetails).solid).then(async (RespBranchInformation) => {
                  objCBSLayer.CBSLoanAccountOpeningAPI(decResponse.PMSNumber, decResponse.JourneyID, decResponse.CustomerID, TokenDetails.AccessToken, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation).then(async (respLoanAccountOpening) => {
                    logger.info('Output CBSLoanAccountOpeningAPI : ' + JSON.stringify(respLoanAccountOpening));
                    if (respLoanAccountOpening.Status == "Success" && respLoanAccountOpening.ErrorCode == "00") {
                      objLoanAccountOpening = {
                        "ErrorCode": respLoanAccountOpening.ErrorCode,
                        "ErrorMessage": respLoanAccountOpening.ErrorMsg
                      }
                      return res.json(objLoanAccountOpening);
                    }
                    else {
                      //For Failure message
                      objLoanAccountOpening = {
                        "ErrorCode": respLoanAccountOpening.ErrorCode,
                        "ErrorMessage": respLoanAccountOpening.ErrorMsg
                      }
                      logger.info('objLoanAccountOpening out: ' + JSON.stringify(objLoanAccountOpening));
                      logger.info('############################### Call CBSLoanAccountOpening API ((END)) ###############################');
                      return res.json(objLoanAccountOpening);
                    }
                  });
                });
              })
            }
          });
        }
        else {
          //For Failure message
          objLoanAccountOpening = {
            "ErrorCode": "00",
            "ErrorMessage": "Loan Account Succesfully opened."
          }
          logger.info('objLoanAccountOpening out: ' + JSON.stringify(objLoanAccountOpening));
          logger.info('############################### Call CBSLoanAccountOpening API ((END)) ###############################');
          return res.json(objLoanAccountOpening);
        }
      }
    });

  });
});







app.post('/api/CallAPIMLoanAccountOpeningAPI', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### Call CBSLoanAccountOpening API ((START)) ###############################');
  logger.info('');
  const { EncPayLoad } = req.body;
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
     decPayload = '{"AadhaarNumber":"PNB131574606407","PMSNumber":"PMS07200026209","JourneyID":"PNB_SVND_000020210","CustomerID":"O38612550"}';
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);
    objGeneralOperation.getCustomerJourneyData(decResponse.PMSNumber).then(async (RespCustomerJourneyData) => {
      if (RespCustomerJourneyData != null) {
        logger.info(JSON.parse(RespCustomerJourneyData).JourneyMilestone);
        if (JSON.parse(RespCustomerJourneyData).JourneyMilestone == 107) {
          refKey='PNB131574606407'
          objGeneralOperation.getCityKYCInfoData(refKey).then(async (CityKYCStatusDetails) => {
            if (CityKYCStatusDetails != null) {
              objGeneralOperation.APIMToken(decResponse.PMSNumber, decResponse.JourneyID).then(async (TokenDetails) => {
                objGeneralOperation.getBranchInformation(JSON.parse(CityKYCStatusDetails).solid).then(async (RespBranchInformation) => {
                  objCBSLayer.APIMLoanAccountOpeningAPI(decResponse.PMSNumber, decResponse.JourneyID, decResponse.CustomerID, TokenDetails.AccessToken, CityKYCStatusDetails, RespCustomerJourneyData, RespBranchInformation).then(async (respLoanAccountOpening) => {
                    logger.info('Output CBSLoanAccountOpeningAPI : ' + JSON.stringify(respLoanAccountOpening));
                    if (respLoanAccountOpening.Status == "Success" && respLoanAccountOpening.ErrorCode == "00") {
                      objLoanAccountOpening = {
                        "ErrorCode": respLoanAccountOpening.ErrorCode,
                        "ErrorMessage": respLoanAccountOpening.ErrorMsg
                      }
                      return res.json(objLoanAccountOpening);
                    }
                    else {
                      //For Failure message
                      objLoanAccountOpening = {
                        "ErrorCode": respLoanAccountOpening.ErrorCode,
                        "ErrorMessage": respLoanAccountOpening.ErrorMsg
                      }
                      logger.info('objLoanAccountOpening out: ' + JSON.stringify(objLoanAccountOpening));
                      logger.info('############################### Call CBSLoanAccountOpening API ((END)) ###############################');
                      return res.json(objLoanAccountOpening);
                    }
                  });
                });
              })
            }
          });
        }
        else {
          //For Failure message
          objLoanAccountOpening = {
            "ErrorCode": "00",
            "ErrorMessage": "Loan Account Succesfully opened."
          }
          logger.info('objLoanAccountOpening out: ' + JSON.stringify(objLoanAccountOpening));
          logger.info('############################### Call CBSLoanAccountOpening API ((END)) ###############################');
          return res.json(objLoanAccountOpening);
        }
      }
    });

  });
});








app.post('/api/GetLoanAccountData', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('############################### Call GetLoanAccountData ((START)) ###############################');
  logger.info('');
  const { EncPayLoad } = req.body;
  objCommonFunction.Decrypt(EncPayLoad).then(async (decPayload) => {
    const decResponse = JSON.parse(decPayload);
    logger.info('EncPayLoad: ' + decResponse);
    logger.info("decPayload AadhaarNo: ", decResponse.AadhaarNumber);
    logger.info("decPayload PMSNumber: ", decResponse.PMSNumber);
    logger.info("decPayload JourneyID: ", decResponse.JourneyID);
    logger.info("decPayload CustomerID: ", decResponse.CustomerID);
    objGeneralOperation.GetLoanAccountData(decResponse.PMSNumber, decResponse.JourneyID, decResponse.AadhaarNumber, decResponse.CustomerID).then(async (RespgetGetLoanAccountData) => {
      logger.info('Output GetLoanAccountData ' + JSON.stringify(RespgetGetLoanAccountData));

      objLoanAccountData = {
        "ErrorCode": "00",
        "ErrorMessage": "",
        "LoanAccNumber": JSON.parse(RespgetGetLoanAccountData).LoanAccountNumber,
        "CustomerName": JSON.parse(RespgetGetLoanAccountData).CustomerName
      }
      logger.info('objLoanAccountData ' + JSON.stringify(objLoanAccountData));
      return res.json(objLoanAccountData);

      // objGeneralOperation.CBSToken(decResponse.PMSNumber,decResponse.JourneyID).then(async (TokenDetails) => {
      // objCBSLayer.PushQRCodeData(decResponse.PMSNumber,decResponse.JourneyID,RespgetPushQRCodeData,TokenDetails.AccessToken).then(async (respPushQRCodeData) => {
      //   logger.info('Output respPushQRCodeData: '+JSON.stringify(respPushQRCodeData));
      //   if(respPushQRCodeData.ErrorStatus == "S" && respPushQRCodeData.ErrorCode=="00") 
      //   {
      //     objPushQRCodeData={
      //       "ErrorCode":respPushQRCodeData.ErrorCode,
      //       "ErrorMessage":respPushQRCodeData.ErrorMsg,
      //       "LoanAccNumber":JSON.parse(RespgetPushQRCodeData).LoanAccountNumber                                 
      //      }
      //      logger.info('PushQRCodeData '+JSON.stringify(objPushQRCodeData));
      //      return res.json(objPushQRCodeData); 
      //   }
      //   else{
      //     objPushQRCodeData={
      //       "ErrorCode":respPushQRCodeData.ErrorCode,
      //       "ErrorMessage":respPushQRCodeData.ErrorMsg,
      //       "LoanAccNumber":''                      
      //      }
      //      logger.info('PushQRCodeData '+JSON.stringify(objPushQRCodeData));
      //      return res.json(objPushQRCodeData); 
      //   }
      // });
      // });
    });
  });
});

app.post('/api/DownloadLoanApplication', async (req, res) => {
  logger.info('############################### Call DownloadLoanApplication API START ###############################');
  const { EncPayLoad, NeslStatus } = req.body;

  try {
    const decPayload = await objCommonFunction.Decrypt(EncPayLoad);
    const decResponse = JSON.parse(decPayload);

    logger.info("PMSNumber: " + decResponse.PMSNumber);
    logger.info("JourneyID: " + decResponse.JourneyID);

    const respDownloadLoanApp = await objGeneralOperation.DownloadLoanApplication(
      decResponse.PMSNumber,
      decResponse.JourneyID,
      NeslStatus
    );

    if (respDownloadLoanApp) {
      // ✅ Return raw object, no extra stringify
      return res.json(respDownloadLoanApp);
    } else {
      return res.status(404).json({ message: "No document found" });
    }
  } catch (err) {
    logger.error("Mid-layer error: " + err);
    return res.status(500).json({ message: "Internal Server Error" });
  }
});


app.post('/api/NeSLFailedDocSubmit', async (req, res) => {
  logger.info('');
  logger.info('');
  logger.info('********************Inside  NeSLFailedDocSubmit ((START))**************************');
  const { PMSNumber, JourneyID } = req.body;

  objGeneralOperation.NeSLFailedDocSubmit(PMSNumber, JourneyID).then(async (objNeSLRejectedDocSubmit) => {
    logger.info(`OUTPUT NeSLFailedDocSubmit: ${JSON.stringify(objNeSLRejectedDocSubmit)}`);
    logger.info('');
    docUploadResponse = {
      "ErrorCode": objNeSLRejectedDocSubmit.ErrorCode,
      "ErrorMessage": objNeSLRejectedDocSubmit.ErrorMsg
    }
    logger.info('Response after loan document upload ' + JSON.stringify(docUploadResponse));
    return res.json(JSON.stringify(docUploadResponse));
  });
});

app.post('/api/TestClick', async (req, res) => {
  logger.info(``);
  logger.info(`********************Inside  TestClick ((START))**************************`);

  let PMSNumber = 'PMS07200019639';
  let JourneyID = 'PNB_SVND_000010057';
  objGeneralOperation.getNeSLDocumentData(PMSNumber, JourneyID).then(async (objNeSLDocumentData) => {
    //logger.info('Output getNeSLDocumentData: '+JSON.stringify(objNeSLDocumentData));

    logger.info('get NeSL Doc Data from Database for bank sign affix ');
    const p12Buffer = objCommonFunction.loadBankCertPfx();
    const PFXbase64Encoded = p12Buffer.toString('base64');
    //logger.info('Base64String' + PFXbase64Encoded);
    const parsedData = JSON.parse(objNeSLDocumentData);
    logger.info('is Pending for Bank Sign:  ' + parsedData.isPendingForBankOfficialSign);

    let DocBase64Byte = '';
    if (parsedData && parsedData.Signed_NeSL_Doc_Byte) {
      const bufferData = Buffer.from(parsedData.Signed_NeSL_Doc_Byte);
      DocBase64Byte = bufferData.toString('base64');
      fs.writeFileSync('NeSLSignDocTranch1.pdf', DocBase64Byte);
    }
    //const bufferData = Buffer.from(JSON.parse(objNeSLDocumentData).Signed_NeSL_Bank_Doc_Byte);


    const outputDir1 = path.resolve(__dirname, '..', 'Logs', 'NeSlSignedDoc');
    const filePath1 = path.join(outputDir1, "NeSLSignDocTranch1.pdf");
    fs.writeFileSync(filePath1, DocBase64Byte);// Write the PDF


    objCBSLayer.BankSignAffix(PMSNumber, JourneyID, parsedData.NeSL_Tran_ID, PFXbase64Encoded, DocBase64Byte).then(async (respBankSignAffix) => {
      /// logger.info('Output BankSignAffix: '+JSON.stringify(respBankSignAffix));
      logger.info('Output BankSignAffix ErrorStatus: ' + respBankSignAffix.ErrorStatus);
      logger.info('Output BankSignAffix ErrorMsg: ' + respBankSignAffix.ErrorMsg);

      const DoccumetByteArray = Buffer.from(respBankSignAffix.DocData, 'base64')
      objCBSLayer.UpdateNeSLDocumentData(PMSNumber, JourneyID, parsedData.NeSL_Tran_ID, DoccumetByteArray, null, null, null, null, null, null
        , null, null, null, null, null, null, null, null, null, null, null, null, null, 'BankSignDocument', null).then(async (respUpdateNeslResponseDatabase) => {
          if (respUpdateNeslResponseDatabase != null) {
            if (respBankSignAffix.ErrorCode == "00") {
              objBankSignAffix = {
                "ErrorCode": respUpdateNeslResponseDatabase.ErrorCode,
                "ErrorMessage": respUpdateNeslResponseDatabase.ErrorMsg
              }
              return res.json(objLoanAccountOpening);
            }
            else {

              objBankSignAffix = {
                "ErrorCode": respUpdateNeslResponseDatabase.ErrorCode,
                "ErrorMessage": respUpdateNeslResponseDatabase.ErrorMsg
              }
              return res.json(objLoanAccountOpening);
            }
          }
        });

    });
  });


});

