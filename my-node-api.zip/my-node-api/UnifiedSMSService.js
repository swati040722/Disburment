// UnifiedSMSService.js

//const logger = require("./logger");
const getLogger = require('./logger');
const logger = getLogger('UnifiedSMSService');
const { SendKarixOTP } = require("./KarixDataLayer");
const { SendVFirstOTP } = require("./ValueFirstDataLayer");


/* ================================
   CONFIG (can move to DB later)
================================ */
const PROVIDER_PRIORITY = ["KARIX", "VFIRST"];
const MAX_RETRY = {
  KARIX: 2,
  VFIRST: 1
};

/* ================================
   UNIFIED SEND OTP
================================ */
async function SendOTPUnified(
  PMSNumber,
  JourneyID,
  OTPReqJson,
  JourneyType
) {
  logger.info("========== UNIFIED OTP SERVICE START ==========");
  logger.info("JourneyID: " + JourneyID);
  logger.info("PMSNumber: " + PMSNumber);

  let lastFailure = null;

  for (const provider of PROVIDER_PRIORITY) {
    const maxRetry = MAX_RETRY[provider];

    for (let attempt = 1; attempt <= maxRetry; attempt++) {
      logger.info(
        `Trying ${provider} | Attempt ${attempt} of ${maxRetry}`
      );

      try {
        let response;

        if (provider === "KARIX") {
          response = await SendKarixOTP(
            PMSNumber,
            JourneyID,
            OTPReqJson,
            JourneyType
          );
        } else if (provider === "VFIRST") {
          response = await SendVFirstOTP(
            PMSNumber,
            JourneyID,
            OTPReqJson,
            JourneyType
          );
        }

        logger.info(
          `${provider} Response: ${JSON.stringify(response)}`
        );

        if (response && response.ErrorCode === "00") {
          logger.info(
            `OTP SENT SUCCESSFULLY USING ${provider}`
          );

          return {
            ...response,
            ProviderUsed: provider
          };
        }

        lastFailure = response;
      } catch (err) {
        logger.error(
          `${provider} FAILED | Attempt ${attempt}`,
          err
        );

        lastFailure = {
          ErrorCode: "01",
          ErrorMsg: `${provider} exception occurred`
        };
      }
    }

    logger.warn(
      `${provider} exhausted retries. Switching provider...`
    );
  }

  logger.error("ALL SMS PROVIDERS FAILED");

  return {
    ErrorCode: "01",
    ErrorMsg:
      "OTP service temporarily unavailable. Please try again later.",
    LastFailure: lastFailure
  };
}

/* ================================
   EXPORT
================================ */
module.exports = {
  SendOTPUnified
};
