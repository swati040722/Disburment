// CommonFunction.js

const CryptoJS = require('crypto-js');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');


//const logger = require('./logger'); // Adjust path if needed
const getLogger = require('./logger');
const logger = getLogger('CommonFunctions');

// 🔐 Constants
const SwanidhiKeyData = '8fdfdb7245c044279078ea1966a096fa';                  //'6dd59482807c4a8fa17ba48e52e1b0ef';
const ivData = '1234567890123456';



const GCM_TAG_LENGTH = 16; // Authentication tag length (128 bits)

const TRANSFORMATION = 'aes-256-gcm';
const key = Buffer.from('8fdfdb7245c044279078ea1966a096fa', 'utf-8'); // 32-byte key
const iv = Buffer.from('8fdfdb7245c04427', 'utf-8'); // 16-byte IV (ensure it's a Buffer)
// Determine transformation based on your key length (32 bytes = aes-256)
const TRANSFORMATION_APIM = 'aes-256-gcm'; 
const TAG_BYTE_LENGTH_APIM = 16; 

// Assuming these are defined globally or passed in
const myKeyString = "8fdfdb7245c044279078ea1966a096fa"; // Your DigiIntegrationKey
const key_APIM = Buffer.from(myKeyString, 'utf8');

// C#: byte[] IV = Arrays.copyOf(key, 16);
const iv_APIM = Buffer.alloc(16, 0);
key.copy(iv_APIM, 0, 0, 16);







/* =========================
   🔒 AES ENCRYPT
========================= */
function Encrypt(PlainRequest) {
  //logger.info('================ ENCRYPT START ================');
 // logger.info('[Encrypt] Incoming PlainRequest : ' + PlainRequest);

  return new Promise((resolve, reject) => {
    try {
     // logger.info('[Encrypt] Using AES Algorithm : AES-CBC-PKCS7');

    //  logger.info('[Encrypt] SwanidhiKeyData (RAW) : ' + SwanidhiKeyData);
     // logger.info('[Encrypt] IV Data (RAW)        : ' + ivData);

      const varKEY = CryptoJS.enc.Utf8.parse(SwanidhiKeyData);
      const varIV  = CryptoJS.enc.Utf8.parse(ivData);

     // logger.info('[Encrypt] Parsed KEY (Hex) : ' + varKEY.toString());
    //  logger.info('[Encrypt] Parsed IV  (Hex) : ' + varIV.toString());

      const encrypted = CryptoJS.AES.encrypt(
        PlainRequest,
        varKEY,
        {
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
          iv: varIV
        }
      ).toString();

     // logger.info('[Encrypt] Encrypted Output (Base64) : ' + encrypted);
     // logger.info('================ ENCRYPT END ==================');

      resolve(encrypted);

    } catch (err) {
      logger.error('[Encrypt] ❌ Exception occurred', err);
      logger.info('================ ENCRYPT FAILED ================');
     // reject(err);
	 resolve(null);
    }
  });
}


/* =========================
   🔓 AES DECRYPT
========================= */
function Decrypt(EncryptedRequest) {
 // logger.info('================ DECRYPT START ================');
 // logger.info('[Decrypt] Incoming EncryptedRequest : ' + EncryptedRequest);

  return new Promise((resolve, reject) => {
    try {
  //    logger.info('[Decrypt] Using AES Algorithm : AES-CBC-PKCS7');

  //    logger.info('[Decrypt] SwanidhiKeyData (RAW) : ' + SwanidhiKeyData);
  //    logger.info('[Decrypt] IV Data (RAW)        : ' + ivData);

      const varKEY = CryptoJS.enc.Utf8.parse(SwanidhiKeyData);
      const varIV  = CryptoJS.enc.Utf8.parse(ivData);

  //    logger.info('[Decrypt] Parsed KEY (Hex) : ' + varKEY.toString());
  //    logger.info('[Decrypt] Parsed IV  (Hex) : ' + varIV.toString());

      const decrypted = CryptoJS.AES.decrypt(
        EncryptedRequest,
        varKEY,
        {
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
          iv: varIV
        }
      ).toString(CryptoJS.enc.Utf8);

    //  logger.info('[Decrypt] Decrypted Plain Text : ' + decrypted);
   //   logger.info('================ DECRYPT END ==================');

      resolve(decrypted);

    } catch (err) {
      logger.error('[Decrypt] ❌ Exception occurred', err);
      logger.info('================ DECRYPT FAILED ================');
      //reject(err);
	  resolve(null);
    }
  });
}




/**
 * FOR APIM 
 */
function APIMEncrypt(PlainRequest) {
    return new Promise((resolve, reject) => {
        try {
            const plaintext = JSON.stringify(PlainRequest);

            const cipher = crypto.createCipheriv(TRANSFORMATION_APIM, key_APIM, iv_APIM, { 
                authTagLength: TAG_BYTE_LENGTH_APIM 
            });

            // Encrypt the data
            const ciphertext = Buffer.concat([
                cipher.update(plaintext, 'utf8'), 
                cipher.final()
            ]);

            // Get the authentication tag
            const tag = cipher.getAuthTag();

            // C# doFinal returns [Ciphertext][Tag]. 
            // We DO NOT prepend the IV here because the C# code doesn't.
            const payload = Buffer.concat([ciphertext, tag]);

            resolve(payload.toString('base64'));
        } catch (err) {
            reject(err);
        }
    });
}

/**
 * Decrypts the output of the C# Encrypt method
 */
function APIMDecrypt(encryptedData) {
    return new Promise((resolve, reject) => {
        try {
            const all = Buffer.from(encryptedData, 'base64');

            // Since we didn't prepend the IV, the structure is:
            // [Ciphertext (0 to length-16)][Tag (last 16)]
            const ct = all.subarray(0, all.length - TAG_BYTE_LENGTH_APIM);
            const tag = all.subarray(all.length - TAG_BYTE_LENGTH_APIM);

            const decipher = crypto.createDecipheriv(TRANSFORMATION_APIM, key_APIM, iv_APIM, { 
                authTagLength: TAG_BYTE_LENGTH_APIM 
            });

            decipher.setAuthTag(tag);

            const pt = Buffer.concat([
                decipher.update(ct), 
                decipher.final()
            ]);

            resolve(JSON.parse(pt.toString('utf8')));
        } catch (err) {
            console.error("Decryption Error (MAC check likely failed if keys/IV mismatch):", err);
            reject(err);
        }
    });
}

















/* =========================
   🔑 SHA-256 HASH
========================= */
function OTPsha256Hash(value) {
  logger.info('[OTPsha256Hash] ▶ Enter');

  return new Promise((resolve, reject) => {
    try {
      logger.info('[OTPsha256Hash] Input length: ' + (value?.length || 0));

      const hash = crypto.createHash('sha256');
      hash.update(Buffer.from(value, 'utf8'));

      const result = hash.digest('hex');

      logger.info('[OTPsha256Hash] ✔ Hash generated');
      resolve(result);

    } catch (err) {
      logger.error('[OTPsha256Hash] ❌ Error', err);
      //reject(err);
	  resolve(null);
    }
  });
}

/* =========================
   🔐 PKCS5 AES ENCRYPT
========================= */
function PKCS5PaddingEncrypt(data, key) {
  logger.info('[PKCS5PaddingEncrypt] ▶ Enter');

  try {
    const decodedKey = Buffer.from(key, 'base64');
    const cipher = crypto.createCipheriv('aes-256-ecb', decodedKey, null);

    let encrypted = cipher.update(data, 'utf8', 'base64');
    encrypted += cipher.final('base64');

    logger.info('[PKCS5PaddingEncrypt] ✔ Encryption successful');
    return encrypted;

  } catch (err) {
    logger.error('[PKCS5PaddingEncrypt] ❌ Error', err);
    throw err;
  }
}

/* =========================
   🔓 PKCS5 AES DECRYPT
========================= */
function PKCS5PaddingDecrypt(data, key) {
  logger.info('[PKCS5PaddingDecrypt] ▶ Enter');

  try {
    const decodedKey = Buffer.from(key, 'base64');
    const decodedData = Buffer.from(data, 'base64');

    const decipher = crypto.createDecipheriv('aes-256-ecb', decodedKey, null);
    decipher.setAutoPadding(true);

    let decrypted = decipher.update(decodedData, null, 'utf8');
    decrypted += decipher.final('utf8');

    logger.info('[PKCS5PaddingDecrypt] ✔ Decryption successful');
    return decrypted;

  } catch (err) {
    logger.error('[PKCS5PaddingDecrypt] ❌ Error', err);
    throw err;
  }
}

/* =========================
   📜 CERT LOADERS
========================= */
function loadBankCertPfx() {
  const certificatePath = path.resolve(__dirname, 'Documents', 'PNB_DIGITALLOANS_DSC.pfx');
  logger.info('[loadBankCertPfx] Path: ' + certificatePath);

  if (!fs.existsSync(certificatePath)) {
    logger.error('[loadBankCertPfx] ❌ File not found');
    return null;
  }

  try {
    const buffer = fs.readFileSync(certificatePath);
    logger.info('[loadBankCertPfx] ✔ Certificate loaded');
    return buffer;
  } catch (err) {
    logger.error('[loadBankCertPfx] ❌ Error reading file', err);
    return null;
  }
}

function loadBankCertPEMKey() {
  const certificatePath = path.resolve(__dirname, 'Documents', 'certificate.p12');
  logger.info('[loadBankCertPEMKey] Path: ' + certificatePath);

  if (!fs.existsSync(certificatePath)) {
    logger.error('[loadBankCertPEMKey] ❌ File not found');
    return null;
  }

  logger.info('[loadBankCertPEMKey] ✔ Certificate loaded');
  return fs.readFileSync(certificatePath, 'utf8');
}

/* =========================
   🔑 RSA KEY LOADERS
========================= */
function loadPrivateKey() {
  const certificatePath = path.resolve(__dirname, 'Documents', 'private_key_nopass.pem');

  if (!fs.existsSync(certificatePath)) {
    logger.error('[loadPrivateKey] ❌ File not found');
    return null;
  }

  logger.info('[loadPrivateKey] ✔ Private key loaded');
  return fs.readFileSync(certificatePath, 'utf8');
}

function loadPublicKey() {
  const certificatePath = path.resolve(__dirname, 'Documents', 'public_cert.pem');

  if (!fs.existsSync(certificatePath)) {
    logger.error('[loadPublicKey] ❌ File not found');
    return null;
  }

  logger.info('[loadPublicKey] ✔ Public key loaded');
  return fs.readFileSync(certificatePath, 'utf8');
}

/* =========================
   🔐 RSA SESSION KEY OPS
========================= */
function EncryptSessionKey(sessionKey) {
  logger.info('[EncryptSessionKey] ▶ Enter');

  const privateKey = loadPrivateKey();
  if (!privateKey) throw new Error('Private key missing');

  const signed = crypto.privateEncrypt(
    {
      key: privateKey,
      padding: crypto.constants.RSA_PKCS1_PADDING,
    },
    Buffer.from(sessionKey)
  );

  logger.info('[EncryptSessionKey] ✔ Session key encrypted');
  return signed.toString('base64');
}

function DecryptSessionKey(encSessionKey) {
  logger.info('[DecryptSessionKey] ▶ Enter');

  const publicKey = loadPublicKey();
  if (!publicKey) throw new Error('Public key missing');

  const decrypted = crypto.publicDecrypt(
    {
      key: publicKey,
      padding: crypto.constants.RSA_PKCS1_PADDING,
    },
    Buffer.from(encSessionKey, 'base64')
  );

  logger.info('[DecryptSessionKey] ✔ Session key decrypted');
  return decrypted.toString('utf8');
}

function PrivatedecryptSessionKey(encryptedBase64Key) {
  logger.info('[PrivatedecryptSessionKey] ▶ Enter');

  const privateKey = loadPrivateKey();
  if (!privateKey) throw new Error('Private key missing');

  const decrypted = crypto.privateDecrypt(
    {
      key: privateKey,
      padding: crypto.constants.RSA_PKCS1_PADDING,
    },
    Buffer.from(encryptedBase64Key, 'base64')
  );

  logger.info('[PrivatedecryptSessionKey] ✔ Session key decrypted');
  return decrypted.toString();
}

/* =========================
   📦 EXPORTS
========================= */
module.exports = {
  Encrypt,
  Decrypt,
  APIMEncrypt,
  APIMDecrypt,
  OTPsha256Hash,
  PKCS5PaddingEncrypt,
  PKCS5PaddingDecrypt,
  PrivatedecryptSessionKey,
  loadPrivateKey,
  loadPublicKey,
  EncryptSessionKey,
  DecryptSessionKey,
  loadBankCertPEMKey,
  loadBankCertPfx
};
