// KarixDataLayer.js

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // Disable SSL check due to bank proxy

const express = require("express");
const axios = require("axios");
//const sql = require("mssql");
const https = require("https");
const { HttpsProxyAgent } = require("https-proxy-agent");

//const logger = require("./logger");
const getLogger = require('./logger');
const logger = getLogger('KarixDataLayer');
const logError = require("./ErrorLog");
const objCommonFunction = require("./CommonFunctions");
const { sql, getPool } = require('./db');

/* ============================
   SQL CONFIG (same as VFirst)
============================ */
// const config = {
//   user: "svanidhiuser",
//   password: "Dbtd@12345678",
//   server: "10.192.244.43",
//   port: 7701,
//   database: "PMSvanidhiDB",
//   options: { encrypt: false },
//   pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
// };

const config = {
  user: "nodejsuser",
  password: "Pnb@12345",
  server: "10.192.236.6",
  port: 1434,
  database: "PMSvanidhiDB",
  options: { encrypt: false,trustServerCertificate: true, },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};

//  const proxyAddress = "http://10.192.205.150:3128";
// const proxyUser = "5216750";
//  const proxyPass = "Welcome!12345";
//  const proxyUrl = `http://${proxyUser}:${proxyPass}@http://10.192.205.150:3128`;


//  const proxyUser = '5216750';
//  const proxyPass = 'Welcome!12345';
//  const proxyHost = '10.192.205.150';
//  const proxyPort = 3128;
 
//  // Construct correct proxy URL
//  const proxyUrl = `http://${proxyUser}:${proxyPass}@${proxyHost}:${proxyPort}`;
//  const agent = new HttpsProxyAgent(proxyUrl);
 

/* ============================
   PROXY CONFIG
============================ */
const proxyUrl  = process.env.HTTPS_PROXY || 'http://10.192.205.150:3128';               //"http://10.192.20.171:8001"
const ProxyAgent = new HttpsProxyAgent(proxyUrl); //111000

/* ============================
   SEND KARIX OTP
============================ */
function SendKarixOTP(PMSNumber, JourneyID, KarixOTPReq, JourneyType) {
  logger.info("********************** Inside SendKarixOTP **********************");
  logger.info("Request: " + KarixOTPReq);

  const parsedReq = JSON.parse(KarixOTPReq);
  const mobileNo = parsedReq.MobileNo;

  return new Promise(async (resolve) => {
    try {
      if (!mobileNo || mobileNo.length !== 10) {
        return resolve({
          ErrorCode: "01",
          ErrorMsg: "Invalid mobile number"
        });
      }

      const KarixDomain = await GetKeyConfigurationValue("KarixNewDomain");
      const KarixKey = await GetKeyConfigurationValue("SMSKey");

      const url = `https://${KarixDomain}/httpapi/JsonReceiver`;

      const otp = Math.floor(100000 + Math.random() * 900000);

      let message = "";
      if (JourneyType === "CustomerJourney") {
        message = `Dear Applicant, ${otp} is your OTP for your e-PM SVANidhi loan. Do not disclose. If not done by you, report on 1800 1800/1800 2021 as FRAUD.PNB`;
      } else {
        message = `Dear User, use OTP ${otp} to login into e-PM SVANidhi Portal -PNB`;
      }

      const requestBody = {
        ver: "1.0",
        encrpt: "0",
        key: KarixKey,
        messages: [
          {
            send: "PNBSMS",
            dest: ["91" + mobileNo],
            text: message
          }
        ]
      };

      logger.info("Karix URL: " + url);
      logger.info("Karix Request Body: " + JSON.stringify(requestBody));

      /* ============ INSERT API LOG ============ */
      const apiLog = await logError.APIRequestResponseLogs(
        PMSNumber,
        JourneyID,
        "SendKarixOTP",
        JSON.stringify(requestBody),
        JSON.stringify(requestBody),
        null,
        null,
        null,
        "Insert"
      );

      if (apiLog.ErrorCode !== "00") {
        return resolve({
          ErrorCode: "01",
          ErrorMsg: "Unable to log API request"
        });
      }

      /* ============ KARIX API CALL ============ */
      const response = await axios.post(url, requestBody, {
        httpsAgent: ProxyAgent,
       // httpsAgent: agent,
        headers: { "Content-Type": "application/json" }
      });

      logger.info("Karix Response: " + JSON.stringify(response.data));

      await logError.APIRequestResponseLogs(
        PMSNumber,
        JourneyID,
        null,
        null,
        null,
        JSON.stringify(response.data),
        JSON.stringify(response.data),
        apiLog.RequestId,
        "Update"
      );

      /* ============ OTP HASH & INSERT ============ */
      const otpHash = await objCommonFunction.OTPsha256Hash(otp.toString());

      const OTPReq = {
        UserID: mobileNo,
        OTPHash: otpHash,
        OTPMsg: "OTP Sent successfully"
      };

      const insertResp = await InsertKarixOTP(OTPReq);

      if (insertResp.ErrorCode === "00") {
        resolve({
          ErrorCode: "00",
          ErrorMsg:
            "OTP successfully sent to your registered mobile number ******" +
            mobileNo.substring(6)
        });
      } else {
        resolve(insertResp);
      }
    } catch (error) {
      logger.error("SendKarixOTP Error", error);

      await logError.ErrorLogs(
        PMSNumber,
        JourneyID,
        error.code || "KARIX_ERROR",
        error.message,
        "SendKarixOTP"
      );

      resolve({
        ErrorCode: "01",
        ErrorMsg:
          "System error occurred. Please retry after sometime or contact your branch for further assistance"
      });
    }
  });
}

/* ============================
   INSERT OTP
============================ */
// function InsertKarixOTP(OTPReq) {
  // logger.info("Inside InsertKarixOTP: " + JSON.stringify(OTPReq));

  // return new Promise(async (resolve) => {
    // try {
      // const pool = await sql.connect(config);

      // const result = await pool
        // .request()
        // .input("UserID", sql.NVarChar, OTPReq.UserID)
        // .input("OTPHash", sql.NVarChar, OTPReq.OTPHash)
        // .input("OTPReqMsg", sql.NVarChar, OTPReq.OTPMsg)
        // .input("Operation", sql.NVarChar, "Insert")
        // .output("p_OutStatus", sql.NVarChar)
        // .execute("proc_VFirstOTP_InsertUpdate"); // SAME PROC

      // if (
        // result.output.p_OutStatus === "200" &&
        // result.rowsAffected[0] === 1
      // ) {
        // resolve({
          // ErrorCode: "00",
          // ErrorMsg: "Karix OTP inserted successfully"
        // });
      // } else {
        // resolve({
          // ErrorCode: "01",
          // ErrorMsg: "Error inserting Karix OTP"
        // });
      // }
    // } catch (err) {
      // logger.error(err);
      // resolve({
        // ErrorCode: "01",
        // ErrorMsg: "DB error while inserting OTP"
      // });
    // }
  // });
// }



function InsertKarixOTP(OTPReq) {
  logger.info("Inside InsertKarixOTP: " + JSON.stringify(OTPReq));

  return new Promise(async (resolve) => {
    try {
      const pool = await getPool();

      const result = await pool
        .request()
        .input("UserID", sql.NVarChar, OTPReq.UserID)
        .input("OTPHash", sql.NVarChar, OTPReq.OTPHash)
        .input("OTPReqMsg", sql.NVarChar, OTPReq.OTPMsg)
        .input("Operation", sql.NVarChar, "Insert")
        .output("p_OutStatus", sql.NVarChar)
        .execute("proc_VFirstOTP_InsertUpdate"); // SAME PROC

      if (
        result.output.p_OutStatus === "200" &&
        result.rowsAffected[0] === 1
      ) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: "Karix OTP inserted successfully"
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: "Error inserting Karix OTP"
        });
      }
    } catch (err) {
      logger.error(err);
      resolve({
        ErrorCode: "01",
        ErrorMsg: "DB error while inserting OTP"
      });
    }
  });
}


/* ============================
   GET CONFIG VALUE
============================ */
// async function GetKeyConfigurationValue(KeyName) {
  // const query =
    // "SELECT KeyValue FROM dbo.SVND_CONFIGURATION_DATA WHERE KeyName=@KeyName";

  // const pool = await sql.connect(config);
  // const result = await pool
    // .request()
    // .input("KeyName", sql.VarChar, KeyName)
    // .query(query);

  // return result.recordset.length > 0
    // ? result.recordset[0].KeyValue
    // : null;
// }


async function GetKeyConfigurationValue(KeyName) {
  const query =
    "SELECT KeyValue FROM dbo.SVND_CONFIGURATION_DATA WHERE KeyName=@KeyName";

  const pool = await getPool();
  const result = await pool
    .request()
    .input("KeyName", sql.VarChar, KeyName)
    .query(query);

  return result.recordset.length > 0
    ? result.recordset[0].KeyValue
    : null;
}


/* ============================
   EXPORTS
============================ */
module.exports = {
  SendKarixOTP,
  InsertKarixOTP
};
