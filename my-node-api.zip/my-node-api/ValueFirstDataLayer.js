   //ValueFirstDataLayer.js

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';// Disable ssl check due to bank's proxy server

const express = require("express");
const axios = require('axios');
//const sql = require("mssql");
const app = express();
app.use(express.json())
var cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { sql, getPool } = require('./db');

app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

const {HttpsProxyAgent} = require('https-proxy-agent');//for System Proxy
const https = require('https');

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('VFirstDataLayer');
const objGeneralOperation = require('./GeneralDataLayer');
const logError = require('./ErrorLog');
const objCommonFunction = require('./CommonFunctions');
// Set up cookie parser middleware
app.use(cookieParser());
//SQL Server configuration
// var config = {
//   user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,    
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000
//   },
//   "options": {
//     "encrypt": false
//   }
// }

const config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

//Squid Proxy Details:
// const proxyAddress = "http://10.192.33.247:7001";
// const proxyUser = "5216750";
// const proxyPass = "Welcome!12345";
// const proxyUrl = `http://${proxyUser}:${proxyPass}@10.192.33.247:7001`;





// const proxyUser = '5216750';
// const proxyPass = 'Welcome!12345';
// const proxyHost = '10.192.205.150';
// const proxyPort = 3128;

// // Construct correct proxy URL
// const proxyUrl = `http://${proxyUser}:${proxyPass}@${proxyHost}:${proxyPort}`;
// const agent = new HttpsProxyAgent(proxyUrl);








// Define your proxy URL (you can get this from environment variables or hardcode it)
const proxyUrl = process.env.HTTPS_PROXY || 'http://dcproxy.pnb.net:3128';          //http://10.192.34.167:3128 //http://corpoffice.pnb.net:3128    //http://10.192.20.171:8001
// Create a new agent instance
const ProxyAgent = new HttpsProxyAgent(proxyUrl);


 const agent = new https.Agent({
    rejectUnauthorized: false, // Set to false to bypass certificate verification 
    HttpsProxyAgent:proxyUrl 
 });
const httpAgent = new https.Agent({
  rejectUnauthorized: false, // Set to false to bypass certificate verification 

});




function generateVFirstToken(PMSNumber,JourneyID) {
    logger.info('*****************inside generateVFirstToken Method*****************'); 
    logger.info('PMSNumber: '+PMSNumber); 
    
    return new Promise(async (resolve, reject) => { 
      try {
        // const VFIRSTAPIUserID = "pnbmsmejsn";
        // const VFIRSTAPIPassword = "EEZBTrtA4}";
        const VFIRSTAPIUserID= await GetKeyConfigurationValue('VFirstUserID');
        const VFIRSTAPIPassword= await GetKeyConfigurationValue('VFirstPassword');
        const VFIRST_TOKEN_GENERATE_URL= await GetKeyConfigurationValue('VFirstTokenAPI_URL');
        //const VFIRST_TOKEN_GENERATE_URL = 'https://api.myvfirst.com/psms/api/messages/token?action=generate';

        let authorizationData = 'Basic ' + btoa(VFIRSTAPIUserID + ':' + VFIRSTAPIPassword);
        logger.info('UserID&Password ' + authorizationData);
  
        headers = {
            'Authorization': authorizationData
        }
        const Emptybody = "Call VFirst token Generation with no data in body";
        //Insert Error Log
        logError.APIRequestResponseLogs(PMSNumber,JourneyID,"VFirstTokenGenerate",JSON.stringify(headers),JSON.stringify(headers),null,null,null,"Insert").then(async (APILogsResp) => {
            logger.info("Insert ErrorCode "+APILogsResp.ErrorCode)
            if(APILogsResp.ErrorCode=="00")
            {
             await axios.post(VFIRST_TOKEN_GENERATE_URL, Emptybody, {headers,httpsAgent: ProxyAgent}).then(async GenTokenResp => {

                logger.info('Resp Data: ', JSON.stringify(GenTokenResp.data));
               if(JSON.stringify(GenTokenResp.data)!="NaN")
               {
                logError.APIRequestResponseLogs(PMSNumber,JourneyID,null,null,null,JSON.stringify(GenTokenResp.data),JSON.stringify(GenTokenResp.data),APILogsResp.RequestId,"Update").then(async (APILogsResp) => {
                    logger.info("Update ErrorCode "+APILogsResp.ErrorCode)
                    if(APILogsResp.ErrorCode=="00")
                    {
                        VFirstToken_Insert(GenTokenResp.data).then(async (vFirstTokenRespInsert) => {
                        logger.info('Out VFirstToken_Insert Result: ',JSON.stringify(vFirstTokenRespInsert));          
                        if (vFirstTokenRespInsert.ErrorCode == "00") {
                          resp={
                            "ErrorCode":"00",
                            "ErrorMsg":"Token successfully generated and saved in database",
                            "VFirstToken":vFirstTokenRespInsert.VFirstToken
                          }
                          resolve(resp);
                        }
                     });
                    }
                }); 
               }
               else{
                logError.ErrorLogs(PMSNumber,JSON.stringify(GenTokenResp.data),JSON.stringify(GenTokenResp.data),"VFirstTokenGenerate").then(async (ErrorLogResp) => {               
                    ExceptionResp={
                        "ErrorCode":"01",
                        "ErrorMsg":"Error while calling VFirst Token Generate API",
                        }
                       logger.info("Error: "+ExceptionResp)
                    resolve(ExceptionResp);
                  });
               }                  
               })
              .catch(error => {
               // console.error('Error posting to SIDBI Status API:',error);
               // console.error('Error VFirst Token API Error Response:',error.response);
               // console.error('Error VFirst Token API Error Response Text:',error.response.statusText);
               // console.error('Error VFirst Token API Error Response data:',error.response.data);
                //Insert Error Log
                logError.ErrorLogs(PMSNumber,JourneyID,error.response.status,error.response.statusText,"VFirstTokenGenerate").then(async (ErrorLogResp) => {               
                 ExceptionResp={
                     "ErrorCode":"01",
                     "ErrorMsg":"System error occurred. Please retry after sometime or contact your branch for further assistance",
                     }                    
                   resolve(ExceptionResp);
               });
             });
            }
        });
          
    } catch (err1) {
      reject(err1);
    }
 });
}
// function VFirstToken_Insert(TokenAPIResp) {
    // logger.info('Inside VFirstToken_Insert Complete Token: ' +TokenAPIResp.token);
    // logger.info('Inside VFirstToken_Insert Access expiryDate: ' + TokenAPIResp.expiryDate);
    // return new Promise((resolve, reject) => {
      // try {          
              // const query = `INSERT INTO SVND_VALUEFIRST_TOKENS([token],[expiry]) VALUES (@token,@expiry)`;
              // var conn = new sql.ConnectionPool(config);
               // conn.connect().then(async function (pool) 
              // {      
                // logger.info('Query: ' + query);                           
                // const result = await pool.request()
                // .input('token', sql.Text, TokenAPIResp.token)
                // .input('expiry', sql.VarChar, TokenAPIResp.expiryDate)            
                // .query(query);
                // logger.info('Result Length: '+JSON.stringify(result));
                 // logger.info('Rows Affacted: '+result.rowsAffected[0]);
                // if(result.recordsets && result.rowsAffected[0]==1)
                // { formattedString={
                    // "ErrorCode":"00",
                    // "ErrorMsg":"ValurFirst API Token Inserted Successfully.",
                    // "VFirstToken":TokenAPIResp.token
                // }
                 // resolve(formattedString);              
                // }
                // else{
                  // logger.info('else:'); 
                  // formattedString1={
                    // "ErrorCode":"01",
                    // "ErrorMsg":"Error to insert VFisrt API Token in database."
                  // }                
                  // resolve(formattedString1);
                // }
              // });
            
      // } catch (err1) {
        // logger.info(err1);
        // reject(err1);
      // }
    // });  
  // }
  
  

function VFirstToken_Insert(TokenAPIResp) {
  logger.info('Inside VFirstToken_Insert Complete Token: ' + TokenAPIResp.token);
  logger.info('Inside VFirstToken_Insert Access expiryDate: ' + TokenAPIResp.expiryDate);

  return new Promise((resolve, reject) => {
    try {
      const query = `INSERT INTO SVND_VALUEFIRST_TOKENS([token],[expiry]) VALUES (@token,@expiry)`;

      (async () => {
        try {
          const pool = await getPool();

          logger.info('Query: ' + query);
          const result = await pool.request()
            .input('token', sql.Text, TokenAPIResp.token)
            .input('expiry', sql.VarChar, TokenAPIResp.expiryDate)
            .query(query);

          logger.info('Result Length: ' + JSON.stringify(result));
          logger.info('Rows Affacted: ' + result.rowsAffected[0]);

          if (result.recordsets && result.rowsAffected[0] === 1) {
            formattedString = {
              "ErrorCode": "00",
              "ErrorMsg": "ValurFirst API Token Inserted Successfully.",
              "VFirstToken": TokenAPIResp.token
            };
            resolve(formattedString);
          } else {
            logger.info('else:');
            formattedString1 = {
              "ErrorCode": "01",
              "ErrorMsg": "Error to insert VFisrt API Token in database."
            };
            resolve(formattedString1);
          }
        } catch (dbErr) {
          logger.info(dbErr);
          reject(dbErr);
        }
      })();

    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}


function SendVFirstOTP(PMSNumber,JourneyID,VfisrtOTPReq,JourneyType) {
    logger.info('**********************inside SendVFirstOTP  Method **********************');
    logger.info('Request: ' + VfisrtOTPReq);   
    let VfirstOTPParseReq=JSON.parse(VfisrtOTPReq);


    // logger.info('Mobile: ' + VfisrtOTPParseReq.MobileNo);
    // logger.info('Token: ' + VfisrtOTPParseReq.Token);
    
    
    //const VFIRST_SMS_API_URL = 'https://api.myvfirst.com/psms/servlet/psms.JsonEservice';
    return new Promise(async (resolve, reject) => {
      try {  
       
          const VFIRST_SMS_API_URL= await GetKeyConfigurationValue('VFirstSendSMS_API_URL');
          const otp = Math.floor(100000 + Math.random() * 900000);    
          
          let Message="";
          if(JourneyType="CustomerJourney")
          {
            Message='Dear Applicant, '+ otp +' is your OTP for your e-PM SVANidhi loan. Do not disclose. If not  done by you, report on 1800 1800/1800 2021 as FRAUD.PNB';
          }
          else if(JourneyType="BranchJourney")
          {
            Message='Dear User, use OTP '+ otp +' to login into e- PM SVANidhi Portal -PNB';
          }
          
          logger.info('Message: ' + Message);   
          
          var headers = {
            'Authorization': 'Bearer ' + VfirstOTPParseReq.Token
          };
          logger.info(headers);
          const SMSbody = {
            '@VER': "1.2",
            USER: {},
            DLR: { '@URL': '' },     
            SMS: [
              {
                '@UDH': '0',
                '@CODING': '1',
                '@TEXT': Message,
                '@PROPERTY': '0',
                '@ID': '1',
                ADDRESS: [
                  {
                    '@FROM': 'PNBSMS',
                    '@TO':VfirstOTPParseReq.MobileNo, //VfisrtOTPParseReq.MobileNo,
                    '@SEQ': '1',
                    '@TAG': ''
                  }
                ]
              }
            ]
          };
  
          logger.info('body: '+JSON.stringify(SMSbody)); 
          //Insert Error Log
          logError.APIRequestResponseLogs(PMSNumber,JourneyID,"SendVFirstOTP",JSON.stringify(SMSbody),JSON.stringify(SMSbody),null,null,null,"Insert").then(async (APILogsResp) => {
            logger.info("Insert ErrorCode "+APILogsResp.ErrorCode)
            if(APILogsResp.ErrorCode=="00")
            {
               // await axios.post(VFIRST_SMS_API_URL, SMSbody, {headers,httpsAgent: ProxyAgent}).then(async response => { //111000
                   await axios.post(VFIRST_SMS_API_URL, SMSbody, {headers,httpsAgent: agent}).then(async response => {
                    logger.info('ValueFirst SendOTP Response: ', JSON.stringify(response.data, null, 2));
                    //{"MESSAGEACK": {"GUID": {"SUBMITDATE": "2024-09-12 12:02:09","GUID": "ko9cc0209092h1f410a04e22n1PNBHRDLAWJ","ID": 1}}}
                    if(JSON.stringify(response.data, null, 2)!=null)
                    {                       
                        //insert otp data in database
                        logError.APIRequestResponseLogs(PMSNumber,JourneyID,null,null,null,JSON.stringify(response.data),JSON.stringify(response.data),APILogsResp.RequestId,"Update").then(async (APILogsResp) => {
                            logger.info("Update ErrorCode "+APILogsResp.ErrorCode)
                            if(APILogsResp.ErrorCode=="00")
                            {
                                objCommonFunction.OTPsha256Hash(otp.toString()).then(async (OTPHash) => {
                                let OTPReq={
                                     "UserID":VfirstOTPParseReq.MobileNo,
                                     "OTPHash":OTPHash,
                                     "OTPMsg":"OTP Sent successfully",
                                }
                                InsertVFirstOTP(OTPReq).then(async (VFirstOTPInsert) => {
                                    logger.info('After VFirstOTP_Insert Result: ', VFirstOTPInsert.ErrorCode);
                                    logger.info('After VFirstOTP_Insert Result: ', VFirstOTPInsert.ErrorMsg);
                                    if (VFirstOTPInsert.ErrorCode == "00") {
                                      resp={
                                        "ErrorCode":"00",
                                        "ErrorMsg":"OTP successfully sent to your registered mobile number " + "******" + VfirstOTPParseReq.MobileNo.substring(6) + "."
                                         }
                                         resolve(resp);
                                    }
                                    else{
                                      resp={
                                        "ErrorCode":VFirstOTPInsert.ErrorCode,
                                        "ErrorMsg":VFirstOTPInsert.ErrorMsg
                                         }
                                         resolve(resp);
                                    }
                                  });
                                });
                            }
                        });                       
                    
                    }
                  })
                  .catch(async (error) => {

    logger.error("================================================");
    logger.error("SendVFirstOTP - ValueFirst API FAILURE");
    logger.error("------------------------------------------------");
    logger.error("JourneyID : " + JourneyID);
    logger.error("PMSNumber : " + PMSNumber);

    /* ================= HTTP RESPONSE ERROR ================= */
    if (error.response) {
        logger.error("HTTP ERROR RECEIVED");
        logger.error("Status Code : " + error.response.status);
        logger.error("Status Text : " + error.response.statusText);
        logger.error("Response Body : ");
        logger.error(JSON.stringify(error.response.data, null, 2));

        await logError.ErrorLogs(
            PMSNumber,
            JourneyID,
            error.response.status,
            error.response.statusText,
            "SendVFirstOTP"
        );

    /* ================= NETWORK / CONNECTION RESET ================= */
    } else if (error.request) {
        logger.error("NO HTTP RESPONSE (Network / Connection Reset)");
        logger.error("Error Code : " + error.code);          // ECONNRESET
        logger.error("Error Msg  : " + error.message);

        await logError.ErrorLogs(
            PMSNumber,
            JourneyID,
            error.code || "NO_RESPONSE",
            error.message,
            "SendVFirstOTP"
        );

    /* ================= CODE / CONFIG ERROR ================= */
    } else {
        logger.error("REQUEST SETUP ERROR");
        logger.error("Error Msg : " + error.message);

        await logError.ErrorLogs(
            PMSNumber,
            JourneyID,
            "REQUEST_ERROR",
            error.message,
            "SendVFirstOTP"
        );
    }

    logger.error("================================================");

    // 🔁 Always return a controlled response to caller
    resolve({
        "ErrorCode": "01",
        "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
    });
});

            }
            });  
          
      } catch (err1) {
        reject(err1);
      }
    });
}

// function InsertVFirstOTP(OTPReq) {
    // logger.info('Inside InsertVFirstOTP Complete Request: ' +JSON.stringify(OTPReq));
   // // logger.info('Inside InsertVFirstOTP OTPHash: ' + OTPReq.OTPHash);
   // return new Promise((resolve, reject) => {
     // try {  
       // var conn = new sql.ConnectionPool(config);
       // conn.connect().then(function (pool) 
      // {      
        // var request = new sql.Request(pool);             
        // request.input('UserID', sql.NVarChar, OTPReq.UserID)
               // .input('OTPHash', sql.NVarChar, OTPReq.OTPHash)                                    
               // .input('OTPReqMsg', sql.NVarChar, OTPReq.OTPMsg)
               // .input('Operation', sql.NVarChar, 'Insert')
               // .output('p_OutStatus', sql.NVarChar) // Define output parameter
               // .execute('proc_VFirstOTP_InsertUpdate',function(err ,queryResult){
                // //logger.info('QueryResult:', queryResult); // Retrieve output parameter 
                // if(queryResult.output.p_OutStatus=='200' && queryResult.rowsAffected[0]=='1')
                // {
                 // resp={
                 // "ErrorCode":"00",
                 // "ErrorMsg":"ValueFirst OTP Inserted Successfully."
                  // }
                  // resolve(resp);              
               // }
               // else{                
                  // logger.info('else:'); 
                  // resp={
                    // "ErrorCode":"01",
                    // "ErrorMsg":"Error to insert VFisrt OTP in database."
                  // }                
                  // resolve(resp);
                  // }
               // });
         // });
           
     // } catch (err1) {
       // logger.info(err1);
       // reject(err1);
     // }
   // });  
  // }
  
  // async function GetKeyConfigurationValue(KeyName) {
    // logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);
      // const query = `SELECT [KeyValue] FROM [dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;
      
      // try {
          // const pool = await sql.connect(config);
          // //logger.info('Connected to the database');
  
          // const result = await pool.request()
              // .input('KeyName', sql.VarChar, KeyName)
              // .query(query);
  
          // if (result.recordset.length > 0) {
             
                 // const jsonString = JSON.stringify(result.recordset, null, 2);
                 // formattedString = jsonString.slice(1, -1);
                // //  logger.info('Result: ',formattedString);               
                // //  logger.info('Parse Result: ',JSON.parse(formattedString));
                 // const OutValue=JSON.parse(formattedString).KeyValue;
                // //  logger.info('OutValue', OutValue.toString());
              // return JSON.parse(formattedString).KeyValue; // Return the formatted string
          // } else {
              // logger.info('No results found for the provided KeyName.');
              // return null;
          // }
      // } catch (err) {
          // console.error('Error:', err);
          // return null;
      // } finally {
          // await sql.close(); // Ensure the connection is closed
      // }   
  // }
  

function InsertVFirstOTP(OTPReq) {
  logger.info('Inside InsertVFirstOTP Complete Request: ' + JSON.stringify(OTPReq));
  // logger.info('Inside InsertVFirstOTP OTPHash: ' + OTPReq.OTPHash);

  return new Promise((resolve, reject) => {
    try {
      (async () => {
        try {
          const pool = await getPool();
          const request = pool.request();

          request
            .input('UserID', sql.NVarChar, OTPReq.UserID)
            .input('OTPHash', sql.NVarChar, OTPReq.OTPHash)
            .input('OTPReqMsg', sql.NVarChar, OTPReq.OTPMsg)
            .input('Operation', sql.NVarChar, 'Insert')
            .output('p_OutStatus', sql.NVarChar)
            .execute('proc_VFirstOTP_InsertUpdate', function (err, queryResult) {
              if (queryResult.output.p_OutStatus == '200' && queryResult.rowsAffected[0] == '1') {
                resp = {
                  "ErrorCode": "00",
                  "ErrorMsg": "ValueFirst OTP Inserted Successfully."
                };
                resolve(resp);
              } else {
                logger.info('else:');
                resp = {
                  "ErrorCode": "01",
                  "ErrorMsg": "Error to insert VFisrt OTP in database."
                };
                resolve(resp);
              }
            });

        } catch (dbErr) {
          logger.info(dbErr);
          reject(dbErr);
        }
      })();
    } catch (err1) {
      logger.info(err1);
      reject(err1);
    }
  });
}

async function GetKeyConfigurationValue(KeyName) {
  logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  const query = `SELECT [KeyValue] FROM [dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;

  try {
    const pool = await getPool();
    const request = pool.request();

    const result = await request
      .input('KeyName', sql.VarChar, KeyName)
      .query(query);

    if (result.recordset.length > 0) {
      const jsonString = JSON.stringify(result.recordset, null, 2);
      formattedString = jsonString.slice(1, -1);

      const OutValue = JSON.parse(formattedString).KeyValue;
      return OutValue;
    } else {
      logger.info('No results found for the provided KeyName.');
      return null;
    }
  } catch (err) {
    console.error('Error:', err);
    return null;
  }
}

  module.exports = {generateVFirstToken,SendVFirstOTP,InsertVFirstOTP};