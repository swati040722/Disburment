// const winston = require('winston');
// const path = require('path');
// const fs = require('fs');
// const moment = require('moment'); // Import moment for date formatting

// // Create logs directory if it doesn't exist
// const logsDir = path.join(__dirname, 'logs');
// if (!fs.existsSync(logsDir)) {
    // fs.mkdirSync(logsDir);
// }

// const currentDate = moment().format('YYYY-MM-DD'); // Use moment for proper date formatting
// // Create a logger
// const logger = winston.createLogger({  
  // format: winston.format.combine(
    // winston.format.timestamp({
      // format: () => moment().local().format('YYYY-MM-DDTHH:mm:ss.SSS') // Local time without 'Z'
    // }),
    // winston.format.json()
  // ),
  // level: 'info', // Default log level
  // transports: [
    // // Write logs to a file
    // new winston.transports.File({
      // filename: path.join(__dirname, 'Logs', 'error.log'),level: 'error',}),
    // new winston.transports.File({
      // filename: path.join(__dirname, 'logs', `combined-${currentDate}.log`),
      // //filename: path.join(__dirname, 'Logs', 'combined.log'),
    // }),
  // ],
// });

// // If you want to log to the console as well
// if ('production' == 'production') {
  // logger.add(new winston.transports.Console({
    // format: winston.format.simple(),
  // }));
// }

// module.exports = logger;

const winston = require('winston');
const path = require('path');
const fs = require('fs');
const moment = require('moment');

// Base logs directory
const baseLogsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(baseLogsDir)) {
    fs.mkdirSync(baseLogsDir);
}

/**
 * Create logger per module/file
 * @param {string} moduleName - JS file name (e.g. 'ValueFirst', 'Karix')
 */
function getLogger(moduleName) {

    const moduleLogDir = path.join(baseLogsDir, moduleName);
    if (!fs.existsSync(moduleLogDir)) {
        fs.mkdirSync(moduleLogDir);
    }

    const currentDate = moment().format('YYYY-MM-DD');

    return winston.createLogger({
        level: 'info',
        format: winston.format.combine(
            winston.format.timestamp({
                format: () => moment().local().format('YYYY-MM-DD HH:mm:ss.SSS')
            }),
            winston.format.json()
        ),
        transports: [
            // Error log (per module)
            new winston.transports.File({
                filename: path.join(moduleLogDir, `error-${currentDate}.log`),
                level: 'error'
            }),

            // Combined log (per module)
            new winston.transports.File({
                filename: path.join(moduleLogDir, `combined-${currentDate}.log`)
            })
        ]
    });
}

module.exports = getLogger;
