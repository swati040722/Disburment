// AadhaarDataLayer.js



const express = require("express");
const axios = require('axios');
//const sql = require("mssql");
const app = express();
app.use(express.json())
var cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');

app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

const { HttpsProxyAgent } = require('https-proxy-agent');//for System Proxy
//const https = require('https');
const http = require('http');
const https = require('https');
const moment = require('moment'); // Import moment for date formatting
const { sql, getPool } = require('./db');

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('AadhaarDataLayer');
const objGeneralOperation = require('./GeneralDataLayer');
const logError = require('./ErrorLog');
const objCommonFunction = require('./CommonFunctions');
const path = require('path');
// Set up cookie parser middleware
app.use(cookieParser());
//SQL Server configuration
//SQL Server configuration
// var config = {
//    user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000
//   },
//   "options": {
//     "encrypt": false
//   }
// }

 var config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

const axiosSafe = axios.create({
  timeout: 60000,
  httpAgent: new http.Agent({ keepAlive: false }),
  httpsAgent: new https.Agent({ keepAlive: false })
});
// Define your proxy URL (you can get this from environment variables or hardcode it)
const proxyUrl = process.env.HTTPS_PROXY || 'http://10.192.34.167:3128';//http://10.192.34.167:3128 //http://corpoffice.pnb.net:3128
// Create a new agent instance
const ProxyAgent = new HttpsProxyAgent(proxyUrl);


// const agent = new https.Agent({
   // rejectUnauthorized: false, // Set to false to bypass certificate verification 
   // HttpsProxyAgent:proxyUrl 
// });
const httpAgent = new https.Agent({
  rejectUnauthorized: false, // Set to false to bypass certificate verification 

});













// function SendAadhaarOTPAPI(PMSNumber, AadhaarNumber, JourneyID) {
  // logger.info('************************ Inside SendAadhaarOTP Method************************');
  // logger.info('PMSNumber: ' + PMSNumber);
  // logger.info('AadhaarNumber: ' + AadhaarNumber);
  // logger.info('JourneyID: ' + JourneyID);
  // return new Promise(async (resolve, reject) => {
    // try {

      // // const API_URL=process.env.Aadhaar_Send_Otp+AadhaarNumber;

      // // const AadhaarAPIUserID = process.env.AadhaarAPIUserID;
      // // const AadhaarAPIPassword = process.env.AadhaarAPIPassword;  
      // const AadhaarAPIUserID = await GetKeyConfigurationValue('Aadhaar_UserID');
      // const AadhaarAPIPassword = await GetKeyConfigurationValue('Aadhaar_Password');
      // const API_URL = await GetKeyConfigurationValue('Aadhaar_SendOTP_API_URL') + AadhaarNumber;
      // logger.info('AadhaarAPIUserID', AadhaarAPIUserID);
      // logger.info('AadhaarAPIPassword', AadhaarAPIPassword);
      // logger.info('API URL', API_URL);

      // let authorizationData = 'Basic ' + btoa(AadhaarAPIUserID + ':' + AadhaarAPIPassword);
      // logger.info('authorizationData ' + authorizationData);

      // const headers = {
        // 'Authorization': authorizationData
      // };
      // const Emptybody = "Call Aadhaar API with no data in body";

      // logError.APIRequestResponseLogs(PMSNumber, JourneyID, "SendAadhaarOTPAPI", API_URL, API_URL, null, null, null, "Insert").then(async (APILogsResp) => {
        // logger.info("API Log Insert ErrorCode " + APILogsResp.ErrorCode)
        // if (APILogsResp.ErrorCode == "00") {
          // await axios.post(API_URL, Emptybody, { headers }).then(resp => {
            // logger.info('Response data:', resp.data);
            // logger.info('Response data ret:', resp.data.ret);
            // logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(resp.data), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
              // logger.info("API Log Update ErrorCode " + APILogsResp.ErrorCode)
              // if (APILogsResp.ErrorCode == "00") {
                // let aadhaarsendOTPResp;
                // if (resp.data.ret == "Y") {
                  // var conn = new sql.ConnectionPool(config);
                  // conn.connect().then(function (pool) {
                    // var request = new sql.Request(pool);
                    // request.input('p_Req_ret', sql.NVarChar, resp.data.ret)
                      // .input('PMSNumber', sql.NVarChar, PMSNumber)
                      // .input('JourneyID', sql.NVarChar, JourneyID)
                      // .input('p_Req_aadhaarId', sql.NVarChar, resp.data.aadhaarId)
                      // .input('p_Req_respCode', sql.NVarChar, resp.data.respCode)
                      // .input('p_Req_respDesc', sql.NVarChar, resp.data.respDesc)
                      // .input('p_Req_uidaiAuthCode', sql.NVarChar, resp.data.uidaiAuthCode)
                      // .input('p_Req_txn', sql.NVarChar, resp.data.txn)
                      // .input('p_Req_communicationId', sql.NVarChar, resp.data.communicationId)
                      // .input('p_Req_uidToken', sql.NVarChar, resp.data.uidToken)
                      // .input('p_Req_uidType', sql.NVarChar, resp.data.uidType)
                      // .input('p_Req_info', sql.NVarChar, resp.data.info)
                      // .input('p_Operation', sql.NVarChar, 'Insert')
                      // .output('p_StatusCode', sql.NVarChar) // Define output parameter
                      // .execute('proc_AadhaarAPIRequestResponseData', function (err, queryResult) {
                        // logger.info('QueryResult Status:', queryResult.output.p_StatusCode); // Retrieve output parameter                                           
                        // logger.info('response affect:' + queryResult.rowsAffected[0]);
                        // if (queryResult.output.p_StatusCode == '200' && queryResult.rowsAffected[0] > 0) {
                          // // logger.info('response resp:' + JSON.stringify(resp));
                          // conn.close();

                          // aadhaarsendOTPResp = {
                            // "ErrorCode": resp.data.respCode,
                            // "ErrorMsg": "A 6 digit OTP has been sent on your mobile number registered with your Aadhaar Card"//resp.data.respDesc                            
                          // }
                          // resolve(aadhaarsendOTPResp);
                        // }
                        // else {
                          // logger.info("Error to save aadhaar otp data in database:- ", err);
                          // aadhaarsendOTPResp = {
                            // "ErrorCode": "01",
                            // "ErrorMsg": "Error to save aadhaar otp data in database"
                          // }
                          // resolve(aadhaarsendOTPResp);
                        // }
                      // });
                  // });
                // }
                // else {
                  // aadhaarsendOTPResp = {
                    // "ErrorCode": "01",
                    // "ErrorMsg": "Error while connecting Aadhaar API"
                  // }
                  // resolve(aadhaarsendOTPResp);
                // }
              // }
            // });

          // }).catch(error => {
            // console.error('Error posting to Loan Status API:', error);
            // // console.error('Error Loan Status Inquiry API Error Response:',error.response);
            // // console.error('Error SendAadhaarOTPAPI Response Text:',error.response.statusText);
            // // console.error('Error SendAadhaarOTPAPI Response data:',error.response.data); 
            // logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "SendAadhaarOTPAPI").then(async (ErrorLogResp) => {
              // resp = {
                // "ErrorCode": "01",
                // "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
              // }
              // resolve(resp);
            // });
          // });
        // }
      // });
    // }
    // catch (exception) {
      // logger.info(exception);
      // reject(exception);
    // }
  // });
// }

function SendAadhaarOTPAPI(PMSNumber, AadhaarNumber, JourneyID) {
  logger.info('************************ Inside SendAadhaarOTP Method************************');
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('AadhaarNumber: ' + AadhaarNumber);
  logger.info('JourneyID: ' + JourneyID);

  return new Promise(async (resolve, reject) => {
    try {

      const AadhaarAPIUserID = await GetKeyConfigurationValue('Aadhaar_UserID');
      const AadhaarAPIPassword = await GetKeyConfigurationValue('Aadhaar_Password');
      const API_URL = await GetKeyConfigurationValue('Aadhaar_SendOTP_API_URL') + AadhaarNumber;

      logger.info('AadhaarAPIUserID', AadhaarAPIUserID);
      logger.info('AadhaarAPIPassword', AadhaarAPIPassword);
      logger.info('API URL', API_URL);

      let authorizationData = 'Basic ' + btoa(AadhaarAPIUserID + ':' + AadhaarAPIPassword);
      logger.info('authorizationData ' + authorizationData);

      const headers = {
        'Authorization': authorizationData
      };

      const Emptybody = "Call Aadhaar API with no data in body";

      logError.APIRequestResponseLogs(
        PMSNumber,
        JourneyID,
        "SendAadhaarOTPAPI",
        API_URL,
        API_URL,
        null,
        null,
        null,
        "Insert"
      ).then(async (APILogsResp) => {

        logger.info("API Log Insert ErrorCode " + APILogsResp.ErrorCode);

        if (APILogsResp.ErrorCode == "00") {

          await axios.post(API_URL, Emptybody, { headers })
            .then(async resp => {

              logger.info('Response data:', resp.data);
              logger.info('Response data ret:', resp.data.ret);

              logError.APIRequestResponseLogs(
                PMSNumber,
                JourneyID,
                null,
                null,
                null,
                JSON.stringify(resp.data),
                JSON.stringify(resp.data),
                APILogsResp.RequestId,
                "Update"
              ).then(async (APILogsResp) => {

                logger.info("API Log Update ErrorCode " + APILogsResp.ErrorCode);

                if (APILogsResp.ErrorCode == "00") {

                  let aadhaarsendOTPResp;

                  if (resp.data.ret == "Y") {

                    /* ✅ DB ACCESS FIXED AS PER OUR APPROACH */
                    const pool = await getPool();
                    const request = pool.request();

                    request
                      .input('p_Req_ret', sql.NVarChar, resp.data.ret)
                      .input('PMSNumber', sql.NVarChar, PMSNumber)
                      .input('JourneyID', sql.NVarChar, JourneyID)
                      .input('p_Req_aadhaarId', sql.NVarChar, resp.data.aadhaarId)
                      .input('p_Req_respCode', sql.NVarChar, resp.data.respCode)
                      .input('p_Req_respDesc', sql.NVarChar, resp.data.respDesc)
                      .input('p_Req_uidaiAuthCode', sql.NVarChar, resp.data.uidaiAuthCode)
                      .input('p_Req_txn', sql.NVarChar, resp.data.txn)
                      .input('p_Req_communicationId', sql.NVarChar, resp.data.communicationId)
                      .input('p_Req_uidToken', sql.NVarChar, resp.data.uidToken)
                      .input('p_Req_uidType', sql.NVarChar, resp.data.uidType)
                      .input('p_Req_info', sql.NVarChar, resp.data.info)
                      .input('p_Operation', sql.NVarChar, 'Insert')
                      .output('p_StatusCode', sql.NVarChar)
                      .execute('proc_AadhaarAPIRequestResponseData')
                      .then(queryResult => {

                        logger.info('QueryResult Status:', queryResult.output.p_StatusCode);
                        logger.info('response affect:' + queryResult.rowsAffected[0]);

                        if (
                          queryResult.output.p_StatusCode == '200' &&
                          queryResult.rowsAffected[0] > 0
                        ) {
                          aadhaarsendOTPResp = {
                            "ErrorCode": resp.data.respCode,
                            "ErrorMsg": "A 6 digit OTP has been sent on your mobile number registered with your Aadhaar Card"
                          };
                          resolve(aadhaarsendOTPResp);
                        } else {
                          logger.info("Error to save aadhaar otp data in database");
                          aadhaarsendOTPResp = {
                            "ErrorCode": "01",
                            "ErrorMsg": "Error to save aadhaar otp data in database"
                          };
                          resolve(aadhaarsendOTPResp);
                        }
                      });

                  } else {
                    aadhaarsendOTPResp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "Error while connecting Aadhaar API"
                    };
                    resolve(aadhaarsendOTPResp);
                  }
                }
              });

            })
            .catch(error => {
              console.error('Error posting to SendAadhaarOTPAPI:', error);

              logError.ErrorLogs(
                PMSNumber,
                JourneyID,
                error?.response?.status,
                error?.response?.statusText,
                "SendAadhaarOTPAPI"
              ).then(() => {
                resolve({
                  "ErrorCode": "01",
                  "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance"
                });
              });
            });
        }
      });

    } catch (exception) {
      logger.info(exception);
      //reject(exception);
	  resolve({
                  "ErrorCode": "01",
                  "ErrorMsg": "System exception occurred. Please retry after sometime or contact your branch for further assistance"
                });
    }
  });
}


//MOCK API
function ValidateAadhaarOTPAPI_MOCK(PMSNumber, AadhaarNumber, OTP, ReqTxn, JourneyID, RespCustomerData) {
  logger.info('************************ Inside ValidateAadhaarOTPAPI_Mock ************************');
  logger.info('AadhaarNumber: ' + AadhaarNumber);
  logger.info('OTP: ' + OTP);
  logger.info('ReqTxn: ' + ReqTxn);
  logger.info('RespCustomerData: ' + JSON.stringify(RespCustomerData));

  let objRespAadhaarOTPValidate;

  try {
    // ✅ Mock Aadhaar API Response
    const mockApiResponse = {
      ret: "Y", // Y = success, N = failure
      respCode: "200",
      respDesc: "Mock Aadhaar OTP validated successfully",
      uidaiAuthCode: "MOCKAUTH12345",
      communicationId: "COMM12345",
      txn: `txn:${ReqTxn}`,
      ttl: "3600",
      rrn: "MOCKRRN12345",
      uidToken: "MOCKTOKEN12345",
      ts: new Date().toISOString(),
      maskedUid: "XXXXXXXX" + AadhaarNumber.slice(-4),
      uidData: {
        uid: AadhaarNumber,
        poi: {
          name: "TEST USER",
          dob: "01-01-1990",
          gender: "M"
        },
        poa: {
          country: "IN",
          pc: "110001",
          vtc: "Delhi",
          street: "MG Road",
          dist: "New Delhi",
          state: "Delhi",
          co: "C/O XYZ",
          house: "123"
        },
        prn: {
          type: "Mock",
          encodedPDF: Buffer.from("Mock PDF Content").toString("base64")
        },
        tkn: "MOCKTKN123"
      }
    };

    logger.info("Mock Aadhaar API Response: " + JSON.stringify(mockApiResponse));

    // ✅ Validate against CBS Data
    const CBSName = RespCustomerData.CustomerName?.toUpperCase();
    const AadhaarName = mockApiResponse.uidData.poi.name.toUpperCase();

    const CBSYOB = new Date(RespCustomerData.Actual_Date_of_Birth).getFullYear();
    const AadhaarYOB = moment(mockApiResponse.uidData.poi.dob, 'DD-MM-YYYY').year();

    const CBSGender = RespCustomerData.Gender;
    const AadhaarGender = mockApiResponse.uidData.poi.gender;

    const CBSAadharLastFour = AadhaarNumber.slice(-4);
    const AadhaarLastFour = mockApiResponse.maskedUid.slice(-4);

    if (CBSName !== AadhaarName) {
      objRespAadhaarOTPValidate = {
        ErrorCode: "01",
        ErrorMsg: "Applicant Name mismatch with PNB records."
      };
    } else if (CBSYOB !== AadhaarYOB) {
      objRespAadhaarOTPValidate = {
        ErrorCode: "01",
        ErrorMsg: "Applicant DOB mismatch with PNB records."
      };
    } else if (CBSGender !== AadhaarGender) {
      objRespAadhaarOTPValidate = {
        ErrorCode: "01",
        ErrorMsg: "Applicant Gender mismatch with PNB records."
      };
    } else if (CBSAadharLastFour !== AadhaarLastFour) {
      objRespAadhaarOTPValidate = {
        ErrorCode: "01",
        ErrorMsg: "Applicant Aadhaar number mismatch with PNB records."
      };
    } else {
      objRespAadhaarOTPValidate = {
        ErrorCode: mockApiResponse.respCode,
        ErrorMsg: "Aadhaar OTP successfully validated (Mock)."
      };
    }

    logger.info("Return Response: " + JSON.stringify(objRespAadhaarOTPValidate));
    return objRespAadhaarOTPValidate;

  } catch (err) {
    logger.error("Mock Aadhaar OTP Validation Error: " + err.message);
    return {
      ErrorCode: "99",
      ErrorMsg: "System error in Aadhaar OTP mock validation."
    };
  }
}


// function ValidateAadhaarOTPAPI(PMSNumber, AadhaarNumber, OTP, ReqTxn, JourneyID, RespCustomerData, RespCustomerData) {
  // logger.info('************************ Inside ValidateAadhaarOTPAPI ************************');
  // logger.info('AadhaarNumber: ' + AadhaarNumber);
  // logger.info('OTP: ' + OTP);
  // logger.info('ReqTxn: ' + ReqTxn);
  // logger.info('RespCustomerData: ' + JSON.stringify(RespCustomerData));


  // let objRespAadhaarOTPValidate;
  // return new Promise(async (resolve, reject) => {
    // try {

      // // const API_URL=process.env.Aadhaar_Verify_Otp+AadhaarNumber+'&OTP='+OTP+'&otpResponseTxn='+ReqTxn;
      // // logger.info(API_URL);
      // // const AadhaarAPIUserID = process.env.AadhaarAPIUserID;
      // // const AadhaarAPIPassword = process.env.AadhaarAPIPassword;    
      // const AadhaarAPIUserID = await GetKeyConfigurationValue('Aadhaar_UserID');
      // const AadhaarAPIPassword = await GetKeyConfigurationValue('Aadhaar_Password');
      // const API_URL = await GetKeyConfigurationValue('Aadhaar_VerifyOTP_API_URL') + AadhaarNumber + '&OTP=' + OTP + '&otpResponseTxn=' + ReqTxn;
      // logger.info('API URL', API_URL);
      // let authorizationData = 'Basic ' + btoa(AadhaarAPIUserID + ':' + AadhaarAPIPassword);
      // logger.info('UserID&Password ' + authorizationData);

      // headers = {
        // 'Authorization': authorizationData
      // }
      // const Emptybody = "Call Aadhaar API with no data in body";

      // //const resp = await axios.post(API_URL,Emptybody,{headers});
      // logError.APIRequestResponseLogs(PMSNumber, JourneyID, "ValidateAadhaarOTPAPI", API_URL, API_URL, null, null, null, "Insert").then(async (APILogsResp) => {
        // logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
        // if (APILogsResp.ErrorCode == "00") {
          // await axios.post(API_URL, Emptybody, { headers }).then(resp => {
            // //logger.info('Response data:', resp.data);              
            // logger.info('Response data ret:', resp.data.ret);
            // logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(resp.data), JSON.stringify(resp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
              // logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
              // if (APILogsResp.ErrorCode == "00") {
                // if (resp.data.ret == "Y") {
                  // var conn = new sql.ConnectionPool(config);
                  // conn.connect().then(function (pool) {
                    // var request = new sql.Request(pool);
                    // request.input('p_Resp_ret', sql.NVarChar, resp.data.ret)
                      // .input('p_Resp_respCode', sql.NVarChar, resp.data.respCode)
                      // .input('p_Resp_respDesc', sql.NVarChar, resp.data.respDesc)
                      // .input('p_Resp_uidaiAuthCode', sql.NVarChar, resp.data.uidaiAuthCode)
                      // .input('p_Resp_communicationId', sql.NVarChar, resp.data.communicationId)
                      // .input('p_Resp_txn', sql.NVarChar, resp.data.txn.split(':')[1])
                      // .input('p_Resp_ttl', sql.NVarChar, resp.data.ttl)
                      // .input('p_Resp_rrn', sql.NVarChar, resp.data.rrn)
                      // .input('p_Resp_uidToken', sql.NVarChar, resp.data.uidToken)
                      // .input('p_Resp_uidData_uid', sql.NVarChar, resp.data.uidData.uid)
                      // .input('p_Resp_uidData_poa_country', sql.NVarChar, resp.data.uidData.poa.country)
                      // .input('p_Resp_uidData_poa_pc', sql.NVarChar, resp.data.uidData.poa.pc)
                      // .input('p_Resp_uidData_poa_vtc', sql.NVarChar, resp.data.uidData.poa.vtc)
                      // .input('p_Resp_uidData_poa_street', sql.NVarChar, resp.data.uidData.poa.street)
                      // .input('p_Resp_uidData_poa_dist', sql.NVarChar, resp.data.uidData.poa.dist)
                      // .input('p_Resp_uidData_poa_state', sql.NVarChar, resp.data.uidData.poa.state)
                      // .input('p_Resp_uidData_poa_co', sql.NVarChar, resp.data.uidData.poa.co)
                      // .input('p_Resp_uidData_poa_house', sql.NVarChar, resp.data.uidData.poa.house)
                      // .input('p_Resp_uidData_tkn', sql.NVarChar, resp.data.uidData.tkn)
                      // .input('p_Resp_uidData_poi_gender', sql.NVarChar, resp.data.uidData.poi.gender)
                      // .input('p_Resp_uidData_poi_dob', sql.NVarChar, resp.data.uidData.poi.dob)
                      // .input('p_Resp_uidData_poi_name', sql.NVarChar, resp.data.uidData.poi.name)
                      // .input('p_Resp_uidData_prn_type', sql.NVarChar, resp.data.uidData.prn.type)
                      // .input('p_Resp_uidData_prn_encodedPDF', sql.VarBinary, new Buffer.from(resp.data.uidData.prn.encodedPDF, 'binary'))
                      // .input('p_Resp_ts', sql.NVarChar, resp.data.ts)
                      // //  .input('p_Resp_UpdateBy', sql.NVarChar, 'System Entered')
                      // .input('p_Operation', sql.NVarChar, 'Update')
                      // .output('p_StatusCode', sql.NVarChar) // Define output parameter
                      // .execute('proc_AadhaarAPIRequestResponseData', function (err, queryResult) {
                        // //logger.info('Aadhaar OTP Validation Successfully updated in Database')

                        // logger.info('queryResult: ' + JSON.stringify(queryResult))
                        // logger.info('err: ' + err);

                        // logger.info(`CBS Name ${RespCustomerData.CustomerName.toUpperCase()}`)
                        // logger.info(`Aadhaar Name ${resp.data.uidData.poi.name.toUpperCase()}`)
                        // //logger.info(`#{}`)

                        // const CBSYOB = (new Date(RespCustomerData.Actual_Date_of_Birth)).getFullYear();
                        // logger.info(`YearPart ${CBSYOB}`)
                        // const AadhaarYOB = moment(resp.data.uidData.poi.dob, 'DD-MM-YYYY').year();
                        // logger.info(`YearPart ${AadhaarYOB}`)

                        // logger.info(`CBS Gender ${RespCustomerData.Gender}`)
                        // logger.info(`Aadhaar Gender ${resp.data.uidData.poi.gender}`)

                        // let CBSAadharLastFourDigit = AadhaarNumber.substring(8, AadhaarNumber.length);
                        // logger.info(`CBSAadharLastFourDigit ${CBSAadharLastFourDigit}`)
                        // const AadharLastFourDigit = (resp.data.maskedUid).substring((resp.data.maskedUid).length - 4);
                        // logger.info(`AadharLastFourDigit ${AadharLastFourDigit}`)


                        // if (queryResult.output.p_StatusCode == '200' && queryResult.rowsAffected[0] > 0) {
                          // //conn.close();
                          // if (RespCustomerData.CustomerName.toUpperCase() != resp.data.uidData.poi.name.toUpperCase()) {
                            // objRespAadhaarOTPValidate = {
                              // "ErrorCode": "01",
                              // "ErrorMsg": "Dear Customer, Applicant Name not matched as per your PNB bank details, please contact your branch for further assistance."
                            // }
                            // logger.info('return Response:' + objRespAadhaarOTPValidate);
                            // resolve(objRespAadhaarOTPValidate);
                          // }
                          // else if (CBSYOB != AadhaarYOB) {
                            // objRespAadhaarOTPValidate = {
                              // "ErrorCode": "01",
                              // "ErrorMsg": "Dear Customer, Applicant DOB not matched as per your PNB bank details, please contact your branch for further assistance."
                            // }
                            // logger.info('return Response:' + objRespAadhaarOTPValidate);
                            // resolve(objRespAadhaarOTPValidate);
                          // }
                          // else if (RespCustomerData.Gender != resp.data.uidData.poi.gender) {
                            // objRespAadhaarOTPValidate = {
                              // "ErrorCode": "01",
                              // "ErrorMsg": "Dear Customer, Applicant Gender not matched as per your PNB bank details, please contact your branch for further assistance."
                            // }
                            // logger.info('return Response:' + objRespAadhaarOTPValidate);
                            // resolve(objRespAadhaarOTPValidate);
                          // }
                          // else if (CBSAadharLastFourDigit != AadharLastFourDigit) {
                            // objRespAadhaarOTPValidate = {
                              // "ErrorCode": "01",
                              // "ErrorMsg": "Dear Customer, Applicant Aadhar not matched as per your PNB bank details, please contact your branch for further assistance."
                            // }
                            // logger.info('return Response:' + objRespAadhaarOTPValidate);
                            // resolve(objRespAadhaarOTPValidate);
                          // }
                          // else {
							
							// // NEW: Update validation status in DB
								// var updateReq = new sql.Request(pool);
								// updateReq.input('PMSNumber', sql.NVarChar, PMSNumber)
									// .output('StatusCode', sql.NVarChar)
									// .execute('proc_UpdateAadharValidationStatus', (updateErr, updateResult) => {
										// conn.close();
										// if (updateErr) {
											// logger.error('Failed to update isAadharValidated flag: ' + updateErr);
										// } else {
											// logger.info('Successfully updated isAadharValidated for: ' + PMSNumber);
										// }
									// });
														  
                            // objRespAadhaarOTPValidate = {
                              // "ErrorCode": resp.data.respCode,
                              // "ErrorMsg": "Aadhaar OTP successfully validated."
                            // }
                            // logger.info('return Response:' + objRespAadhaarOTPValidate);
                            // resolve(objRespAadhaarOTPValidate);
                          // }
                        // }
                        // else {
                          // logger.info("Else Block: Error while update in database :- " + err);
                          // objRespAadhaarOTPValidate = {
                            // "ErrorCode": "01",
                            // "ErrorMsg": "Error to update Aadhaar OTP validate data in database"
                          // }
                          // resolve(objRespAadhaarOTPValidate);
                        // }
                      // });
                  // });
                // }
                // else {
                  // objRespAadhaarOTPValidate = {
                    // "ErrorCode": "01",
                    // "ErrorMsg": "Error while connecting Aadhaar API"
                  // }
                  // resolve(objRespAadhaarOTPValidate);
                // }
              // }
            // });

          // }).catch(error => {
			  // // 1. Prepare a structured Error Object for logging
					// const errorLogDetails = {
						// message: error.message,
						// status: error.response ? error.response.status : 'NO_RESPONSE',
						// statusText: error.response ? error.response.statusText : 'TIMEOUT/NETWORK_FAILURE',
						// responseData: error.response ? error.response.data : 'No data received from third party'
					// };

					// // 2. Log details using logger.info
					// logger.info('************************ ValidateAadhaarOTPAPI EXCEPTION ************************');
					// logger.info('Error details for PMS: ' + PMSNumber);
					// logger.info('Stringified Error JSON: ' + JSON.stringify(errorLogDetails));
            // // console.error('Error posting to Loan Status API:',error);
            // // console.error('Error Loan Status Inquiry API Error Response:',error.response);
            // console.error('Error ValidateAadhaarOTPAPI Error Response Text:', error.response.statusText);
            // console.error('Error ValidateAadhaarOTPAPI Error Response data:', error.response.data);
			// logger.info('');
            // logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "ValidateAadhaarOTPAPI").then(async (ErrorLogResp) => {
              // objRespAadhaarOTPValidate = {
                // "ErrorCode": "01",
                // "ErrorMsg": "Aadhar OTP Validation Service Failed, Please try after sometime.",
              // }
              // resolve(objRespAadhaarOTPValidate);
            // });
          // });
        // }
      // });

    // }
    // catch (exception) {
      // logger.info(exception);
      // reject(exception);
    // }
  // });
// }


// function ValidateAadhaarOTPAPI(PMSNumber, AadhaarNumber, OTP, ReqTxn, JourneyID, RespCustomerData, RespCustomerData) {
  // logger.info('************************ Inside ValidateAadhaarOTPAPI ************************');
  // logger.info('AadhaarNumber: ' + AadhaarNumber);
  // logger.info('OTP: ' + OTP);
  // logger.info('ReqTxn: ' + ReqTxn);
  // logger.info('RespCustomerData: ' + JSON.stringify(RespCustomerData));

  // let objRespAadhaarOTPValidate;

  // return new Promise(async (resolve, reject) => {
    // try {
      // const AadhaarAPIUserID = await GetKeyConfigurationValue('Aadhaar_UserID');
      // const AadhaarAPIPassword = await GetKeyConfigurationValue('Aadhaar_Password');
      // const API_URL =
        // (await GetKeyConfigurationValue('Aadhaar_VerifyOTP_API_URL')) +
        // AadhaarNumber +
        // '&OTP=' +
        // OTP +
        // '&otpResponseTxn=' +
        // ReqTxn;

      // let authorizationData = 'Basic ' + btoa(AadhaarAPIUserID + ':' + AadhaarAPIPassword);

      // const headers = { Authorization: authorizationData };
      // const Emptybody = 'Call Aadhaar API with no data in body';

      // const insertLog = await logError.APIRequestResponseLogs(
        // PMSNumber,
        // JourneyID,
        // 'ValidateAadhaarOTPAPI',
        // API_URL,
        // API_URL,
        // null,
        // null,
        // null,
        // 'Insert'
      // );

      // if (insertLog.ErrorCode !== '00') {
        // objRespAadhaarOTPValidate = {
          // ErrorCode: '01',
          // ErrorMsg: 'Unable to initialize Aadhaar OTP validation.'
        // };
        // return resolve(objRespAadhaarOTPValidate);
      // }

      // let resp;
	  // let axiosResponseForLog = null;
      // try {
        // resp = await axios.post(API_URL, Emptybody, { headers });
		// axiosResponseForLog = resp.data; // success case
		  // logger.info('************************ ValidateAadhaarOTPAPI SUCC START************************');
		  // logger.info('Error details for PMS: ' + PMSNumber);
		  // logger.info('Stringified Error JSON: ' + JSON.stringify(axiosResponseForLog));
		  // logger.info('************************ ValidateAadhaarOTPAPI SUCC END************************');
		  
      // } catch (error) {
			// axiosResponseForLog = error.response
			// ? error.response.data               // Aadhaar responded with error payload
			// : {
				// message: error.message,
				// status: 'NO_RESPONSE',
				// statusText: 'TIMEOUT/NETWORK_FAILURE'
			  // };
			  
		// logger.info('************************ ValidateAadhaarOTPAPI ERROR START************************');
		// logger.info('Error details for PMS: ' + PMSNumber);
		// logger.info('Stringified Error JSON: ' + JSON.stringify(axiosResponseForLog));
		// logger.info('************************ ValidateAadhaarOTPAPI ERROR END************************');
  
        // const errorLogDetails = {
          // message: error.message,
          // status: error.response ? error.response.status : 'NO_RESPONSE',
          // statusText: error.response ? error.response.statusText : 'TIMEOUT/NETWORK_FAILURE',
          // responseData: error.response ? error.response.data : 'No data received from third party'
        // };

        // logger.info('************************ ValidateAadhaarOTPAPI EXCEPTION ************************');
        // logger.info('Error details for PMS: ' + PMSNumber);
        // logger.info('Stringified Error JSON: ' + JSON.stringify(errorLogDetails));

        // await logError.ErrorLogs(
          // PMSNumber,
          // JourneyID,
          // errorLogDetails.status,
          // errorLogDetails.statusText,
          // 'ValidateAadhaarOTPAPI'
        // );

        // objRespAadhaarOTPValidate = {
          // ErrorCode: '01',
          // ErrorMsg: 'Aadhar OTP Validation Service Failed, Please try after sometime.'
        // };
        // return resolve(objRespAadhaarOTPValidate);
      // }

      // if (!resp || !resp.data) {
        // objRespAadhaarOTPValidate = {
          // ErrorCode: '01',
          // ErrorMsg: 'Invalid response received from Aadhaar service.'
        // };
        // return resolve(objRespAadhaarOTPValidate);
      // }

      // logger.info('Response data ret: ' + resp.data.ret);

      // const updLog = await logError.APIRequestResponseLogs(
        // PMSNumber,
        // JourneyID,
        // null,
        // null,
        // null,
        // JSON.stringify(resp.data),
        // JSON.stringify(resp.data),
        // insertLog.RequestId,
        // 'Update'
      // );

      // if (updLog.ErrorCode !== '00') {
        // objRespAadhaarOTPValidate = {
          // ErrorCode: '01',
          // ErrorMsg: 'Failed to log Aadhaar response.'
        // };
        // return resolve(objRespAadhaarOTPValidate);
      // }

      // if (resp.data.ret !== 'Y') {
        // objRespAadhaarOTPValidate = {
          // ErrorCode: '01',
          // ErrorMsg: resp.data.respDesc || 'Aadhaar OTP validation failed.'
        // };
        // return resolve(objRespAadhaarOTPValidate);
      // }

      // // ---------------- MAIN DB UPDATE ----------------
      // const conn = new sql.ConnectionPool(config);
      // const pool = await conn.connect();

      // const request = new sql.Request(pool);
      // const queryResult = await request
        // .input('p_Resp_ret', sql.NVarChar, resp.data.ret)
        // .input('p_Resp_respCode', sql.NVarChar, resp.data.respCode)
        // .input('p_Resp_respDesc', sql.NVarChar, resp.data.respDesc)
        // .input('p_Resp_uidaiAuthCode', sql.NVarChar, resp.data.uidaiAuthCode)
        // .input('p_Resp_communicationId', sql.NVarChar, resp.data.communicationId)
        // .input('p_Resp_txn', sql.NVarChar, resp.data.txn.split(':')[1])
        // .input('p_Resp_ttl', sql.NVarChar, resp.data.ttl)
        // .input('p_Resp_rrn', sql.NVarChar, resp.data.rrn)
        // .input('p_Resp_uidToken', sql.NVarChar, resp.data.uidToken)
        // .input('p_Resp_uidData_uid', sql.NVarChar, resp.data.uidData.uid)
        // .input('p_Resp_uidData_poa_country', sql.NVarChar, resp.data.uidData.poa.country)
        // .input('p_Resp_uidData_poa_pc', sql.NVarChar, resp.data.uidData.poa.pc)
        // .input('p_Resp_uidData_poa_vtc', sql.NVarChar, resp.data.uidData.poa.vtc)
        // .input('p_Resp_uidData_poa_street', sql.NVarChar, resp.data.uidData.poa.street)
        // .input('p_Resp_uidData_poa_dist', sql.NVarChar, resp.data.uidData.poa.dist)
        // .input('p_Resp_uidData_poa_state', sql.NVarChar, resp.data.uidData.poa.state)
        // .input('p_Resp_uidData_poa_co', sql.NVarChar, resp.data.uidData.poa.co)
        // .input('p_Resp_uidData_poa_house', sql.NVarChar, resp.data.uidData.poa.house)
        // .input('p_Resp_uidData_tkn', sql.NVarChar, resp.data.uidData.tkn)
        // .input('p_Resp_uidData_poi_gender', sql.NVarChar, resp.data.uidData.poi.gender)
        // .input('p_Resp_uidData_poi_dob', sql.NVarChar, resp.data.uidData.poi.dob)
        // .input('p_Resp_uidData_poi_name', sql.NVarChar, resp.data.uidData.poi.name)
        // .input('p_Resp_uidData_prn_type', sql.NVarChar, resp.data.uidData.prn.type)
        // .input('p_Resp_uidData_prn_encodedPDF', sql.VarBinary, Buffer.from(resp.data.uidData.prn.encodedPDF, 'binary'))
        // .input('p_Resp_ts', sql.NVarChar, resp.data.ts)
        // .input('p_Operation', sql.NVarChar, 'Update')
        // .output('p_StatusCode', sql.NVarChar)
        // .execute('proc_AadhaarAPIRequestResponseData');

      // if (queryResult.output.p_StatusCode !== '200' || queryResult.rowsAffected[0] <= 0) {
        // conn.close();
        // objRespAadhaarOTPValidate = {
          // ErrorCode: '01',
          // ErrorMsg: 'Error to update Aadhaar OTP validate data in database'
        // };
        // return resolve(objRespAadhaarOTPValidate);
      // }

      // // ---------------- SECOND DB UPDATE ----------------
      // const updateReq = new sql.Request(pool);
      // await updateReq
        // .input('PMSNumber', sql.NVarChar, PMSNumber)
        // .output('StatusCode', sql.NVarChar)
        // .execute('proc_UpdateAadharValidationStatus');

      // conn.close();

      // objRespAadhaarOTPValidate = {
        // ErrorCode: resp.data.respCode,
        // ErrorMsg: 'Aadhaar OTP successfully validated.'
      // };
      // return resolve(objRespAadhaarOTPValidate);
    // } catch (exception) {
      // logger.info(exception);
      // reject(exception);
    // }
  // });
// }

// async function ValidateAadhaarOTPAPI(PMSNumber, AadhaarNumber, OTP, ReqTxn, JourneyID, RespCustomerData) {
  // logger.info('************************ Inside ValidateAadhaarOTPAPI ************************');
  // logger.info('AadhaarNumber: ' + AadhaarNumber);
  // logger.info('OTP: ' + OTP);
  // logger.info('ReqTxn: ' + ReqTxn);
  // logger.info('RespCustomerData: ' + JSON.stringify(RespCustomerData));

  // try {
    // const AadhaarAPIUserID = await GetKeyConfigurationValue('Aadhaar_UserID');
    // const AadhaarAPIPassword = await GetKeyConfigurationValue('Aadhaar_Password');
    // const API_URL =
      // (await GetKeyConfigurationValue('Aadhaar_VerifyOTP_API_URL')) +
      // AadhaarNumber + '&OTP=' + OTP + '&otpResponseTxn=' + ReqTxn;

    // const headers = {
      // Authorization: 'Basic ' + Buffer.from(AadhaarAPIUserID + ':' + AadhaarAPIPassword).toString('base64')
    // };

    // // Insert API log
    // const insertLog = await logError.APIRequestResponseLogs(
      // PMSNumber, JourneyID, "ValidateAadhaarOTPAPI", API_URL, API_URL, null, null, null, "Insert"
    // );

    // if (insertLog.ErrorCode !== "00") {
      // return { ErrorCode: "01", ErrorMsg: "Unable to initiate Aadhaar validation logging" };
    // }

    // // Call Aadhaar API (safe axios)
    // const resp = await axiosSafe.post(API_URL, "Call Aadhaar API with no data in body", { headers });

    // // Update API log
    // await logError.APIRequestResponseLogs(
      // PMSNumber, JourneyID, null, null, null,
      // JSON.stringify(resp.data), JSON.stringify(resp.data),
      // insertLog.RequestId, "Update"
    // );

    // if (!resp || !resp.data || resp.data.ret !== "Y") {
      // return { ErrorCode: "01", ErrorMsg: "Error while connecting Aadhaar API" };
    // }

    // // Save response to DB
    // const pool = await new sql.ConnectionPool(config).connect();
    // const request = new sql.Request(pool);

    // const CBSYOB = (new Date(RespCustomerData.Actual_Date_of_Birth)).getFullYear();
    // const AadhaarYOB = moment(resp.data.uidData.poi.dob, 'DD-MM-YYYY').year();
    // const CBSAadharLastFourDigit = AadhaarNumber.substring(8);
    // const AadharLastFourDigit = resp.data.maskedUid.substring(resp.data.maskedUid.length - 4);

    // const dbResult = await request
      // .input('p_Resp_ret', sql.NVarChar, resp.data.ret)
      // .input('p_Resp_respCode', sql.NVarChar, resp.data.respCode)
      // .input('p_Resp_respDesc', sql.NVarChar, resp.data.respDesc)
      // .input('p_Resp_uidaiAuthCode', sql.NVarChar, resp.data.uidaiAuthCode)
      // .input('p_Resp_communicationId', sql.NVarChar, resp.data.communicationId)
      // .input('p_Resp_txn', sql.NVarChar, resp.data.txn.split(':')[1])
      // .input('p_Resp_ttl', sql.NVarChar, resp.data.ttl)
      // .input('p_Resp_rrn', sql.NVarChar, resp.data.rrn)
      // .input('p_Resp_uidToken', sql.NVarChar, resp.data.uidToken)
      // .input('p_Resp_uidData_uid', sql.NVarChar, resp.data.uidData.uid)
      // .input('p_Resp_uidData_poa_country', sql.NVarChar, resp.data.uidData.poa.country)
      // .input('p_Resp_uidData_poa_pc', sql.NVarChar, resp.data.uidData.poa.pc)
      // .input('p_Resp_uidData_poa_vtc', sql.NVarChar, resp.data.uidData.poa.vtc)
      // .input('p_Resp_uidData_poa_street', sql.NVarChar, resp.data.uidData.poa.street)
      // .input('p_Resp_uidData_poa_dist', sql.NVarChar, resp.data.uidData.poa.dist)
      // .input('p_Resp_uidData_poa_state', sql.NVarChar, resp.data.uidData.poa.state)
      // .input('p_Resp_uidData_poa_co', sql.NVarChar, resp.data.uidData.poa.co)
      // .input('p_Resp_uidData_poa_house', sql.NVarChar, resp.data.uidData.poa.house)
      // .input('p_Resp_uidData_tkn', sql.NVarChar, resp.data.uidData.tkn)
      // .input('p_Resp_uidData_poi_gender', sql.NVarChar, resp.data.uidData.poi.gender)
      // .input('p_Resp_uidData_poi_dob', sql.NVarChar, resp.data.uidData.poi.dob)
      // .input('p_Resp_uidData_poi_name', sql.NVarChar, resp.data.uidData.poi.name)
      // .input('p_Resp_uidData_prn_type', sql.NVarChar, resp.data.uidData.prn.type)
      // .input('p_Resp_uidData_prn_encodedPDF', sql.VarBinary, Buffer.from(resp.data.uidData.prn.encodedPDF, 'binary'))
      // .input('p_Resp_ts', sql.NVarChar, resp.data.ts)
      // .input('p_Operation', sql.NVarChar, 'Update')
      // .output('p_StatusCode', sql.NVarChar)
      // .execute('proc_AadhaarAPIRequestResponseData');

    // if (dbResult.output.p_StatusCode !== '200' || dbResult.rowsAffected[0] <= 0) {
      // return { ErrorCode: "01", ErrorMsg: "Error to update Aadhaar OTP validate data in database" };
    // }

    // // CBS vs Aadhaar validations
    // if (RespCustomerData.CustomerName.toUpperCase() !== resp.data.uidData.poi.name.toUpperCase()) {
      // return { ErrorCode: "01", ErrorMsg: "Dear Customer, Applicant Name not matched as per your PNB bank details, please contact your branch for further assistance." };
    // }
    // if (CBSYOB !== AadhaarYOB) {
      // return { ErrorCode: "01", ErrorMsg: "Dear Customer, Applicant DOB not matched as per your PNB bank details, please contact your branch for further assistance." };
    // }
    // if (RespCustomerData.Gender !== resp.data.uidData.poi.gender) {
      // return { ErrorCode: "01", ErrorMsg: "Dear Customer, Applicant Gender not matched as per your PNB bank details, please contact your branch for further assistance." };
    // }
    // if (CBSAadharLastFourDigit !== AadharLastFourDigit) {
      // return { ErrorCode: "01", ErrorMsg: "Dear Customer, Applicant Aadhar not matched as per your PNB bank details, please contact your branch for further assistance." };
    // }

    // // Update validation flag
    // await new sql.Request(pool)
      // .input('PMSNumber', sql.NVarChar, PMSNumber)
	  // .output('StatusCode', sql.NVarChar)
      // .execute('proc_UpdateAadharValidationStatus');

    // pool.close();

    // return {
      // ErrorCode: resp.data.respCode,
      // ErrorMsg: "Aadhaar OTP successfully validated."
    // };

  // } catch (err) {
    // logger.error('ValidateAadhaarOTPAPI EXCEPTION', err);
    // return {
      // ErrorCode: "01",
      // ErrorMsg: "Aadhar OTP Validation Service Failed, Please try after sometime."
    // };
  // }
// }

async function ValidateAadhaarOTPAPI(
  PMSNumber,
  AadhaarNumber,
  OTP,
  ReqTxn,
  JourneyID,
  RespCustomerData
) {
  logger.info('************************ Inside ValidateAadhaarOTPAPI ************************');
  logger.info('AadhaarNumber: ' + AadhaarNumber);
  logger.info('OTP: ' + OTP);
  logger.info('ReqTxn: ' + ReqTxn);
  logger.info('RespCustomerData: ' + JSON.stringify(RespCustomerData));

  try {
    const AadhaarAPIUserID = await GetKeyConfigurationValue('Aadhaar_UserID');
    const AadhaarAPIPassword = await GetKeyConfigurationValue('Aadhaar_Password');
    const API_URL =
      (await GetKeyConfigurationValue('Aadhaar_VerifyOTP_API_URL')) +
      AadhaarNumber +
      '&OTP=' + OTP +
      '&otpResponseTxn=' + ReqTxn;

    const headers = {
      Authorization:
        'Basic ' +
        Buffer.from(AadhaarAPIUserID + ':' + AadhaarAPIPassword).toString('base64')
    };

    /* ---------- INSERT API LOG ---------- */
    const insertLog = await logError.APIRequestResponseLogs(
      PMSNumber,
      JourneyID,
      'ValidateAadhaarOTPAPI',
      API_URL,
      API_URL,
      null,
      null,
      null,
      'Insert'
    );

    if (insertLog.ErrorCode !== '00') {
      return {
        ErrorCode: '01',
        ErrorMsg: 'Unable to initiate Aadhaar validation logging'
      };
    }

    /* ---------- CALL AADHAAR API ---------- */
    const resp = await axiosSafe.post(
      API_URL,
      'Call Aadhaar API with no data in body',
      { headers }
    );

    /* ---------- UPDATE API LOG ---------- */
    await logError.APIRequestResponseLogs(
      PMSNumber,
      JourneyID,
      null,
      null,
      null,
      JSON.stringify(resp.data),
      JSON.stringify(resp.data),
      insertLog.RequestId,
      'Update'
    );

    if (!resp || !resp.data || resp.data.ret !== 'Y') {
      return {
        ErrorCode: '01',
        ErrorMsg: 'Error while connecting Aadhaar API'
      };
    }

    /* ---------- DB SAVE (FIXED AS PER OUR APPROACH) ---------- */
    const pool = await getPool();
    const request = pool.request();

       const CBSYOB = new Date(RespCustomerData.Actual_Date_of_Birth).getFullYear();
	  logger.info('CBSYOB: ' + CBSYOB);
    const AadhaarYOB = moment(resp.data.uidData.poi.dob, 'DD-MM-YYYY').year();
	  logger.info('AadhaarYOB: ' + AadhaarYOB);
    const CBSAadharLastFourDigit = AadhaarNumber.substring(8);
    const AadharLastFourDigit =
      resp.data.maskedUid.substring(resp.data.maskedUid.length - 4);

    const dbResult = await request
      .input('p_Resp_ret', sql.NVarChar, resp.data.ret)
      .input('p_Resp_respCode', sql.NVarChar, resp.data.respCode)
      .input('p_Resp_respDesc', sql.NVarChar, resp.data.respDesc)
      .input('p_Resp_uidaiAuthCode', sql.NVarChar, resp.data.uidaiAuthCode)
      .input('p_Resp_communicationId', sql.NVarChar, resp.data.communicationId)
      .input('p_Resp_txn', sql.NVarChar, resp.data.txn.split(':')[1])
      .input('p_Resp_ttl', sql.NVarChar, resp.data.ttl)
      .input('p_Resp_rrn', sql.NVarChar, resp.data.rrn)
      .input('p_Resp_uidToken', sql.NVarChar, resp.data.uidToken)
      .input('p_Resp_uidData_uid', sql.NVarChar, resp.data.uidData.uid)
      .input('p_Resp_uidData_poa_country', sql.NVarChar, resp.data.uidData.poa.country)
      .input('p_Resp_uidData_poa_pc', sql.NVarChar, resp.data.uidData.poa.pc)
      .input('p_Resp_uidData_poa_vtc', sql.NVarChar, resp.data.uidData.poa.vtc)
      .input('p_Resp_uidData_poa_street', sql.NVarChar, resp.data.uidData.poa.street)
      .input('p_Resp_uidData_poa_dist', sql.NVarChar, resp.data.uidData.poa.dist)
      .input('p_Resp_uidData_poa_state', sql.NVarChar, resp.data.uidData.poa.state)
      .input('p_Resp_uidData_poa_co', sql.NVarChar, resp.data.uidData.poa.co)
      .input('p_Resp_uidData_poa_house', sql.NVarChar, resp.data.uidData.poa.house)
      .input('p_Resp_uidData_tkn', sql.NVarChar, resp.data.uidData.tkn)
      .input('p_Resp_uidData_poi_gender', sql.NVarChar, resp.data.uidData.poi.gender)
      .input('p_Resp_uidData_poi_dob', sql.NVarChar, resp.data.uidData.poi.dob)
      .input('p_Resp_uidData_poi_name', sql.NVarChar, resp.data.uidData.poi.name)
      .input('p_Resp_uidData_prn_type', sql.NVarChar, resp.data.uidData.prn.type)
      .input(
        'p_Resp_uidData_prn_encodedPDF',
        sql.VarBinary(sql.MAX),
        Buffer.from(resp.data.uidData.prn.encodedPDF, 'binary')
      )
      .input('p_Resp_ts', sql.NVarChar, resp.data.ts)
      .input('p_Operation', sql.NVarChar, 'Update')
      .output('p_StatusCode', sql.NVarChar)
      .execute('proc_AadhaarAPIRequestResponseData');

    if (
      dbResult.output.p_StatusCode !== '200' ||
      dbResult.rowsAffected[0] <= 0
    ) {
      return {
        ErrorCode: '01',
        ErrorMsg: 'Error to update Aadhaar OTP validate data in database'
      };
    }

    /* ---------- CBS vs AADHAAR VALIDATIONS ---------- */
    if (
      RespCustomerData.CustomerName.toUpperCase() !==
      resp.data.uidData.poi.name.toUpperCase()
    ) {
      return {
        ErrorCode: '01',
        ErrorMsg:
          'Dear Customer, Applicant Name not matched as per your PNB bank details, please contact your branch for further assistance.'
      };
    }

    if (CBSYOB !== AadhaarYOB) {
      return {
        ErrorCode: '01',
        ErrorMsg:
          'Dear Customer, Applicant DOB not matched as per your PNB bank details, please contact your branch for further assistance.'
      };
    }

    if (RespCustomerData.Gender !== resp.data.uidData.poi.gender) {
      return {
        ErrorCode: '01',
        ErrorMsg:
          'Dear Customer, Applicant Gender not matched as per your PNB bank details, please contact your branch for further assistance.'
      };
    }

    if (CBSAadharLastFourDigit !== AadharLastFourDigit) {
      return {
        ErrorCode: '01',
        ErrorMsg:
          'Dear Customer, Applicant Aadhar not matched as per your PNB bank details, please contact your branch for further assistance.'
      };
    }

    /* ---------- UPDATE AADHAAR VALIDATION FLAG ---------- */
    await pool
      .request()
      .input('PMSNumber', sql.NVarChar, PMSNumber)
      .output('StatusCode', sql.NVarChar)
      .execute('proc_UpdateAadharValidationStatus');

    return {
      ErrorCode: resp.data.respCode,
      ErrorMsg: 'Aadhaar OTP successfully validated.'
    };

  } catch (err) {
    logger.error('ValidateAadhaarOTPAPI EXCEPTION', err);
    return {
      ErrorCode: '01',
      ErrorMsg: 'Aadhar OTP Validation Service Failed, Please try after sometime.'
    };
  }
}



// async function GetKeyConfigurationValue(KeyName) {
  // logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);
  // const query = `SELECT [KeyValue] FROM [dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;

  // try {
     // const pool = await getPool();
    // const request = pool.request();

    // const result = await request
      // .input('KeyName', sql.VarChar, KeyName)
      // .query(query);

    // if (result.recordset.length > 0) {

      // const jsonString = JSON.stringify(result.recordset, null, 2);
      // formattedString = jsonString.slice(1, -1);
      // //  logger.info('Result: ',formattedString);               
      // //  logger.info('Parse Result: ',JSON.parse(formattedString));
      // const OutValue = JSON.parse(formattedString).KeyValue;
      // //  logger.info('OutValue', OutValue.toString());
      // return JSON.parse(formattedString).KeyValue; // Return the formatted string
    // } else {
      // logger.info('No results found for the provided KeyName.');
      // return null;
    // }
  // } catch (err) {
    // console.error('Error:', err);
    // return null;
  // } finally {
    // await sql.close(); // Ensure the connection is closed
  // }
// }

async function GetKeyConfigurationValue(KeyName) {
  logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  const query = `
    SELECT [KeyValue]
    FROM [dbo].[SVND_CONFIGURATION_DATA]
    WHERE KeyName = @KeyName
  `;

  try {
    const pool = await getPool();
    const request = pool.request();

    const result = await request
      .input('KeyName', sql.VarChar, KeyName)
      .query(query);

    if (result.recordset && result.recordset.length > 0) {
      const value = result.recordset[0].KeyValue;
      logger.info('KeyValue fetched: ' + value);
      return value;
    } else {
      logger.info('No results found for the provided KeyName.');
      return null;
    }

  } catch (err) {
    logger.error('GetKeyConfigurationValue Error:', err);
    return null;
  }
}


async function GetDataByRefKeyAPI(refKey) {

    logger.info("******************** Inside GetDataByRefKeyAPI ********************");
      logger.info("refKey: " + refKey);

    return new Promise(async (resolve, reject) => {
        try {

            // Get configuration
            const APIUserID = await GetKeyConfigurationValue("Aadhaar_UserID");
            const APIPassword = await GetKeyConfigurationValue("Aadhaar_Password");
            const API_URL = await GetKeyConfigurationValue("AadharGetDataByRefKey");

            const authHeader = "Basic " + Buffer.from(APIUserID + ":" + APIPassword).toString("base64");

            const headers = {
                "Content-Type": "application/json",
                "Authorization": authHeader
            };

            const requestBody = { refKey };

            axios.post(API_URL, requestBody, { headers })
                .then(async (resp) => {

                    logger.info("API Response:", JSON.stringify(resp.data));

                    const data = resp.data;
                   logger.info('Response get from refKEY ', +data);
                    // Save to DB using existing Aadhaar SP
                    //await SaveADVResponseToDB(PMSNumber, JourneyID, data);

                    resolve({
                        ErrorCode: "00",
                        ErrorMsg: "Success",
                        Data: data
                    });

                })
                .catch(async (err) => {

                    logger.error("Error calling GetDataByRefKey API:", err);

                    resolve({
                        ErrorCode: "01",
                        ErrorMsg: "System error occurred."
                    });

                });

        } catch (ex) {
            logger.error(ex);
            //reject(ex);
			resolve({
                        ErrorCode: "01",
                        ErrorMsg: "System error occurred."
                    });
        }
    });
}

// async function GetDataByUIDAPI(uid) {
    // logger.info("================================================");
    // logger.info("Inside GetDataByUIDAPI");
    // logger.info("UID Requested : " + uid);
    // logger.info("================================================");

    // try {
        // /* ================= CONFIG ================= */
        // const APIUserID   = await GetKeyConfigurationValue("Aadhaar_UserID");
        // const APIPassword = await GetKeyConfigurationValue("Aadhaar_Password");
        // const API_URL     = await GetKeyConfigurationValue("AadharGetDataByUid");

        // const authHeader =
            // "Basic " + Buffer.from(`${APIUserID}:${APIPassword}`).toString("base64");

        // const headers = {
            // "Content-Type": "application/json",
            // "Authorization": authHeader
        // };

        // const requestBody = { uid };

        // try {
            // /* ================= HTTP 200 ================= */
            // const resp = await axios.post(API_URL, requestBody, { headers });

            // logger.info("GetDataByUID API - HTTP 200");
            // logger.info("Status : " + resp.status);
            // logger.info("Response Body:");
            // logger.info(JSON.stringify(resp.data, null, 2));

            // return {
                // ErrorCode: "00",
                // ErrorMsg: "Success",
                // Data: resp.data
            // };

        // } catch (err) {

            // /* ================= RAW ERROR DUMP ================= */
            // logger.info("ADV================================================");
            // logger.info("RAW AXIOS ERROR OBJECT");
            // logger.info("------------------------------------------------");

            // try {
                // logger.info(JSON.stringify(err, Object.getOwnPropertyNames(err), 2));
            // } catch (jsonErr) {
                // logger.info("RAW ERROR (string fallback): " + err.toString());
            // }

            // logger.info("================================================");

            // /* ================= HTTP ERROR ================= */
            // if (err.response) {
                // const status  = err.response.status;
                // const errData = err.response.data || null;

                // logger.info("GetDataByUID API - HTTP ERROR DETAILS");
                // logger.info("HTTP Status   : " + status);
                // logger.info("UID Requested : " + uid);

                // logger.info("Response Headers:");
                // logger.info(JSON.stringify(err.response.headers, null, 2));

                // logger.info("Response Body:");
                // logger.info(errData ? JSON.stringify(errData, null, 2) : "<EMPTY>");

                // return {
                    // ErrorCode: "HTTP_" + status,
                    // ErrorMsg: "UID Vault API returned HTTP error",
                    // Data: errData
                // };
            // }

            // /* ================= NO RESPONSE (NETWORK) ================= */
            // if (err.request) {
                // logger.info("GetDataByUID API - NO RESPONSE RECEIVED");
                // logger.info("UID Requested : " + uid);
                // logger.info("Request Object:");
                // logger.info(JSON.stringify(err.request, null, 2));
            // }

            // return {
                // ErrorCode: "NET_01",
                // ErrorMsg: "No response from UID Vault API",
                // Data: null
            // };
        // }

    // } catch (ex) {
        // /* ================= UNHANDLED ================= */
        // logger.info("================================================");
        // logger.info("UNHANDLED EXCEPTION IN GetDataByUIDAPI");
        // logger.info("UID Requested : " + uid);
        // logger.info("Error Message : " + ex.message);
        // logger.info("Stack Trace   : ");
        // logger.info(ex.stack);
        // logger.info("================================================");

        // return {
            // ErrorCode: "EX_01",
            // ErrorMsg: ex.message || "Unhandled exception occurred",
            // Data: null
        // };
    // }
// }

// async function GetDataByUIDAPI(uid) {
    // logger.info("================================================");
    // logger.info("Inside GetDataByUIDAPI");
    // logger.info("UID Requested : " + uid);
    // logger.info("================================================");

    // try {
        // /* ================= 1. CONFIGURATION ================= */
        // const APIUserID   = await GetKeyConfigurationValue("Aadhaar_UserID");
        // const APIPassword = await GetKeyConfigurationValue("Aadhaar_Password");
        // const API_URL     = await GetKeyConfigurationValue("AadharGetDataByUid");

        // const authHeader = "Basic " + Buffer.from(`${APIUserID}:${APIPassword}`).toString("base64");

        // const headers = {
            // "Content-Type": "application/json",
            // "Authorization": authHeader
        // };

        // const requestBody = { uid };

        // /* ================= 2. API EXECUTION ================= */
        // try {
            // const resp = await axios.post(API_URL, requestBody, { headers, timeout: 10000 });

            // logger.info("GetDataByUID API - HTTP 200 SUCCESS");
            // logger.info("Response Body: " + JSON.stringify(resp.data));

            // return {
                // ErrorCode: "00",
                // ErrorMsg: "Success",
                // Data: resp.data
            // };

        // } catch (err) {
            // /* ================= 3. SAFE ERROR LOGGING ================= */
            // logger.error("ADV================================================");
            // logger.error("API ERROR DETECTED for UID: " + uid);
            
            // // Log basic error message (e.g., "Request failed with status code 404")
            // logger.error("Error Message: " + err.message);

            // // A. Handle HTTP Response Errors (Server responded with 4xx/5xx)
            // if (err.response) {
                // const status = err.response.status;
                // const errData = err.response.data;

                // logger.error(`HTTP ERROR DETAILS - Status: ${status}`);
                // logger.error("Response Data: " + JSON.stringify(errData));

                // return {
                    // ErrorCode: "HTTP_" + status,
                    // ErrorMsg: "UID Vault API returned HTTP error",
                    // Data: errData
                // };
            // }

            // // B. Handle Network/Timeout Errors (No response received)
            // if (err.request) {
                // logger.error("NETWORK ERROR: No response received from server (Timeout or Connection Refused).");
                // return {
                    // ErrorCode: "NET_01",
                    // ErrorMsg: "No response from UID Vault API",
                    // Data: null
                // };
            // }

            // // C. Handle Request Setup Errors
            // logger.error("REQUEST SETUP ERROR: " + err.message);
            // return {
                // ErrorCode: "REQ_ERR",
                // ErrorMsg: err.message,
                // Data: null
            // };
        // }

    // } catch (ex) {
        // /* ================= 4. UNHANDLED GLOBAL EXCEPTION ================= */
        // logger.error("================================================");
        // logger.error("CRITICAL EXCEPTION IN GetDataByUIDAPI");
        // logger.error("Exception Message: " + ex.message);
        // logger.error("Stack Trace: " + ex.stack);
        // logger.error("================================================");

        // return {
            // ErrorCode: "EX_01",
            // ErrorMsg: "Internal processing error: " + ex.message,
            // Data: null
        // };
    // }
// }

async function GetDataByUIDAPI(uid) {
    logger.info("================================================");
    logger.info("Inside GetDataByUIDAPI");
    logger.info("UID Requested : " + uid);
    logger.info("================================================");

    try {
        /* ================= 1. CONFIGURATION ================= */
        const APIUserID    = await GetKeyConfigurationValue("Aadhaar_UserID");
        const APIPassword = await GetKeyConfigurationValue("Aadhaar_Password");
        const API_URL     = await GetKeyConfigurationValue("AadharGetDataByUid");

        const authHeader =
            "Basic " + Buffer.from(`${APIUserID}:${APIPassword}`).toString("base64");

        const headers = {
            "Content-Type": "application/json",
            "Authorization": authHeader
        };

        const requestBody = { uid };

        /* ================= 2. API EXECUTION ================= */
        let response;

        try {
            response = await axios.post(API_URL, requestBody, {
                headers,
                timeout: 60000,
                validateStatus: () => true // 👈 IMPORTANT: accept ALL HTTP status codes
            });
        } catch (networkErr) {
            logger.error("NETWORK ERROR: Unable to reach UID Vault API");
            logger.error(networkErr.message);

            return {
                ErrorCode: "NET_01",
                ErrorMsg: "Network error while calling UID Vault API",
                Data: null
            };
        }

        /* ================= 3. RESPONSE HANDLING ================= */
			const httpStatus = response.status;
			const respData = response.data;

			logger.info(`UID Vault API HTTP Status : ${httpStatus}`);

			if (respData && typeof respData === "object") {
				const businessCode = respData.respCode;
				const businessDesc = respData.respDesc || "";
				
				logger.info(`UID Vault API businessCode : ${businessCode}`);
				logger.info(`UID Vault API businessDesc : ${businessDesc}`);

				// Define success based on common success codes (000, 007, etc.) 
				// OR the presence of "successfully" in description
				const isSuccessCode = (businessCode === "000" || businessCode === "007");
				const isSuccessMsg = businessDesc.toLowerCase().includes("successfully");

				if (isSuccessCode || isSuccessMsg) {
					return {
						ErrorCode: "00",
						ErrorMsg: "Success",
						Data: respData
					};
				}

				// ❌ Handle Business Errors (like 500 + "Uid is not valid")
				logger.info(`UID Vault Business Failure: ${businessCode} - ${businessDesc}`);
				return {
					ErrorCode: businessCode || "01",
					ErrorMsg: businessDesc || "UID Vault business error",
					Data: respData
				};
			}

        /* ================= 4. UNEXPECTED RESPONSE ================= */
        logger.info("Unexpected API response format");

        return {
            ErrorCode: "RESP_FMT_ERR",
            ErrorMsg: "Invalid response received from UID Vault API",
            Data: respData || null
        };

    } catch (ex) {
        /* ================= 5. UNHANDLED EXCEPTION ================= */
        logger.info("================================================");
        logger.info("CRITICAL EXCEPTION IN GetDataByUIDAPI");
        logger.info("Exception Message: " + ex.message);
        logger.info("Stack Trace: " + ex.stack);
        logger.info("================================================");

        return {
            ErrorCode: "EX_01",
            ErrorMsg: "Internal processing error",
            Data: null
        };
    }
}

// async function GetDataByUIDAPI(uid) {
    // logger.info("******************** Inside GetDataByuidAPI ********************");
    // logger.info("Request UID: " + uid);

    // return new Promise(async (resolve, reject) => {
        // try {
            // // Get configuration
            // const APIUserID = await GetKeyConfigurationValue("Aadhaar_UserID");
            // const APIPassword = await GetKeyConfigurationValue("Aadhaar_Password");
            // const API_URL = await GetKeyConfigurationValue("AadharGetDataByUid");

            // const authHeader = "Basic " + Buffer.from(APIUserID + ":" + APIPassword).toString("base64");

            // const headers = {
                // "Content-Type": "application/json",
                // "Authorization": authHeader
            // };

            // const requestBody = { uid };

            // axios.post(API_URL, requestBody, { headers })
                // .then(async (resp) => {
                    // // LOGGING EVERYTHING IN SUCCESS
                    // logger.info("--- GetDataByuid API Success Response ---");
                    // logger.info("Status: " + resp.status);
                    // logger.info("Body: " + JSON.stringify(resp.data, null, 2));

                    // const data = resp.data;

                    // resolve({
                        // ErrorCode: "00",
                        // ErrorMsg: "Success",
                        // Data: data
                    // });
                // })
                // .catch(async (err) => {
                    // // LOGGING EVERYTHING IN FAILURE
                    // logger.error("--- GetDataByuid API Failure ---");
                    
                    // if (err.response) {
                        // // The server responded with a status code outside the 2xx range
                        // logger.error("Status: " + err.response.status);
                        // logger.error("Response Data: " + JSON.stringify(err.response.data));
                        // logger.error("Headers: " + JSON.stringify(err.response.headers));
                    // } else if (err.request) {
                        // // The request was made but no response was received
                        // logger.error("No response received from server. Request details: " + err.config.url);
                    // } else {
                        // // Something happened in setting up the request
                        // logger.error("Message: " + err.message);
                    // }

                    // resolve({
                        // ErrorCode: "01",
                        // ErrorMsg: "System error occurred."
                    // });
                // });

        // } catch (ex) {
            // logger.error("Unhandled Exception in GetDataByUIDAPI: ", ex);
            // reject(ex);
        // }
    // });
// }

async function SaveADVResponseToDB(PMSNumber, JourneyID, apiResponse) {
    try {

        const vault = apiResponse.vaultData;

		const pool = await getPool();
		const request = pool.request();
		
        // const conn = await new sql.ConnectionPool(config).connect();
        // const request = new sql.Request(conn);

        request.input("p_Req_ret", sql.VarChar, null);
        request.input("PMSNumber", sql.VarChar, PMSNumber);
        request.input("JourneyID", sql.VarChar, JourneyID);

        // Request Data
        request.input("p_Req_aadhaarId", sql.VarChar, vault.refKey);
        request.input("p_Req_respCode", sql.VarChar, apiResponse.respCode);
        request.input("p_Req_respDesc", sql.VarChar, apiResponse.respDesc);
        request.input("p_Req_uidaiAuthCode", sql.VarChar, null);
        request.input("p_Req_txn", sql.VarChar, null);
        request.input("p_Req_communicationId", sql.VarChar, null);
        request.input("p_Req_uidToken", sql.VarChar, vault.uidToken);
        request.input("p_Req_uidType", sql.VarChar, null);
        request.input("p_Req_info", sql.VarChar, vault.additionalData1);

        // Response Data — ALL NULL (ADV API does not return these fields)
        request.input("p_Resp_ret", sql.VarChar, null);
        request.input("p_Resp_respCode", sql.VarChar, null);
        request.input("p_Resp_respDesc", sql.VarChar, null);
        request.input("p_Resp_uidaiAuthCode", sql.VarChar, null);
        request.input("p_Resp_communicationId", sql.VarChar, null);
        request.input("p_Resp_txn", sql.VarChar, null);
        request.input("p_Resp_ttl", sql.VarChar, null);
        request.input("p_Resp_rrn", sql.VarChar, null);
        request.input("p_Resp_uidToken", sql.VarChar, null);
        request.input("p_Resp_uidData_uid", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_country", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_pc", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_vtc", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_street", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_dist", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_state", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_co", sql.VarChar, null);
        request.input("p_Resp_uidData_poa_house", sql.VarChar, null);
        request.input("p_Resp_uidData_tkn", sql.VarChar, null);
        request.input("p_Resp_uidData_poi_gender", sql.VarChar, null);
        request.input("p_Resp_uidData_poi_dob", sql.VarChar, null);
        request.input("p_Resp_uidData_poi_name", sql.VarChar, null);
        request.input("p_Resp_uidData_prn_type", sql.VarChar, null);
        request.input("p_Resp_uidData_prn_encodedPDF", sql.VarBinary, null);
        request.input("p_Resp_ts", sql.VarChar, null);

        // Common fields
        request.input("p_Operation", sql.VarChar, "Insert");
        request.output("p_StatusCode", sql.VarChar);

        const result = await request.execute("proc_AadhaarAPIRequestResponseData");

        logger.info("DB Save Status: " + result.output.p_StatusCode);

        conn.close();
        return true;

    } catch (err) {
        logger.error("DB Save Error:", err);
        return false;
    }
}


async function FetchMissingAccountAPI(CustId, Scheme_Code, PMSNumber, JourneyID) {
  logger.info('************************ Inside FetchMissingAccountAPI ************************');
  logger.info('CustId: ' + CustId);
  logger.info('Scheme_Code: ' + Scheme_Code);
  logger.info('PMSNumber: ' + PMSNumber);
  logger.info('JourneyID: ' + JourneyID);

  let finalResp;

  try {
    const APIUserID = await GetKeyConfigurationValue('Aadhaar_UserID');
    const APIPassword = await GetKeyConfigurationValue('Aadhaar_Password');
    const BaseURL = await GetKeyConfigurationValue('Adhoc_FetchMissingAccount_URL');

    const API_URL = `${BaseURL}?CustId=${encodeURIComponent(CustId)}&Scheme_Code=${encodeURIComponent(Scheme_Code)}`;
    const authHeader = 'Basic ' + Buffer.from(`${APIUserID}:${APIPassword}`).toString('base64');

    const headers = {
      'Authorization': authHeader,
      'Content-Type': 'application/json'
    };

    // Insert API Log
    const insertLog = await logError.APIRequestResponseLogs(
      PMSNumber,
      JourneyID,
      'FetchMissingAccountAPI',
      API_URL,
      API_URL,
      null,
      null,
      null,
      'Insert'
    );

    if (insertLog.ErrorCode !== '00') {
      return {
        ErrorCode: '01',
        ErrorMsg: 'Unable to initialize FetchMissingAccount API logging.'
      };
    }

    let response;
    try {
      response = await axios.post(API_URL, null, {
        headers,
        timeout: 15000,
        validateStatus: () => true
      });

      logger.info('FetchMissingAccountAPI HTTP Status: ' + response.status);
      logger.info('FetchMissingAccountAPI Response: ' + JSON.stringify(response.data));
    } catch (networkErr) {
      logger.info('NETWORK ERROR in FetchMissingAccountAPI: ' + networkErr.message);

      await logError.ErrorLogs(
        PMSNumber,
        JourneyID,
        'NO_RESPONSE',
        'NETWORK_FAILURE',
        'FetchMissingAccountAPI'
      );

      return {
        ErrorCode: '01',
        ErrorMsg: 'Unable to reach Adhoc service. Please try later.'
      };
    }

    // Update API Log with Response
    await logError.APIRequestResponseLogs(
      PMSNumber,
      JourneyID,
      null,
      null,
      null,
      JSON.stringify(response.data),
      JSON.stringify(response.data),
      insertLog.RequestId,
      'Update'
    );

    const data = response.data;

    if (!data || typeof data !== 'object') {
      return {
        ErrorCode: '01',
        ErrorMsg: 'Invalid response received from Adhoc service.'
      };
    }

    // ---------------- BUSINESS + DB UPDATE ----------------
    if (data.Status === 'SUCCESS' && data.AccountNo) {

      try {
        //const pool = await sql.connect(config);
		
		const pool = await getPool();
		const request = pool.request();

        //const updateResult = await pool.request()
        const updateResult = await request
          .input('LoanAccountNumber', sql.NVarChar, data.AccountNo)
          .input('CustomerID', sql.NVarChar, CustId)
          .input('PMSNumber', sql.NVarChar, PMSNumber)
          .input('JourneyID', sql.NVarChar, JourneyID)
          .query(`
            UPDATE SVND_LOAN_JOURNEY_MASTER
            SET
              JourneyMilestone = '108',
              JourneyMilestoneDesc = 'Loan Account Opened in CBS',
              isLoanAccountOpened = 1,
              LoanAccountOpenDate = GETDATE(),
              LoanAccountNumber = @LoanAccountNumber,
			  isJourneyRejected=0, JourneyRejectedReason=null, JourneyRejectionCode=null, isCustomerJourneyCompleted=1
            WHERE
              CustomerID = @CustomerID
              AND PMSNumber = @PMSNumber
              AND JourneyID = @JourneyID
          `);

        logger.info(
          `Journey Master updated. RowsAffected=${updateResult.rowsAffected[0]}, AccountNo=${data.AccountNo}`
        );

        if (updateResult.rowsAffected[0] <= 0) {
          return {
            ErrorCode: '01',
            ErrorMsg: 'Account fetched but journey record not found for update.',
            AccountNo: data.AccountNo
          };
        }

      } catch (dbErr) {
        logger.info('Failed to update SVND_LOAN_JOURNEY_MASTER: ' + dbErr.message);
        logger.info(dbErr.stack);

        return {
          ErrorCode: '01',
          ErrorMsg: 'Account fetched but failed to update journey status.',
          AccountNo: data.AccountNo
        };
      }

      finalResp = {
        ErrorCode: '00',
        ErrorMsg: data.Message || 'Account fetched and journey updated successfully.',
        AccountNo: data.AccountNo
      };

    } else {
      finalResp = {
        ErrorCode: '01',
        ErrorMsg: data.Message || 'Failed to fetch account.',
        AccountNo: null
      };
    }

    logger.info('FetchMissingAccountAPI Final Response: ' + JSON.stringify(finalResp));
    return finalResp;

  } catch (ex) {
    logger.info('Exception in FetchMissingAccountAPI: ' + ex.message);
    logger.info(ex.stack);

    return {
      ErrorCode: 'EX_01',
      ErrorMsg: 'Internal processing error in FetchMissingAccountAPI.'
    };
  }
}



module.exports = { SendAadhaarOTPAPI, ValidateAadhaarOTPAPI ,GetDataByUIDAPI,GetDataByRefKeyAPI, FetchMissingAccountAPI};