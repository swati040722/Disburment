// ErrorLog.js

const express = require("express");
const axios = require('axios');
const { sql, getPool } = require('./db');
// Dedicated SIDBI client – isolated from SOAP / CBS calls
const sidbiClient = axios.create({
  headers: {
    'Content-Type': 'application/json'
  },
  timeout: 60000
});
//const sql = require("mssql");
const app = express();
app.use(express.json())
var cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');

app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

const { HttpsProxyAgent } = require('https-proxy-agent');//for System Proxy
const https = require('https');

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('SIDBIDataLayer');
const objGeneralOperation = require('./GeneralDataLayer');
const logError = require('./ErrorLog');

// Set up cookie parser middleware
app.use(cookieParser());
//SQL Server configuration
// var config = {
//   user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 60000
//   },
//   "options": {
//     "encrypt": false
//   }
// }

const config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};






const proxyUser = '5216750';
const proxyPass = 'Welcome!12345';
const proxyHost = '10.192.205.150';
const proxyPort = 3128;

// Construct correct proxy URL
const proxyUrl = `http://${proxyUser}:${proxyPass}@${proxyHost}:${proxyPort}`;
const agent = new HttpsProxyAgent(proxyUrl);






// const proxyAddress = "http://10.192.33.247:7001";
// const proxyUser = "5202714";
// const proxyPass = "Welcome@122025";
// const proxyUrl = `http://${proxyUser}:${proxyPass}@10.192.33.247:7001`;

 //Define your proxy URL (you can get this from environment variables or hardcode it)
//const proxyUrl = process.env.HTTPS_PROXY || 'http://10.192.34.167:3128';//http://10.192.34.167:3128 //http://corpoffice.pnb.net:3128  //http://10.192.20.171:8001   //111000
// Create a new agent instance
//const ProxyAgent = new HttpsProxyAgent(proxyUrl); //111000


// const agent = new https.Agent({
//    rejectUnauthorized: false, // Set to false to bypass certificate verification 
//    HttpsProxyAgent:proxyUrl 
// });
const httpAgent = new https.Agent({
  rejectUnauthorized: false, // Set to false to bypass certificate verification 

});


// function CallSIDBICurrentStatusAPI(PMSNumber, JourneyID, CustomerJourneyDataParsed) {
  // logger.info('************************************Inside SIDBICurrentStatusAPI Method************************************');
  // logger.info('PMSNumber ' + PMSNumber);
  // logger.info('Mobile No:' + CustomerJourneyDataParsed.MobileNo);
  // logger.info('PMS MOBILENO:' + MOBILENO);

  // return new Promise(async (resolve, reject) => {
    // try {


      // const ClientID = await GetKeyConfigurationValue('SIDBI_ClientID')
      // logger.info('ClientID: ' + ClientID);

      // // sidbiClient.post(API_URL, JSON.stringify(body), {headers,httpsAgent: agent}).then(resp => {
      // const SIDBI_STATUS_API_URL = await GetKeyConfigurationValue('SIDBI_STATUS_API_URL')
      // logger.info('SIDBI_STATUS_API_URL: ' + SIDBI_STATUS_API_URL);

		// objGeneralOperation.getPMSData(PMSNumber, "FreshJourney").then(async (PMSDetails) => {
							// logger.info('Out PMSDetails: '+ JSON.stringify(PMSDetails));
							// if (PMSDetails != null) {
							  // PMSDataParse = JSON.parse(PMSDetails);
							// }

      // //CustomerJourneyDataParsed.MobileNo
	  // let MOBILENO=PMSDataParse.MOBILENO;
	 // let targetMobileNo;

		// // Check if MOBILENO is present and valid
		// if (MOBILENO && MOBILENO !== "") {
			// targetMobileNo = MOBILENO;
		// } else {
			// // Fallback to the parsed journey data
			// targetMobileNo = CustomerJourneyDataParsed.MobileNo;
		// }

		// logger.info(`Final Mobile Number used for SIDBI Request: ${targetMobileNo}`);

		// const bankJSONRequest = new SIDBICurrentStatusRequestBody("", ClientID, targetMobileNo, PMSNumber);
		
      // logger.info('JSON Request: ' + JSON.stringify(bankJSONRequest));

      // const Emptybody = "Call SIDBI API for LOR Status and Application Status";
      // //Insert Error Log
      // logError.APIRequestResponseLogs(PMSNumber, JourneyID, "SIDBICurrentStatusAPI", JSON.stringify(bankJSONRequest), JSON.stringify(bankJSONRequest), null, null, null, "Insert").then(async (APILogsResp) => {
        // logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
        // if (APILogsResp.ErrorCode == "00") {
          // await sidbiClient.post(SIDBI_STATUS_API_URL, JSON.stringify(bankJSONRequest), { httpsAgent: ProxyAgent }).then(async SIDBIStatusAPIResp => {

            // if (JSON.stringify(SIDBIStatusAPIResp.data, null, 2) != null) {

              // logger.info(`SIDBI Status API Response: ${JSON.stringify(SIDBIStatusAPIResp.data)}`);
              // logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(SIDBIStatusAPIResp.data), JSON.stringify(SIDBIStatusAPIResp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                // logger.info("Update ErrorCode " + APILogsResp.ErrorCode)
                // if (APILogsResp.ErrorCode == "00") {
                  // const data = SIDBIStatusAPIResp.data.response;
                  // const status = SIDBIStatusAPIResp.data.status;
                  // // Extracting values from the JSON
                  // if (status.isSuccess) {
                    // if (data.applicationExists) {
                      // logger.info(`Exists Status: ${data.applicationExists}`);
                      // const application = data.lstResLenderApplicationStatus[0];
                      // logger.info(`Application No: ${application.applicationNo}`);
                      // logger.info(`Applicant Name: ${application.applicantname}`);
                      // logger.info(`Vendor Category: ${application.vendorCategory}`);
                      // logger.info(`Mobile No: ${application.mobileNo}`);
                      // logger.info(`Application Date: ${application.applicationDate}`);
                      // logger.info(`Picked Up By Bank: ${application.pickedUpByBank}`);
                      // logger.info(`Picked Up By Branch: ${application.pickedUpByBranch}`);
                      // logger.info(`Picked Up Date: ${application.pickedUpDt}`);
                      // logger.info(`Sanctioned Amount: ${application.sanctionedAmount}`);
                      // logger.info(`Sanctioned Date: ${application.sanctionedDt}`);
                      // logger.info(`Disbursed Bank: ${application.disbursedBank}`);
                      // logger.info(`Disbursed Branch: ${application.disbursedBranch}`);
                      // logger.info(`Disbursed Branch IFSC: ${application.disbursedBranchIFSC}`);
                      // logger.info(`Disbursed Date: ${application.disbursedDt}`);
                      // logger.info(`Disbursed Amount: ${application.disbursedAmount}`);
                      // logger.info(`Loan Term: ${application.loanTerm}`);
                      // logger.info(`Current Status: ${application.currentStatus}`);
                      // logger.info(`LOR Status: ${application.loRStatus}`);
                      // logger.info(`Status: ${application.status}`);

                      // //application.currentStatus = "Sanctioned";//Logged for Rejection
// //application.loRStatus = 'Approved';  
                         // logger.info(`LOR Status: ${application.loRStatus}`);
                      // objGeneralOperation.SIDBICurrentStatus_Update(PMSNumber, JourneyID, application.loRStatus, application.currentStatus).then(async (SIDBIStatusResp) => {
                        // logger.info('Out SIDBICurrentStatus_Update Result: ', JSON.stringify(SIDBIStatusResp));
                        // if (SIDBIStatusResp.ErrorCode == "00") {
                          // logger.info('Swati 111111111111111111111111111111111111111111111111111111111111111');
                          // //All Application Status: Pickup/Sanction/Disbursed/Logged/Disabled                    
                          

                          // //  if (application.loRStatus != "Approved" && application.loRStatus != "Not Applicable")
                          // if (application.loRStatus != "Approved" ) {
                            // logger.info(application.loRStatus);
                            // outResp = {
                              // "ErrorCode": "02",
                              // "ErrorMsg": "You are not eligible for Digital Journey, please contact the concerned PNB branch",  //LOR status is other than Approved. Please contact the branch for further details.
                              // "StatusCode": status.isSuccess,
                            // }
                            // resolve(outResp);
                          // }
                          // else if (application.currentStatus != "Picked Up" && application.currentStatus != "Sanctioned") {
                            // outResp = {
                              // "ErrorCode": "02",
                              // "ErrorMsg": "Application curren status is not Pickup or Sanction. Please contact the branch for further details.",
                              // "StatusCode": status.isSuccess,
                            // }
                            // resolve(outResp);
                          // }
                          // else {
                            // logger.info('Swati 22222222222222222222222222222222222222222222222222222222222222');
                            // outResp = {
                              // "ErrorCode": SIDBIStatusResp.ErrorCode,
                              // "ErrorMsg": SIDBIStatusResp.ErrorMsg,
                              // "StatusCode": status.isSuccess,
                            // }
                            // resolve(outResp);
                          // }
                        // }
                        // else {
                          // outResp = {
                            // "ErrorCode": "01",
                            // "ErrorMsg": SIDBIStatusResp.ErrorMsg,
                            // "StatusCode": status.isSuccess,
                          // }
                          // resolve(outResp);
                        // }
                      // });
                    // }
                    // else {
                      // outResp = {
                        // "ErrorCode": "01",
                        // "ErrorMsg": "No current status available with SIDBI for your PMS application number. Please check with SIDBI.",
                        // "StatusCode": status.isSuccess,
                      // }
                      // resolve(outResp);
                    // }
                  // }
                  // else {
                    // outResp = {
                      // "ErrorCode": "01",
                      // "ErrorMsg": "No response from SIDBI for your PMS application.",
                      // "StatusCode": status.isSuccess,
                    // }
                    // resolve(outResp);
                  // }

                // }
              // });
            // }
          // })
            // .catch(error => {
              // console.error('Error posting to SIDBI Current Status API:' + error);
              // // console.error('Error Loan Status Inquiry API Error Response:',error.response);
              // // console.error('Error Loan Status Inquiry API Error Response Text:',error.response.statusText);
              // // console.error('Error Loan Status Inquiry API Error Response data:',error.response.data);
              // logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "SIDBICurrentStatusAPI").then(async (ErrorLogResp) => {
                // ExceptionResp = {
                  // "ErrorCode": "01",
                  // "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                  // //"ErrorMsg":error.response.status+" - "+error.response.statusText,
                // }
                // resolve(ExceptionResp);
              // });
            // });
        // }
      // });
    // } catch (err1) {
      // logger.info('Exception err1: ' + err1);
      // reject(err1);
    // }
  // });
// }

function CallSIDBICurrentStatusAPI(PMSNumber, JourneyID, CustomerJourneyDataParsed) {
    logger.info('************************************Inside SIDBICurrentStatusAPI Method************************************');
    logger.info('PMSNumber ' + PMSNumber);
    logger.info('Default Mobile No (Journey Data): ' + CustomerJourneyDataParsed.MobileNo);

    return new Promise(async (resolve, reject) => {
        try {
            const ClientID = await GetKeyConfigurationValue('SIDBI_ClientID');
            const SIDBI_STATUS_API_URL = await GetKeyConfigurationValue('SIDBI_STATUS_API_URL');
            logger.info('ClientID: ' + ClientID);
            logger.info('SIDBI_STATUS_API_URL: ' + SIDBI_STATUS_API_URL);

            // 1. Fetch PMS Data first to get the correct Mobile Number
            objGeneralOperation.getPMSData(PMSNumber, "FreshJourney").then(async (PMSDetails) => {
                logger.info('Out PMSDetails: ' + JSON.stringify(PMSDetails));

                let PMSDataParse = {};
                if (PMSDetails != null) {
                    // Check if it's already an object or needs parsing
                    PMSDataParse = (typeof PMSDetails === 'string') ? JSON.parse(PMSDetails) : PMSDetails;
                }

                let MOBILENO = PMSDataParse.MOBILENO;
                let targetMobileNo;

                // Priority logic for Mobile Number
                if (MOBILENO && MOBILENO !== "") {
                    targetMobileNo = MOBILENO;
                } else {
                    targetMobileNo = CustomerJourneyDataParsed.MobileNo;
                }

                logger.info(`Final Mobile Number used for SIDBI Request: ${targetMobileNo}`);

                const bankJSONRequest = new SIDBICurrentStatusRequestBody("", ClientID, targetMobileNo, PMSNumber);
                logger.info('JSON Request: ' + JSON.stringify(bankJSONRequest));

                // 2. Log the Request and call SIDBI API
                logError.APIRequestResponseLogs(PMSNumber, JourneyID, "SIDBICurrentStatusAPI", JSON.stringify(bankJSONRequest), JSON.stringify(bankJSONRequest), null, null, null, "Insert").then(async (APILogsResp) => {
                    logger.info("Insert ErrorCode " + APILogsResp.ErrorCode);

                    if (APILogsResp.ErrorCode == "00") {
                       // await sidbiClient.post(SIDBI_STATUS_API_URL, JSON.stringify(bankJSONRequest), { httpsAgent: ProxyAgent }).then(async SIDBIStatusAPIResp => {
                           await sidbiClient.post(SIDBI_STATUS_API_URL, JSON.stringify(bankJSONRequest), { httpsAgent: agent }).then(async SIDBIStatusAPIResp => { 
                            if (SIDBIStatusAPIResp.data != null) {
                                logger.info(`SIDBI Status API Response: ${JSON.stringify(SIDBIStatusAPIResp.data)}`);

                                logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(SIDBIStatusAPIResp.data), JSON.stringify(SIDBIStatusAPIResp.data), APILogsResp.RequestId, "Update").then(async (UpdateLogResp) => {
                                    logger.info("Update ErrorCode " + UpdateLogResp.ErrorCode);

                                    if (UpdateLogResp.ErrorCode == "00") {
                                        const data = SIDBIStatusAPIResp.data.response;
                                        const status = SIDBIStatusAPIResp.data.status;

                                        if (status.isSuccess) {
                                            if (data.applicationExists) {
                                                const application = data.lstResLenderApplicationStatus[0];
                                                logger.info(`Current Status: ${application.currentStatus} | LOR Status: ${application.loRStatus}`);

                                                objGeneralOperation.SIDBICurrentStatus_Update(PMSNumber, JourneyID, application.loRStatus, application.currentStatus).then(async (SIDBIStatusResp) => {
                                                    
                                                    let outResp;
                                                    if (SIDBIStatusResp.ErrorCode == "00") {
                                                        if (application.loRStatus != "Approved") {
                                                            outResp = {
                                                                "ErrorCode": "02",
                                                                "ErrorMsg": "You are not eligible for Digital Journey, please contact the concerned PNB branch",
                                                                "StatusCode": status.isSuccess,
                                                            };
                                                            resolve(outResp);
                                                        } else if (application.currentStatus != "Picked Up" && application.currentStatus != "Sanctioned") {
                                                            outResp = {
                                                                "ErrorCode": "02",
                                                                "ErrorMsg": "Application current status is not Pickup or Sanction. Please contact the branch for further details.",
                                                                "StatusCode": status.isSuccess,
                                                            };
                                                            resolve(outResp);
                                                        } else {
                                                            outResp = {
                                                                "ErrorCode": SIDBIStatusResp.ErrorCode,
                                                                "ErrorMsg": SIDBIStatusResp.ErrorMsg,
                                                                "StatusCode": status.isSuccess,
                                                            };
                                                            resolve(outResp);
                                                        }
                                                    } else {
                                                        resolve({
                                                            "ErrorCode": "01",
                                                            "ErrorMsg": SIDBIStatusResp.ErrorMsg,
                                                            "StatusCode": status.isSuccess,
                                                        });
                                                    }
                                                });
                                            } else {
                                                resolve({ "ErrorCode": "01", "ErrorMsg": "No current status available with SIDBI.", "StatusCode": status.isSuccess });
                                            }
                                        } else {
                                            resolve({ "ErrorCode": "01", "ErrorMsg": "No response from SIDBI.", "StatusCode": status.isSuccess });
                                        }
                                    }
                                });
                            }
                        }).catch(error => {
                            logger.info('Error SIDBI API: ' + error.message);
                            const status = error.response ? error.response.status : "500";
                            const statusText = error.response ? error.response.statusText : "Network Error";
                            
                            logError.ErrorLogs(PMSNumber, JourneyID, status, statusText, "SIDBICurrentStatusAPI").then(async () => {
                                resolve({ "ErrorCode": "01", "ErrorMsg": "System error occurred at SIDBI API." });
                            });
                        });
                    }
                });
            });
        } catch (err1) {
            logger.info('Exception err1: ' + err1);
            //reject(err1);
			 resolve({ "ErrorCode": "01", "ErrorMsg": "System exception occurred at SIDBI API." });
        }
    });
}

class SIDBICurrentStatusRequestBody {
  constructor(apiVersion, clientId, mobileNo, pmsApplicationNo) {
    this.header = {
      apiVersion: apiVersion,
      clientID: clientId,
      timeStamp: this.getEpochTimestamp()
    };
    this.request = {
      MobileNo: mobileNo,
      PMSApplicationNo: pmsApplicationNo
    };
  }

  getEpochTimestamp() {
    return Math.floor(Date.now() / 1000); // Returns the timestamp in seconds
  }

  toJSON() {
    return {
      header: this.header,
      request: this.request
    };
  }
}


function CallSIDBI_SanctionedOrDisbursedStatusAPI(PMSNumber, JourneyID, JourneyStatus, APIURL, CityKYCStatusDetails) {
  logger.info('#########inside CallSIDBI_SanctionedOrDisbursedStatusAPI Method:############');
  logger.info(`PMSNumber ${PMSNumber}`);
  logger.info(`JourneyID ${JourneyID}`);
  logger.info(`JourneyStatus ${JourneyStatus}`);
  logger.info(`APIURL ${APIURL}`);
  return new Promise(async (resolve, reject) => {
    try {
      const ClientID = await GetKeyConfigurationValue('SIDBI_ClientID');

      logger.info(`ClientID ${ClientID}`);

      let bankJSONRequest;

      logger.info(`SOLID HO`)
      logger.info(`SOLID ${JSON.parse(CityKYCStatusDetails).solid}`)
      objGeneralOperation.getCustomerJourneyData(PMSNumber).then(async (RespCustomerJourneyData) => {
        objGeneralOperation.getBranchInformation(JSON.parse(CityKYCStatusDetails).solid).then(async (RespBranchInformation) => {
          //logger.info("RespCustomerJourneyData"+JSON.stringify(RespCustomerJourneyData));
          logger.info(`######################################################################`);
          logger.info(`RespBranchInformation ${JSON.stringify(RespBranchInformation)}`);
          if (JourneyStatus == "Sanctioned") {
            bankJSONRequest = new SIDBISanctionedStatusRequest("1", ClientID, PMSNumber, JourneyStatus, RespBranchInformation, RespCustomerJourneyData);
          }
          if (JourneyStatus == "Disbursed") {
            bankJSONRequest = new SIDBIDisbursedStatusRequest("1", ClientID, PMSNumber, JourneyStatus, RespBranchInformation, RespCustomerJourneyData);
          }
           else if (JourneyStatus == "RJ000012")//MarkedAsNotInterestedAPI        
          {
            logger.info(`#####Inside JourneyStatus with #### ${JourneyStatus}`);
             bankJSONRequest = new SIDBIRejectedStatusUpdateRequest("1", ClientID, PMSNumber, JourneyStatus);
           }
          else if (JourneyStatus == "RJ000013")//MarkedAsNotInterestedAPI        
          {
            logger.info(`#####Inside JourneyStatus with #### ${JourneyStatus}`);
            bankJSONRequest = new SIDBIRejectedStatusUpdateRequest("1", ClientID, PMSNumber, JourneyStatus);
          }
           else if (JourneyStatus == "RJ000057")//MarkedAsNotInterestedAPI     for NPA tranch 2 and tranche 3   
          {
            logger.info(`#####Inside JourneyStatus with #### ${JourneyStatus}`);
            bankJSONRequest = new SIDBIRejectedStatusUpdateRequest("1", ClientID, PMSNumber, JourneyStatus);
          }
          logger.info("######################################################################");
          logger.info(`SIDBI JSON Request: ${JSON.stringify(bankJSONRequest)} For Sataus: ${JourneyStatus}`);
          logger.info("######################################################################");
          //Insert Error Log
          logError.APIRequestResponseLogs(PMSNumber, JourneyID, "SIDBI_Sanction_Disbursement_Rejection_" + JourneyStatus, JSON.stringify(bankJSONRequest), JSON.stringify(bankJSONRequest), null, null, null, "Insert").then(async (APILogsResp) => {
            logger.info("Insert ErrorCode " + APILogsResp.ErrorCode)
            if (APILogsResp.ErrorCode == "00") {
              const Emptybody = `Call SIDBI API for Update Customer Journey Status: ${JourneyStatus}`;

             // await sidbiClient.post(APIURL, bankJSONRequest, { httpsAgent: ProxyAgent }).then(async SIDBIStatusAPIResp => {
                     await sidbiClient.post(APIURL, bankJSONRequest, { httpsAgent: agent }).then(async SIDBIStatusAPIResp => {
                if (JSON.stringify(SIDBIStatusAPIResp.data, null, 2) != null)//
                {
                  //logger.info("SIDBI JSON Response: "+JSON.stringify(SIDBIStatusAPIResp.data, null, 2))
                  // // Parse the JSON string
                  logError.APIRequestResponseLogs(PMSNumber, JourneyID, null, null, null, JSON.stringify(SIDBIStatusAPIResp.data), JSON.stringify(SIDBIStatusAPIResp.data), APILogsResp.RequestId, "Update").then(async (APILogsResp) => {
                    logger.info("Update ErrorCode in CallSIDBI_SanctionedOrDisbursedStatusAPI " + APILogsResp.ErrorCode)
                    if (APILogsResp.ErrorCode == "00") {
                      const data = JSON.parse(JSON.stringify(SIDBIStatusAPIResp.data, null, 2));
                      logger.info(`SIDBI Response ${JSON.stringify(data)}`)

                      if (data.response && Array.isArray(data.response.applications) && data.response.applications.length > 0) {
                        logger.info(`Yaha Pauch Gaya`);
                        if (data.response.applications[0].application_Status.statusCode == "Y")//Success Response
                        {
                          StatusAPIResponse = {
                            "ErrorCode": "00",
                            "ErrorMsg": data.response.applications[0].application_Status.statusMsg,
                            "StatusCode": data.response.applications[0].application_Status.statusCode
                          }
                          logger.info('1. Taken Actionafter SIDBI Response' + JSON.stringify(StatusAPIResponse));
                          resolve(StatusAPIResponse);
                        }
                        else if (data.response.applications[0].application_Status.statusCode == "N" && data.response.applications[0].error_Details.ErrorCode == "92")//Success Response for Sanctioned/Disburesment
                        {
                          StatusAPIResponse = {
                            "ErrorCode": "00",
                            "ErrorMsg": data.response.applications[0].error_Details.ErrorMessage,
                            "StatusCode": data.response.applications[0].application_Status.statusCode
                          }
                          logger.info('2. Taken Actionafter SIDBI Response' + JSON.stringify(StatusAPIResponse));
                          resolve(StatusAPIResponse);
                        }
                        else if (data.response.applications[0].application_Status.statusCode == "N" && data.response.applications[0].error_Details.ErrorCode == "52")//Success Response for Reject Mark
                        {
                          StatusAPIResponse = {
                            "ErrorCode": "00",
                            "ErrorMsg": data.response.applications[0].error_Details.ErrorMessage,
                            "StatusCode": data.response.applications[0].application_Status.statusCode
                          }
                          logger.info('3. Taken Actionafter SIDBI Response' + JSON.stringify(StatusAPIResponse));
                          resolve(StatusAPIResponse);
                        }
                        else if (data.response.applications[0].application_Status.statusCode == "N" && data.response.applications[0].error_Details.ErrorCode == "60")//Success Response for Reject Mark
                        {
                          StatusAPIResponse = {
                            "ErrorCode": "00",
                            "ErrorMsg": data.response.applications[0].error_Details.ErrorMessage,
                            "StatusCode": data.response.applications[0].application_Status.statusCode
                          }
                          logger.info('4. Taken Actionafter SIDBI Response' + JSON.stringify(StatusAPIResponse));
                          resolve(StatusAPIResponse);
                        }
                        else {
                          if (data.response.applications[0].error_Details != null) {
                            StatusAPIResponse = {
                              "ErrorCode": "01",
                              "ErrorMsg": JSON.stringify(data.response.applications[0].error_Details),
                              "StatusCode": data.response.applications[0].application_Status.statusCode
                            }
                            logger.info('5. Taken Actionafter SIDBI Response' + JSON.stringify(StatusAPIResponse));
                            resolve(StatusAPIResponse);
                          }
                        }
                      }
                    }
                  });
                }
                else {
                  resp = {
                    "ErrorCode": "01",
                    "ErrorMsg": "Error during SIDBI API Call"
                  }
                  resolve(resp);
                }
              })
                .catch(error => {
                  console.error('Error posting to SIDBI API for SanctionedOrDisbursedStatus:', error);
                  // console.error('Error Loan Status Inquiry API Error Response:',error.response);
                  // console.error('Error Loan Status Inquiry API Error Response Text:',error.response.statusText);
                  // console.error('Error Loan Status Inquiry API Error Response data:',error.response.data);
                  logError.ErrorLogs(PMSNumber, JourneyID, error.response.status, error.response.statusText, "CallSIDBI_SanctionedOrDisbursedStatusAPI").then(async (ErrorLogResp) => {
                    ExceptionResp = {
                      "ErrorCode": "01",
                      "ErrorMsg": "System error occurred. Please retry after sometime or contact your branch for further assistance",
                    }
                    resolve(ExceptionResp);
                  })
                });
            }
          });
        });  //End Get Branch Information Data  
      }); //End Get Customer Journey         
    } catch (err1) {
      logger.info('Exception err1: ', +err1);
      //reject(err1);
	   resolve({ "ErrorCode": "01", "ErrorMsg": "System exception occurred. Please retry after sometime or contact your branch for further assistance" });
    }
  });
}

class SIDBISanctionedStatusRequest {
  constructor(apiVersion, clientId, pmsApplicationNo, JourneyStatus, RespBranchInformation, RespCustomerJourneyData, IsDisbursedRequest) {
    this.header = {
      apiVersion: apiVersion,
      clientID: clientId,
      timeStamp: this.getEpochTimestamp()
    };
    this.request = {
      applications: [
        {
          application_No: pmsApplicationNo,
          portal_RefNo: pmsApplicationNo,
          loan_Account_No: "",
          bankName: "",
          branchName: "",
          ifsc: "",
          accountNo: "",
          paymentAggregatorCode: "",
          upiid: "",
          dP1QRCode: "",
          //sanctionDate: JSON.parse(RespCustomerJourneyData).JourneySanctionedDate.toString("dd/mm/yyyy"),
//		  sanctionDate: JSON.parse(RespCustomerJourneyData).JourneySanctionedDate,
		  sanctionDate: new Date().toLocaleDateString('en-GB'),

          sanctionAmount: JSON.parse(RespCustomerJourneyData).LoanAmount,
          disbursementDate: "",
          disbursementAmt: "",
          // loan_Tenure:JSON.parse(RespCustomerJourneyData).LoanTenure,
          interestRate: "",//JSON.parse(RespCustomerJourneyData).ROI
          IsDisbursedRequest: "N",
          SanctioningBranchIFSC: JSON.parse(RespBranchInformation).IFSC
        }
      ],
      rejectionReasonTypeCode: JourneyStatus,
      otherReason: "Test Reason"
    };
  }

  getEpochTimestamp() {
    return Math.floor(Date.now() / 1000); // Returns the timestamp in seconds
  }

  toJSON() {
    return {
      header: this.header,
      request: this.request
    };
  }
}

class SIDBIDisbursedStatusRequest {
  constructor(apiVersion, clientId, pmsApplicationNo, JourneyStatus, RespBranchInformation, RespCustomerJourneyData) {
    this.header = {
      apiVersion: apiVersion,
      clientID: clientId,
      timeStamp: this.getEpochTimestamp()
    };
    this.request = {
      applications: [
        {
          application_No: pmsApplicationNo,
          portal_RefNo: pmsApplicationNo,
          loan_Account_No: "",
          bankName: "",
          branchName: "",
          ifsc: "",
          accountNo: "",
          paymentAggregatorCode: "",
          upiid: "",
          dP1QRCode: "",
          sanctionDate: JSON.parse(RespCustomerJourneyData).JourneySanctionedDate.toString("dd/mm/yyyy"),
          sanctionAmount: JSON.parse(RespCustomerJourneyData).LoanAmount,
          disbursementDate: "",
          disbursementAmt: "",
          // loan_Tenure:JSON.parse(RespCustomerJourneyData).LoanTenure,
          interestRate: "",//JSON.parse(RespCustomerJourneyData).ROI
          IsDisbursedRequest: "Y",
          SanctioningBranchIFSC: JSON.parse(RespBranchInformation).IFSC
        }
      ],
      rejectionReasonTypeCode: JourneyStatus,
      otherReason: "Test Reason"
    };
  }

  getEpochTimestamp() {
    return Math.floor(Date.now() / 1000); // Returns the timestamp in seconds
  }

  toJSON() {
    return {
      header: this.header,
      request: this.request
    };
  }
}

class SIDBIRejectedStatusUpdateRequest {
  constructor(apiVersion, clientId, pmsApplicationNo, JourneyStatus) {
    this.header = {
      apiVersion: apiVersion,
      clientID: clientId,
      timeStamp: this.getEpochTimestamp()
    };
    this.request = {
      applicationNumber: [
        {
          applicationNo: pmsApplicationNo
        }
      ],
      rejectionReasonTypeCode: JourneyStatus,
      otherReason: ""
    };
  }

  getEpochTimestamp() {
    return Math.floor(Date.now() / 1000); // Returns the timestamp in seconds
  }

  toJSON() {
    return {
      header: this.header,
      request: this.request
    };
  }
}

// async function GetKeyConfigurationValue(KeyName) {
  // logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);
  // const query = `SELECT [KeyValue] FROM [dbo].[SVND_CONFIGURATION_DATA] WHERE KeyName=@KeyName`;

  // try {
    // const pool = await sql.connect(config);
    // //logger.info('Connected to the database');

    // const result = await pool.request()
      // .input('KeyName', sql.VarChar, KeyName)
      // .query(query);

    // if (result.recordset.length > 0) {

      // const jsonString = JSON.stringify(result.recordset, null, 2);
      // formattedString = jsonString.slice(1, -1);
      // //  logger.info('Result: ',formattedString);               
      // //  logger.info('Parse Result: ',JSON.parse(formattedString));
      // const OutValue = JSON.parse(formattedString).KeyValue;
      // //  logger.info('OutValue', OutValue.toString());
      // return JSON.parse(formattedString).KeyValue; // Return the formatted string
    // } else {
      // logger.info('No results found for the provided KeyName.');
      // return null;
    // }
  // } catch (err) {
    // console.error('Error:', err);
    // return null;
  // } finally {
    // await sql.close(); // Ensure the connection is closed
  // }
// }


async function GetKeyConfigurationValue(KeyName) {
  logger.info('**********************************Inside GetKeyConfigurationValue Method for KeyName ' + KeyName);

  const query = `
    SELECT [KeyValue]
    FROM [dbo].[SVND_CONFIGURATION_DATA]
    WHERE KeyName = @KeyName
  `;

  try {
    const pool = await getPool();
    const request = pool.request();

    const result = await request
      .input('KeyName', sql.VarChar, KeyName)
      .query(query);

    if (result.recordset && result.recordset.length > 0) {
      const value = result.recordset[0].KeyValue;
      logger.info('KeyValue fetched: ' + value);
      return value;
    } else {
      logger.info('No results found for the provided KeyName.');
      return null;
    }

  } catch (err) {
    logger.error('GetKeyConfigurationValue Error:', err);
    return null;
  }
}




module.exports = { CallSIDBICurrentStatusAPI, CallSIDBI_SanctionedOrDisbursedStatusAPI };