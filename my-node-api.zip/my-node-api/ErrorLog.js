// ErrorLog.js

const express = require("express");
const axios = require('axios');
//const sql = require("mssql");
const app = express();
app.use(express.json())
var cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');

const winston = require('winston');
const path = require('path')
const { sql, getPool } = require('./db');

app.use(cors());// Allows cross-origin requests
app.use(bodyParser.json({ limit: '50mb' }));

//const logger = require('./logger'); // Adjust the path as necessary
const getLogger = require('./logger');
const logger = getLogger('ErrorLogs');

// Set up cookie parser middleware
app.use(cookieParser());
// SQL Server configuration
// var config = {
//     user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,    
//   },
//   strictSSL: false, // Set to false to disable strict SSL/TLS checking  
//   pool: {
//     max: 10,
//     min: 0,
//     idleTimeoutMillis: 30000
//   },
//   "options": {
//     "encrypt": false
//   }
// }


 var config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};




// function ErrorLogs(PMSNumber,JourneyID,ErrorCode, ErrorMessage,LogStage) {

    // logger.info('Inside ErrorLogs ErrorCode: ' +ErrorCode);
    // logger.info('Inside ErrorLogs ErrorMessage: ' + ErrorMessage);
    // return new Promise((resolve, reject) => {
      // try {          
              // const query = `INSERT INTO SVND_ERROR_LOG([PMSNumber],[JourneyID],[ErrorCode],[ErrorDescription],[LoggingStage]) VALUES(@PMSNumber,@JourneyID,@ErrorCode,@ErrorDescription,@LogStage)`;
              // var conn = new sql.ConnectionPool(config);
              // conn.connect().then(async function (pool) 
              // {      
                // logger.info('Query: ' + query);                           
                // const result = await pool.request()
                // .input('PMSNumber', sql.VarChar, PMSNumber)
                // .input('JourneyID', sql.VarChar, JourneyID)
                // .input('ErrorCode', sql.VarChar, ErrorCode.toString())
                // .input('ErrorDescription', sql.Text, ErrorMessage)
                // .input('LogStage', sql.VarChar, LogStage)
                // .query(query);                
                // if(result.recordsets && result.rowsAffected[0]==1)
                // {
                   // logger.info("Success");
                 
                  // response={
                    // "ErrorCode":"00",
                    // "ErrorMsg":"Data Saved success"
                  // }
                 // resolve(response);              
                // }
                // else{
                  // logger.info("Failed");

                  // response={
                    // "ErrorCode":"01",
                    // "ErrorMsg":"Data Saved failed"
                  // }
                  // resolve(response);
                // }
              // });            
          // } catch (err1) {
            // logger.info(err1);
            // reject(err1);
          // }
    // });  
  // }

function ErrorLogs(PMSNumber, JourneyID, ErrorCode, ErrorMessage, LogStage) {

  logger.info('Inside ErrorLogs ErrorCode: ' + ErrorCode);
  logger.info('Inside ErrorLogs ErrorMessage: ' + ErrorMessage);

  return new Promise(async (resolve, reject) => {
    try {
      const query = `
        INSERT INTO SVND_ERROR_LOG
        ([PMSNumber],[JourneyID],[ErrorCode],[ErrorDescription],[LoggingStage])
        VALUES
        (@PMSNumber,@JourneyID,@ErrorCode,@ErrorDescription,@LogStage)
      `;

      const pool = await getPool();
      const result = await pool.request()
        .input('PMSNumber', sql.VarChar, PMSNumber)
        .input('JourneyID', sql.VarChar, JourneyID)
        .input('ErrorCode', sql.VarChar, ErrorCode.toString())
        .input('ErrorDescription', sql.Text, ErrorMessage)
        .input('LogStage', sql.VarChar, LogStage)
        .query(query);

      if (result.rowsAffected && result.rowsAffected[0] === 1) {
        logger.info('Error log saved successfully');
        resolve({
          ErrorCode: "00",
          ErrorMsg: "Data Saved success"
        });
      } else {
        logger.info('Error log insert failed');
        resolve({
          ErrorCode: "01",
          ErrorMsg: "Data Saved failed"
        });
      }

    } catch (err) {
      logger.error('ErrorLogs DB Error', err);
      reject(err);
    }
  });
}


  // function APIRequestResponseLogs(PMSNumber,JourneyID,APIName,PlainRequest,EncRequest,PlainResponse,EncResponse,RequestId,Operation) {
    // logger.info('*****************Inside APIRequestResponseLogs for '+APIName+' ((Start)) *****************');
    // // logger.info('*****************Inside APIRequestResponseLogs Method *****************');
    // // logger.info('PMS Number: ' +PMSNumber);
    // // logger.info('JourneyID: ' + JourneyID);
    // // logger.info('Operation: ' + Operation);
    // if(Operation=="Update")
    // {
      // logger.info('RequestId: ' +RequestId);
      // logger.info('RequestId: HELLO');
    // }   
    
    // return new Promise((resolve, reject) => {
      // try {
           // var conn = new sql.ConnectionPool(config);
           // conn.connect().then(function (pool) 
           // { 
              // var request = new sql.Request(pool); // Create a new request object for every row insert
              // request.input('PMSNumber', sql.VarChar, PMSNumber);
              // request.input('JourneyID', sql.VarChar, JourneyID);
              // request.input('APIName', sql.VarChar, APIName);                  
              // request.input('PlainRequest', sql.Text, PlainRequest);
              // request.input('EncRequest', sql.Text, EncRequest);              
              // request.input('PlainResponse', sql.Text, PlainResponse);
              // request.input('EncResponse', sql.Text, EncResponse);
              // request.input('RequestId', sql.VarChar, RequestId);
              // request.input('Operation', sql.VarChar, Operation);
              // request.output('p_Output', sql.VarChar) // Define output parameter             
              // request.execute('proc_API_RequestResponseLogs',function(err ,queryResult){
              // logger.info('queryResult '+JSON.stringify(queryResult));
			  // logger.info('hello');
              // //logger.info('Error '+err);             
              // if(queryResult.rowsAffected[0]>0)
              // {
                  // formattedString={
                    // "ErrorCode":"00",
                    // "ErrorMsg":"API Request-Response data successfully saved",
                    // "RequestId":queryResult.output.p_Output
                  // }
                  // logger.info('*****************Inside APIRequestResponseLogs '+APIName+' ((End)) *****************');
                  // resolve(formattedString);
              // }
                // else{
                 // //logger.info('else:'+err); 
                  // formattedString={
                    // "ErrorCode":"01",
                    // "ErrorMsg":"Error to update Customer Journey.",
                    // "RequestId":""
                  // }
                  // logger.info('*****************Inside APIRequestResponseLogs '+APIName+' ((End)) *****************');
                  // resolve(formattedString);
              // }
              // });          
            // });           
          // } catch (err1) {
            // logger.info(err1);
            // reject(err1);
          // }
    // });  
  // }
  
  
// function APIRequestResponseLogs(
  // PMSNumber,
  // JourneyID,
  // APIName,
  // PlainRequest,
  // EncRequest,
  // PlainResponse,
  // EncResponse,
  // RequestId,
  // Operation
// ) {
  // logger.info('*****************Inside APIRequestResponseLogs for ' + APIName + ' ((Start)) *****************');

  // if (Operation === "Update") {
    // logger.info('RequestId: ' + RequestId);
    // logger.info('RequestId: HELLO');
  // }

  // return new Promise((resolve, reject) => {
    // let conn;

    // try {
      // conn = new sql.ConnectionPool(config);

      // conn.connect()
        // .then(pool => {
          // const request = new sql.Request(pool);

          // request.input('PMSNumber', sql.VarChar, PMSNumber);
          // request.input('JourneyID', sql.VarChar, JourneyID);
          // request.input('APIName', sql.VarChar, APIName);
          // request.input('PlainRequest', sql.Text, PlainRequest);
          // request.input('EncRequest', sql.Text, EncRequest);
          // request.input('PlainResponse', sql.Text, PlainResponse);
          // request.input('EncResponse', sql.Text, EncResponse);
          // request.input('RequestId', sql.VarChar, RequestId);
          // request.input('Operation', sql.VarChar, Operation);
          // request.output('p_Output', sql.VarChar);

		// const debugSql = `
		// EXEC proc_API_RequestResponseLogs
		  // @PMSNumber     = '${PMSNumber || ''}',
		  // @JourneyID     = '${JourneyID || ''}',
		  // @APIName       = '${APIName || ''}',
		  // @PlainRequest  = ${PlainRequest ? `'${PlainRequest.replace(/'/g, "''")}'` : 'NULL'},
		  // @EncRequest    = ${EncRequest ? `'${EncRequest.replace(/'/g, "''")}'` : 'NULL'},
		  // @PlainResponse = ${PlainResponse ? `'${PlainResponse.replace(/'/g, "''")}'` : 'NULL'},
		  // @EncResponse   = ${EncResponse ? `'${EncResponse.replace(/'/g, "''")}'` : 'NULL'},
		  // @RequestId     = '${RequestId || ''}',
		  // @Operation     = '${Operation || ''}',
		  // @p_Output      = NULL OUTPUT
		// `;
		// //logger.info('DEBUG SQL (Re-runnable in SSMS):\n' + debugSql);

          // request.execute('proc_API_RequestResponseLogs', function (err, queryResult) {
            // try {
              // if (err) {
                // logger.error('proc_API_RequestResponseLogs Error: ' + err.message);
                // return reject(err);
              // }

              // logger.info('queryResult ' + JSON.stringify(queryResult));
              // logger.info('AFTER QUERY RESULT - STILL ALIVE');

              // let formattedString;

              // if (queryResult.rowsAffected && queryResult.rowsAffected[0] > 0) {
                // formattedString = {
                  // "ErrorCode": "00",
                  // "ErrorMsg": "API Request-Response data successfully saved",
                  // "RequestId": queryResult.output.p_Output
                // };
              // } else {
                // formattedString = {
                  // "ErrorCode": "01",
                  // "ErrorMsg": "Error to update Customer Journey.",
                  // "RequestId": ""
                // };
              // }

              // logger.info('BEFORE RESOLVE');
              // resolve(formattedString);
              // logger.info('AFTER RESOLVE');

              // logger.info('*****************Inside APIRequestResponseLogs ' + APIName + ' ((End)) *****************');
            // } catch (cbEx) {
              // logger.error('Callback Fatal Error: ' + cbEx.message);
              // reject(cbEx);
            // }
          // });
        // })
        // .catch(connErr => {
          // logger.error('DB Connection Error: ' + connErr.message);
          // reject(connErr);
        // });

    // } catch (err1) {
      // logger.error('APIRequestResponseLogs Fatal Error: ' + err1.message);
      // reject(err1);
    // }
  // });
// }


function APIRequestResponseLogs(
  PMSNumber,
  JourneyID,
  APIName,
  PlainRequest,
  EncRequest,
  PlainResponse,
  EncResponse,
  RequestId,
  Operation
) {
  logger.info(
    '*****************Inside APIRequestResponseLogs for ' + APIName + ' ((Start)) *****************'
  );

  if (Operation === "Update") {
    logger.info('RequestId: ' + RequestId);
  }

  return new Promise(async (resolve, reject) => {
    try {
      const pool = await getPool();
      const request = pool.request();

      request.input('PMSNumber', sql.VarChar, PMSNumber);
      request.input('JourneyID', sql.VarChar, JourneyID);
      request.input('APIName', sql.VarChar, APIName);
      request.input('PlainRequest', sql.Text, PlainRequest);
      request.input('EncRequest', sql.Text, EncRequest);
      request.input('PlainResponse', sql.Text, PlainResponse);
      request.input('EncResponse', sql.Text, EncResponse);
      request.input('RequestId', sql.VarChar, RequestId);
      request.input('Operation', sql.VarChar, Operation);
      request.output('p_Output', sql.VarChar);

      const result = await request.execute('proc_API_RequestResponseLogs');

      logger.info('queryResult ' + JSON.stringify(result));

      if (result.rowsAffected && result.rowsAffected[0] > 0) {
        resolve({
          ErrorCode: "00",
          ErrorMsg: "API Request-Response data successfully saved",
          RequestId: result.output.p_Output
        });
      } else {
        resolve({
          ErrorCode: "01",
          ErrorMsg: "Error to update API request-response log.",
          RequestId: ""
        });
      }

      logger.info(
        '*****************Inside APIRequestResponseLogs ' + APIName + ' ((End)) *****************'
      );

    } catch (err) {
      logger.error('APIRequestResponseLogs Error', err);
      reject(err);
    }
  });
}



  
  
  module.exports = { ErrorLogs,APIRequestResponseLogs };