// db.js
const sql = require('mssql');

/**
 * SQL Server configuration
 */
// const config = {
//   user: 'svanidhiuser',
//   password: 'Dbtd@12345678',
//   server: '10.192.244.43',
//   port: 7701,
//   database: 'PMSvanidhiDB',
//   extra: {
//     trustServerCertificate: false,
//   },
//   strictSSL: false,
//   pool: {
//     max: 50,
//     min: 1,
//     idleTimeoutMillis: 60000
//   },
//   options: {
//     encrypt: false
//   }
// };

const config = {
  user: 'nodejsuser',
  password: 'Pnb@12345',
  server: '10.192.236.6',
  port: 1434,
  database: 'PMSvanidhiDB',
   extra: {
    trustServerCertificate: false,
  },
  strictSSL: false,
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
   
  },
};












let pool;
let poolConnecting = false;

/**
 * Returns a shared SQL connection pool.
 * Handles race conditions and reconnects safely.
 */
async function getPool() {
  try {
    // Pool exists and is connected
    if (pool && pool.connected) {
      return pool;
    }

    // Prevent parallel reconnect attempts
    if (poolConnecting) {
      await new Promise(resolve => setTimeout(resolve, 100));
      return getPool();
    }

    poolConnecting = true;

    // Close old/broken pool if exists
    if (pool) {
      try {
        await pool.close();
      } catch (e) {
        console.error('Error closing existing pool:', e.message);
      }
    }

    pool = new sql.ConnectionPool(config);
    await pool.connect();

    poolConnecting = false;
    return pool;

  } catch (err) {
    poolConnecting = false;
    console.error('DB Pool connection failed:', err);
    throw err;
  }
}

module.exports = {
  sql,
  getPool
};
